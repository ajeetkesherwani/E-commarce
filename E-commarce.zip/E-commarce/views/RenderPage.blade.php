<x-app-layout>
    @section('meta_info')
        <title>{{ isset($data['meta_info']['seometa_title']) ? $data['meta_info']['seometa_title'] : '' }}</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="{{ isset($data['meta_info']['seometa_title']) ? $data['meta_info']['seometa_title'] : '' }}" name="keywords">
        <meta content="{{ isset($data['meta_info']['seometa_desc']) ? $data['meta_info']['seometa_desc'] : '' }}" name="description">
        {{-- OG Meta --}}
        <meta property="og:title" content="{{ isset($data['meta_info']['seometa_title']) ? $data['meta_info']['seometa_title'] : '' }}"/>
	    <meta property="og:type" content="website" />
	    <meta property="og:url" content="{{URL::current()}}" />
	    <meta property="og:image" content="{{ isset($data['meta_info']['product_image']) ? getFullImageUrl($data['meta_info']['product_image']) : getImageUrlWithKey('website_logo') }}" />
	    <meta name="twitter:card" content="summary" />
	    <meta name="twitter:site" content="{{ getSetting('site_title')}}" />
	    <meta name="twitter:title" content="{{ isset($data['meta_info']['seometa_title']) ? $data['meta_info']['seometa_title'] : '' }}" />
	    <meta name="twitter:description" content="{{ isset($data['meta_info']['seometa_desc']) ? $data['meta_info']['seometa_desc'] : '' }}" />
	    <meta name="twitter:image" content="{{ isset($data['meta_info']['product_image']) ? getFullImageUrl($data['meta_info']['product_image']) : getImageUrlWithKey('website_logo') }}" />
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    @endsection
        <x-dynamic-component :component="$activeTheme" :data="$data" class="mt-4" />

</x-app-layout>
