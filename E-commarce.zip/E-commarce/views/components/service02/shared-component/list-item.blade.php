
@php
use App\Models\Listing\Services\ListService;
@endphp

<div class="col-lg-3 col-md-6 col-12">
    <div class="card features feature-primary feature-clean explore-feature p-4 px-md-3 border-0 rounded-md shadow text-center">
            <img src="{{getFullImageUrl($listing->listing_image)}}" alt="service-listing" class="h-100">


        <div class="card-body p-0 content">
            <h5 class="mt-4"><a href="javascript:void(0)" class="title text-dark">{{$listing->listing_name ?? ''}}</a></h5>
            <p class="text-muted">{!! Str::limit($listing->listing_description ?? '',100) !!}</p>

            <a href="{{ListService::url($listing->listing_id , 'listing')}}" class="read-more">Read More <i class="uil uil-angle-right-b align-middle"></i></a>
        </div>
    </div>
</div><!--end col-->

                         

