<!-- favicon -->
<link rel="shortcut icon" href="{{ LoadAssets('assets/images/favicon.ico') }}" />
<!-- Css -->
<link href="{{ LoadAssets('assets/libs/tiny-slider/tiny-slider.css') }}" rel="stylesheet">
<link href="{{ LoadAssets('assets/libs/swiper/css/swiper.min.css') }}" rel="stylesheet">
<link href="{{ LoadAssets('assets/libs/tobii/css/tobii.min.css') }}" rel="stylesheet">
<!-- Bootstrap Css -->
<link href="{{ LoadAssets('assets/css/bootstrap.min.css') }}" class="theme-opt" rel="stylesheet" type="text/css" />
<!-- Icons Css -->
<link href="{{ LoadAssets('assets/css/icons.min.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ LoadAssets('assets/libs/@iconscout/unicons/css/line.css') }}" type="text/css" rel="stylesheet" />
<!-- Style Css-->
<link href="{{ LoadAssets('assets/css/style.min.css') }}" class="theme-opt" rel="stylesheet" type="text/css" />



<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800&display=swap"
    rel="stylesheet" />
<link rel="stylesheet" href="https://fonts.sandbox.google.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
