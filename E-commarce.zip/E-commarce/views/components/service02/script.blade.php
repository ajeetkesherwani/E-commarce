<!-- Back to top -->
        <a href="#" onclick="topFunction()" id="back-to-top" class="back-to-top fs-5"><i data-feather="arrow-up" class="fea icon-sm icons align-middle"></i></a>
        <!-- Back to top -->

        <!-- javascript -->
        <!-- JAVASCRIPT -->
        <script src="{{ LoadAssets('assets/libs/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
        <script src="{{ LoadAssets('assets/libs/feather-icons/feather.min.js') }}"></script>
        <!-- SLIDER -->
        <script src="{{ LoadAssets('assets/libs/tiny-slider/min/tiny-slider.js') }}"></script>
        <script src="{{ LoadAssets('assets/libs/swiper/js/swiper.min.js') }}"></script>
        <!-- Lightbox -->
        <script src="{{ LoadAssets('assets/libs/tobii/js/tobii.min.js') }}"></script>
        <!-- Main Js -->
        <script src="{{ LoadAssets('assets/js/plugins.init.js') }}"></script><!--Note: All init js like tiny slider, counter, countdown, maintenance, lightbox, gallery, swiper slider, aos animation etc.-->
        <script src="{{ LoadAssets('assets/js/app.js') }}"></script><!--Note: All important javascript like page loader, menu, sticky menu, menu-toggler, one page menu etc. -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

   <!-- // toastify -->
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
<script>

function Notify(msg, status) {
        Toastify({
            text: msg,
            className: "info",
            duration: 2000,
            close: true,
            gravity: "bottom", // `top` or `bottom`
            position: "right", // `left`, `center` or `right`
            style: {
                background: status ? "green" : "red",
            }
        }).showToast();

    }

$(".customFrom").on('submit',function(e){
    e.preventDefault();
    let formData = $(this).serialize();
   
    /*Ajax Request Header setup*/
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $.ajax({
        url: "{{ route('customFormSubmit')}}",
        method: 'post',
        data: formData,
        success: function(response){
            if(response.status == 0){
                 $.each(response.message, function(i, v) {
                    console.log('#erro_'+i);
                    //$('.result').append(v); 
                    $('#'+i+'-error').html(v);
                });
            } else{
                $('.result').append(response.message);
                Notify('Data send successfully',true);
                $('.customFrom').trigger("reset");
            }
        },

    });

});

</script>

@if(getsetting('newsletter_popup')=='yes')
@if(empty(Cache::get("loaditem")))
<script>

    window.onload = function showNewsLatter() {
        $.ajax({
            url: "/onloadnewslatter",
            success: function (response) {
                $(".newsmodal").html(response);
                $('#onloadModal').modal('show');
            },
            error: function (error) {
                
            },
        });
    }

</script>
@endif
@endif

