
<!-- Navbar Start -->
<header id="topnav" class="defaultscroll sticky">
    <div class="container">
        <!-- Logo container-->
        <div>
            <a class="logo" href="{{url('/')}}">
            <span class="logo-light-mode">
          
                <img src="{{ getImageUrlWithKey('website_logo') }}" class="l-dark" height="24" alt="logo">
                <img src="{{ getImageUrlWithKey('website_logo') }}" class="l-light" height="24" alt="logo">
            </span>
        </a>
        </div>


        <!-- End Logo container-->
        <div class="menu-extras">
            <div class="menu-item">
                <!-- Mobile menu toggle-->
                <a class="navbar-toggle" id="isToggle" onclick="toggleMenu()">
                    <div class="lines">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </a>
                <!-- End mobile menu toggle-->
            </div>
        </div>

        {{-- <!--Login button Start-->
        <ul class="buy-button list-inline mb-0">
            <li class="list-inline-item mb-0">
                <a href="javascript:void(0)" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight">
                    <div class="login-btn-primary"><span class="btn btn-icon btn-pills btn-soft-primary"><i data-feather="settings" class="fea icon-sm"></i></span></div>
                    <div class="login-btn-light"><span class="btn btn-icon btn-pills btn-light"><i data-feather="settings" class="fea icon-sm"></i></span></div>
                </a>
            </li>   
            
        </ul>
        <!--Login button End--> --}} 

        <div id="navigation">
            <!-- Navigation Menu-->   
            <ul class="navigation-menu nav-light">             
                @if(!empty($main_menu))
                @foreach($main_menu as $key=>$value)
                  @if(in_array($value->menu_type, array('1','2','4')) && isset($value->menulist) )
                    <li class="has-submenu parent-menu-item {{$value->menu_ref_id==0 ? 'has-submenu parent-menu-item': '' }}"  >
                      <a href="javascript:void(0)" >{{$value->menu_name}}</a><span class="menu-arrow"></span>
                        @if(!empty($value->menulist))
                        <ul class="submenu">
                            @foreach($value->menulist as $cmenu)
                              @if(!empty($cmenu['title']))
                                <li class="has-submenu parent-menu-item">
                                  <a href="{{ $cmenu['link']  }}" class="has-submenu parent-menu-item">{{ $cmenu['title'] }}</a><span class="submenu-arrow"></span>
                                  @if(!empty($cmenu['subcate']))
                                    <ul class="submenu">
                                      @foreach($cmenu['subcate'] as $smenu)
                                        <li class="menu-dropdown position-static"><a href="{{ $smenu['link'] }}" class="sub-menu-item" >{{ $smenu['title'] }}</a>  
                                        </li>
                                      @endforeach
                                    </ul>
                                  @endif
                                </li><!-- /.nav-item -->
                              @endif
                            @endforeach
                        </ul><!-- /.dropdown-menu -->
                        @endif
                    </li><!-- /.nav-item -->
                  @else
                    <li class="nav__item"><a  class=" nav__item-link" href="{{$value->menu_link}}" >{{$value->menu_name}}</a></li>
                  @endif              
                @endforeach
              @endif

               <li class="nav__item"><a  class=" nav__item-link" href="{{url('/plans')}}" >Plans</a></li>
              <li class="nav__item"><a  class=" nav__item-link" href="{{url('/login')}}" >My Account</a></li>
              
               @if(empty($allServiceCategory))
              <li class="has-submenu parent-menu-item">
                <a href="#" data-toggle="dropdown" class="has-submenu parent-menu-item">Services Categories</a><span class="submenu-arrow"></span>
                <ul class="submenu">
                  @foreach($allServiceCategory as $serviveKey=>$Services)                  
                  <li class="has-submenu parent-menu-item">
                    <a href="{{route('categorySlug',['slug'=>$Services->categories_slug])}}" class="nav__item-link">{{$Services->category_name}}</a>
                  </li><!-- /.nav-item -->
                  @endforeach
                </ul><!-- /.dropdown-menu -->
              </li><!-- /.nav-item -->
              @endif
            </ul><!--end navigation menu-->

            
        </div><!--end navigation-->
    </div><!--end container-->
</header><!--end header-->
<!-- Navbar End -->