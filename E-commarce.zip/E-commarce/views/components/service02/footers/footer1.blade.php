<!-- Footer Start -->
        <!-- Footer Start -->
        <footer class="footer">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12">
                        <div class="footer-py-60 text-left">
                            <div class="row">
                                {{-- <div class="col-md-4">
                                    <div class="card border-0 text-center features feature-primary feature-clean bg-transparent">
                                        <div class="icons text-center mx-auto">
                                            <i class="uil uil-phone d-block rounded h3 mb-0"></i>
                                        </div>
                                        <div class="content mt-4">
                                            <h5 class="footer-head">Phone</h5>
                                            <p class="text-muted">Start working with Landrick that can provide everything</p>
                                            <a href="tel:+152534-468-854" class="text-foot">{{ getSetting('phone')}}</a>
                                        </div>
                                    </div>
                                </div><!--end col-->
                                 <div class="col-md-4 mt-4 mt-sm-0 pt-2 pt-sm-0">
                                    <div class="card border-0 text-center features feature-primary feature-clean bg-transparent">
                                        <div class="icons text-center mx-auto">
                                            <i class="uil uil-envelope d-block rounded h3 mb-0"></i>
                                        </div>
                                        <div class="content mt-4">
                                            <h5 class="footer-head">Email</h5>
                                            <p class="text-muted">Start working with Landrick that can provide everything</p>
                                            <a href="mailto:contact@example.com" class="text-foot">contact@example.com</a>
                                        </div>
                                    </div>
                                </div><!--end col-->                        
                                <div class="col-md-4 mt-4 mt-sm-0 pt-2 pt-sm-0">
                                    <div class="card border-0 text-center features feature-primary feature-clean bg-transparent">
                                        <div class="icons text-center mx-auto">
                                            <i class="uil uil-map-marker d-block rounded h3 mb-0"></i>
                                        </div>
                                        <div class="content mt-4">
                                            <h5 class="footer-head">Location</h5>
                                            <p class="text-muted">C/54 Northwest Freeway, Suite 558, <br>Houston, USA 485</p>
                                            <a href="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d39206.002432144705!2d-95.4973981212445!3d29.709510002925988!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8640c16de81f3ca5%3A0xf43e0b60ae539ac9!2sGerald+D.+Hines+Waterwall+Park!5e0!3m2!1sen!2sin!4v1566305861440!5m2!1sen!2sin"
                                                data-type="iframe" class="video-play-icon text-foot lightbox">View on Google map</a>
                                        </div>
                                    </div>
                                </div><!--end col--> --}}

                                 <div class="col-lg-3 col-12 mb-0 mb-md-4 pb-0 pb-md-2">
                                  <a href="{{url('/')}}" class="logo-footer"><img src="{{getImageUrlWithKey('website_logo')}}" alt="{{getSetting('site_title')}}-logo" height="50"/></a>
                                    <p class="mt-4">{{getSetting('footer_about_description') ?? ''}}</p>
                                    <ul class="list-unstyled social-icon foot-social-icon mb-0 mt-4">
                                      @if(!empty(socialLinks('facebook_url')))
                                        <li class="list-inline-item"><a href="{{getSetting('facebook_url')}}" target="_blank" class="rounded"><i data-feather="facebook" class="fea icon-sm fea-social"></i></a></li>
                                      @endif 
                                      @if(!empty(socialLinks('instagram_url')))
                                        <li class="list-inline-item"><a href="{{getSetting('instagram_url')}}" target="_blank" class="rounded"><i data-feather="instagram" class="fea icon-sm fea-social"></i></a></li>
                                      @endif
                                      @if(!empty(socialLinks('twitter_url')))  
                                        <li class="list-inline-item"><a href="{{getSetting('twitter_url')}}" target="_blank" class="rounded"><i data-feather="twitter" class="fea icon-sm fea-social"></i></a></li>
                                      @endif 
                                      @if(!empty(socialLinks('google_url')))  
                                        <li class="list-inline-item"><a href="{{getSetting('google_url')}}" target="_blank" class="rounded"><i data-feather="google" class="fea icon-sm fea-social"></i></a></li>
                                      @endif 
                                      @if(!empty(socialLinks('youtube_url')))
                                        <li class="list-inline-item"><a href="{{socialLinks('youtube_url')}}" target="_blank" class="rounded"><i data-feather="youtube" class="fea icon-sm fea-social"></i></a></li>
                                      @endif  
                                    </ul><!--end icon-->
                                </div><!--end col-->

                                <div class="col-lg-3 col-md-6 col-12 mt-4 mt-lg-0 pt-2 pt-lg-0">
                                    <h5 class="footer-head">{{translation('INFORMATION')}}</h5>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="foot-subscribe mb-3">
                                                  @if(!empty($footermenulist1))
                                                    <ul class="list-unstyled footer-list">
                                                          @foreach($footermenulist1 as $key=>$value) 
                                                        <li><a href="{{$value['link'] ?? ''}}" class="text-foot"><i class="uil uil-angle-right-b me-1"></i>{{$value['name'] ?? ''}}</a></li>
                                                        @endforeach
                                                    </ul>
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                </div><!--end col-->
                                <div class="col-lg-3 col-md-6 col-12 mt-4 mt-lg-0 pt-2 pt-lg-0">
                                    <h5 class="footer-head">{{translation('CUSTOM_LINKS')}}</h5>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="foot-subscribe mb-3">
                                                  @if(!empty($footermenulist2))
                                                    <ul class="list-unstyled footer-list">
                                                        @foreach($footermenulist2 as $footer2key=>$footer2value)
                                                        <li><a href="{{($footer2value['link'])}}" class="text-foot"><i class="uil uil-angle-right-b me-1"></i>{{$footer2value['name']}}</a></li>
                                                        @endforeach
                                                    </ul>
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                </div><!--end col-->

                                <div class="col-lg-3 col-md-6 col-12 mt-4 mt-lg-0 pt-2 pt-lg-0">
                                    <h5 class="footer-head">{{translation('NEWS_LETTER')}}</h5>
                                    <p class="mt-4">{!! getSetting('footer_newsletter_info') ?? '' !!}</p>
                                     <form id="newslatterform" class="validate" novalidate="" 
                                name="mc-embedded-subscribe-form" method="POST">
                                @csrf
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="foot-subscribe mb-3">
                                                    <label class="form-label">Write your email <span class="text-danger">*</span></label>
                                                    <div class="form-icon position-relative">
                                                        <i data-feather="mail" class="fea icon-sm icons"></i>
                                                        <input type="email" name="customer_email" class="form-control ps-5 rounded email" placeholder="{{translation('ENTER_YOUR_EMAIL_HERE')}}" value="" required>
                                                         <p class="text-danger mail_error" style="font-size:20px;"></p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="d-grid">
                                                 <input type="submit" id="mc-embedded-subscribe" name="subscribe" class="btn btn-soft-primary" value="{{translation('SIGN_UP')}}">
                                                 <input type="reset" hidden id="configreset" value="Reset">
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div><!--end col-->                      
                                
                            </div><!--end row-->
                        </div>
                    </div><!--end col-->
                </div><!--end row-->
            </div><!--end container-->

            <div class="footer-py-30 footer-bar bg-footer">
                <div class="container text-center">
                    <div class="row align-items-center justify-content-between">                                               
                               <div class="footer__copyrights">
                                    <span class="fz-14">{{$copyRightText ?? ''}}</span>
                                </div>
                    </div><!--end row-->
                </div><!--end container-->
            </div>
        </footer><!--end footer-->
        <!-- Footer End -->
        <!-- Footer End -->



@push('scripts')
<script>
    $(document).ready(function() {
        //alert('hello');
        $(document).on('click', '#mc-embedded-subscribe', function(e) {
          e.preventDefault();
          var data = {
            'customer_email': $('.email').val(),
          }
          //console.log(data);
          $.ajaxSetup({
            headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
          });
          $.ajax({
            type: "POST",
            url: "/newslatterstore",
            data :data,
            dataType:"json",
            success: function(response) {
             // console.log(response);
             if(response.status==400)
            {
                $('.mail_error').text(response.error.customer_email);  
              
            }
            else
            {   
                $('.email').val(),
                $('.mail_error').text(""); 
                Notify('Subscribed Successfully', true);
               $("#newslatterform").trigger("reset")
            }             
            }
           
          });
        });
    });

</script>
@endpush