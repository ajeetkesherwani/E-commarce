<!-- Login Form Start -->

<div class="modal fade" id="login-popup" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog  modal-lg modal-dialog-centered">
        <div class="modal-content rounded shadow border-0">
            <div class="modal-body p-0">
                <div class="modal-button">
                    <button type="button" class="btn btn-icon btn-close btn-close" data-bs-dismiss="modal" id="close-modal"><i
                            class="uil uil-times fs-4 text-dark"></i></button>
                </div>
                <div class="container-fluid px-0 sub" id="sublogin">
                    <div class="row align-items-center g-0">
                        <!--end col-->
                      <div class="row align-items-center g-0">
                        <div class="col-lg-6 col-md-5">
                            <img src="{{ LoadAssets('assets/images/user/login.svg')}}" class="img-fluid" alt="">
                        </div>
                        <!--end col-->

                        <div class="col-lg-6 col-md-7">
                            <h3 class="modal-title mt-2" id="LoginForm-title">Login</h3>
                            <form class="login-form p-4" id="login-modal-form">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="mb-3">
                                            <label class="form-label">Your Email <span
                                                    class="text-danger">*</span></label>
                                            <div class="form-icon position-relative">
                                                <i class="fa fa-user fea icon-sm icons" aria-hidden="true"></i>
                                                <input type="email" id="login_email" class="form-control ps-5"
                                                    placeholder="Email" name="email" required="">
                                            </div>

                                            <span class="text-danger" id="email-logerror"></span>
                                            @if ($errors->has('email'))
                                            <span class="text-danger">{{ $errors->first('email') }}</span>
                                            @endif

                                        </div>
                                    </div>
                                    <!--end col-->

                                    <div class="col-lg-12">
                                        <div class="mb-3">
                                            <label class="form-label">Password <span
                                                    class="text-danger">*</span></label>
                                            <div class="form-icon position-relative">
                                                <i class="fa fa-key fea icon-sm icons" aria-hidden="true"></i>
                                                <input type="password" name="password" id="login_Password"
                                                    class="form-control ps-5" placeholder="Password" required="">
                                            </div>

                                            <span class="text-danger" id="password-logerror"></span>
                                            @if ($errors->has('password'))
                                            <span class="text-danger">{{ $errors->first('password') }}</span>
                                            @endif

                                        </div>
                                    </div>
                                    <!--end col-->

                                    <span class="text-danger" id="invalid-creddential"></span>

                                    <div class="col-lg-12">
                                        <div class="d-flex justify-content-between">
                                            <div class="mb-3">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value=""
                                                        id="flexCheckDefault4">
                                                    <label class="form-check-label" for="flexCheckDefault4">Remember
                                                        me</label>
                                                </div>
                                            </div>
                                            <p class="forgot-pass mb-0"><a href="auth-re-password.html"
                                                    class="text-dark fw-bold">Forgot password ?</a></p>
                                        </div>
                                    </div>
                                    <!--end col-->                                    

                                    <div class="col-lg-12 mb-0">
                                        <div class="d-grid">
                                            <button type="submit" class="btn btn-primary" id="modalSignInBtn">Sign
                                                in</button>
                                        </div>                                        
                                    </div>
                                    <div class="col-12 text-center">
                                        <p class="mb-0 mt-3"><small class="text-dark me-2">Don't have an account
                                                ?</small> <a href="javascript:void(0)" class="text-dark fw-bold"
                                                id="modalExchSignUpBtn">Sign
                                                Up</a></p>
                                    </div>
                                    <!--end col-->
                                    <!--end col-->

                                    {{-- <div class="col-12 text-center">
                                        <p class="mb-0 mt-3"><small class="text-dark me-2">Don't have an account
                                                ?</small> <a href="javascript:void(0)" class="text-dark fw-bold"
                                                id="modalExchSignUpBtn">Sign
                                                Up</a></p>
                                    </div> --}}
                                    <!--end col-->
                                </div>
                                <!--end row-->
                            </form>
                        </div>
                        <!--end col-->
                    </div>
                        <!--end col-->
                    </div>
                    <!--end row-->
                </div>
                <!--end container-->


                <!-- Register -->

                <!--Register Modal start-->
                <div class="container-fluid px-0 d-none" id="subregister">
                    <div class="row align-items-center g-0">
                        <!--end col-->
                            
                        <div class="col-lg-12 col-md-12">
                            <h3 class="modal-title mt-2 text-center" id="LoginForm-title">Register</h3>
                            <form class="login-form p-4" id="register-modal-form">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="mb-3">
                                            <label class="form-label">First name<span class="text-danger">*</span></label>
                                            <div class="form-icon position-relative">
                                                <i class="fa fa-user fea icon-sm icons" aria-hidden="true"></i>
                                                <input type="text" name="first_name" class="form-control ps-5"
                                                    placeholder="first name" id="register_first_name" required="">
                                            </div>
                                            <span class="text-danger" id="register-first_name"></span>
                                            @if ($errors->has('first_name'))
                                            <span class="text-danger">{{ $errors->first('first_name') }}</span>
                                            @endif

                                        </div>
                                    </div>

                                    <div class="col-lg-12">
                                        <div class="mb-3">
                                            <label class="form-label">Last name<span
                                                    class="text-danger">*</span></label>
                                            <div class="form-icon position-relative">
                                                <i class="fa fa-building fea icon-sm icons" aria-hidden="true"></i>
                                                <input type="text" name="register_last_name" class="form-control ps-5"
                                                    placeholder="Last name" id="register-last_name">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-12">
                                        <div class="mb-3">
                                            <label class="form-label">Email<span
                                                    class="text-danger">*</span></label>
                                            <div class="form-icon position-relative">
                                                <i class="fa fa-building fea icon-sm icons" aria-hidden="true"></i>
                                                <input type="text" name="register_email" class="form-control ps-5"
                                                    placeholder="Email" id="email">
                                            </div>

                                            <span class="text-danger" id="register-email"></span>
                                            @if ($errors->has('password'))
                                            <span class="text-danger">{{ $errors->first('password') }}</span>
                                            @endif
                                        </div>
                                    </div>

                                    <!--end col-->

                                    <div class="col-lg-12">
                                        <div class="mb-3">
                                            <label class="form-label">Password <span
                                                    class="text-danger">*</span></label>
                                            <div class="form-icon position-relative">
                                                <i class="fa fa-key fea icon-sm icons" aria-hidden="true"></i>
                                                <input type="password" id="register_password" name="password"
                                                    class="form-control ps-5" placeholder="Password" required="">
                                            </div>
                                            <span class="text-danger" id="register-password"></span>
                                            @if ($errors->has('password'))
                                            <span class="text-danger">{{ $errors->first('password') }}</span>
                                            @endif
                                        </div>
                                    </div>
                                    <!--end col-->
                                    
                                    <div class="col-lg-12">
                                        <div class="d-flex justify-content-between">
                                            <div class="mb-3">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value=""
                                                        id="flexCheckDefault4">
                                                    <label class="form-check-label" for="flexCheckDefault4">Remember
                                                        me</label>
                                                </div>
                                            </div>
                                            <p class="forgot-pass mb-0"><a href="auth-re-password.html"
                                                    class="text-dark fw-bold">Forgot password ?</a></p>
                                        </div>
                                    </div>
                                    <!--end col-->

                                    <div class="col-lg-12 mb-0">
                                        <div class="d-grid">
                                            <button type="submit" class="btn btn-primary" id="modalSignUpBtn">Sign
                                                Up</button>
                                        </div>
                                    </div>
                                    <!--end col-->

                                    <div class="col-12 text-center">
                                        <p class="mb-0 mt-3"><small class="text-dark me-2">Already Register
                                                ?</small>
                                            <a href="javascript:void(0)" class="text-dark fw-bold"
                                                id="modalExchSignInBtn">Sign
                                                In</a>
                                        </p>
                                    </div>
                                    <!--end col-->
                                </div>
                                <!--end row-->
                            </form>
                        </div>
                        <!--end col-->
                    </div>
                    <!--end row-->
                </div>

                  <!-- End of register modal-->

            </div>
        </div>
    </div>
</div>




@push('scripts')
<script>
    $(document).ready(function () {

        // $('#industryServices-dropdown').html('<option value="">Select industry first</option>'); 

        // $('#Indutry-dropdown').on('change', function() {
        //   var industry_id = this.value;
        //   $("#industryServices-dropdown").html('');
        //   $.ajaxSetup({
        //         headers: {
        //             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        //         }
        //     });
        //   $.ajax({
        //   url:"{{url('get-services-by-industry')}}",
        //   type: "POST",
        //   data: {
        //     industry_id: industry_id,
        //   },
        // dataType : 'json',
        // success: function(result){
        // $('#industryServices-dropdown').html('<option value="">Select...</option>'); 
        // $.each(result,function(key,value){
        // $("#industryServices-dropdown").append('<option value="'+value.industry_category_id+'">'+value.industry_category_name+'</option>');
        //      });
        //    }
        //  });
        // });    

        // Initialize select2

        // $(".industry_category_id").select2();

        // $('#industryServices-dropdown').select2({
        //     dropdownParent: $('#enquiry-popup')
        // });


        // Add new industry
        $(document).on('click', '#industryServices-dropdown', function (e) {
            if ($(this).val() == "other") {
                $('.extra-industry').removeClass('d-none');
            }
        });

        // add Request for demo  ajax

        $(document).on('click', '#sendRequestDemo', function (e) {
            e.preventDefault();
            var data = {
                'customers_name': $('#demo_customers_name').val(),
                'company_name': $('#demo_company_name').val(),
                'email_address': $('#demo_email_address').val(),
                'phone': $('#demo_phone').val(),
                // 'industry': $('#Indutry-dropdown').val(),
                // 'industry_category_id': $('.industry_category_id').val(),
                // 'industry_name': $('#industry_name').val(),
                'business_type': $('#business_type').val(),
                'website': $('#website').val(),
                'message': $('#demo_message').val(),
                'page_source': $('#page_source').val(),
                'newsletter': ($('#demo_newsletter').is(':checked')) ? '1' : '0',
            }
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "{{url('request-for-demo-store')}}",
                data: data,
                dataType: "json",
                success: function (response) {
                    if (response.status == 400) {
                        $.each(response.error, function (key, err_val) {
                            $('#enq_' + key).text(err_val);
                        });
                    } else {
                        swal("Thank you for your request", "Our representative will get back to you shortly.", "success");
                        $('#RequestDemoForm').trigger("reset");
                        $('#enquiry-popup').modal('hide');
                    }
                }

            });
        });
    });



    $(document).ready(function () {
        $(".planLoginbtn").click(function () {
            $("#login-popup").modal('show');
        });
        
        // dismiss delete/cancel pop up

        $(".modal-dismiss").click(function () {
            $(".confirmationModal").modal('hide');
        });

        // dismiss login/register popup

        $(".btn-close").click(function () {
            $("#login-popup").modal('hide');
        });


        // Sign in to SignUp form

        $("#modalExchSignUpBtn").click(function () {
            $("#sublogin").addClass('d-none');
            $("#subregister").removeClass('d-none');

        });

        // Sign up to SignIn form  

        $("#modalExchSignInBtn").click(function () {
            $("#sublogin").removeClass('d-none');
            $("#subregister").addClass('d-none');
        });



        // Login Ajax start here

        $(document).on('click', '#modalSignInBtn', function (e) {
            e.preventDefault();
            var data = {
                'email': $('#login_email').val(),
                'password': $('#login_Password').val(),
            }
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "{{url('/custome-login')}}",
                data: data,
                dataType: "json",

                beforeSend: function () {
                    $('#modalSignInBtn').html('Logging....');
                },
                success: function (response) {
                    if (response.status == "200") {
                        $('#login-modal-form').trigger("reset");
                        $("#login-popup").modal('hide');
                        // var URL = window.location.href;
                        // var arr = URL.split('/');
                        // if (arr.includes("services"))
                        //     $('.chekoutForm').submit();
                        // else
                        //     window.location = "{{url('/account/profile')}}";
                    }
                    if (response.status == 420) {
                        $('#invalid-creddential').text(response.message);
                    }

                },
                error: function (response) {
                    var response = JSON.parse(response.responseText);
                    $.each(response, function (key, err_val) {
                        $('#' + key + '-logerror').text(err_val);
                    });
                },
                complete: function (response) {
                    $('#modalSignInBtn').html('Sign In');
                }

            });
        });


        // Register Ajax start here

        $(document).on('click', '#modalSignUpBtn', function (e) {
            e.preventDefault();
            var data = {
                'first_name': $('#register_first_name').val(),
                'company_name': $('#register_company_name').val(),
                'email': $('#register_email').val(),
                'password': $('#register_password').val(),
                'password_confirmation': $('#password_confirmation').val(),
            }
            console.log(data);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "{{url('custome-register')}}",
                data: data,
                dataType: "json",

                beforeSend: function () {
                    $('#modalSignUpBtn').html('Registering...');
                },

                success: function (response) {
                    if (response.status == 400) {
                        $.each(response.error, function (key, err_val) {
                            $('#' + 'register-' + key).text(err_val);
                        });
                    }
                    if (response.status == 200) {
                        $("#sublogin").removeClass('d-none');
                        $("#subregister").addClass('d-none');
                    }
                },
                complete: function () {
                    $('#modalSignUpBtn').html('Sign Up');
                }

            });
        });

        // Add New Address form
        $("#addNewAdd").click(function () {
            $("#add-new-address").modal('show', 'fade');
        });

         // Add New Address in account form
         $("#addNewAddress").click(function () {
            $("#AddNewLoginAddress").modal('show', 'fade');
        });

        // add address function  ajax
        $(document).on('click', '#Newaddressformbutton', function (e) {
            e.preventDefault();
            var data = {
                'first_name': $('#firstName').val(),
                'billing_email': $('#email').val(),
                'billing_phone': $('#phone').val(),
                'billing_street_address': $('#address').val(),
                'billing_city': $('#city').val(),
                'billing_state': $('#state').val(),
                'billing_country': $('#country').val(),
                'billing_zipcode': $('#zip').val(),
                'business_id': $('#bussinessInfoData').val(),
            }
            //console.log(data);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "{{url('account/add-address')}}",
                data: data,
                dataType: "json",
                success: function (response) {
                    if (response.status == 400) {
                        $.each(response.error, function (key, err_val) {
                            $('#add_' + key).text(err_val);
                        });
                    } else {
                        $html = `<div class="col-lg-12 col-md-6  shadow py-2 mt-2 "><div class="row">
                                   <div class="col-lg-1">
                                       <input id="credit" value=${response.data.business_info_id} name="business_info_id" type="radio" class="form-check-input"
                                       checked required>
                                   </div>
                                   <div class="col-lg-11">
                                       <h6>${response.data.billing_contact_name}</h6>
                                       ${response.data.billing_email}<br/>
                                       ${response.data.billing_phone}<br/>
                                       ${response.data.billing_street_address} , ${response.data.billing_city}<br/>
                                       ${response.data.billing_state} , ${response.data.billing_country}<br/>
                                       ${response.data.billing_zipcode}
                                   </div>
                                </div>
                                </div>`;

                        $('#addressboxes').append($html);
                        $('#add-new-address').modal('hide');
                        $('#Newaddress').trigger("reset");
                    }
                }

            });
        });

    });

</script>
@endpush