@php
$main_arr = [
    'title' => $listing->listing_name ?? '',
    'sublist' => [
        [
            'name' => 'HOME',
            'link' => url('/'),
        ],
        [
            'name' => $listing->categories_name,
            'link' => route('categorySlug',['slug'=>$listing->categories_slug]),
        ],
        [
            'name' => $listing->listing_name ?? '',
            'link' => URL::current(),
        ],
    ],
];

@endphp
 
      <x-Service02.SharedComponent.BreadCrumb :data="$main_arr" />        
  
  

<!-- Start -->
<section class="section pt-2 pb-0">        
    <div class="container mt-100 mt-60">
        <div class="row align-items-end mb-4 pb-4">
            <div class="col-md-8">
                <div class="section-title text-center text-md-start">
                    <h4 class="title mb-4">Services We Offer</h4>                            
                </div>
            </div><!--end col-->                    
        </div><!--end row-->

        <div class="row">
            <div class="col-md-4 mt-4 ">
                <ul class="nav nav-pills nav-justified flex-column rounded shadow p-3 mb-0 sticky-bar" id="pills-tab" role="tablist">
                @if(!empty($related_services) && sizeof($related_services)>0)
                @foreach($related_services as $rskey=>$RSval)
                    <li class="nav-item">
                        <a class="nav-link rounded" href="{{route('listingDetail',['slug'=>$RSval->listing_slug])}}" role="tab" aria-controls="developing" aria-selected="false">
                            <div class="text-center py-1">
                                <h6 class="mb-0">{{$RSval->listing_name ?? ''}}</h6>
                            </div>
                        </a><!--end nav link-->                                 
                    </li><!--end nav item-->
                @endforeach
                @endif                            
                </ul><!--end nav pills-->
            </div><!--end col-->

            <div class="col-md-8 col-12 mt-4 pt-2">
                <div class="tab-content">
                    <div class="tab-pane fade show active p-4 rounded shadow" id="developing" role="tabpanel" aria-labelledby="webdeveloping">
                        <img src="assets/images/work/7.jpg" class="img-fluid rounded shadow" alt="">
                        <div class="mt-4">
                          <h5 class="text-block__title">Overview</h5>
                            <p class="text-muted">{!!$listing->listing_description!!}</p>                                    
                        </div>
                    </div><!--end teb pane-->
                </div><!--end tab content-->
            </div><!--end col-->
        </div><!--end row-->
    </div><!--end container-->
</section><!--end section-->
<!-- End -->
    