<style>

#topnav .navigation-menu.nav-light>li>a {
    color: #000;
}
.pricing-layout1{
padding-top:10rem;
}
</style>

<!-- =========================
        Pricing
        =========================== -->
<section class="pricing-layout1">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-6 offset-lg-3">
                <div class="heading text-center mb-40">
                    <h2 class="heading__subtitle">Our Pricing And Plans</h2>
                    <h3 class="heading__title">Effective & Flexible Pricing
                        That Adapts Your Needs</h3>
                </div><!-- /.heading -->
            </div><!-- /.col-lg-6 -->
        </div><!-- /.row -->
      

        {{-- Plan Tabel start here --}}
        <table class="table table-bordered text-center table-responsive" style="display: inline-table">
            <thead>
                <tr>
                    <th scope="row"></th>
                    @foreach ($PlanData as $planKey => $planVal)
                    @php
                    $price = planToAmount($planVal->plan_id);  
                    @endphp
                    <th scope="col" title="{!! $planVal->plan_desc ?? '' !!}">
                        {{ $planVal->plan_name ?? '' }}<br />
                        @if ($planVal->discount_type == 1)
                        Flat ${{ $planVal->plan_discount ?? '' }} Off<br />
                        @elseif($planVal->discount_type == 2)
                        {{ $planVal->plan_discount ?? '' }} % Off <br />
                        @else
                        Fixed Price <br />
                        @endif
                        @if ($planVal->discount_type != 0)
                        $ <s>{{ $planVal->plan_amount ?? '' }}</s> {{ $price }} /
                        {{ $planVal->plan_duration ?? '' }} month<br />
                        @else
                        $ {{ $price }} / {{ $planVal->plan_duration ?? '' }} month<br />
                        @endif
                    </th>
                    @endforeach
                </tr>
            </thead>
            <th></th>
            @foreach ($PlanData as $planKey => $planVal)
            <th scope="row">
                <form action="#" method="post" class="chekoutForm">
                    @csrf
                    <input type="hidden" name="plan_id" value="{{ $planVal->plan_id }}">
                    @guest
                     <button type="button" class="btn btn-primary planLoginbtn" role="button">Buy
                                    Now</button>
                    @endguest
                    @auth
                    <button type="submit" class="btn btn-primary " role="button">Buy
                        Now</button>
                    @endauth

                </form>
            </th>
            @endforeach
            {{-- </tr>

            </tr> --}}
            @foreach ($FeatureData as $featKey => $featVal)
            @if (!empty($featVal->feature_status))
            <tr>
                <td>{{ $featVal->feature_title ?? '' }}</td>
                @foreach ($featVal->feature_status as $avKey => $avVal)
                @if ($avVal->status == 'yes')
                <td><i class="fa fa-check text-success" aria-hidden="true"></i></td>
                @else
                <td><i class="fa fa-times text-danger" aria-hidden="true"></i></td>
                @endif
                @endforeach
            </tr>
            @endif
            @endforeach
            <td></td>
            @foreach ($PlanData as $planKey => $planVal)
            <td>
                <form action="#" method="post" class="chekoutForm">
                    @csrf
                    <input type="hidden" name="plan_id" value="{{ $planVal->plan_id }}">
                    <button type="submit" class="btn btn-primary planLoginbtn" role="button">Buy
                        Now</button>
                </form>
            </td>
            @endforeach

        </table>
        {{-- Plan Tabel end here --}}


       
</section><!-- /.pricing  -->



<x-Service02.Pages.Modal />