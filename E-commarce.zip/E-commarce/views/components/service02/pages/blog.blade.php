@php

$main_arr = [
  'title'=>'Blogs',
  'sublist' => [
    [
    'name'=>'HOME',
    'link'=>url("/")
    ],
    [
    'name'=>'Blog' ,
    'link'=>url("")
    ], 
  ]
];
@endphp

<x-Service02.SharedComponent.BreadCrumb :data="$main_arr" /> 
   

@if(!empty($allBlog) && sizeof($allBlog)>0)
  <!-- Start -->
  <section class="section">
      <div class="container">
          <div class="row">
           @foreach($allBlog as $blogKey=>$blogData)

              <div class="col-lg-4 col-md-6 col-12 mb-4 pb-2">
                  <div class="card border-0 blog blog-primary shadow overflow-hidden">
                      <img src="{{getFullImageUrl($blogData->img)}}" class="img-fluid" alt="">

                      <div class="content card-body">
                          <ul class="list-unstyled d-flex justify-content-between">
                              <li class="text-muted">
                              @php
                                echo(date('d F,Y', strtotime($blogData->created_at ?? '')));
                              @endphp
                              </li>
                              <li class="text-muted"><a href="javascript:void(0)" class="badge bg-soft-primary">Business</a></li>
                          </ul>

                          <h5><a href="javascript:void(0)" class="card-title title text-dark">{{$blogData->post_title ?? ''}}</a></h5>
                          <p class="post__desc">{{$blogData->post_excerpt ?? ''}}

                          <div class="post-meta d-flex justify-content-between mt-3">
                              <a href="{{url('blog/'.$blogData->slug)}}" class="text-muted readmore">Read More <i class="uil uil-angle-right-b align-middle"></i></a>
                          </div>
                      </div>
                  </div>
              </div><!--end col-->
          @endforeach
              <!-- PAGINATION START -->
              <div class="col-12">
                  <ul class="pagination justify-content-center mb-0">
                      <li class="page-item"><a class="page-link" href="javascript:void(0)" aria-label="Previous">Prev</a></li>
                      <li class="page-item active"><a class="page-link" href="javascript:void(0)">1</a></li>
                      <li class="page-item"><a class="page-link" href="javascript:void(0)">2</a></li>
                      <li class="page-item"><a class="page-link" href="javascript:void(0)">3</a></li>
                      <li class="page-item"><a class="page-link" href="javascript:void(0)" aria-label="Next">Next</a></li>
                  </ul>
              </div><!--end col-->
              <!-- PAGINATION END -->
          </div><!--end row-->
      </div><!--end container-->
  </section><!--end section-->
  <!-- End -->
@endif   