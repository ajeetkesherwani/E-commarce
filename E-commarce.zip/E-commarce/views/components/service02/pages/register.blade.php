 <style>
#topnav .navigation-menu.nav-light>li>a {
    color: #000;
}
 </style>
 <!-- Hero Start -->
        <section class="bg-auth-home d-table w-100">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-7 col-md-6">
                        <div class="me-lg-5">   
                            <img src="{{ LoadAssets('assets/images/user/signup.svg'
                            )}}" class="img-fluid d-block mx-auto" alt="">
                        </div>
                    </div>
                    <div class="col-lg-5 col-md-6">
                        <div class="card shadow rounded border-0">
                            <div class="card-body">
                                <h4 class="card-title text-center">{{ translation('REGISTRATION') }}</h4>  
                                <form class="login-form mt-4" action="{{ route('register') }}" method="post" id="register_form">
                                @csrf
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">First name <span class="text-danger">*</span></label>
                                                <div class="form-icon position-relative">
                                                    <i data-feather="user" class="fea icon-sm icons"></i>
                                                    <input type="text"  name="first_name" class="form-control ps-5" placeholder="{{ translation('FIRST_NAME') }}" >
                                                @error('first_name')
                                                    <strong class="text-danger mb-5">{{ $message }}</strong>
                                                @enderror
                                                </div>
                                            </div>
                                        </div><!--end col-->

                                        <div class="col-md-6">
                                            <div class="mb-3"> 
                                                <label class="form-label">Last name <span class="text-danger">*</span></label>
                                                <div class="form-icon position-relative">
                                                    <i data-feather="user-check" class="fea icon-sm icons"></i>
                                                    <input type="text" class="form-control ps-5" name="last_name" placeholder="{{ translation('LAST_NAME') }}">
                                                @error('last_name')
                                                    <strong class="text-danger mb-5">{{ $message }}</strong>
                                                @enderror
                                                </div>
                                            </div>
                                        </div><!--end col-->

                                        <div class="col-md-12">
                                            <div class="mb-3">
                                                <label class="form-label">Your Email <span class="text-danger">*</span></label>
                                                <div class="form-icon position-relative">
                                                    <i data-feather="mail" class="fea icon-sm icons"></i>
                                                    <input name="email"  type="email"  placeholder="{{ translation('REG_EMAIL') }}" class="form-control ps-5">
                                                @error('email')
                                                    <strong class="text-danger mb-5">{{ $message }}</strong>
                                                @enderror
                                                </div>
                                            </div>
                                        </div><!--end col-->

                                        <div class="col-md-12">
                                            <div class="mb-3">
                                                <label class="form-label">Password <span class="text-danger">*</span></label>
                                                <div class="form-icon position-relative">
                                                    <i data-feather="key" class="fea icon-sm icons"></i>
                                                    <input type="password" class="form-control ps-5" name="password" placeholder="{{ translation('REG_PASSWORD') }}">
                                                @error('password')
                                                    <strong class="text-danger mb-5">{{ $message }}</strong>
                                                @enderror
                                                </div>
                                            </div>
                                        </div><!--end col-->

                                        <div class="col-md-12">
                                            <div class="mb-3">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                                    <label class="form-check-label" for="flexCheckDefault">I Accept <a href="#" class="text-primary">Terms And Condition</a></label>
                                                </div>
                                            </div>
                                        </div><!--end col-->

                                        <div class="col-md-12">
                                            <div class="d-grid">
                                                <button class="btn btn-primary">{{ translation('REGISTER') }}</button>
                                            </div>
                                        </div><!--end col-->

                                    
                                     <div class="mx-auto">
                                            <p class="mb-0 mt-3"><small class="text-dark me-2">Already have an account ?</small> <a href="{{ route('login') }}" class="text-dark fw-bold">{{ translation('LOGIN') }}</a></p>
                                        </div>
                                    </div><!--end row-->
                                </form>
                            </div>
                        </div>
                    </div> <!--end col-->
                </div><!--end row-->
            </div> <!--end container-->
        </section><!--end section-->
        <!-- Hero End -->