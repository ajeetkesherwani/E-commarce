@php
use App\Models\Listing\Services\ListService;
@endphp

@if(!empty($templateComponentKey))
    @foreach ($templateComponentKey as $templateComponentKey)    
        @switch($templateComponentKey->component_key)
            @case($templateComponentKey->component_key == config('constkey.home_slider'))
                @if(!empty($slider_data))
                    <section class="swiper-slider-hero position-relative d-block vh-100" id="home">
                        <div class="swiper-container">
                            <div class="swiper-wrapper">
                                @foreach($slider_data as $key=>$data)     
                                 
                                    <div class="swiper-slide d-flex align-items-center overflow-hidden">
                                        <div class="slide-inner slide-bg-image d-flex align-items-center" style="background: center center;" data-background="{{$data->image}}">
                                            <div class="bg-overlay"></div>
                                            <div class="container">
                                                <div class="row justify-content-center">
                                                    <div class="col-12">
                                                        <div class="title-heading text-center">
                                                            <h1 class="display-5 text-white title-dark fw-bold mb-4">{{$data->banners_title ?? ''}}</h1>
                                                            
                                                            <p class="para-desc mx-auto text-white-50">Launch your campaign and benefit from our expertise on designing and managing conversion centered bootstrap v5 html page.</p>
                                                            
                                                            <div class="mt-4 pt-2">
                                                                <a href="https://dev04.e-nnovation.net/pages/contact-us" class="btn btn-primary">Contact us</a>
                                                            </div>
                                                        </div>
                                                    </div><!--end col-->
                                                </div><!--end row-->
                                            </div><!--end container-->
                                        </div><!-- end slide-inner --> 
                                    </div> <!-- end swiper-slide -->
                                @endforeach
                            </div>              
                            <!-- end swiper-wrapper -->
                            <!-- swipper controls -->
                            <!-- <div class="swiper-pagination"></div> -->
                            <div class="swiper-button-next rounded-circle text-center"></div>
                            <div class="swiper-button-prev rounded-circle text-center"></div>
                        </div><!--end container-->
                    </section><!--end section-->                    
                @endif
                <!-- Hero End -->
            @break  
        @endswitch
    @endforeach
@endif

<!-- FEATURES START -->
<section class="section bg-light">
    @if(!empty($popular_category))
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    <div class="features-absolute">
                        <div class="row">
                            @foreach($popular_category as $pckey=>$popCatval)
                                <div class="col-lg-3 col-md-6 col-12">
                                    <div class="card features feature-primary feature-clean explore-feature p-4 px-md-3 border-0 rounded-md shadow text-center">
                                        <div class="icons text-center mx-auto">
                                            <img src="{{getFullImageUrl($popCatval->categories_image)}}" alt="category-listing" class="h-100" >
                                        </div>
            
                                        <div class="card-body p-0 content">
                                            <h5 class="mt-4"><a href="{{ListService::url($popCatval->categories_id , 'services')}}" class="title text-dark">{{$popCatval->category_name ?? ''}}</a></h5>
                                            <p class="text-muted">{!! Str::limit($popCatval->category_description ?? '',150) !!}</p>
            
                                            
                                            
                                            <a href="{{ListService::url($popCatval->categories_id , 'services')}}" class="read-more">Read More <i class="uil uil-angle-right-b align-middle"></i></a>
                                        </div>
                                    </div>
                                </div><!--end col--> 
                            @endforeach  

                            {{-- <div class="col-lg-3 col-md-6 col-12 mt-4 mt-md-0 pt-2 pt-md-0">
                                <div class="card features feature-primary feature-clean explore-feature p-4 px-md-3 border-0 rounded-md shadow text-center">
                                    <div class="icons text-center mx-auto">
                                        <i class="uil uil-clipboard-alt d-block rounded h3 mb-0 mx-auto"></i>
                                    </div>
        
                                    <div class="card-body p-0 content">
                                        <h5 class="mt-4"><a href="javascript:void(0)" class="title text-dark">Authorised Finance Brand</a></h5>
                                        <p class="text-muted">The most well-known which is said to have originated</p>
        
                                        <a href="javascript:void(0)" class="read-more">Read More <i class="uil uil-angle-right-b align-middle"></i></a>
                                    </div>
                                </div>
                            </div><!--end col-->
                            
                            <div class="col-lg-3 col-md-6 col-12 mt-4 mt-lg-0 pt-2 pt-lg-0">
                                <div class="card features feature-primary feature-clean explore-feature p-4 px-md-3 border-0 rounded-md shadow text-center">
                                    <div class="icons text-center mx-auto">
                                        <i class="uil uil-credit-card-search d-block rounded h3 mb-0 mx-auto"></i>
                                    </div>
        
                                    <div class="card-body p-0 content">
                                        <h5 class="mt-4"><a href="javascript:void(0)" class="title text-dark">Compehensive Advices</a></h5>
                                        <p class="text-muted">The most well-known which is said to have originated</p>
        
                                        <a href="javascript:void(0)" class="read-more">Read More <i class="uil uil-angle-right-b align-middle"></i></a>
                                    </div>
                                </div>
                            </div><!--end col-->
                            
                            <div class="col-lg-3 col-md-6 col-12 mt-4 mt-lg-0 pt-2 pt-lg-0">
                                <div class="card features feature-primary feature-clean explore-feature p-4 px-md-3 border-0 rounded-md shadow text-center">
                                    <div class="icons text-center mx-auto">
                                        <i class="uil uil-ruler-combined d-block rounded h3 mb-0 mx-auto"></i>
                                    </div>
        
                                    <div class="card-body p-0 content">
                                        <h5 class="mt-4"><a href="javascript:void(0)" class="title text-dark">Best Tax Advantages</a></h5>
                                        <p class="text-muted">The most well-known which is said to have originated</p>
        
                                        <a href="javascript:void(0)" class="read-more">Read More <i class="uil uil-angle-right-b align-middle"></i></a>
                                    </div>
                                </div>
                            </div><!--end col--> --}}
                        </div>
                    </div>
                </div>
            </div><!--end row-->
        </div><!--end container-->
    @endif
   
</section><!--end section-->

<section class="section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 text-center">
                <div class="section-title">
                    <h4 class="title mb-4">Our Features</h4>
                    <p class="text-muted para-desc mx-auto mb-0">Start working with <span class="text-primary fw-bold">Landrick</span> that can provide everything you need to generate awareness, drive traffic, connect.</p>
                </div>
            </div><!--end col-->
        </div><!--end row-->

        <div class="row">
        @foreach($web_features as $key=>$feature_data)
            <div class="col-lg-4 col-md-6 mt-4 pt-2">
                <div class="d-flex features feature-primary key-feature align-items-center p-3 rounded shadow">
                    <div class="icon text-center rounded-circle me-3">
                        <img src="{{getFullImageUrl($feature_data->feature_icon)}}"
                            alt="{{getSetting('site_title')}}-{{$feature_data->feature_title}}"
                            class="img-responsive" />
                    </div>
                    <div class="flex-1">
                       <h4>{{$feature_data->feature_title}}</h4>
                            <p>{{$feature_data->feature_subtitle}}</p>
                    </div>
                </div>
            </div><!--end col-->
         @endforeach
        </div><!--end row-->
    </div><!--end container-->
</section><!--end section-->

<section class="section pt-2 pb-0">   

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 text-center">
                <div class="section-title mb-4 pb-2">
                    <h4 class="title mb-4">Client Testimonials</h4>
                    <p class="text-muted para-desc mx-auto mb-0">SWhat our happy customers says !</p>
                </div>
            </div><!--end col-->
        </div><!--end row-->

        <div class="row justify-content-center">
            <div class="col-lg-12 mt-4">
                <div class="tiny-three-item">
                @foreach($webTestimonialList as $key=>$data)
                    <div class="tiny-slide">
                        <div class="d-flex client-testi m-2">
                        <img src="{{ $data->user_data->profile_photo ?? 'https://cdn.pixabay.com/photo/2020/07/01/12/58/icon-5359553_960_720.png' }}" class="avatar avatar-small client-image rounded shadow" alt="{{getSetting('site_title')}}-User">
                            <div class="card flex-1 content p-3 shadow rounded position-relative">
                                <ul class="list-unstyled mb-0">
                                    <li class="list-inline-item"><i class="mdi mdi-star text-warning"></i></li>
                                    <li class="list-inline-item"><i class="mdi mdi-star text-warning"></i></li>
                                    <li class="list-inline-item"><i class="mdi mdi-star text-warning"></i></li>
                                    <li class="list-inline-item"><i class="mdi mdi-star text-warning"></i></li>
                                    <li class="list-inline-item"><i class="mdi mdi-star text-warning"></i></li>
                                </ul>
                                <p class="text-muted mt-2">{{ Str::limit($data->testimonial_text, 120) }}</p>
                                        <h6 class="text-primary">{{ !empty($data->user_data) ?  $data->user_data->first_name : '' }} {{ !empty($data->user_data) ? $data->user_data->last_name : ''}}<small class="text-muted">{{ !empty($data->user_data) ? $data->user_data->email : ''}}</small></h6>
                            </div>
                        </div>
                    </div>
                 @endforeach
                </div>
            </div><!--end col-->
        </div><!--end row-->
    </div><!--end container-->

    <div class="container mt-100 mt-60">
        <div class="row align-items-center mb-4 pb-2">
            <div class="col-lg-6">
                <div class="section-title text-center text-lg-start">
                    <h6 class="text-primary">Blog</h6>
                    <h4 class="title mb-4 mb-lg-0">Reads Our Latest <br> News & Blog</h4>
                </div>
            </div><!--end col-->           
        </div><!--end row-->

@if(!empty($allBlog) && sizeof($allBlog)>0)
    <!-- Start -->
    <section class="section pt-2 pb-0">
            <div class="container">
                <div class="row">
                    @foreach($allBlog as $blogKey=>$blogData)
                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="card border-0 blog blog-primary shadow overflow-hidden">
                            <img src="{{getFullImageUrl($blogData->img)}}" class="img-fluid" alt="">

                            <div class="content card-body">
                                <ul class="list-unstyled d-flex justify-content-between">
                                    <li class="text-muted">
                                    @php
                                        echo(date('d F,Y', strtotime($blogData->created_at ?? '')));
                                    @endphp
                                    </li>
                                    <li class="text-muted"><a href="javascript:void(0)" class="badge bg-soft-primary">Business</a></li>
                                </ul>

                                <h5><a href="{{url('blog/'.$blogData->slug)}}" class="card-title title text-dark">{{$blogData->post_title ?? ''}}</a></h5>
                                <p class="post__desc">{{$blogData->post_excerpt ?? ''}}

                                <div class="post-meta d-flex justify-content-between">
                                    <a href="{{url('blog/'.$blogData->slug)}}" class="text-muted readmore">Read More <i class="uil uil-angle-right-b align-middle"></i></a>
                                </div>
                            </div>
                        </div>
                    </div><!--end col-->
                    @endforeach
                
                </div><!--end row-->
            </div><!--end container-->
    </section><!--end section-->
    <!-- End -->
@endif  
</section><!--end section-->

<!--Starting of Newslatter Modal-->
<div class="modal newsmodal" id="onloadModal">
    <div class="modal-dialog newslatter_modal_dialog">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header">
                <section class="pop-up-from">
                    <div class="content newsmodal">

                    </div>
                </section>
                <button type="button" class="btn-close" id="btnnewslatter" data-bs-dismiss="modal"></button>
            </div>
        </div>
    </div>
</div>
<!--Ending of NewsLatter Modal-->