
@php

$main_arr = [
  'title'=>'Services',
  'sublist' => [
    [
    'name'=>'HOME',
    'link'=>url("/")
    ],
    [
    'name'=>'Services' ,
    'link'=>url("")
    ], 
  ]
];

@endphp

<x-Service02.SharedComponent.BreadCrumb :data="$main_arr" /> 


<div class="position-relative">
    <div class="shape overflow-hidden text-color-white">
        <svg viewBox="0 0 2880 48" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 48H1437.5H2880V0H2160C1442.5 52 720 0 720 0H0V48Z" fill="currentColor"></path>
        </svg>
    </div>
</div>
<!-- Hero End -->

<!-- Start --> 
<section class="section">
    <div class="container">
        <div class="row align-items-center">

            @foreach($popular_category as $pckey=>$popCatval)
                                <div class="col-lg-3 col-md-6 col-12">
                                    <div class="card features feature-primary feature-clean explore-feature p-4 px-md-3 border-0 rounded-md shadow text-center">
                                        <div class="icons text-center mx-auto">
                                            <img src="{{getFullImageUrl($popCatval->categories_image)}}" alt="category-listing" class="h-100" >
                                        </div>
            
                                        <div class="card-body p-0 content">
                                            <h5 class="mt-4"><a href="{{route('categorySlug',['slug'=>$popCatval->categories_slug])}}" class="title text-dark">{{$popCatval->category_name ?? ''}}</a></h5>
                                            <p class="text-muted">{!! Str::limit($popCatval->category_description ?? '',150) !!}</p>
            
                                            
                                            <a href="{{route('categorySlug',['slug'=>$popCatval->categories_slug])}}" class="read-more">Read More <i class="uil uil-angle-right-b align-middle"></i></a>
                                        </div>
                                    </div>
                                </div><!--end col-->
                            @endforeach 

        </div><!--end row-->
    </div><!--end container-->
    

</section><!--end section-->
<!-- End -->