@php
$main_arr = [
'title'=>$categoryDesc->categories_name ?? '',
'sublist' => $breadCumbArr
];

@endphp

    <!-- ========================
       page title 
    =========================== -->
    <x-Service02.SharedComponent.BreadCrumb :data="$main_arr" />  
      <!-- ========================
          Services Layout 1
      =========================== -->
      <section class="services-layout1 pt-130 pb-90 mt-5">       
        <div class="container">        
          <div class="row">
            @if(!empty($listings) && sizeof($listings)>0)
            @foreach($listings as $listing)

            <x-Service02.shared-component.list-item  :data="$listing" />

            @endforeach
            @endif
          </div><!-- /.row -->
        </div><!-- /.container -->
      </section><!-- /.Services Layout 1 -->
  
    
 
  
     <!-- Feature Start -->
        <section class="section">            
            
            <div class="container mt-100 mt-60">
                <div class="row justify-content-center">
                    <div class="col-12">
                        <div class="section-title text-center mb-4 pb-2">
                            <h6 class="text-primary">Work Process</h6>
                            <h4 class="title mb-4">How do we works ?</h4>
                            <p class="text-muted para-desc mx-auto mb-0">Start working with <span class="text-primary fw-bold">Landrick</span> that can provide everything you need to generate awareness, drive traffic, connect.</p>
                        </div>
                    </div><!--end col-->
                </div><!--end row-->

            </div><!--end container-->

            <div class="container-fluid mt-100 mt-60">
                <div class="bg-cta shadow rounded card overflow-hidden" style="background: url('{{ URL::asset("Service02/assets/images/2.jpg")}}') center center;" id="cta">
                    <div class="bg-overlay"></div>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-12 text-center">
                                <div class="section-title">
                                    <h4 class="title title-dark text-white mb-4">We Are Creative Dreamers and Innovators</h4>
                                    <p class="text-white-50 para-dark para-desc mx-auto">Start working with Landrick that can provide everything you need to generate awareness, drive traffic, connect.</p>
                                    <a href="#!" data-type="youtube" data-id="yba7hPeTSjk" class="play-btn  mt-4 lightbox">
                                        <i data-feather="play" class="fea icon-ex-md text-white title-dark"></i>
                                    </a>
                                </div>
                            </div><!--end col-->
                        </div><!--end row-->
                    </div><!--end container-->
                </div>
            </div><!--end container-->

            <div class="container mt-100 mt-60">
                <div class="row align-items-end mb-4 pb-4">
                    <div class="col-md-8">
                        <div class="section-title text-center text-md-start">
                            <h6 class="text-primary">Services</h6>
                            <h4 class="title mb-4">What we do ?</h4>
                            <p class="text-muted mb-0 para-desc">Start working with <span class="text-primary fw-bold">Landrick</span> that can provide everything you need to generate awareness, drive traffic, connect.</p>
                        </div>
                    </div><!--end col-->

                    <div class="col-md-4 mt-4 mt-sm-0">
                        <div class="text-center text-md-end">
                            <a href="javascript:void(0)" class="text-primary h6">See More <i class="uil uil-angle-right-b align-middle"></i></a>
                        </div>
                    </div><!--end col-->
                </div><!--end row-->

                <div class="row">
                    <div class="col-md-4 mt-4 pt-2">
                        <ul class="nav nav-pills nav-justified flex-column rounded shadow p-3 mb-0 sticky-bar" id="pills-tab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link rounded active" id="webdeveloping" data-bs-toggle="pill" href="#developing" role="tab" aria-controls="developing" aria-selected="false">
                                    <div class="text-center py-1">
                                        <h6 class="mb-0">Web Developing</h6>
                                    </div>
                                </a><!--end nav link-->
                            </li><!--end nav item-->
                            
                            <li class="nav-item mt-2">
                                <a class="nav-link rounded" id="database" data-bs-toggle="pill" href="#data-analise" role="tab" aria-controls="data-analise" aria-selected="false">
                                    <div class="text-center py-1">
                                        <h6 class="mb-0">Database Analysis</h6>
                                    </div>
                                </a><!--end nav link-->
                            </li><!--end nav item-->
                            
                            <li class="nav-item mt-2">
                                <a class="nav-link rounded" id="server" data-bs-toggle="pill" href="#security" role="tab" aria-controls="security" aria-selected="false">
                                    <div class="text-center py-1">
                                        <h6 class="mb-0">Server Security</h6>
                                    </div>
                                </a><!--end nav link-->
                            </li><!--end nav item-->
                            
                            <li class="nav-item mt-2">
                                <a class="nav-link rounded" id="webdesigning" data-bs-toggle="pill" href="#designing" role="tab" aria-controls="designing" aria-selected="false">
                                    <div class="text-center py-1">
                                        <h6 class="mb-0">Web Designing</h6>
                                    </div>
                                </a><!--end nav link-->
                            </li><!--end nav item-->
                        </ul><!--end nav pills-->
                    </div><!--end col-->

                    <div class="col-md-8 col-12 mt-4 pt-2">
                        <div class="tab-content" id="pills-tabContent">
                            <div class="tab-pane fade show active p-4 rounded shadow" id="developing" role="tabpanel" aria-labelledby="webdeveloping">
                                <img src="{{ LoadAssets('assets/images/work/7.jpg')}}" class="img-fluid rounded shadow" alt="">
                                <div class="mt-4">
                                    <p class="text-muted">This is required when, for example, the final text is not yet available. Dummy text is also known as 'fill text'. It is said that song composers of the past used dummy texts as lyrics.</p>
                                    <a href="javascript:void(0)" class="text-primary">See More <i class="uil uil-angle-right-b align-middle"></i></a>
                                </div>
                            </div><!--end teb pane-->
                            
                            <div class="tab-pane fade p-4 rounded shadow" id="data-analise" role="tabpanel" aria-labelledby="database">
                                <img src="{{ LoadAssets('assets/images/work/8.jpg')}}" class="img-fluid rounded shadow" alt="">
                                <div class="mt-4">
                                    <p class="text-muted">This is required when, for example, the final text is not yet available. Dummy text is also known as 'fill text'. It is said that song composers of the past used dummy texts as lyrics.</p>
                                    <a href="javascript:void(0)" class="text-primary">See More <i class="uil uil-angle-right-b align-middle"></i></a>
                                </div>
                            </div><!--end teb pane-->

                            <div class="tab-pane fade p-4 rounded shadow" id="security" role="tabpanel" aria-labelledby="server">
                                <img src="{{ LoadAssets('assets/images/work/9.jpg')}}" class="img-fluid rounded shadow" alt="">
                                <div class="mt-4">
                                    <p class="text-muted">This is required when, for example, the final text is not yet available. Dummy text is also known as 'fill text'. It is said that song composers of the past used dummy texts as lyrics.</p>
                                    <a href="javascript:void(0)" class="text-primary">See More <i class="uil uil-angle-right-b align-middle"></i></a>
                                </div>
                            </div><!--end teb pane-->
                            
                            <div class="tab-pane fade p-4 rounded shadow" id="designing" role="tabpanel" aria-labelledby="webdesigning">
                                <img src="{{ LoadAssets('assets/images/work/12.jpg')}}" class="img-fluid rounded shadow" alt="">
                                <div class="mt-4">
                                    <p class="text-muted">This is required when, for example, the final text is not yet available. Dummy text is also known as 'fill text'. It is said that song composers of the past used dummy texts as lyrics.</p>
                                    <a href="javascript:void(0)" class="text-primary">See More <i class="uil uil-angle-right-b align-middle"></i></a>
                                </div>
                            </div><!--end teb pane-->
                        </div><!--end tab content-->
                    </div><!--end col-->
                </div><!--end row-->
            </div><!--end container-->
        </section><!--end section-->
        <!-- Feature Start -->

       
