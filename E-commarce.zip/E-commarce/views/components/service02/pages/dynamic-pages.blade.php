@php
$main_arr = [
  'title'=>$PageData->pages_title,
  'sublist' => [
    [
    'name'=>'HOME',
    'link'=>url("/")
    ],
    [
    'name'=>$PageData->pages_title,
    'link'=> URL::current(),
    ], 
  ]
];

@endphp

@push('styles')
<style>
.error{
  color:red;
  display:block !important;
}
</style>
@endpush


<!-- Breadcrumb Area start -->
<!-- Breadcrumb Area End -->

        
<!-- About Area Start -->
<x-Service02.SharedComponent.BreadCrumb :data="$main_arr" />
<section class="section">
    <div class="container">
  
        <div class="row align-items-center">
            {!!$PageData->pages_content!!}
        </div><!--end row-->
    </div><!--end container-->
</section><!--end section-->




<!-- About Area Start -->