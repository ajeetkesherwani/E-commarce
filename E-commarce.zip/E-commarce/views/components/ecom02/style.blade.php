<link rel="shortcut icon" type="image/x-icon" href="{{ getImageUrlWithKey('website_favicon') }}" />
 <!-- Css -->
 <link href="{{ LoadAssets('assets/libs/tiny-slider/tiny-slider.css') }}" rel="stylesheet">
 <!-- Bootstrap Css -->
 <link href="{{ LoadAssets('assets/css/bootstrap.min.css') }}" class="theme-opt" rel="stylesheet" type="text/css" />
 <!-- Icons Css -->
 <link href="{{ LoadAssets('assets/css/icons.min.css') }}" rel="stylesheet" type="text/css" />
 <link href="{{ LoadAssets('assets/libs/@iconscout/unicons/css/line.css') }}" type="text/css" rel="stylesheet" />
 <!-- Style Css-->
 <link href="{{ LoadAssets('assets/css/style.min.css') }}" class="theme-opt" rel="stylesheet" type="text/css" />
 <link rel="stylesheet" href="{{ LoadAssets('assets/css/default.css') }}">
 <!-- // toastify  -->
 <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">

 <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
 <script src="https://kit.fontawesome.com/be06daa5b1.js" crossorigin="anonymous"></script>
