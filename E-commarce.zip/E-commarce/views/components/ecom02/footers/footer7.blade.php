@php
$footermenu1=MenuKey("footer-menu-1");
$footermenu2=MenuKey("footer-menu-2");
@endphp
 <!-- Footer Start -->
 <footer class="footer footer-bar">
            <div class="footer-py-30">
                <div class="container text-center">
                    <div class="row align-items-center">
                        <div class="col-sm-3">
                            <div class="text-sm-start">
                             <a href="{{url('/')}}" class="logo-footer">
                                <img src="{{getImageUrlWithKey('website_logo')}}" alt="{{getSetting('site_title')}}-logo" height="24"/>
                             </a>
                            </div>
                        </div>

                        <div class="col-sm-6 mt-4 mt-sm-0 pt-2 pt-sm-0">
                            <div class="text-center">
                                <p class="mb-0">{{$copyRightText ?? ''}}</p>
                            </div>
                        </div>

                        <div class="col-sm-3 mt-4 mt-sm-0 pt-2 pt-sm-0">
                            <ul class="list-unstyled social-icon foot-social-icon text-sm-end mb-0">
                            @if(!empty(socialLinks('facebook_url')))
                                        <li class="list-inline-item"><a href="{{getSetting('facebook_url')}}" target="_blank" class="rounded"><i data-feather="facebook" class="fea icon-sm fea-social"></i></a></li>
                                        @endif 
                                        @if(!empty(socialLinks('instagram_url')))
                                            <li class="list-inline-item"><a href="{{getSetting('instagram_url')}}" target="_blank" class="rounded"><i data-feather="instagram" class="fea icon-sm fea-social"></i></a></li>
                                        @endif
                                        @if(!empty(socialLinks('twitter_url')))  
                                            <li class="list-inline-item"><a href="{{getSetting('twitter_url')}}" target="_blank" class="rounded"><i data-feather="twitter" class="fea icon-sm fea-social"></i></a></li>
                                        @endif 
                                        @if(!empty(socialLinks('google_url')))  
                                            <li class="list-inline-item"><a href="{{getSetting('google_url')}}" target="_blank" class="rounded"><i data-feather="google" class="fea icon-sm fea-social"></i></a></li>
                                        @endif 
                                        @if(!empty(socialLinks('youtube_url')))
                                            <li class="list-inline-item"><a href="{{socialLinks('youtube_url')}}" target="_blank" class="rounded"><i data-feather="youtube" class="fea icon-sm fea-social"></i></a></li>
                                        @endif
                            </ul><!--end icon-->
                        </div><!--end col-->
                    </div><!--end row-->
                </div><!--end container-->
            </div>
        </footer><!--end footer-->
        <!-- Footer End -->

         <!-- Popup Modal Start  -->
        <!-- Product View Start -->
        <div class="modal fade" id="productModalShow" tabindex="-1" aria-labelledby="productview-title" aria-hidden="true">
              <div class="modal-dialog  modal-lg modal-dialog-centered">
                 <div id="product-detail-modal"></div> 
               </div>     
        </div>
        <!-- Product View End -->

         @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))

        <!-- Wishlist Popup Start -->
        <div class="modal fade" id="wishlist" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content rounded shadow-lg border-0 overflow-hidden">
                    <div class="modal-body py-5">
                        <div class="text-center">
                            <div class="icon d-flex align-items-center justify-content-center bg-soft-danger rounded-circle mx-auto" style="height: 95px; width:95px;">
                                <h1 class="mb-0">
                                    @if($wishlist_count == 0)
                                    <i class="uil uil-heart-break align-middle"></i>
                                    @else
                                    <i class="uil uil-heart align-middle"></i>
                                    @endif
                                </h1>
                            </div>
                            <div class="mt-4">
                                 @if($wishlist_count == 0)
                                <h4>Your wishlist is empty.</h4>
                                <p class="text-muted">Create your first wishlist request...</p>
                                <a href="{{url('/')}}" class="btn btn-primary btn-lg btn-block" role="button" aria-pressed="true">Continue to shop </a>
                                @else
                                <div class="mt-4">
                                    <p class="text-muted div_wishlist_count">There are {{$wishlist_count}} item avaliable in your wishlist</p>
                                    <a href="{{url('wishlist')}}" class="btn btn-outline-primary"> View Wishlist</a>
                                </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endif
        <!-- Wishlist Popup End -->
     <!-- Back to top -->
     <a href="#" onclick="topFunction()" id="back-to-top" class="back-to-top fs-5"><i data-feather="arrow-up" class="fea icon-sm icons align-middle"></i></a>
        <!-- Back to top -->

@push('scripts')
<script>
    $(document).ready(function() {

        $(document).on('submit', '#newslatterform', function(e) {
         e.preventDefault();
            $('#newslatterform').addClass('was-validated');
            if ($('#newslatterform')[0].checkValidity() === false) {
            event.stopPropagation();
            } else {
          var data = {
            'customer_email': $('.email').val(),
          }
          $.ajaxSetup({
            headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
          });
          $.ajax({
            type: "POST",
            url: "/newslatterstore",
            data :data,
            dataType:"json",
            success: function(response) {
             if(response.status==400)
            {
                $('.mail_error').text(response.error.customer_email);  
              
            }
            else
            {   
                $('.email').val(),
                $('.mail_error').text(""); 
                Notify('Subscribed Successfully', true);
                $("#newslatterform").trigger("reset");
                $("#newslatterform").removeClass('was-validated');
            }             
            }
          });
         }
        });
    });

</script>
@endpush