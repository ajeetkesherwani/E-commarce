@php
$footermenu1=MenuKey("footer-menu-1");
$footermenu2=MenuKey("footer-menu-2");
@endphp
     <!-- Footer Start -->
     <footer class="footer page-footer footer-light">    
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="footer-py-60">
                            <div class="row">
                                <div class="col-lg-3 col-12 mb-0 mb-md-4 pb-0 pb-md-2">
                                    <a href="{{url('/')}}" class="logo-footer">
                                        <img src="{{getImageUrlWithKey('website_logo')}}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="{{getSetting('site_title')}}-logo" height="24"/>
                                    </a>
                                    <p class="mt-2">{{getSetting('footer_about_description') ?? ''}}</p>
                                    <ul class="list-unstyled social-icon social mb-0 mt-4">
                                        @if(!empty(socialLinks('facebook_url')))
                                        <li class="list-inline-item"><a href="{{getSetting('facebook_url')}}" target="_blank" class="rounded"><i data-feather="facebook" class="fea icon-sm fea-social"></i></a></li>
                                        @endif 
                                        @if(!empty(socialLinks('instagram_url')))
                                            <li class="list-inline-item"><a href="{{getSetting('instagram_url')}}" target="_blank" class="rounded"><i data-feather="instagram" class="fea icon-sm fea-social"></i></a></li>
                                        @endif
                                        @if(!empty(socialLinks('twitter_url')))  
                                            <li class="list-inline-item"><a href="{{getSetting('twitter_url')}}" target="_blank" class="rounded"><i data-feather="twitter" class="fea icon-sm fea-social"></i></a></li>
                                        @endif 
                                        @if(!empty(socialLinks('google_url')))  
                                            <li class="list-inline-item"><a href="{{getSetting('google_url')}}" target="_blank" class="rounded"><i data-feather="google" class="fea icon-sm fea-social"></i></a></li>
                                        @endif 
                                        @if(!empty(socialLinks('youtube_url')))
                                            <li class="list-inline-item"><a href="{{socialLinks('youtube_url')}}" target="_blank" class="rounded"><i data-feather="youtube" class="fea icon-sm fea-social"></i></a></li>
                                        @endif
                                    </ul><!--end icon-->
                                </div><!--end col-->
                        
                                <div class="col-lg-3 col-md-4 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0">
                                    <h5 class="footer-head">{{translation('INFORMATION')}}</h5>
                                    @if(!empty($footermenulist1))
                                    <ul class="list-unstyled footer-list mt-2">
                                       @foreach($footermenulist1 as $key=>$value)
                                        <li><a href="{{$value['link'] ?? ''}}" class="text-foot"><i class="uil uil-angle-right-b me-1"></i>{{translation($value['name'] ?? '')}}</a></li>
                                       @endforeach
                                    </ul>
                                    @endif
                                </div><!--end col-->
                        
                                <div class="col-lg-3 col-md-4 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0">
                                    <h5 class="footer-head">{{translation('CUSTOM_LINKS')}}</h5>
                                    @if(!empty($footermenulist2))
                                    <ul class="list-unstyled footer-list mt-2">
                                      @foreach($footermenulist2 as $footer2key=>$footer2value)
                                        <li><a href="{{($footer2value['link'])}}" class="text-foot"><i class="uil uil-angle-right-b me-1"></i> {{translation($footer2value['name'] ?? '')}}</a></li>
                                      @endforeach
                                    </ul>
                                    @endif
                                </div><!--end col-->
    
                                <div class="col-lg-3 col-md-4 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0">
                                    <h5 class="footer-head">{{translation('NEWS_LETTER')}}</h5>
                                    <p class="mb-2">Sign up and receive the latest tips via email.</p>
                                   <form id="newslatterform" class="validate needs-validation" novalidate="" 
                                name="mc-embedded-subscribe-form" method="post">
                                    @csrf
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="foot-subscribe foot-white mb-3">
                                                    <label class="form-label">Write your email <span class="text-danger">*</span></label>
                                                    <div class="form-icon position-relative">
                                                        <i data-feather="mail" class="fea icon-sm icons"></i>
                                                        <input type="email" name="customer_email" class="form-control ps-5 rounded email" placeholder="{{translation('ENTER_YOUR_EMAIL_HERE')}}" value="" required>
                                                        <p class="text-danger mail_error" style="font-size:20px;"></p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="d-grid">
                                                 <input type="submit" id="mc-embedded-subscribe" name="subscribe" class="btn btn-primary" value="{{translation('SIGN_UP')}}">
                                                 <input type="reset" hidden id="configreset" value="Reset">  
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div><!--end col-->
                            </div><!--end row-->
                        </div>
                    </div><!--end col-->
                </div><!--end row-->
            </div><!--end container-->

            <div class="footer-py-30 bg-footer text-white-50 border-top">
                <div class="container text-center">
                    <div class="row align-items-center">
                        <div class="col-sm-6">
                            <div class="text-sm-start">
                                <p class="mb-0">{{$copyRightText ?? ''}}</p>
                            </div>
                        </div><!--end col-->

                        <div class="col-sm-6 mt-4 mt-sm-0 pt-2 pt-sm-0">
                            <ul class="list-unstyled text-sm-end mb-0">
                                <li class="list-inline-item"><a href="javascript:void(0)"><img class="payment-img avatar avatar-ex-sm" src="{{ LoadAssets('assets/images/icons/payment.png')}}" alt="{{getSetting('site_title')}}-payment" /></a></li>
                            </ul>
                        </div><!--end col-->
                    </div><!--end row-->
                </div><!--end container-->
            </div>
        </footer><!--end footer-->
        <!-- Footer End -->

         <!-- Popup Modal Start  -->
        <!-- Product View Start -->
        <div class="modal fade" id="productModalShow" tabindex="-1" aria-labelledby="productview-title" aria-hidden="true">
              <div class="modal-dialog  modal-lg modal-dialog-centered">
                 <div id="product-detail-modal"></div> 
               </div>     
        </div>
        <!-- Product View End -->

         @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))

        <!-- Wishlist Popup Start -->
        <div class="modal fade" id="wishlist" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content rounded shadow-lg border-0 overflow-hidden">
                    <div class="modal-body py-5">
                        <div class="text-center">
                            <div class="icon d-flex align-items-center justify-content-center bg-soft-danger rounded-circle mx-auto" style="height: 95px; width:95px;">
                                <h1 class="mb-0">
                                    @if($wishlist_count == 0)
                                    <i class="uil uil-heart-break align-middle"></i>
                                    @else
                                    <i class="uil uil-heart align-middle"></i>
                                    @endif
                                </h1>
                            </div>
                            <div class="mt-4" id="count-wishlist-div">
                                 @if($wishlist_count == 0)
                                <h4>Your wishlist is empty.</h4>
                                <p class="text-muted">Create your first wishlist request...</p>
                                <a href="{{url('/')}}" class="btn btn-primary btn-lg btn-block" role="button" aria-pressed="true">Continue to shop </a>
                                @else
                                <div class="mt-4">
                                    <!-- <span class="count-wishlist-total"></span> -->
                                    <p class="text-muted div_wishlist_count">There are {{$wishlist_count}} item avaliable in your wishlist</p>
                                    <a href="{{url('wishlist')}}" class="btn btn-outline-primary"> View Wishlist</a>
                                </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endif
        <!-- Wishlist Popup End -->
  
           <!-- Back to top -->
        <a href="#" onclick="topFunction()" id="back-to-top" class="back-to-top fs-5"><i data-feather="arrow-up" class="fea icon-sm icons align-middle"></i></a>
        <!-- Back to top -->
               
@push('scripts')
<script>
    $(document).ready(function() {

        $(document).on('submit', '#newslatterform', function(e) {
         e.preventDefault();
            $('#newslatterform').addClass('was-validated');
            if ($('#newslatterform')[0].checkValidity() === false) {
            event.stopPropagation();
            } else {
          var data = {
            'customer_email': $('.email').val(),
          }
          $.ajaxSetup({
            headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
          });
          $.ajax({
            type: "POST",
            url: "/newslatterstore",
            data :data,
            dataType:"json",
            success: function(response) {
             if(response.status==400)
            {
                $('.mail_error').text(response.error.customer_email);  
              
            }
            else
            {   
                $('.email').val(),
                $('.mail_error').text(""); 
                Notify('Subscribed Successfully', true);
                $("#newslatterform").trigger("reset");
                $("#newslatterform").removeClass('was-validated');
            }             
            }
          });
         }
        });
    });

</script>
@endpush