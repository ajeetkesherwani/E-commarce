@php
$footermenu1=MenuKey("footer-menu-1");
$footermenu2=MenuKey("footer-menu-2");
@endphp
   <!-- Footer Start -->
   <footer class="footer">    
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="footer-py-60">
                            <div class="row">
                                <div class="col-lg-3 col-12 mb-0 mb-md-4 pb-0 pb-md-2">
                                  <a href="{{url('/')}}" class="logo-footer"><img src="{{getImageUrlWithKey('website_logo')}}" alt="{{getSetting('site_title')}}-logo" height="50"/></a>
                                    <p class="mt-4">{{getSetting('footer_about_description') ?? ''}}</p>
                                    <ul class="list-unstyled social-icon foot-social-icon mb-0 mt-4">
                                      @if(!empty(socialLinks('facebook_url')))
                                        <li class="list-inline-item"><a href="{{getSetting('facebook_url')}}" target="_blank" class="rounded"><i data-feather="facebook" class="fea icon-sm fea-social"></i></a></li>
                                      @endif 
                                      @if(!empty(socialLinks('instagram_url')))
                                        <li class="list-inline-item"><a href="{{getSetting('instagram_url')}}" target="_blank" class="rounded"><i data-feather="instagram" class="fea icon-sm fea-social"></i></a></li>
                                      @endif
                                      @if(!empty(socialLinks('twitter_url')))  
                                        <li class="list-inline-item"><a href="{{getSetting('twitter_url')}}" target="_blank" class="rounded"><i data-feather="twitter" class="fea icon-sm fea-social"></i></a></li>
                                      @endif 
                                      @if(!empty(socialLinks('google_url')))  
                                        <li class="list-inline-item"><a href="{{getSetting('google_url')}}" target="_blank" class="rounded"><i data-feather="google" class="fea icon-sm fea-social"></i></a></li>
                                      @endif 
                                      @if(!empty(socialLinks('youtube_url')))
                                        <li class="list-inline-item"><a href="{{socialLinks('youtube_url')}}" target="_blank" class="rounded"><i data-feather="youtube" class="fea icon-sm fea-social"></i></a></li>
                                      @endif  
                                    </ul><!--end icon-->
                                </div><!--end col-->
                                  <div class="col-lg-3 col-md-6 col-12 mt-4 mt-lg-0 pt-2 pt-lg-0">
                                    <h6 class="footer-head mb-3">{{translation('FOOTER_INFORMATION_TITLE')}}</h6>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="foot-subscribe mb-3">
                                                  @if(!empty($footermenulist1))
                                                    <ul class="list-unstyled footer-list">
                                                          @foreach($footermenulist1 as $key=>$value) 
                                                        <li><a href="{{url($value['link'] ?? '')}}" class="text-foot"><i class="uil uil-angle-right-b me-1"></i>{{translation($value['name'] ?? '')}}</a></li>
                                                        @endforeach
                                                    </ul>
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                </div><!--end col-->
                                <div class="col-lg-3 col-md-6 col-12 mt-4 mt-lg-0 pt-2 pt-lg-0">
                                    <h6 class="footer-head mb-3">{{translation('FOOTER_CUSTOM_LINKS_TITLE')}}</h6>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="foot-subscribe mb-3">
                                                  @if(!empty($footermenulist2))
                                                    <ul class="list-unstyled footer-list">
                                                        @foreach($footermenulist2 as $footer2key=>$footer2value)
                                                        <li><a href="{{(url($footer2value['link']))}}" class="text-foot"><i class="uil uil-angle-right-b me-1"></i>{{translation($footer2value['name'])}}</a></li>
                                                        @endforeach
                                                    </ul>
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                </div><!--end col-->
                                <div class="col-lg-3 col-md-6 col-12 mt-4 mt-lg-0 pt-2 pt-lg-0">
                                    <h6 class="footer-head mb-3">{{translation('FOOTER_NEWSLETTER_TITLE')}}</h6>
                                    <p>{!! getSetting('footer_newsletter_info') ?? '' !!}</p>
                                     <form id="newslatterform" class="validate needs-validation" novalidate=""  name="mc-embedded-subscribe-form" method="post">
                                @csrf
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="foot-subscribe mb-3">
                                                    <!-- <label class="form-label">{{translation('FOOTER_EMAIL')}}<span class="text-danger">*</span></label> -->
                                                    <div class="form-icon position-relative">
                                                        <i data-feather="mail" class="fea icon-sm icons"></i>
                                                        <input type="email" name="customer_email" class="form-control ps-5 rounded email" placeholder="{{translation('FOOTER_EMAIL_PLACEHOLDER')}}" value="" required>
                                                         <p class="text-danger mail_error" style="font-size:20px;"></p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="d-grid">
                                                 <input type="submit" id="mc-embedded-subscribe" name="subscribe" class="btn footer-btn" value="{{translation('FOOTER_SIGNUP_BUTTON')}}">
                                                 <input type="reset" hidden id="configreset" value="Reset">
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div><!--end col-->
                            </div><!--end row-->
                        </div>
                    </div><!--end col-->
                </div><!--end row-->
            </div><!--end container-->
            
            <!-- website feature tag -->
            @if(!empty($web_features))

            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="footer-py-30 footer-border">
                            <div class="container">
                                <div class="row">
                                   @foreach($web_features as $key=>$feature_data)
                                    <div class="col-lg-3">
                                        <div class="d-flex align-items-center justify-content-center">
                                            @if($feature_data->feature_title == 'Free Shipping')
                                            <i class="uil uil-truck align-middle h5 mb-0 me-2"></i>
                                             <h6 class="mb-0">{{translation($feature_data->feature_title)}}</h6>
                                            @endif
                                            @if($feature_data->feature_title == 'Free Returns')
                                            <i class="uil uil-transaction align-middle h5 mb-0 me-2"></i>
                                             <h6 class="mb-0">{{translation($feature_data->feature_title)}}</h6>
                                            @endif
                                            @if($feature_data->feature_title == '100% Payment Secure')
                                            <i class="uil uil-shield-check align-middle h5 mb-0 me-2"></i>
                                             <h6 class="mb-0">{{translation($feature_data->feature_title)}}</h6>
                                            @endif
                                            @if($feature_data->feature_title == 'Support 24/7')
                                            <i class="uil uil-archive align-middle h5 mb-0 me-2"></i>
                                             <h6 class="mb-0">{{translation($feature_data->feature_title)}}</h6>
                                            @endif
                                        </div>
                                    </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
             @endif
            <!--end  website feature tag -->
      
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="footer-py-30 footer-border">
                            <div class="container text-center">
                                <div class="row align-items-center">
                                    <div class="col-sm-6">
                                        <div class="text-sm-start">
                                            <p class="mb-0">{{$copyRightText ?? ''}}</p>
                                        </div>
                                    </div><!--end col-->
        
                                    <div class="col-sm-6 mt-4 mt-sm-0 pt-2 pt-sm-0">
                                        <ul class="list-unstyled text-sm-end mb-0">
                                            @if(!empty($activePayList))
                                                @foreach ($activePayList as $payment)
                                                    <li class="list-inline-item">
                                                        {{-- <a href="javascript:void(0)"> --}}
                                                            <img class="payment-img avatar avatar-ex-sm" src="{{getSuperFullImageUrl($payment->method_logo)}}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="{{getSetting('site_title')}}-payment">
                                                        {{-- </a> --}}
                                                    </li>
                                                @endforeach
                                            @endif
                                        </ul>
                                    </div><!--end col-->
                                </div><!--end row-->
                            </div><!--end container-->
                        </div>
                    </div>
                </div>
            </div><!--end container-->
        </footer><!--end footer-->

        <!-- Popup Modal Start  -->
        <!-- Product View Start -->
        <div class="modal fade" id="productModalShow" tabindex="-1" aria-labelledby="productview-title" aria-hidden="true">
              <div class="modal-dialog  modal-lg modal-dialog-centered">
                 <div id="product-detail-modal"></div> 
               </div>     
        </div>
        <!-- Product View End -->

         @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))

        <!-- Wishlist Popup Start -->
        <div class="modal fade" id="wishlist" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content rounded shadow-lg border-0 overflow-hidden">
                    <div class="modal-body py-5 wishlist-body">
                        <div class="text-center">
                            <div class="icon d-flex align-items-center justify-content-center bg-soft-danger rounded-circle mx-auto" style="height: 95px; width:95px;">
                                <h1 class="mb-0 wish_list">
                                    @if($wishlist_count == 0)
                                        <i class="uil uil-heart-break align-middle"></i>
                                    @else
                                        <i class="uil uil-heart align-middle "></i>
                                    @endif
                                </h1>
                            </div>
                            <div class="mt-4 wislist_Div">
                                 @if($wishlist_count == 0)
                                <h4>Your wishlist is empty.</h4>
                                <p class="text-muted">{{translation('ADD_WISHLIST_PRODUCT')}}</p>
                                <a href="{{url('/')}}" class="btn btn-primary btn-sm btn-block" role="button" aria-pressed="true">{{translation('CONTINUE_TO_SHOP')}}</a>
                                @else
                                <div class="mt-4 ">
                                    <p class="text-muted t wishlist_count">There are  {{$wishlist_count}} item avaliable in your wishlist</p>
                                    <a href="{{url('wishlist')}}" class="btn btn-outline-primary"> {{translation('VIEW_WISHLIST')}}</a>
                                </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endif
        <!-- Wishlist Popup End -->

        <!-- Offcanvas Start -->
        {{-- <div class="offcanvas offcanvas-end shadow" tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel">
            <div class="offcanvas-header p-4 border-bottom">
                <h5 id="offcanvasRightLabel" class="mb-0">
                    <img src="assets/images/logo-dark.png" height="24" class="light-version" alt="">
                    <img src="assets/images/logo-light.png" height="24" class="dark-version" alt="">
                </h5>
                <button type="button" class="btn-close d-flex align-items-center text-dark" data-bs-dismiss="offcanvas" aria-label="Close"><i class="uil uil-times fs-4"></i></button>
            </div>
            <div class="offcanvas-body p-4">
                <div class="row">
                    <div class="col-12">
                        <img src="assets/images/contact.svg" class="img-fluid d-block mx-auto" style="max-width: 256px;" alt="">
                        <div class="card border-0 mt-5" style="z-index: 1">
                            <div class="card-body p-0">
                                <form method="post" name="myForm" id="myForm" onsubmit="return validateForm()">
                                    <p id="error-msg" class="mb-0"></p>
                                    <div id="simple-msg"></div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Your Name <span class="text-danger">*</span></label>
                                                <div class="form-icon position-relative">
                                                    <i data-feather="user" class="fea icon-sm icons"></i>
                                                    <input name="name" id="name" type="text" class="form-control ps-5" placeholder="Name :">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Your Email <span class="text-danger">*</span></label>
                                                <div class="form-icon position-relative">
                                                    <i data-feather="mail" class="fea icon-sm icons"></i>
                                                    <input name="email" id="email" type="email" class="form-control ps-5" placeholder="Email :">
                                                </div>
                                            </div> 
                                        </div>

                                        <div class="col-12">
                                            <div class="mb-3">
                                                <label class="form-label">Subject</label>
                                                <div class="form-icon position-relative">
                                                    <i data-feather="book" class="fea icon-sm icons"></i>
                                                    <input name="subject" id="subject" class="form-control ps-5" placeholder="subject :">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-12">
                                            <div class="mb-3">
                                                <label class="form-label">Comments <span class="text-danger">*</span></label>
                                                <div class="form-icon position-relative">
                                                    <i data-feather="message-circle" class="fea icon-sm icons clearfix"></i>
                                                    <textarea name="comments" id="comments" rows="4" class="form-control ps-5" placeholder="Message :"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="d-grid">
                                                <button type="submit" id="submit" name="send" class="btn btn-primary">Send Message</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> --}}
        <!-- Back to top -->
        <a href="#" onclick="topFunction()" id="back-to-top" class="back-to-top fs-5"><i data-feather="arrow-up" class="fea icon-sm icons align-middle"></i></a>
        <!-- Back to top -->
        <!--   Popup Modal End  -->
        <!-- Javascript -->
        <!-- Footer End -->
     
    

@push('scripts')
<script>
    $(document).ready(function() {

        $(document).on('submit', '#newslatterform', function(e) {
         e.preventDefault();
            $('#newslatterform').addClass('was-validated');
            if ($('#newslatterform')[0].checkValidity() === false) {
                event.stopPropagation();
            } 
            else {
                var data = {
                    'customer_email': $('.email').val(),
                }
                $.ajaxSetup({
                    headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "/newslatterstore",
                    data :data,
                    dataType:"json",
                    success: function(response) {
                        if(response.status==400){
                            $('.mail_error').text(response.error.customer_email);  
                        }
                        else{   
                            $('.email').val(),
                            $('.mail_error').text(""); 
                            Notify('{{translation('SUBSCRIBE_SUCCESS_MSG')}}', true);
                            $("#newslatterform").trigger("reset");
                            $("#newslatterform").removeClass('was-validated');
                        }             
                    }
                });
            }
        });
    });
</script>
@endpush