@php
$footermenu1=MenuKey("footer-menu-1");
$footermenu2=MenuKey("footer-menu-2");
@endphp
       <!-- Footer Start -->
        <footer class="footer">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-12">
                        <div class="footer-py-60 text-center">
                            <div class="row py-5">
                                <div class="col-md-4">
                                    <div class="card border-0 text-center features feature-primary feature-clean bg-transparent">
                                        <div class="icons text-center mx-auto">
                                            <i class="uil uil-phone d-block rounded h3 mb-0"></i>
                                        </div>
                                        <div class="content mt-4">
                                            <h5 class="footer-head">Phone</h5>
                                            <p class="text-muted">{!! (getSetting('footer_about_description'))? html_entity_decode(getSetting('footer_about_description')) : '' !!}</p>
                                            <a href="tel:{{ getSetting('contact_phone')}}" class="text-foot">{{ getSetting('contact_phone')}}</a>
                                        </div>
                                    </div>
                                </div><!--end col-->
                        
                                <div class="col-md-4 mt-4 mt-sm-0 pt-2 pt-sm-0">
                                    <div class="card border-0 text-center features feature-primary feature-clean bg-transparent">
                                        <div class="icons text-center mx-auto">
                                            <i class="uil uil-envelope d-block rounded h3 mb-0"></i>
                                        </div>
                                        <div class="content mt-4">
                                            <h5 class="footer-head">Email</h5>
                                            <p class="text-muted">{!! (getSetting('footer_about_description'))? html_entity_decode(getSetting('footer_about_description')) : '' !!}</p>
                                            <a href="mailto:{{ getSetting('contact_email') }}" class="text-foot"> {{ getSetting('contact_email')}}</a>
                                        </div>
                                    </div>
                                </div><!--end col-->
                        
                                <div class="col-md-4 mt-4 mt-sm-0 pt-2 pt-sm-0">
                                    <div class="card border-0 text-center features feature-primary feature-clean bg-transparent">
                                        <div class="icons text-center mx-auto">
                                            <i class="uil uil-map-marker d-block rounded h3 mb-0"></i>
                                        </div>
                                        <div class="content mt-4">
                                            <h5 class="footer-head">Address</h5>
                                            <p class="text-muted">{!! (getSetting('footer_about_description'))? html_entity_decode(getSetting('footer_about_description')) : '' !!}</p>
                                            <a href="mailto:contact@example.com" class="text-foot">{{ getSetting('contact_address')}}</a>
                                        </div>
                                    </div>
                                </div><!--end col-->
                            </div><!--end row-->
                        </div>
                    </div><!--end col-->
                </div><!--end row-->
            </div><!--end container-->

            <div class="footer-py-30 footer-bar bg-footer">
                <div class="container text-center">
                    <div class="row align-items-center justify-content-between">
                        <div class="col-lg-3 col-md-2 col-sm-3">
                            <div class="text-sm-start">
                                <a href="{{url('/')}}" class="logo-footer">
                                    <img src="{{getImageUrlWithKey('website_logo')}}" alt="{{getSetting('site_title')}}-logo" height="34"/>
                                </a>  
                            </div>
                        </div><!--end col-->
                        @if(!empty($footermenulist1))
                        <div class="col-lg-6 col-md-6 col-sm-6 mt-4 mt-sm-0 pt-2 pt-sm-0">
                            <ul class="list-unstyled footer-list terms-service mb-0">
                              @foreach($footermenulist1 as $key=>$value) 
                                <li class="list-inline-item mb-0"><a href="{{$value['link'] ?? ''}}" class="text-foot me-2">{{translation($value['name'] ?? '')}}</a></li>
                              @endforeach
                            </ul>
                        </div><!--end col-->
                        @endif 
                        <div class="col-lg-3 col-md-4 col-sm-3 mt-4 mt-sm-0 pt-2 pt-sm-0">
                            <div class="text-sm-end">
                                <p class="mb-0 text-foot">{{$copyRightText ?? ''}}</p>
                            </div>
                        </div><!--end col-->
                    </div><!--end row-->
                </div><!--end container-->
            </div>
        </footer><!--end footer-->
        <!-- Footer End -->

         <!-- Popup Modal Start  -->
        <!-- Product View Start -->
        <div class="modal fade" id="productModalShow" tabindex="-1" aria-labelledby="productview-title" aria-hidden="true">
              <div class="modal-dialog  modal-lg modal-dialog-centered">
                 <div id="product-detail-modal"></div> 
               </div>     
        </div>
        <!-- Product View End -->

         @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))

        <!-- Wishlist Popup Start -->
        <div class="modal fade" id="wishlist" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content rounded shadow-lg border-0 overflow-hidden">
                    <div class="modal-body py-5">
                        <div class="text-center">
                            <div class="icon d-flex align-items-center justify-content-center bg-soft-danger rounded-circle mx-auto" style="height: 95px; width:95px;">
                                <h1 class="mb-0">
                                    @if($wishlist_count == 0)
                                    <i class="uil uil-heart-break align-middle"></i>
                                    @else
                                    <i class="uil uil-heart align-middle"></i>
                                    @endif
                                </h1>
                            </div>
                            <div class="mt-4">
                                 @if($wishlist_count == 0)
                                <h4>Your wishlist is empty.</h4>
                                <p class="text-muted">Create your first wishlist request...</p>
                                <a href="{{url('/')}}" class="btn btn-primary btn-lg btn-block" role="button" aria-pressed="true">Continue to shop </a>
                                @else
                                <div class="mt-4">
                                    <p class="text-muted div_wishlist_count">There are {{$wishlist_count}} item avaliable in your wishlist</p>
                                    <a href="{{url('wishlist')}}" class="btn btn-outline-primary"> View Wishlist</a>
                                </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endif
        <!-- Wishlist Popup End -->
  
        
   <!-- Back to top -->
        <a href="#" onclick="topFunction()" id="back-to-top" class="back-to-top fs-5"><i data-feather="arrow-up" class="fea icon-sm icons align-middle"></i></a>
    <!-- Back to top -->
@push('scripts')
<script>
    $(document).ready(function() {

        $(document).on('submit', '#newslatterform', function(e) {
         e.preventDefault();
            $('#newslatterform').addClass('was-validated');
            if ($('#newslatterform')[0].checkValidity() === false) {
            event.stopPropagation();
            } else {
          var data = {
            'customer_email': $('.email').val(),
          }
          $.ajaxSetup({
            headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
          });
          $.ajax({
            type: "POST",
            url: "/newslatterstore",
            data :data,
            dataType:"json",
            success: function(response) {
             if(response.status==400)
            {
                $('.mail_error').text(response.error.customer_email);  
              
            }
            else
            {   
                $('.email').val(),
                $('.mail_error').text(""); 
                Notify('Subscribed Successfully', true);
                $("#newslatterform").trigger("reset");
                $("#newslatterform").removeClass('was-validated');
            }             
            }
           
          });
         }
        });
    });

</script>
@endpush