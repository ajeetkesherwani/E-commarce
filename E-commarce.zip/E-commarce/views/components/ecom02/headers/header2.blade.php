       <!-- Navbar STart -->
        <header id="topnav" class="defaultscroll sticky navbar-white-bg">
            <div class="container">
                <!-- Logo container-->
                <a class="logo" href="{{ url('/')}}">
                    <img src="{{ getImageUrlWithKey('website_logo') }}" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" height="50" class="logo-light-mode" alt="{{getSetting('site_title')}}-logo">
                    <img src="{{ getImageUrlWithKey('website_logo') }}" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" height="50" class="logo-dark-mode" alt="{{getSetting('site_title')}}-logo">
                </a>
                
                <!-- Logo End -->
        
                <!-- End Logo container-->
                <div class="menu-extras">
                    <div class="menu-item">
                        <!-- Mobile menu toggle-->
                        <a class="navbar-toggle" id="isToggle" onclick="toggleMenu()">
                            <div class="lines">
                                <span></span>
                                <span></span>
                                <span></span>
                            </div>
                        </a>
                        <!-- End mobile menu toggle-->
                    </div>
                </div>
        
                <!--Login button Start-->
                <ul class="buy-button list-inline mb-0">
                @if (webFunctionStatus(config('constkey.is_header_search_box_enabled')))
                    <li class="list-inline-item mb-0 pe-1">
                        <div class="dropdown">
                            <button type="button" class="btn dropdown-toggle p-0" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="uil uil-search text-dark fs-5 align-middle"></i>
                            </button>
                            <div class="dropdown-menu dd-menu dropdown-menu-end bg-white shadow rounded border-0 mt-3 p-0 search_list" style="width: 300px;">
                                <div class="search-bar">
                                    <div id="itemSearch" class="menu-search mb-0">
                                    <form role="search" method="get" id="searchform" class="search-drop needs-validation" novalidate>
                                            <input type="text" class="form-control border rounded " required id="searchtext"  placeholder="{{translation('SEARCH_ENTIRE_STORE_HERE')}}" autocomplete="off">
                                            <button type="submit" class="btn p-0" id="searchbutton">
                                                <i class="uil uil-search text-dark fs-5 align-middle"></i>
                                            </button>
                                        </form>
                                    </div>
                                    <div class="searchItem hide">
                                    <div class="searchItemList"></div>
                                    </div> 
                                </div>
                            </div>
                        </div>
                    </li>
                @endif
                @if (webFunctionStatus(config('constkey.is_user_registeration_enabled')))
                    <li class="list-inline-item mb-0">
                    <div class="dropdown dropdown-primary pe-1">
                            @guest  
                            <a href="{{ url('login') }}" type="button" class="btn btn-icon btn-pills btn-primary dropdown-toggle"><i data-feather="user" class="icons"></i></a>
                            
                            @endguest
                            @auth
                            <button type="button" class="btn btn-icon btn-pills btn-primary dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i data-feather="user" class="icons"></i></button>
                            <div class="dropdown-menu dd-menu dropdown-menu-end bg-white shadow rounded border-0 mt-3 py-3" style="width: 200px;">
                                    <a class="dropdown-item text-dark" href="{{ url('account/orders') }}"><i class="uil uil-clipboard-notes align-middle me-1"></i> Order History</a>
                                    <div class="dropdown-divider my-3 border-top"></div>
                                    <a class="dropdown-item text-dark" href="route('logout')" onclick="event.preventDefault();
                                    document.getElementById('myLogOutForm').submit();"><i class="uil uil-sign-out-alt align-middle me-1"></i> {{ translation('LOG_OUT') }}
                                    <form method="POST" id="myLogOutForm" action="{{ route('logout') }}">
                                            @csrf
                                    </form>
                                    </a>
                                
                            </div>
                            @endauth
                        </div>
                    </li>
                @endif
                    @if (webFunctionStatus(config('constkey.is_cart_enabled')))
                    <li class="list-inline-item ps-0 mb-0">
                        <a href="{{ url('cart')}}"> 
                            <div class="btn btn-icon btn-pills btn-primary"><i data-feather="shopping-cart" class="fea icon-sm"></i>
                            <span class="item-quantity-tag count-cart-total"><span class="item-quantity-tag">{{ $cart['total_count'] ?? '0'}}</span></span>                           
                            </div>
                        </a>
                    </li>
                    @endif
                    @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))
                        <li class="list-inline-item ps-1 mb-0">
                            <a href="{{url('wishlist')}}">
                                <div class="btn btn-icon btn-pills btn-primary"><i data-feather="heart" class="fea icon-sm"></i>
                                <span class="item-quantity-tag"><span class="item-quantity-tag count-wishlist-total">{{$wishlist_count}}</span></span>
                                </div>
                            </a>
                        </li>
                    @endif
                </ul>
                <!--Login button End-->
                @if(!empty($main_menu))
                <div id="navigation">
                    <!-- Navigation Menu-->   
                    <ul class="navigation-menu">
                        @foreach($main_menu as $key=>$value)
                            @if(in_array($value->menu_type, array('1', '2','3')) )
                                <li class="has-submenu parent-menu-item"{{$value->menu_ref_id=="0" ? 'class=menu-dropdown': '' }}>
                                    <a href="{{url($value->menu_ref_id=="0"? '#' : $value->menu_link)}}">{{translation($value->menu_name)}}
                                    </a>
                                    @if(!empty($value->menulist))
                                        <span class="menu-arrow"></span>
                                    @endif
                                    @if(!empty($value->menulist))
                                        <ul class="submenu">
                                            @foreach($value->menulist as $cmenu)
                                                @if(!empty($cmenu['title']))
                                                    <li class="has-submenu parent-menu-item">
                                                        <a href="{{url($cmenu['link'])}}"> 
                                                            {{translation($cmenu['title'])}} 
                                                        </a>
                                                        @if(!empty($cmenu['subcate']))
                                                            <span class="submenu-arrow"></span>
                                                        @endif
                                                        @if(!empty($cmenu['subcate']))
                                                            <ul class="submenu">
                                                                @foreach($cmenu['subcate'] as $smenu)
                                                                    <li>
                                                                        <a href="{{url($smenu['link'])}}" class="sub-menu-item">
                                                                            {{ translation($smenu['title']) }}
                                                                        </a>
                                                                    </li>
                                                                @endforeach
                                                            </ul>
                                                        @endif  
                                                    </li>
                                                @endif
                                            @endforeach
                                        </ul>
                                    @endif
                                </li>
                            @else
                                <li>
                                    <a href="{{url($value->menu_link)}}">{{translation($value->menu_name)}}</a>
                                </li>
                            @endif
                        @endforeach
                        <!-- Currency dropdownlist start -->
                        @if (count($Curr_arr) > 1)
                        <li class="has-submenu parent-menu-item">
                            <a href="javascript:void(0)">{{$defcurrency_data->currencies_code}} {{$defcurrency_data->symbol_left}}</a><span class="menu-arrow"></span>
                            <ul class="submenu">
                            @if(!empty($Curr_arr))
                              @foreach($Curr_arr as $key=>$data)
                                <li><a href="#" class="sub-menu-item">{{$data['name']}} {{$data['icon']}}</a></li>
                              @endforeach
                            @endif
                            </ul>
                        </li>
                        @endif
                        <!-- Currency dropdownlist end -->

                        <!-- Language dropdownlist start -->
                        @if (count($Lang_arr) > 1)
                        <li class="has-submenu parent-menu-item">
                            <a href="javascript:void(0)">{{$def_lang->languages_code}}</a><span class="menu-arrow"></span>
                            <ul class="submenu">
                            @if(!empty($Lang_arr))
                                @foreach($Lang_arr as $key=>$data)
                                <li><a href="{{ url('/lang/locale/'.$data['name']) }}" class="sub-menu-item"><img src="{{asset(config('constkey.flags_path').'/'.$data['name']. '.svg')}}" alt="N/F"  height="10" width="15"> {{$data['name']}}</a></li>
                              @endforeach
                            @endif
                            </ul>
                        </li>
                        @endif
                        <!-- Language dropdownlist end -->
                    </ul><!--end navigation menu-->
                </div><!--end navigation-->
                @endif
            </div><!--end container-->
        </header><!--end header-->
        <!-- Navbar End -->       

@push('scripts')
<script>
    $(document).ready(function () {
        $('#searchbutton').click(function (e) {
            e.preventDefault();
            var data = $('#searchtext').val();
            if(data == ''){
                Notify('Please enter some value for search!');exit;
            }else{
                window.location.href = "/search/" + data;
            }
        });

        $(document).on('keyup', '#searchtext', function (e) {
            e.preventDefault();
            var searchVal = $(this).val();

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $.ajax({
                url: '{{ route("SearchSuggestion") }}',
                method: 'POST',
                data: {
                    search: searchVal
                },
                success: function (response) {
                    console.log(response);
                    $('.searchItem').removeClass('hide');
                    $('.searchItemList').html(response.searchHtml);
                },
                error: function (error) {
                    Notify(error.message, false);
                }
            });
        });
        // hide search suggestion box
        $('.searchItemList').on('mouseleave', function (e) {
            $('.searchItem').addClass('hide');
        });

    });

    $(window).scroll(function () {
        $('.searchItem').addClass('hide');
    });

</script>
@endpush