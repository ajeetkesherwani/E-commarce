 <!-- Navbar Start -->
 <header id="topnav" class="defaultscroll sticky">
            <div class="container">
                <!-- Logo container-->
                <!-- <p>{{ getSetting('site_slogan') }}</p> -->
                <a class="logo" href="{{ url('/')}}">
                    <img src="{{ getImageUrlWithKey('website_logo') }}" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" height="50" class="logo-light-mode" alt="{{getSetting('site_title')}}-logo">
                    <img src="{{ getImageUrlWithKey('website_logo') }}" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" height="50" class="logo-dark-mode" alt="{{getSetting('site_title')}}-logo">
                </a>
                <!-- End Logo container-->

                <div class="menu-extras">
                    <div class="menu-item">
                        <!-- Mobile menu toggle-->
                        <a class="navbar-toggle" id="isToggle" onclick="toggleMenu()">
                            <div class="lines">
                                <span></span>
                                <span></span>
                                <span></span>
                            </div>
                        </a>
                        <!-- End mobile menu toggle-->
                    </div>
                </div>

                <ul class="buy-button list-inline mb-0">
                    @if (webFunctionStatus(config('constkey.is_header_search_box_enabled')))
                    <li class="list-inline-item mb-0 pe-1">
                        <div class="dropdown">
                            <button type="button" class="btn dropdown-toggle p-0" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="uil uil-search text-dark fs-5 align-middle"></i>
                            </button>
                            <div class="dropdown-menu dd-menu dropdown-menu-end bg-white shadow rounded border-0 mt-3 p-0" style="width: 300px;">
                                <div class="search-bar">
                                    <div id="itemSearch" class="menu-search mb-0">
                                        <form role="search" method="get" id="searchform" class="search-drop needs-validation" novalidate>
                                            <input type="text" class="form-control border rounded " required id="searchtext"  placeholder="{{translation('HEADER_SEARCH_PLACEHOLDER')}}" autocomplete="off">
                                            <button type="submit" id="searchbutton" class="btn p-0">
                                                <i class="uil uil-search text-dark fs-5 align-middle"></i>
                                            </button>
                                        </form>
                                    </div>
                                     <div class="searchItem hide">
                                     <div class="searchItemList"></div> 
                                  </div>
                                </div>
                            </div>
                        </div>        
                    </li>
                    @endif
                    <!--Seach Area End -->
                    @if (webFunctionStatus(config('constkey.is_cart_enabled')))
                    <li class="list-inline-item mb-0 amount-tag">
                        <div class="dropdown">
                            <button type="button" class="btn btn-icon btn-pills btn-primary dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i data-feather="shopping-cart" class="icons"></i>
                            <span class="item-quantity-tag"><span class="item-quantity-tag count-cart-total">{{ $cart['total_count'] ?? '0'}}</span></span>
                            </button>
                            <div id="cart-item-sidebar" class="dropdown-menu dd-menu dropdown-menu-end bg-white shadow rounded border-0 mt-3 p-2 popupDiv" style="width: 300px; overflow-y: scroll; height: 350px;">
                              <div>
                               @if($cart['total_count'] == 0)
                               <img src="{{ LoadAssets('assets/images/EmptyImages/Cart-Empty.jpg')}}" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" class="rounded mx-auto d-block" width="150px" height="120px" alt="{{getSetting('site_title')}} Cart-Empty">
                                <p class="h4 text-center text-dark mt-2">{{translation('EMPTY_CART_MSG')}}!</p>
                                <div class="text-center my-3">
                                <a href="{{url('/')}}" class="btn btn-primary btn-lg btn-block" role="button" aria-pressed="true">{{translation('CONTINUE_TO_SHOP')}} </a>
                                </div> 
                                @else
                                <div class="cartpopup">
                                    @if(!empty($cart))
                                    @foreach($cart['cart_list'] as $key=>$ca)
                                    <a href="{{url('product/'.$ca->product->product_slug)}}" class="d-flex align-items-center pb-2 mb-3 border-bottom" id="cart-total_{{$ca->cart_id}}" >
                                        <img src="{{getFullImageUrl($ca->product->product_image)}}" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" alt="{{ $ca->product->products_name ?? ''}}" class="shadow rounded" style="max-height: 64px;">
                                        <div class="flex-1 text-start ms-2 me-2">
                                            <h6 class="text-dark mb-0">{{Str::limit( $ca->product->products_name,30) }}</h6>
                                            <p class="text-muted mb-0 ">
                                        @php
                                            $qty = (int) $ca->qty;
                                            $price =$ca->final_price ?? 0;
                                            $total_price = $ca->final_price * $ca->qty;   
                                        @endphp
                                            {{ currencyFormat($price) }} x <span class="cart_popupQty_{{$ca->cart_id}}">{{$qty}}</span>
                                           </p>
                                        </div>
                                        <h6 class="text-dark mb-0 total_price_{{$ca->cart_id}}"> {{ currencyFormat($total_price) }}</h6>
                                    </a>
                                     @endforeach
                                   @endif
                                </div>
                                <div class="d-flex align-items-center justify-content-between pt-1">
                                    <h6 class="text-dark mb-0">{{translation('CART_TOTAL')}}</h6>
                                    <h6 class="text-dark mb-0 popup_cartTotal">{{ currencyFormat($cart['grand_total'] ?? '')}}</h6>
                                </div>
                                </div>
                                <div class="mt-3 text-center">
                                    <a href="{{ url('cart')}}" class="btn btn-primary me-2">{{translation('VIEW_CART')}}</a>
                                    <a href="{{ url('checkout') }}" class="btn btn-primary">{{translation('CHECKOUT')}}</a>
                                </div>
                                {{-- <p class="text-muted text-start mt-1 mb-0">{{translation('TERMS_AND_CONDITION')}}</p> --}}
                                @endif
                            </div>
                        </div>     
                    </li>
                    @endif
                    @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))
                    <li class="list-inline-item mb-0">
                        <div class="dropdown">
                            <button type="button" class="btn btn-icon btn-pills btn-primary dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i data-feather="heart" class="icons"></i>
                            <span class="item-quantity-tag"><span class="item-quantity-tag count-wishlist-total">{{$wishlist_count ?? '0'}}</span></span>
                            </button>
                            <div id="cart-item-sidebar" 
                                class="dropdown-menu dd-menu dropdown-menu-end bg-white shadow rounded border-0 mt-3 p-2" style="width: 300px; overflow-y: scroll; height: 280px;">
                                <div style="height: 95px; width:95px;"
                                    class="icon d-flex align-items-center justify-content-center bg-soft-danger rounded-circle mx-auto" >
                                    <h1 class="mb-0 wish_list">
                                        @if($wishlist_count == 0)
                                            <i class="uil uil-heart-break align-middle"></i>
                                        @else
                                            <i class="uil uil-heart align-middle "></i>
                                        @endif
                                    </h1>
                                </div>
                                <div class="mt-4 wislist_Div">
                                    @if($wishlist_count == 0)
                                        <h5 class="text-center">{{translation('EMPTY_WISHLIST_MSG')}}</h5>
                                        <p class="text-muted text-center">
                                            Create your first wishlist request
                                        </p>
                                        <a href="{{url('/')}}" class="btn btn-primary btn-block" role="button" aria-pressed="true">{{translation('CONTINUE_TO_SHOP')}}</a>
                                    @else
                                        <div class="mt-4 ml-3">
                                            <p class="text-center text-muted t wishlist_count">

                                                There are  {{$wishlist_count}} item avaliable in your wishlist</p>
                                            <a href="{{url('wishlist')}}" class="text-center btn btn-outline-primary"> 
                                                {{translation('VIEW_WISHLIST')}}
                                            </a>
                                        </div>
                                   @endif
                               </div>
                            </div>
                    </li>
                    @endif
                    {{-- registration enable / disable --}}
                    @if (webFunctionStatus(config('constkey.is_user_registeration_enabled')))
                    <li class="list-inline-item mb-0">
                        <div class="dropdown dropdown-primary pe-1">
                            @guest  
                            <a href="{{ url('login') }}" type="button" class="btn btn-icon btn-pills btn-primary dropdown-toggle"><i data-feather="user" class="icons"></i></a>
                            
                            @endguest
                            @auth
                            <button type="button" class="btn btn-icon btn-pills btn-primary dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i data-feather="user" class="icons"></i></button>
                            <div class="dropdown-menu dd-menu dropdown-menu-end bg-white shadow rounded border-0 mt-3 py-3" style="width: 200px;">
                                    <a class="dropdown-item text-dark" href="{{ url('account/orders') }}"><i class="uil uil-clipboard-notes align-middle me-1"></i> {{translation('ORDER_HISTORY')}}</a>
                                    <div class="dropdown-divider my-3 border-top"></div>
                                    <a class="dropdown-item text-dark" href="route('logout')" onclick="event.preventDefault();
                                    document.getElementById('myLogOutForm').submit();"><i class="uil uil-sign-out-alt align-middle me-1"></i> {{ translation('LOGOUT') }}
                                    <form method="POST" id="myLogOutForm" action="{{ route('logout') }}">
                                            @csrf
                                    </form>
                                    </a>    
                            </div>
                            @endauth
                        </div>
                    </li>
                    @endif

                    <!-- Currency dropdownlist start -->
                    @if (count($Curr_arr) > 1)
                      <li class="list-inline-item mb-0">
                        <div class="dropdown dropdown-primary pe-2">
                            <button type="button" class="btn btn-icon btn-pills btn-primary dropdown-toggle" style="width: 73px;" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">{{$defcurrency_data->currencies_code}} {{$defcurrency_data->symbol_left}}</button>
                            @if(!empty($Curr_arr))
                              @foreach($Curr_arr as $key=>$data)
                                <div class="dropdown-menu dd-menu dropdown-menu-end bg-white shadow rounded border-0 mt-3 py-3" style="width: 200px;">
                                   <a class="dropdown-item text-dark" href="#"> {{$data['name']}} {{$data['icon']}}</a>
                                </div>
                              @endforeach
                            @endif
                        </div>
                    </li>
                    @endif
                    <!-- Currency dropdownlist end -->
                    
                    <!-- Language dropdownlist start -->
                     @if (count($Lang_arr) > 1)
                      <li class="list-inline-item mb-0">
                        <div class="dropdown dropdown-primary">
                            <button type="button" class="btn btn-icon btn-pills btn-primary dropdown-toggle" data-bs-toggle="dropdown" style="width: 73px;" aria-haspopup="true" aria-expanded="false">{{$def_lang->languages_code}}</i></button>
                            <div class="dropdown-menu dd-menu dropdown-menu-end bg-white shadow rounded border-0 mt-3 py-3" style="width: 200px;">
                                @if(!empty($Lang_arr))
                                    @foreach($Lang_arr as $key=>$data)
                                <a class="dropdown-item text-dark" href="{{ url('/lang/locale/'.$data['name']) }}"><img src="{{asset(config('constkey.flags_path').'/'.$data['name']. '.svg')}}" alt="N/F"  height="10" width="15"> {{$data['name']}}</a>
                                @endforeach
                                    @endif
                            </div>
                        </div>
                    </li>
                     @endif
                     <!-- Language dropdownlist end -->
                </ul><!--end login button-->
                @if(!empty($main_menu))
                <div id="navigation">
                    <!-- Navigation Menu-->   
                    <ul class="navigation-menu">
                        @foreach($main_menu as $key=>$value)
                            @if(in_array($value->menu_type, array('1', '2','3')) )
                                <li class="has-submenu parent-menu-item"{{$value->menu_ref_id=="0" ? 'class=menu-dropdown': '' }}>
                                    <a href="{{url($value->menu_ref_id=="0"? '#' : $value->menu_link)}}"> {{$value->menu_name}}</a>
                                    @if(!empty($value->menulist)) 
                                        <span class="menu-arrow"></span>
                                    @endif

                                    @if(!empty($value->menulist))
                                        <ul class="submenu">
                                            @foreach($value->menulist as $cmenu)
                                                @if(!empty($cmenu['title']))
                                                    <li class="has-submenu parent-menu-item"><a href="{{url($cmenu['link'])}}">{{$cmenu['title']}} </a>
                                                        @if(!empty($cmenu['subcate']))
                                                            <span class="submenu-arrow"></span>
                                                        @endif
                                                        @if(!empty($cmenu['subcate']))
                                                            <ul class="submenu">
                                                                @foreach($cmenu['subcate'] as $smenu)
                                                                    <li>
                                                                        <a href="{{url($smenu['link']) }}" class="sub-menu-item">
                                                                            {{$smenu['title']}}
                                                                        </a>
                                                                    </li>
                                                                @endforeach
                                                            </ul>
                                                        @endif  
                                                    </li>
                                                @endif
                                            @endforeach
                                        </ul>
                                    @endif
                                </li>
                            @else
                                <li>
                                    <a href="{{url($value->menu_link)}}">
                                        {{$value->menu_name}}
                                    </a>
                                </li>
                            @endif
                        @endforeach
                    </ul><!--end navigation menu-->
                </div><!--end navigation-->
                @endif
            </div><!--end container-->
        </header><!--end header-->
        <!-- Navbar End -->

@push('scripts')
<script>
    $(document).ready(function () {
        $('#searchbutton').click(function (e) {
            e.preventDefault();
            var data = $('#searchtext').val();
            if(data == ''){
                Notify('{{translation('ERROR_SEARCH_MSG')}}!');exit;
            }else{
                window.location.href = "/search/" + data;
            }
        });

        $(document).on('keyup', '#searchtext', function (e) {
            e.preventDefault();
            var searchVal = $(this).val();

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $.ajax({
                url: '{{ route("SearchSuggestion") }}',
                method: 'POST',
                data: {
                    search: searchVal
                },
                success: function (response) {
                    $('.searchItem').removeClass('hide');
                    $('.searchItemList').html(response.searchHtml);
                },
                error: function (error) {
                    Notify(error.message, false);
                }
            });
        });
        // hide search suggestion box
        $('.searchItemList').on('mouseleave', function (e) {
            $('.searchItem').addClass('hide');
        });

    });

    $(window).scroll(function () {
        $('.searchItem').addClass('hide');
    });

</script>
@endpush