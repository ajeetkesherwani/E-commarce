@foreach($web_features as $key=>$feature_data)
<div class="col-lg-3 col-xs-12 col-md-6 col-sm-6">
    <div class="single-static pb-res-md-0 pb-res-sm-0 pb-res-xs-0">
        <img src="{{getFullImageUrl($feature_data->feature_icon)}}"
            alt="{{getSetting('site_title')}}-{{$feature_data->feature_title}}"
            onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
            class="img-responsive" />
        <div class="single-static-meta">
            <h4>{{$feature_data->feature_title}}</h4>
            <p>{{$feature_data->feature_subtitle}}</p>
        </div>
    </div>
</div>
@endforeach
