<!-- Start testimonials -->
@if ($testimonial_data->isNotEmpty()) 
<div class="tiny-three-item">
@foreach ($testimonial_data as $key => $data)
    <div class="tiny-slide">
        <div class="d-flex client-testi m-1">
            <img src="{{ $data->user_data->profile_photo ?? asset('images/testimonial.webp') }}" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" alt="{{ getSetting('site_title') }}-Use" class="avatar avatar-small client-image rounded shadow"/>
            <div class="card flex-1 content p-3 shadow rounded position-relative">
                <p class="text-muted mt-2">{{ Str::limit($data->testimonial_text, 120) }}</p>
                <h6 class="text-primary">
                    {{ !empty($data->user_data) ? $data->user_data->first_name : '' }}
                    {{ !empty($data->user_data) ? $data->user_data->last_name : '' }}
                    <small class="text-muted">
                        {{ !empty($data->user_data) ? $data->user_data->email : '' }}
                    </small>
                </h6>
            </div>
        </div>
    </div>
@endforeach
</div>
@endif
<!-- Testimonial  End -->
