<!-- ======================== Banner Layout  =========================== -->
@if(!empty($banner_data))
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12  mt-4 pt-2"> 
                <div class="card shop-features border-0 rounded overflow-hidden text-center">
                    <a href="{{$banner_data->banners_url}}">
                        <img src="{{getFullImageUrl($banner_data->banners_image)}}"
                        onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="{{$banner_data->banners_title}}" class="img-fluid"  />
                    </a>
                </div>               
            </div>
        </div>
    </div>
@endif