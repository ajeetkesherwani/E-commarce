<form id="newslatterform" class="validate needs-validation" novalidate=""  name="mc-embedded-subscribe-form" method="post">
    @csrf
    <div class="row">
        <div class="col-lg-12">
            <div class="foot-subscribe mb-3 text-start">
                <label class="form-label">{{translation('NAME')}}<span class="text-danger">*</span></label>
                <div class="form-icon position-relative">
                    <i data-feather="mail" class="fea icon-sm icons"></i>
                    <input type="text" name="customer_email" class="form-control ps-5 rounded email subscriber_name" placeholder="{{translation('NAME_PLACEHOLDER')}}" value="" required>
                        <p class="text-danger subscriber_name_error" style="font-size:16px;"></p>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="foot-subscribe mb-3 text-start">
                <label class="form-label">{{translation('EMAIL')}}<span class="text-danger">*</span></label>
                <div class="form-icon position-relative">
                    <i data-feather="mail" class="fea icon-sm icons"></i>
                    <input type="email" name="customer_email" class="form-control ps-5 rounded email" placeholder="{{translation('NEWSLETTER_EMAIL_PLACEHOLDER')}}" value="" required>
                        <p class="text-danger mail_error" style="font-size:16px;"></p>
                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="d-grid">
                <input type="submit" id="mc-embedded-subscribe" name="subscribe" class="btn btn-soft-primary" value="{{translation('SIGN_UP')}}">
                <input type="reset" hidden id="configreset" value="Reset">
            </div>
        </div>
    </div>
</form>
