@if (!empty($brand_data))
<div class="tiny-brand">
    @foreach($brand_data as $key=>$data)
        @if(empty($data->brand_slug))
            {{brandIDtoSlug($data->brand_id)}}
        @endif
        <a href="{{url('brand/'.$data->brand_slug ?? '')}}"> 
            <div class="tiny-slide">
            <div class="card shop-list border-0 position-relative m-2">
                <div class="position-relative overflow-hidden">
                    <img src="{{getFullImageUrl($data->brand_icon)}}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="{{$data->brand_name}}" class="img-fluid" style="height: 115px;" />
                    </div>
                </div>
            </div>
        </a>
    @endforeach
</div>
@endif
