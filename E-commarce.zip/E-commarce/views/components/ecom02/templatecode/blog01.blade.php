@if (!empty($blog_data) && sizeof($blog_data)>0)
@foreach ($blog_data->take(3) as $blog)
    <div class="col-lg-4 col-md-6 mt-4 pt-2 d-flex blog-wrapper">
        <div class="card blog blog-primary rounded border-0 shadow overflow-hidden">
            <div class="position-relative">
                <a href="{{ url('blog/'.$blog->slug) }}">
                <img src="{{getFullImageUrl($blog->img) ?? LoadAssets('assets/images/blog-image/blog-16.jpg') }} " onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="{{getSetting('site_title')}} Not-Found"  class="card-img-top img-fluid" >
                </a>
                    <a class="overlay rounded-top" href="{{ url('blog/'.$blog->slug) }}"></a>
            </div>
            <div class="card-body content px-3 py-4 text-start">
                <h5><a href="{{ url('blog/'.$blog->slug) }}" class="card-title  text-dark">{{ $blog->post_title ?? ''}}</a></h5>
                <div class="post-meta">
                    <ul class="list-unstyled mb-0">
                        <li class="list-inline-item me-2 mb-0"><a href="javascript:void(0)" class="text-muted like">{!! Str::limit($blog->post_excerpt ?? '',50) !!}</a></li>
                    </ul>
                    <a href="{{ url('blog/'.$blog->slug) }}" class="readmore">{{translation('READ_MORE')}}<i class="uil uil-angle-right-b align-middle"></i></a>
                </div>
            </div>
            <div class="author">
                <small class="date">
                    <i class="uil uil-calendar-alt"></i>
                    @php
                        echo(date('d F,Y', strtotime($blog->created_at ?? '')));
                    @endphp
                </small>
            </div>
        </div>
    </div>
@endforeach
<div class="col-12 mt-4 pt-2 pb-4">
    <div class="text-center">
        <a href="{{ url('blog') }}" class="btn btn-primary">{{ translation('BLOGS_SEE_MORE') }} <i data-feather="arrow-right" class="fea icon-sm"></i></a>
    </div>
</div>
@endif