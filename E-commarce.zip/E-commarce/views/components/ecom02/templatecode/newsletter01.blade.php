<div class="col-lg-3 col-md-6 col-12 mt-4 mt-lg-0 pt-2 pt-lg-0">
    <h5 class="footer-head">{{translation('NEWS_LETTER')}}</h5>
    <p class="mt-4">{!! getSetting('footer_newsletter_info') ?? '' !!}</p>
        <form id="newslatterform" class="validate needs-validation" novalidate=""  name="mc-embedded-subscribe-form" method="post">
        @csrf
        <div class="row">
            <div class="col-lg-12">
                <div class="foot-subscribe mb-3">
                    <label class="form-label">{{translation('EMAIL')}}<span class="text-danger">*</span></label>
                    <div class="form-icon position-relative">
                        <i data-feather="mail" class="fea icon-sm icons"></i>
                        <input type="email" name="customer_email" class="form-control ps-5 rounded email" placeholder="{{translation('NEWSLETTER_EMAIL_PLACEHOLDER')}}" value="" required>
                            <p class="text-danger mail_error" style="font-size:20px;"></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="d-grid">
                    <input type="submit" id="mc-embedded-subscribe" name="subscribe" class="btn btn-soft-primary" value="{{translation('SIGN_UP')}}">
                    <input type="reset" hidden id="configreset" value="Reset">
                </div>
            </div>
        </div>
    </form>
</div><!--end col-->
