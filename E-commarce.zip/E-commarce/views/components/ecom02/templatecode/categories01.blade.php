@if (!empty($popular_category) && sizeof($popular_category) > 0 )
    @if (!empty($popular_category) && sizeof($popular_category) > 0 )
        <!-- Start Categories -->
        <div class="tiny-four-item">
            @foreach($popular_category as $key=>$value)
                <div class="col-lg-2 col-md-4 col-6">
                    <div class="card features feature-primary explore-feature border-0 rounded text-center">
                        <div class="card-body">
                        <a href="{{ App\Models\Ecom\Services\EcomService::url($value->categories_id , 'category')}}">
                            <img src="{{getFullImageUrl($value->categories_image)}}"
                            alt="{{$value->category_name ?? ''}}" 
                            onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" class="avatar avatar-small rounded-circle shadow-md"/>
                        </a>           
                            <div class="content mt-2">
                                <h6 class="mb-0"><a href="{{url('category/'.$value->categories_slug)}}" class="text-dark">{{$value->category_name ?? 'Test cat'}}</a></h6>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    <!-- End popular Categories -->
    @endif
@endif