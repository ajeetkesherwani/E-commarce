@php
use App\Models\Ecom\Services\EcomService;
use App\Models\WishList;
$wishlistAry = WishList::getProductsAry();
@endphp

@if(!empty($featureGroupList))
@foreach($featureGroupList as $featureGroup)
@if(!empty($featureGroup->featured_product) && sizeof($featureGroup->featured_product) > 0 )
<div class="container mt-100 mt-60">
    <div class="row">
        <div class="col-12">
            <h3 class="mb-0">{{$featureGroup->group_name}}</h3>
        </div><!--end col-->

        <!-------------------- Grid View Start------------------------>
        @if($viewType == 'grid')
            <div class="col-12 mt-2">
                <div class="tiny-four-item">
                @foreach ($featureGroup->featured_product as $featured_product )
                    @if(!empty($featured_product->product))
                        @php
                        $avgrating=AvgRating($featured_product->product->product_id);
                        @endphp
                        <div class="tiny-slide">
                            <div class="card shop-list border-0 position-relative m-2">
                                <ul class="label list-unstyled mb-0">
                                @if(!empty($featured_product->product->feature_name))
                                    @foreach($featured_product->product->feature_name as $productFeature)
                                    <li>  
                                        <a href="javascript:void(0)" class="badge badge-link rounded-pill bg-danger"> {{$productFeature}} </a>     
                                    </li>
                                    @endforeach
                                @endif     
                                </ul>
                                <div class="shop-image position-relative overflow-hidden rounded shadow">
                                <a href="{{ EcomService::url($featured_product->product->product_id , 'product')}}">
                                    <img src="{{getFullImageUrl($featured_product->product->product_image)}}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="{{$product->products_name ?? ''}}" class="img-fluid">
                                </a>
                                <a href="{{ EcomService::url($featured_product->product->product_id , 'product')}}" class="overlay-work">
                                    <img src="{{getFullImageUrl($featured_product->product->product_image)}}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="{{$featured_product->product->products_name ?? ''}}" class="img-fluid">
                                </a>
                                <ul class="list-unstyled shop-icons">
                                    @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))
                                    <li>
                                    <a href="javascript:void(0)" onclick="addToWishListFromDetail({{ $featured_product->product->product_id }})" title="wishlist"
                                        class="btn btn-icon btn-pills btn-soft-danger">
                                        <i data-feather="heart" class="icons">
                                        </i>
                                    </a>
                                    </li>
                                    @endif
                                    @if (webFunctionStatus(config('constkey.is_cart_enabled')))
                                    <li class="mt-2">
                                    <a href="javascript:void(0)" class="btn btn-icon btn-pills btn-soft-primary quick_view"
                                        onclick="showfunction('{{ $featured_product->product->product_slug }}')" title="Quick View">
                                        <i data-feather="eye" class="icons">
                                        </i>
                                    </a>
                                    </li>
                                    @endif
                                    <li class="mt-2">
                                    <a href="{{ url('product/'.$featured_product->product->product_slug) }}" class="btn btn-icon btn-pills btn-soft-warning">
                                        <i data-feather="shopping-cart" class="icons">
                                        </i>
                                    </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="card-body content pt-4 p-2">
                            <a href="{{ url('product/'.$featured_product->product->product_slug) }}" class="text-dark product-name h6"
                                title="{{ $featured_product->product->products_name ?? '' }}">{{ Str::limit($featured_product->product->products_name ?? '',50) }}
                                </a>
                                <div class="d-flex justify-content-between mt-1">
                                    
                                @if($featured_product->product->products_prices!=null)
                                    @foreach($featured_product->product->products_prices as $holeprice)
                                        <h6 class=" small mb-0 mt-1">
                                        @if($holeprice->discount_percent !='0')
                                            <del class="text-danger ms-2">
                                            {{currencyFormat($holeprice->max_sale_price) }}
                                            </del>
                                        @endif
                                        <span>
                                            {{ currencyFormat($holeprice->sale_price ?? '0.00') }} 
                                        </span>
                                        <span>
                                            / {{$holeprice->product_qty}} Unit
                                        </span>
                                        @if($holeprice->discount_percent != '0')
                                            <span class="text-success ms-1">
                                                {{ currencyFormat( $holeprice->discount_percent )}}% {{translation('PRODUCT_DISCOUNT')}}
                                            </span>
                                        @endif
                                        </h6>
                                    @break
                                    @endforeach
                                @else
                                    <h6 class=" small mb-0 mt-1">
                                    @if($featured_product->product->discount_type != 'no')
                                        <del class="text-danger ms-2">
                                        {{currencyFormat($featured_product->product->max_sale_price) }}
                                        </del>
                                    @endif
                                    {{ currencyFormat($featured_product->product->sale_price ?? '0.00') }} 
                                    @if($featured_product->product->discount_type != 'no')
                                        @if($featured_product->product->discount_type == 'flat')
                                        <span class="text-success ms-1">
                                            {{ currencyFormat($featured_product->product->discount_amount) }} {{translation('PRODUCT_DISCOUNT')}}
                                        </span>
                                        @else
                                        <span class="text-success ms-1">
                                            {{ currencyFormat( $featured_product->product->discount_amount )}}% {{translation('PRODUCT_DISCOUNT')}}
                                        </span>
                                        @endif
                                    @endif
                                    </h6>
                                @endif

                                <ul class="list-unstyled text-warning mb-0">
                                    <li class="list-inline-item">
                                    @if(!empty($avgrating))
                                        @for($i=0;$i<5;$i++) 
                                            @if($i<$avgrating) 
                                            <i class="mdi mdi-star"></i>
                                            @else
                                            <i class="mdi mdi-star-outline"></i>
                                            @endif
                                        @endfor
                                    @endif
                                    </li>
                                </ul>
                                </div>
                            </div>
                            </div>
                        </div>
                    @endif
                @endforeach 
                </div>
            </div><!--end col-->
        @endif
        <!-------------------- Grid View End------------------------>

        <!----------- List View Start------------------------>
        @if($viewType == 'list')
            @foreach ($featureGroup->featured_product as $featured_product )
                @if(!empty($featured_product->product))
                    @php
                        $avgrating=AvgRating($featured_product->product->product_id);
                    @endphp
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 mt-4 pt-2">
                        <div class="card shop-list border-0 shadow position-relative">
                            <ul class="label list-unstyled mb-0">
                                @if(!empty($featured_product->product->feature_name))
                                @foreach($featured_product->product->feature_name as $productFeature)
                                <li>  
                                    <a href="javascript:void(0)" class="badge badge-link rounded-pill bg-danger">
                                        {{$productFeature}}
                                    </a>     
                                </li>
                                @endforeach
                                @endif
                            </ul>
                            <div class="row align-items-center g-0">
                            <div class="col-lg-4 col-md-6">
                                <div class="shop-image position-relative overflow-hidden">
                                <a href="{{ EcomService::url($featured_product->product->product_id , 'product')}}">
                                    <img src="{{getFullImageUrl($featured_product->product->product_image)}}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                                    alt="{{$featured_product->product->products_name ?? ''}}" class="img-fluid first-img"></a>
                                </div>
                            </div>
                            <!--end col-->

                            <div class="col-lg-8 col-md-6">
                                <div class="card-body content p-4">
                                <a href="{{ EcomService::url($featured_product->product->product_id , 'product')}}" class="text-dark product-name h6">
                                    {{$featured_product->product->products_name ?? '' }}
                                </a>
                                <div class="d-lg-flex align-items-center mt-2 mb-3">
                                    
                                    @if($featured_product->product->products_prices!=null)
                                        @foreach($featured_product->product->products_prices as $holeprice)
                                            <h6 class=" small mb-0 mt-1">
                                            @if($holeprice->discount_percent !='0')
                                                <del class="text-danger ms-2">
                                                {{currencyFormat($holeprice->max_sale_price) }}
                                                </del>
                                            @endif
                                            <span>
                                                {{ currencyFormat($holeprice->sale_price ?? '0.00') }} 
                                            </span>
                                            <span>
                                                / {{$holeprice->product_qty}} Unit
                                            </span>
                                            @if($holeprice->discount_percent != '0')
                                                <span class="text-success ms-1">
                                                    {{ currencyFormat( $holeprice->discount_percent )}}% {{translation('PRODUCT_DISCOUNT')}}
                                                </span>
                                            @endif
                                            </h6>
                                        @break
                                        @endforeach
                                    @else
                                        <h6 class=" small mb-0 mt-1">
                                        @if($featured_product->product->discount_type != 'no')
                                            <del class="text-danger ms-2">
                                            {{currencyFormat($featured_product->product->max_sale_price) }}
                                            </del>
                                        @endif
                                        {{ currencyFormat($featured_product->product->sale_price ?? '0.00') }} 
                                        @if($featured_product->product->discount_type != 'no')
                                            @if($featured_product->product->discount_type == 'flat')
                                            <span class="text-success ms-1">
                                                {{ currencyFormat($featured_product->product->discount_amount) }} {{translation('PRODUCT_DISCOUNT')}}
                                            </span>
                                            @else
                                            <span class="text-success ms-1">
                                                {{ currencyFormat( $featured_product->product->discount_amount )}}% {{translation('PRODUCT_DISCOUNT')}}
                                            </span>
                                            @endif
                                        @endif
                                        </h6>
                                    @endif

                                    <ul class="list-unstyled text-warning mb-0">
                                    @if(!empty($avgrating))
                                        @for($i=0;$i<5;$i++) 
                                            @if($i<$avgrating) 
                                                <li class="list-inline-item"><i class="mdi mdi-star"></i></li>
                                            @else
                                                <li class="list-inline-item"><i class="mdi mdi-star-outline"></i></li>
                                            @endif
                                        @endfor
                                    @endif
                                    </ul>
                                </div>
                                <p class="para-desc text-muted mb-1">{!! Str::limit($featured_product->product->products_description ?? '',150) !!}</p>

                                @foreach($featured_product->product->products_to_features as $featKey=>$featVal)
                                    <p class="para-desc text-muted mb-1">
                                        {{$featVal->feature_title ?? ''}}: 
                                        {{$featVal->feature_value ?? ''}}
                                    </p>
                                @endforeach
                                <ul class="list-unstyled mb-0">
                                    <li class="list-inline-item">
                                        <a href="javascript:void(0)" class="btn btn-icon btn-pills btn-soft-primary">
                                            <i data-feather="heart" onclick="addToWishListFromDetail({{ $featured_product->product->product_id }})" title="Wishlist"  class="icons">
                                            </i>
                                        </a>
                                        </li>
                                    <li class="mt-2 list-inline-item">
                                        <a href="javascript:void(0)" onclick="showfunction('{{ $featured_product->product->product_slug }}')" class="btn btn-icon btn-pills btn-soft-primary">
                                            <i data-feather="eye" class="icons"></i>
                                        </a>
                                    </li>
                                    <li class="mt-2 list-inline-item"><a href="{{ url('cart')}}"
                                        class="btn btn-icon btn-pills btn-soft-primary"><i data-feather="shopping-cart" class="icons"></i></a>
                                    </li>
                                </ul>
                                </div>
                            </div>
                            <!--end col-->
                            </div>
                            <!--end row-->
                        </div>
                        <!--end blog post-->
                    </div>
                @endif
            @endforeach
        @endif
        <!----------- List View End------------------------>


        <!----------- Slider View Start ------------------------>
        @if($viewType == 'slider')
            <div class="col-12 mt-2">
                <div class="tiny-four-item">
                    @foreach ($featureGroup->featured_product as $featured_product )
                        @if(!empty($featured_product->product))
                            <div class="tiny-slide">
                                <div class="card shop-list border-0 position-relative m-2">
                                    <ul class="label list-unstyled mb-0">
                                    @if(!empty($featured_product->product->feature_name))
                                        @foreach($featured_product->product->feature_name as $productFeature)
                                        <li>  
                                            <a href="javascript:void(0)" class="badge badge-link rounded-pill bg-danger"> {{$productFeature}} </a>     
                                        </li>
                                        @endforeach
                                    @endif     
                                    </ul>
                                    <div class="shop-image position-relative overflow-hidden rounded shadow">
                                        <a href="{{ EcomService::url($featured_product->product->product_id , 'product')}}">
                                        <img src="{{getFullImageUrl($featured_product->product->product_image)}}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="{{$featured_product->product->products_name ?? ''}}" class="img-fluid">
                                        </a>
                                        <a href="{{ EcomService::url($featured_product->product->product_id , 'product')}}" class="overlay-work">
                                        <img src="{{getFullImageUrl($featured_product->product->product_image)}}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="{{$featured_product->product->products_name ?? ''}}" class="img-fluid">
                                        </a>
                                        <ul class="list-unstyled shop-icons">
                                        @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))
                                        <li>
                                            <a href="javascript:void(0)" onclick="addToWishListFromDetail({{ $featured_product->product->product_id }})" title="wishlist"
                                            class="btn btn-icon btn-pills btn-soft-danger">
                                            <i data-feather="heart" class="icons">
                                            </i>
                                            </a>
                                        </li>
                                        @endif
                                        @if (webFunctionStatus(config('constkey.is_cart_enabled')))
                                        <li class="mt-2">
                                            <a href="javascript:void(0)" class="btn btn-icon btn-pills btn-soft-primary quick_view"
                                            onclick="showfunction('{{$featured_product->product->product_slug }}')" title="Quick View">
                                            <i data-feather="eye" class="icons">
                                            </i>
                                            </a>
                                        </li>
                                        @endif
                                        <li class="mt-2">
                                            <a href="{{ url('product/'.$featured_product->product->product_slug) }}" class="btn btn-icon btn-pills btn-soft-warning">
                                            <i data-feather="shopping-cart" class="icons">
                                            </i>
                                            </a>
                                        </li>
                                        </ul>
                                    </div>
                                    <div class="card-body content pt-4 p-2">
                                    <a href="{{ url('product/'.$featured_product->product->product_slug) }}" class="text-dark product-name h6"
                                        title="{{ $featured_product->product->products_name ?? '' }}">{{ Str::limit($featured_product->product->products_name  ?? '',50) }}
                                    </a>
                                    <div class="d-flex justify-content-between mt-1">
                                        @if($featured_product->product->products_prices!=null)
                                            @foreach($featured_product->product->products_prices as $holeprice)
                                                <h6 class=" small mb-0 mt-1">
                                                @if($holeprice->discount_percent !='0')
                                                    <del class="text-danger ms-2">
                                                    {{currencyFormat($holeprice->max_sale_price) }}
                                                    </del>
                                                @endif
                                                <span>
                                                    {{ currencyFormat($holeprice->sale_price ?? '0.00') }} 
                                                </span>
                                                <span>
                                                    / {{$holeprice->product_qty}} Unit
                                                </span>
                                                @if($holeprice->discount_percent != '0')
                                                    <span class="text-success ms-1">
                                                        {{ currencyFormat( $holeprice->discount_percent )}}% {{translation('PRODUCT_DISCOUNT')}}
                                                    </span>
                                                @endif
                                                </h6>
                                            @break
                                            @endforeach
                                        @else
                                            <h6 class=" small mb-0 mt-1">
                                            @if($featured_product->product->discount_type != 'no')
                                                <del class="text-danger ms-2">
                                                {{currencyFormat($featured_product->product->max_sale_price) }}
                                                </del>
                                            @endif
                                            {{ currencyFormat($featured_product->product->sale_price ?? '0.00') }} 
                                            @if($featured_product->product->discount_type != 'no')
                                                @if($featured_product->product->discount_type == 'flat')
                                                <span class="text-success ms-1">
                                                    {{ currencyFormat($featured_product->product->discount_amount) }} {{translation('PRODUCT_DISCOUNT')}}
                                                </span>
                                                @else
                                                <span class="text-success ms-1">
                                                    {{ currencyFormat( $featured_product->product->discount_amount )}}% {{translation('PRODUCT_DISCOUNT')}}
                                                </span>
                                                @endif
                                            @endif
                                            </h6>
                                        @endif
                                        <ul class="list-unstyled text-warning mb-0">
                                        <li class="list-inline-item">
                                            @if(!empty($avgrating))
                                                @for($i=0;$i<5;$i++) 
                                                   @if($i<$avgrating) 
                                                       <i class="mdi mdi-star"> </i>
                                                    @else
                                                       <i class="mdi mdi-star-outline"></i>
                                                    @endif
                                                @endfor
                                            @endif
                                        </li>
                                        </ul>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        @endif
                    @endforeach 
                </div>
            </div><!--end col-->
        @endif
        <!----------- Slider View End ------------------------>
    </div>
</div>
@endif
@endforeach
@endif