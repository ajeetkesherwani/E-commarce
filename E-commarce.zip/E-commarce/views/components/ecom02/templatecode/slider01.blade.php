@if($slider_data)
<section class="home-slider position-relative">
    <div id="carouselExampleInterval" class="carousel slide carousel-fade" data-bs-ride="carousel">
        <div class="carousel-indicators">
                @foreach($slider_data->sliderImages as $key=>$data)
                    <button type="button" data-bs-target="#carouselExampleInterval" data-bs-slide-to="{{$key}}" class="active" aria-current="true" aria-label="Slide {{$key}}">
                    </button>
                @endforeach
        </div>
        <div class="carousel-inner">
        <div class="carousel-inner">
            @if(!empty($slider_data))
                @foreach($slider_data->sliderImages as $key=>$data)
                    <div class="carousel-item {{$key+1==sizeof($slider_data->sliderImages) ? 'active':''}}" data-bs-interval="3000">
                        <div class="bg-home slider-rtl-2 d-flex align-items-center" style="background-image: url({{getFullImageUrl($data->sliders_image)}}) ;">
                        </div>
                    </div>
                @endforeach
            @endif
        </div>
    </div>
</section><!--end section-->
@endif
