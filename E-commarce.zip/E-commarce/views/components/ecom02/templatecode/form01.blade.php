@if(!empty($form_data))
<div class="custom-form mt-3">
    <form class="contact-form-style customFrom needs-validation" id="f-{{$form_data->form_shortcode}}" novalidate name={{$form_data->form_name ?? ''}} method="post" action="{{route('customFormSubmit', ['id' => $form_data->form_id])}}">
        @csrf
        <input type="hidden" name="form_id" value="{{$form_data->form_id ?? ''}}" />
        <p id="error-msg" class="mb-0"></p>
        <div id="simple-msg"></div>
        <div class="row">
        <div class="col-sm-12">
          <h4 class="contact-panel__title">{{$form_data->form_name ?? ''}}</h4>
          <p class="contact-panel__desc mb-30">For a cleaning that meets your highest standards, you need a dedicated team of trained specialists with all supplies needed to thoroughly clean your home.
          </p>
        </div>

        @if(sizeof($form_data->form_fields)>0)
          @foreach($form_data->form_fields as $formFieldsVal)
            <!-- Input Types Start-->
            @if($formFieldsVal->field_type=="text" || $formFieldsVal->field_type=="email" || $formFieldsVal->field_type=="number" || $formFieldsVal->field_type=="tel")
              <div class="col-sm-6 col-md-6 col-lg-6">
                  <div class="form-group">
                    <label for="fid_{{$formFieldsVal->fields_id}}">{{$formFieldsVal->field_label ?? ''}}</label>
                    <input type="{{$formFieldsVal->field_type ?? ''}}" id="fid_{{$formFieldsVal->fields_id}}" placeholder="{{$formFieldsVal->field_label ?? ''}}" class="{{$formFieldsVal->field_class ?? ''}}" name={{$formFieldsVal->field_name ?? ''}} @if($formFieldsVal->required==1) required @endif>
                  </div>
              </div>
            @endif
            <!-- Input Types End-->

            <!-- Textarea Start-->
            @if($formFieldsVal->field_type=="textarea")
              <div class="col-sm-12 col-md-12 col-lg-12">
                  <div class="form-group">
                      <label for="fid_{{$formFieldsVal->fields_id}}">{{$formFieldsVal->field_label ?? ''}}</label>
                      <textarea class="{{$formFieldsVal->field_class ?? ''}}" placeholder="{{$formFieldsVal->field_label ?? ''}}" id="fid_{{$formFieldsVal->fields_id}}" name={{$formFieldsVal->field_name ?? ''}} @if($formFieldsVal->required==1) required @endif></textarea>
                  </div>
              </div>
            @endif
            <!-- Textarea End-->

            <!-- Drop Down Start -->
              @if($formFieldsVal->field_type=="dropdown")
                <div class="col-sm-12 col-md-6 col-lg-6">
                    <div class="form-group">
                        <label for="fid_{{$formFieldsVal->fields_id}}">{{$formFieldsVal->field_label ?? ''}}</label>
                        <select id="fid_{{$formFieldsVal->fields_id}}" class="{{$formFieldsVal->field_class ?? ''}}" name={{$formFieldsVal->field_name ?? ''}} @if($formFieldsVal->required==1) required @endif>
                          <option selected disabled value="">---Select---</option>
                          @if(!empty($formFieldsVal->dataArray))
                          @foreach($formFieldsVal->dataArray as $dropdwnData)
                          <option value="{{$dropdwnData->optionID}}">{{$dropdwnData->optionName}}</option>
                          @endforeach
                          @else
                          @foreach($formFieldsVal->fldValArray as $dropdwnData)
                          <option value="{{$dropdwnData}}">{{$dropdwnData}}</option>
                          @endforeach
                          @endif
                        </select>
                    </div>
                </div>
              @endif
            <!-- Drop Down End -->

            <!-- Radio Button Start -->
            @if($formFieldsVal->field_type=="radio" && !empty($formFieldsVal->fldValArray))
              <div class="col-12">
                  <div class="form-group">
                  <label for="fid_{{$formFieldsVal->fields_id}}">{{$formFieldsVal->field_label ?? ''}}</label>
                  <div>
                  @foreach($formFieldsVal->fldValArray as $radioData)
                    <div class="custom-control custom-radio custom-control-inline">
                      <input type="radio" id="fid_{{$radioData}}" name={{$formFieldsVal->field_name ?? ''}} @if($formFieldsVal->required==1) required @endif  class="custom-control-input {{$formFieldsVal->field_class ?? ''}}" value="{{$radioData}}">
                      <label class="custom-control-label" for="fid_{{$radioData}}">{{$radioData}}</label>
                    </div>
                    @endforeach
                  </div>
                  </div>
              </div>
            @endif
            <!-- Radio Button End -->

            <!-- Checkbox Button Start -->
            @if($formFieldsVal->field_type=="checkbox" && !empty($formFieldsVal->fldValArray))
              <div class="col-12">
                  <div class="form-group">
                  <label for="fid_{{$formFieldsVal->fields_id}}">{{$formFieldsVal->field_label ?? ''}}</label>
                  <div>
                    @foreach($formFieldsVal->fldValArray as $radioData)
                    <div class="custom-control custom-radio custom-control-inline">
                      <input type="checkbox" id="fid_{{$radioData}}" name={{ucfirst($radioData ?? '')}} @if($formFieldsVal->required==1) required @endif  class="custom-control-input {{$formFieldsVal->field_class ?? ''}}" value="{{$radioData}}">
                      <label class="custom-control-label" for="fid_{{$radioData}}">{{$radioData}}</label>
                    </div>
                    @endforeach
                  </div>
                  </div>
              </div>
            @endif
            <!-- Checkbox Button End -->


            <!-- Button Start -->
            @if($formFieldsVal->field_type=="submit")
              <button type="submit" class="btn btn__secondary btn__block btn__xhight d-flex justify-content-between mt-10">
                  <span>{{$formFieldsVal->field_name}}</span> <i class="icon-arrow-right icon-outlined"></i>
              </button>
            @endif
            <!-- Button End -->
          @endforeach
        @endif
      </div><!-- /.row -->
    </form>
</div>
@endif