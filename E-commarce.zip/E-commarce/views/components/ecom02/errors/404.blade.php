<section class="page_error mx-auto pt-5 pb-5">
    <div class="container">
        <div class="row">
            {{-- <div class="col-sm-12 "> --}}
                <div class="col-lg-6 col-12 text-center mx-auto">
                    <div class="page_heading">
                        <img src="{{asset('images/404.svg')}}" class="img-fluid" alt="error_img">
                    </div>
                    <div class="contant_box">
                        <h3> 
                            {{translation('ERROR_404_TITLE')}}
                        </h3>
                        <p>{{translation('ERROR_404_SUB_TITLE')}}</p>

                        <a href="javascript:history.back()" class="link_error btn">{{translation('GO_BACK_BUTTON')}}</a>
                        <a href="{{url('/')}}" class="link_error btn  btn_border">{{translation('BACK_HOMEPAGE_BUTTON')}}</a>
                    </div>
                </div>
            {{-- </div> --}}
        </div>
    </div>
</section>