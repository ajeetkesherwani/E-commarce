<div class="col-lg-4 col-md-6 mt-4 pt-2  blog-wrapper">
    <div class="card blog blog-primary rounded border-0 shadow overflow-hidden">
        <div class="position-relative blog-img-wrap">
            <a href="{{ url('blog/'.$data->slug) }}">
            <img src="{{getFullImageUrl($data->img) ?? LoadAssets('assets/images/blog-image/blog-16.jpg') }} " onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="{{getSetting('site_title')}} Not-Found"  class="card-img-top img-fluid" >
            </a>
            {{-- <div class="overlay rounded-top" href="{{ url('blog/'.$data->slug) }}"> --}}
                <a class="overlay rounded-top" href="{{ url('blog/'.$data->slug) }}"></a>
            {{-- </div> --}}
        </div>
        <div class="card-body content px-3 py-4">
            <h5><a href="{{ url('blog/'.$data->slug) }}" class="card-title title text-dark">{{ $data->post_title ?? ''}}</a></h5>
            <div class="post-meta">
                <ul class="list-unstyled mb-0">
                    <li class="list-inline-item me-2 mb-0"><a href="javascript:void(0)" class="text-muted like">{!! Str::limit($data->post_excerpt ?? '',50) !!}</a></li>
                </ul>
                <a href="{{ url('blog/'.$data->slug) }}" class="readmore">{{translation('READ_MORE')}}<i class="uil uil-angle-right-b align-middle"></i></a>
            </div>
        </div>
        <div class="author">
            <small class="date">
                <i class="uil uil-calendar-alt"></i>
                 @php
                     echo(date('d F,Y', strtotime($data->created_at ?? '')));
                @endphp
            </small>
        </div>
    </div>
</div><!--end col-->   

