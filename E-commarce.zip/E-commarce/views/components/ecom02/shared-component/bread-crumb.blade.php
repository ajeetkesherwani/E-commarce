<section class="bg-half-170 d-table w-100 py-3">
  <div class="container">
    {{-- <div class="row mt-5 justify-content-center">
      <div class="col-lg-12 text-center">
        <div class="pages-heading">
          <h4 class="title mb-0">{{ $title }}</h4>
        </div>
      </div>
      <!--end col-->
    </div> --}}
    <div class="position-breadcrumb">
      <nav aria-label="breadcrumb" class="d-inline-block">
        @if (!empty($sublist))
        <ul class="breadcrumb mb-0 px-0 py-2">
          @foreach ($sublist as $key=>$list)
          <li class="breadcrumb-item">
            @if( $key+1 < sizeof($sublist) ) <a href="{{ $list['link'] }}">{{ $list['name'] }}
            </a>
            @else
            {{ $list['name'] }}
            @endif
          </li>
          @endforeach
        </ul>
        @endif
      </nav>
    </div>
  </div>
  <!--end container-->
</section>