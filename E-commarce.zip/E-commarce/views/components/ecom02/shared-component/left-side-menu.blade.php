@php
$urlSegment = Request::segment(2);
$imgurl = url($user_data->profile_photo ?? 'https://cdn.pixabay.com/photo/2020/07/01/12/58/icon-5359553_960_720.png');
@endphp
<div class="col-md-4 mt-4  pe-5 profile-dashboard">
    <div>
        <div class="mx-0">
            <ul class="nav nav-pills nav-justified flex-column rounded p-3 mb-0" id="pills-tab" role="tablist">
                <li class="nav-item">
                    <a class="nav-link rounded text-start {{($urlSegment == 'dashboard') ? 'active' : '' }}" id="dashboard" href="{{ url('account/dashboard') }}" aria-controls="dash"
                        aria-selected="false">
                        <i class="uil uil-dashboard h5 align-middle me-2 mb-0"></i> 
                                {{ translation("ACCOUNT_DASHBOARD")}}
                    </a>
                    <!--end nav link-->
                </li>
                <!--end nav item-->

                <li class="nav-item mt-2">
                    <a class="nav-link rounded text-start {{($urlSegment == 'my-account') ? 'active' : '' }}" id="account-details" href="{{ url('account/my-account') }}" aria-controls="account"
                        aria-selected="false">
                          <i class="uil uil-user h5 align-middle me-2 mb-0"></i>
                                {{ translation('ACCOUNT_TITLE') }}
                    </a>
                    <!--end nav link-->
                </li>
                <!--end nav item-->

                <li class="nav-item mt-2">
                    <a class="nav-link rounded text-start {{($urlSegment == 'orders') ? 'active' : '' }}" id="order-history" href="{{ url('account/orders') }}" aria-controls="orders"
                        aria-selected="false">
                           <i class="uil uil-list-ul h5 align-middle me-2 mb-0"></i>{{ translation("ACCOUNT_ORDER_TITLE")}}
                    </a>
                    <!--end nav link-->
                </li>
                <!--end nav item-->

                <li class="nav-item mt-2">
                    <a class="nav-link rounded text-start {{($urlSegment == 'addreses') ? 'active' : '' }}" id="addresses" href="{{ url('account/addreses') }}" aria-controls="address"
                        aria-selected="false">
                            <i class="uil uil-map-marker h5 align-middle me-2 mb-0"></i> {{
                                translation("ACCOUNT_ADDRESS_TITLE") }}
                    </a>
                    <!--end nav link-->
                </li>
                <!--end nav item-->

                <li class="nav-item mt-2">
                    @auth
                    <a class="nav-link rounded text-start" href="route('logout')" aria-selected="false" onclick="event.preventDefault(); document.getElementById('myLogOutForm').submit();">
                            <i class="uil uil-sign-out-alt h5 align-middle me-2 mb-0"></i> {{
                                translation('LOGOUT') }}
                            <form method="POST" id="myLogOutForm" action="{{ route('logout') }}">
                                @csrf
                            </form>
                        
                    </a>
                    <!--end nav link-->
                    @endauth
                </li>
                <!--end nav item-->
            </ul>
        </div>
    </div>
</div>
<!--end nav pills-->
@push('scripts')
<script>
    $(document).ready(function () {
        $("#fileToUpload").change(function () {
            $.ajaxSetup({
                headers: {
                    "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr(
                        "content"
                    ),
                },
            });
            var profileimage = document.getElementById("changeProfileImage");
            var formData = new FormData(profileimage);
            $.ajax({
                type: "POST",
                url: "{{ url('account/change-image')}}",
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                success: function (response) {
                    if (response.status == 400) {
                    } else {
                        Notify("Profile Image Updated Successfully", true);
                        location.reload();
                    }
                },
                error: function (data) {
                    console.log(data);
                },
            });
        });
    });
</script>
@endpush