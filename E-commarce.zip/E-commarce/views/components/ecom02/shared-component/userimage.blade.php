@php
$urlSegment = Request::segment(2);
$imgurl = url($user_data->profile_photo ?? 'https://cdn.pixabay.com/photo/2020/07/01/12/58/icon-5359553_960_720.png');
@endphp
{{-- <div class="col-md-4 text-center">
<form method="post" enctype="multipart/form-data" id="changeProfileImage">
        <label for="fileToUpload">
            <div class="profile-picc" style="background-image: url('{{ $imgurl }}')">
                <span class="glyphicon glyphicon-camera"></span>
                <span>{{ translation('CHANGE_IMAGE') }}</span>
            </div>
        </label>
        <input type="File" name="fileToUpload" id="fileToUpload" />
        <h5 class="card-title text-center text-uppercase pt-2">
            {{ Auth::user()->first_name }} {{ Auth::user()->last_name }}
        </h5>
    </form>
</div> --}}


@push('scripts')
<script>
    $(document).ready(function () {
        $("#fileToUpload").change(function () {
            $.ajaxSetup({
                headers: {
                    "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr(
                        "content"
                    ),
                },
            });
            var profileimage = document.getElementById("changeProfileImage");
            var formData = new FormData(profileimage);
            $.ajax({
                type: "POST",
                url: "{{ url('account/change-image')}}",
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                success: function (response) {
                    if (response.status == 400) {
                    } else {
                        Notify("Profile Image Updated Successfully", true);
                        location.reload();
                    }
                },
                error: function (data) {
                    console.log(data);
                },
            });
        });
    });
</script>
@endpush