@php
$avgrating=AvgRating($product->product_id);
use App\Models\Ecom\Services\EcomService;  
@endphp
@if($viewtype == 'grid')

<div class="col-lg-4 col-md-6 col-12 mt-4 pt-2">
  <div class="card shop-list border-0 position-relative">
    <ul class="label list-unstyled mb-0">
        @if(!empty($product->feature_name))
          @foreach($product->feature_name as $productFeature)  
          <li>  
            <a href="javascript:void(0)" class="badge badge-link rounded-pill bg-primary"> {{$productFeature}} </a>     
          </li>
          @endforeach
        @endif
    </ul>
    <div class="shop-image position-relative overflow-hidden rounded shadow">
      <a href="{{ EcomService::url($product->product_id , 'product')}}" class="thumbnail" >
        <img class="first-img img-fluid"
          src="{{getFullImageUrl($product->product_image)}}"
          onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
          alt="{{$product->products_name ?? ''}}" />
      </a>  

      <a href="{{ EcomService::url($product->product_id , 'product')}}" class="thumbnail" >
        <img class="first-img img-fluid"
          src="{{getFullImageUrl($product->product_image)}}"
          onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
          alt="{{$product->products_name ?? ''}}" class="overlay-work" />
      </a> 
      <ul class="list-unstyled shop-icons">
        @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))
        <li>
          <a href="javascript:void(0)" onclick="addToWishListFromDetail({{ $product->product_id }})" title="wishlist"
            class="btn btn-icon btn-pills btn-soft-danger">
              @if(in_array($product->product_id, $wishlistAry))
                <i data-feather="heart" class="icons whishlist-active"></i>
              @else
                <i data-feather="heart" class="icons"></i>
              @endif
          </a>
        </li>
        @endif
        @if (webFunctionStatus(config('constkey.is_cart_enabled')))
        <li class="mt-2">
          <a href="javascript:void(0)" class="btn btn-icon btn-pills btn-soft-primary quick_view"
            onclick="showfunction('{{ $product->product_slug }}')" title="Quick View">
            <i data-feather="eye" class="icons"></i>
          </a>
        </li>
        @endif
        <li class="mt-2">
          <a href="{{ url('product/'.$product->product_slug) }}" class="btn btn-icon btn-pills btn-soft-warning">
            <i data-feather="shopping-cart" class="icons">
            </i>
          </a>
          <!--  <a href="javascript:void(0)" onclick="addToCartFromDetail({{ $product->product_id }})"  class="btn btn-icon btn-pills btn-soft-warning">
            <i data-feather="shopping-cart" class="icons">
            </i>
          </a> -->
        </li>
      </ul>
    </div>
    <div class="card-body content pt-4 p-2">
      <a href="{{ url('product/'.$product->product_slug) }}" class="text-dark product-name h6"
        title="{{ $product->products_name ?? '' }}">{{ Str::limit($product->products_name ?? '',50) }}
      </a>
      <div class="d-flex justify-content-between mt-1">
        @if($product->products_prices!=null)
          @foreach($product->products_prices as $holeprice)
            <h6 class=" small mb-0 mt-1">
              @if($holeprice->discount_percent !='0')
              <del class="text-danger ms-2">
                {{currencyFormat($holeprice->max_sale_price) }}
              </del>
              @endif
              <span>
                {{ currencyFormat($holeprice->sale_price ?? '0.00') }} 
              </span>
              <span>
                / {{$holeprice->product_qty}} Unit
              </span>
              @if($holeprice->discount_percent != '0')
                  <span class="text-success ms-1">
                    {{ currencyFormat( $holeprice->discount_percent )}}% {{translation('PRODUCT_DISCOUNT')}}
                  </span>
              @endif
            </h6>
            @break
          @endforeach
        @else
          <h6 class=" small mb-0 mt-1">
            @if($product->discount_type != 'no')
            <del class="text-danger ms-2">
              {{currencyFormat($product->max_sale_price) }}
            </del>
            @endif
            {{ currencyFormat($product->sale_price ?? '0.00') }} 
            @if($product->discount_type != 'no')
              @if($product->discount_type == 'flat')
                <span class="text-success ms-1">
                  {{ currencyFormat($product->discount_amount) }} {{translation('PRODUCT_DISCOUNT')}}
                </span>
              @else
              <span class="text-success ms-1">
                {{ currencyFormat( $product->discount_amount )}}% {{translation('PRODUCT_DISCOUNT')}}
              </span>
              @endif
            @endif
          </h6>
        @endif

        <ul class="list-unstyled text-warning mb-0">
          <li class="list-inline-item">
            @if(!empty($avgrating))
              @for($i=0;$i<5;$i++) 
                @if($i<2) 
                  <i class="mdi mdi-star"> </i>
                @else
                  <i class="mdi mdi-star-outline"></i>
                @endif
              @endfor
            @endif
          </li>
        </ul>
      </div>
    </div>
  </div>
</div>
<!--end col-->
@endif

@if($viewtype == 'list')
<!-- Start Products -->
<div class="col-lg-6 mt-4 pt-2">
  <div class="card shop-list border-0 shadow position-relative">
    <ul class="label list-unstyled mb-0">
      <li> 
        @if(!empty($product->feature_name))
          @foreach($product->feature_name as $productFeature)  
          <li>  
            <a href="javascript:void(0)" class="badge badge-link rounded-pill bg-primary"> {{$productFeature}} </a>     
          </li>
          @endforeach
        @endif
      <!-- {{ $product->product_condition
          == 1 ? 'New' : 'Refurbished' }} -->
     </li>
    </ul>
    <div class="row align-items-center g-0">
      <div class="col-lg-4 col-md-6">
        <div class="shop-image position-relative overflow-hidden">
          <a href="{{ EcomService::url($product->product_id , 'product')}}" class="thumbnail" >
            <img class="first-img img-fluid"
            src="{{getFullImageUrl($product->product_image)}}"
            onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
            alt="{{$product->products_name ?? ''}}" />
          </a> 
        </div>
      </div>
      <!--end col-->

      <div class="col-lg-8 col-md-6">
        <div class="card-body content p-4">
          <a href="{{ url('product/'.$product->product_slug) }}" class="text-dark product-name h6">{{
            $product->products_name ?? '' }}</a>
          <div class="d-lg-flex align-items-center">
            @if($product->products_prices!=null)
              @foreach($product->products_prices as $holeprice)
                <h6 class=" small mb-0 mt-1">
                    @if($holeprice->discount_percent !='0')
                      <del class="text-danger ms-2">
                        {{currencyFormat($holeprice->max_sale_price) }}
                      </del>
                    @endif
                    <span>{{ currencyFormat($holeprice->sale_price ?? '0.00') }} </span>
                    <span>
                      / {{$holeprice->product_qty}} Unit
                    </span>
                    @if($holeprice->discount_percent != '0')
                    <span class="text-success ms-1">
                      {{ currencyFormat( $product->discount_percent ) }}% {{translation('PRODUCT_DISCOUNT')}}
                    </span>
                    @endif
                </h6>
                @break
              @endforeach
            @else
              <h6 class=" small mb-0 mt-1">
                @if($product->discount_type != 'no')
                <del class="text-danger ms-2">
                  {{currencyFormat($product->max_sale_price) }}
                </del>
                @endif
                  {{ currencyFormat($product->sale_price ?? '0.00') }} 
                @if($product->discount_type != 'no')
                  @if($product->discount_type == 'flat')
                    <span class="text-success ms-1">
                      {{ currencyFormat($product->discount_amount) }} {{translation('PRODUCT_DISCOUNT')}}
                    </span>
                  @else
                  <span class="text-success ms-1">
                    {{ currencyFormat( $product->discount_amount )}}% {{translation('PRODUCT_DISCOUNT')}}
                  </span>
                  @endif
                @endif
              </h6>
            @endif
            
            <ul class="list-unstyled text-warning mb-0">
              @if(!empty($avgrating))
              @for($i=0;$i<5;$i++) @if($i<$avgrating) <li class="list-inline-item"><i class="mdi mdi-star"></i></li>
                @else
                <li class="list-inline-item"><i class="mdi mdi-star-outline"></i></li>
                @endif
                @endfor
                @endif
            </ul>
          </div>
          <p class="para-desc text-muted mb-1">{!! Str::limit($product->products_description ?? '',50) !!}</p>

          @foreach($product->products_to_features as $featKey=>$featVal)
          <p class="para-desc text-muted mb-1">{{$featVal->feature_title ?? ''}}: {{ Str::limit($featVal->feature_value ?? '', 50) }}</p>
          @endforeach
          <ul class="list-unstyled mb-0">
            <li class="list-inline-item">
              <a href="javascript:void(0)" class="btn btn-icon btn-pills btn-soft-primary">
              @if(in_array($product->product_id, $wishlistAry))
                <i data-feather="heart" class="icons whishlist-active" onclick="addToWishListFromDetail({{ $product->product_id }})" title="Wishlist"></i>
                @else
                <i data-feather="heart" class="icons" onclick="addToWishListFromDetail({{ $product->product_id }})" title="Wishlist"></i>
                @endif
                <!-- <i data-feather="heart" onclick="addToWishListFromDetail({{ $product->product_id }})" title="Wishlist"
                  class="icons">
                </i> -->
              </a>
            </li>
            <li class="mt-2 list-inline-item">
              <a href="javascript:void(0)" onclick="showfunction('{{ $product->product_slug }}')" class="btn btn-icon btn-pills btn-soft-primary">
                <i data-feather="eye" class="icons"></i>
              </a>
            </li>
            <li class="mt-2 list-inline-item"><a href="{{ url('cart')}}"
                class="btn btn-icon btn-pills btn-soft-primary"><i data-feather="shopping-cart" class="icons"></i></a>
            </li>
          </ul>
        </div>
      </div>
      <!--end col-->
    </div>
    <!--end row-->
  </div>
  <!--end blog post-->
</div>
<!--end col-->
<!-- End Products -->
@endif
