        <!-- JAVASCRIPT -->
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="{{ LoadAssets('assets/libs/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
        <script src="{{ LoadAssets('assets/libs/feather-icons/feather.min.js') }}"></script>
        <!-- SLIDER -->
        <script src="{{ LoadAssets('assets/libs/tiny-slider/min/tiny-slider.js') }}"></script>
        <!-- Main Js -->
        <script src="{{ LoadAssets('assets/js/plugins.init.js') }}"></script><!--Note: All init js like tiny slider, counter, countdown, maintenance, lightbox, gallery, swiper slider, aos animation etc.-->
        <script src="{{ LoadAssets('assets/js/app.js') }}"></script><!--Note: All important javascript like page loader, menu, sticky menu, menu-toggler, one page menu etc. -->
       <!-- // toastify -->
       <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
       <script>
     
    // $(".customFrom").on('submit',function(e){
    //     e.preventDefault();
    //     let formData = $(this).serialize();
       
    //     /*Ajax Request Header setup*/
    //     $.ajaxSetup({
    //         headers: {
    //             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    //         }
    //     });

    //     $.ajax({
    //         url: "{{ route('customFormSubmit')}}",
    //         method: 'post',
    //         data: formData,
    //         success: function(response){
    //             if(response.status == 0){
    //                  $.each(response.message, function(i, v) {
    //                     console.log('#erro_'+i);
    //                     //$('.result').append(v); 
    //                     $('#'+i+'-error').html(v);


    //                 });
    //             } else{
    //                 $('.result').append(response.message);
    //                 $('.customFrom').trigger("reset");
    //             }
    //         },

    //     });

    // });

    function Notify(msg, status) {
        Toastify({
            text: msg,
            className: "info",
            duration: 2000,
            close: true,
            gravity: "bottom", // `top` or `bottom`
            position: "right", // `left`, `center` or `right`
            style: {
                background: status ? "green" : "red",
            }
        }).showToast();

    }

     // Custome form submitted

     $(".customFrom").on('submit',function(e){
    e.preventDefault();
    let formData = $(this).serialize();
   
    /*Ajax Request Header setup*/
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $.ajax({
        url: "{{ route('customFormSubmit')}}",
        method: 'post',
        data: formData,
        success: function(response){
            if(response.status == 0){
                 $.each(response.message, function(i, v) {
                    console.log('#erro_'+i);
                    //$('.result').append(v); 
                    $('#'+i+'-error').html(v);
                });
            } else{
                $('.result').append(response.message);
                Notify('Data send successfully',true);
                $('.customFrom').trigger("reset");
            }
        },

    });

});
</script>

@if(empty(Cache::get("loaditem")))
<script>

    window.onload = function showNewsLatter() {
        $.ajax({
            url: "/onloadnewslatter",
            success: function (response) {
                $(".newsmodal").html(response);
                $('#onloadModal').modal('show');
            },
            error: function (error) {
                // alert("Hello Error");
            },
        });
    }

</script>
@endif

<script>
    //Enquiry Form Modal
    function showEnquiryForm() {

        $('#EnquiryModal').modal('show');
    }
</script>

<script>
    function addToCart(product_id, qty = 1, attributes_id = '') {
        
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
            url: '{{ route("addUpdateToCart") }}',
            method: 'POST',
            data: {
                qty: qty,
                attributes_id: attributes_id,
                product_id: product_id,
            },
            success: function (response) {
                console.log(response);
                $('.count-cart-total').html(response.total_count_html);
                $(".amount-tag").load(location.href + " .amount-tag");
                Notify('Item Added To Cart !', true);

            },
            error: function (error) {
                Notify(error.message, false);
            }
        });

    }

     //Wishlist Ajax start
         
     function addToWishListFromDetail(product_id) {
            $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
            url: '{{ route("addUpdateToWishList") }}',
            method: 'POST',
            data: {
                product_id: product_id,
            },
            success: function (response) {
                $('.count-wishlist-total').html(response.wish_list_item_html);
                Notify('Item Added To WishList !', true);
                $(".ion-android-favorite-outline").addClass('whishlist-active');
            },
            error: function (error) {
                //Notify(error.message, false);
                Notify('Please Login to add products in Wishlist!');
            }
        });;
        }

        //End of Wishlist Ajax 

    function showfunction(slug) {
        var Callurl = `{{ url('showproduct')}}/` + slug;
        
        $.ajaxSetup({
            headers: {
                "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
            },
        });

        $.ajax({
            type: "POST",
            url: Callurl,
            data: {
                slug: slug,
            },
            success: function (response) {
                console.log(response);
                $("#product-detail-modal").html(response);
                $('#productModalShow').modal('show');
            },
            error: function (error) { },
        });
    }


    let choosen_attributes = [];

    function addToCartFromModalDetail(product_id) {
        var qtyItemAdd = $('#modalqtyItemAdd').val();
        let attributes = choosen_attributes.join(',');
        addToCart(product_id, qtyItemAdd, attributes);
    }

    function chooseModalAttributes(params) {
        if (!choosen_attributes.includes(params.value)) {
            choosen_attributes.push(params.value);
        }
    }
    
</script>