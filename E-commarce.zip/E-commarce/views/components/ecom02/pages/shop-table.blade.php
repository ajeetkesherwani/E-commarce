<!-- Dynamic Product Load To  -->
<!-- Shop Tab Content Start -->
@if(!empty($products) && sizeof($products)>0)
 <div class="row">
     @foreach($products as $product)
       <x-Ecom02.shared-component.product viewtype="grid" :data="$product" />
     @endforeach
 </div><!--end row-->

 <!-- PAGINATION START -->
<input type="hidden" id="nextPage" value="1">
<div class="col-12 mt-4 pt-2 pro-pagination-style-wrapper">
    {{ $products->links('vendor.pagination.for-ajax') }}    
</div>
                             
@else
<center><h3 class="text-secondary">No product avaliable for this query.</h3></center>
@endif  
 <!-- PAGINATION END -->  
