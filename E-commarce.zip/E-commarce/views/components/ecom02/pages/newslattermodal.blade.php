<div  id="newsletter-wrapper" class="border">
    <button type="button" class="btn-close prdtbtn-close close-popup" data-bs-dismiss="modal" aria-label="Close"><i class="uil uil-times fs-4 text-white"></i></button>
      <div class="white-popup">
        <div class="banner-newsletter">
          <img src="{{getFullImageUrl(getSetting('newsletter_image'))}}" class="img-fluid"
          onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" 
          alt="{{ getSetting('site_title') }}-New Latter Image">
        </div>
        <div class="popup-newsletter bg-white">
          <div class="popup-title">
            <h2>{{ getSetting('newsletter_title') ?? '' }}</h2>
          </div>
          <p>{{ getSetting('newsletter_subtitle') ?? '' }}</p>
          <form class="form-subscribe needs-validation"   id="newsltrModalForm" novalidate>
            <input class="input  newsletter-email form-control" type="email" id="customeremail" placeholder="{{translation('NEWSLETTER_EMAIL_PLACEHOLDER')}}" name="EMAIL" required>
            <button class="button" name="subscribe" id="modal_subscribe" type="submit">{{translation('NEWSLETTER_SUBSCRIBE_BUTTON')}}</button>
          </form>
          <span id="email_err" class="text-danger"></span> 
              <ul class="p-0 mt-2">
                @if (!empty(socialLinks('facebook_url')))
               <li><a href="{{ socialLinks('facebook_url') }}"><i class="fab fa-facebook-f"></i></a></li>
                @endif
                @if (!empty(socialLinks('twitter_url')))
                <li><a href="{{ socialLinks('twitter_url') }}"><i class="fab fa-twitter"></i></a></li>
                @endif
                @if (!empty(socialLinks('linkedin_url')))
                <li><a href="{{ socialLinks('linkedin_url') }}"><i class="fab fa-linkedin-in"></i></a></li>
                @endif
                @if (!empty(socialLinks('pinterest_url')))
                <li><a href="{{ socialLinks('pinterest_url') }}"><i class="fab fa-pinterest-p"></i></a></li>
                @endif
                @if (!empty(socialLinks('instagram_url')))
                <li><a href="{{ socialLinks('instagram_url') }}"><i class="fab fa-instagram"></i></a></li>
                @endif
                @if (!empty(socialLinks('youtube_url')))
                <li><a href="{{ socialLinks('youtube_url') }}"><i class="fab fa-youtube"></i></a></li>
                @endif
              </ul>
        </div>
      </div>
    </div>