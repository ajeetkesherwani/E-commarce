 @php
$currentURL = URL::current();
$avgrating=AvgRating($response['product_id']);
@endphp
            
<div class="modal-content rounded shadow border-0">
    <div class="modal-header border-bottom">
        <h5 class="modal-title" id="productview-title">{{translation('PRODUCT_QUICK_VIEW_TITLE')}}</h5>
        <button type="button" class="btn btn-icon btn-close" data-bs-dismiss="modal" id="close-modal"><i class="uil uil-times fs-4 text-dark"></i></button>
    </div>
    
    <div class="modal-body p-4">
        <div class="container-fluid px-0">
            <div class="row">
                <div class="col-lg-5">
                    <div class="tiny-single-item">
                        <div class="tiny-slide active">
                            <img src="{{getFullImageUrl($response['product_image'])}}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                            alt="{{$response['products_name']}}" class="img-fluid rounded">
                        </div>
                    </div>
                </div><!--end col-->

                <div class="col-lg-7 mt-4 mt-lg-0 pt-2 pt-lg-0">
                    <h4 class="title">{{$response['products_name']}}</h4>
                    <a href="javascript:void(0)" class="btn btn-icon btn-pills btn-soft-danger">
                        <i data-feather="heart" onclick="addToWishListFromDetail({{$response['product_id'] }})"  title="Wishlist" class="icons">
                        </i>
                    </a>
                    <input type="hidden" id="products_id" name="products_id"  class="modal_products_id" value="{{ $response['product_id']}}">
                    <div class="pricing-meta">
                        @if($response->products_prices !=null)
                            <div class="position-relative">
                                <div class="pricing-meta-head">
                                  <div class="qty"><b>{{translation('PRODUCT_QTY')}}</b></div>
                                  <div  class="price"><b>{{translation('PRODUCT_PRICE')}}</b></div>
                                </div>
                                <div class="tiny-four-item">
                                  @foreach($response->products_prices as $producprice)
                                  <div>
                                    <div class="qty"><b>{{$producprice->product_qty}}</b></div>
                                    <div class="amount">{{currencyFormat($producprice->sale_price)}}</div>
                                   </div>
                                  @endforeach
                                </div>
                            </div>
                          @else
                          <ul>
                              @if($response->discount_type != 'no')
                              <del class="text-danger ms-2 discount_amount">{{currencyFormat($response->max_sale_price) }}
                              </del>
                              @endif
                              <span class="old-price not-cut">
                                  {{ currencyFormat($response->sale_price ?? '0.00') }} 
                              </span>
                              @if($response->discount_type != 'no')
                              @if($response->discount_type == 'flat')
                              <span class="text-success ms-1">
                                {{ currencyFormat($response->discount_amount) }} {{translation('PRODUCT_DISCOUNT')}}
                              </span>
                              @else
                              <span class="text-success ms-1">
                                {{ currencyFormat( $response->discount_amount )}}% {{translation('PRODUCT_DISCOUNT')}}
                              </span>
                              @endif
                              @endif
                          </ul>
                        @endif
                      </div>
                    <ul class="list-unstyled text-warning h5">
                        @if(!empty($avgrating))
                        @for($i=0;$i<5;$i++)
                        @if($i<$avgrating)
                            <li class="list-inline-item"><i class="mdi mdi-star"></i></li>
                        @else
                            <li class="list-inline-item"><i class="mdi mdi-star-outline"></i></li>
                        @endif
                        @endfor
                        @endif
                    </ul>
                          
                    @if (webFunctionStatus(config('constkey.is_cart_enabled')) || webFunctionStatus(config('constkey.is_enquiry_enabled')))
                        <div class="row mt-4 pt-2">
                            <div class="col-12">
                                @if (!empty($response->productAttribute))
                                    @foreach ($response->productAttribute as $attribute)
                                        <div class="d-flex align-items-center product-variants">
                                            <h6 class="mb-0">{{ ucfirst($attribute['option_name'] ?? '')}} :</h6>
                                            @if( isset($attribute['option_value_list']) && !empty($attribute['option_value_list']))
                                            <ul class="list-unstyled ms-3" id="attributes_{{$attribute['options_id']}}">
                                                @foreach($attribute->option_value_list as $idx => $option_value)
                                                    <li class="list-inline-item input-container">
                                                    <!-- <div class="btn btn-soft-primary ms-2"> -->   
                                                    <input class="modal_input-radio" type="radio"
                                                    data-product-attribute="{{ $option_value['options_id']}}"
                                                    name="attributes_{{ $option_value['options_id']}}" {{$idx==0?"checked":""}}
                                                    value="{{$option_value['options_id']}}_{{ $option_value['options_values_id'] }}"
                                                    title="{{ $option_value->productOptionsValue->products_options_values_name }}">
                                                    <span class="radio-label">{{ $option_value->productOptionsValue->products_options_values_name }}</span> 
                                                    <!-- </div> -->
                                                    </li>
                                                @endforeach
                                            </ul>
                                            @endif
                                        </div>
                                    @endforeach
                                @endif
                            </div><!--end col-->

                            <div class="col-12 mt-4">
                                <div class="d-flex shop-list align-items-center">
                                    <h6 class="mb-0">{{translation('PRODUCT_QTY')}}</h6>
                                    <div class="ms-3">
                                        <div class="qty-icons qty_buttons">
                                            <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" class="btn btn-icon btn-soft-primary minus qtybutton">-</button>
                                            @if($response->products_prices !=null)
                                                @foreach($response->products_prices as $producprice)
                                                     <input min="1" name="qtyItemAdd" onblur="QtyToPrice('quickView')"  value="{{$producprice->product_qty}}" type="number" class="btn btn-icon btn-soft-primary qty-btn modal_qtyItemAdd" id="qtyItemAdd">
                                                @break
                                                @endforeach
                                            @else
                                            <input min="1" name="qtyItemAdd" onblur="QtyToPrice('quickView')"  value="1" type="number" class="btn btn-icon btn-soft-primary qty-btn modal_qtyItemAdd" id="qtyItemAdd">
                                            @endif
                                            <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="btn btn-icon btn-soft-primary plus qtybutton">+</button>
                                            <input type="hidden" value="quickView" class="source">
                                        </div>
                                    </div>
                                </div> 
                            </div>

                            <input type="hidden" value="{{$response['product_slug']}}" id="productSlug">
                            <input type="hidden" value="quickView" id="source">

                        </div><!--end row-->
                    @endif
                    @if($response->products_prices!=null)
                    <div class="pricing-meta mt-3">
                        <span>
                            {{translation('PRODUCT_PRICE')}}:
                            @foreach($response->products_prices as $holeprice)
                                @if($holeprice->discount_percent !='0')
                                    <del class="text-danger ms-2 discount_amount">
                                        {{currencyFormat($holeprice->max_sale_price) }}
                                    </del>
                                @endif
                                <span class="old-price not-cut">
                                    {{ currencyFormat($holeprice->sale_price ?? '0.00') }} 
                                </span>
                                <span class="">
                                / {{$holeprice->product_qty}} {{translation('PRODUCT_UNIT')}}
                                </span>
                                @if($holeprice->discount_percent != '0')
                                    <span class="discount-price ms-1">
                                        {{ currencyFormat( $holeprice->discount_percent )}}% {{translation('PRODUCT_DISCOUNT')}}
                                    </span>
                                @endif
                                @break
                            @endforeach
                        </span>
                    </div>
                    @endif

                    <div class="mt-4 pt-2">
                        <a href="javascript:void(0);" class="btn btn-primary ms-2" onclick="addToCartFromModalDetail({{$response['product_id']}})">{{translation('ADD_TO_CART')}}</a>
                    </div>
                </div><!--end col-->
            </div><!--end row-->
        </div><!--end container-->
    </div>
</div>
 @push('scripts')
<script>

    let detail_choosen_attributes = [];

    function addToCartFromDetail(product_id) {

        var qtyItemAdd = $('#qtyItemAdd').val();
        let attributes = detail_choosen_attributes.join(',');
        if (attributes == '') {

            $('input[type="radio"]:checked').each(function() {
                if (!detail_choosen_attributes.includes(this.value)) {
                    detail_choosen_attributes.push(this.value);
                }
                console.log(detail_choosen_attributes);
            });
            let attributes = detail_choosen_attributes.join(',');

            addToCart(product_id, qtyItemAdd, attributes);
        } else {
            addToCart(product_id, qtyItemAdd, attributes);
        }

    }

    $('.input-radio').on('click', function() {
        let detail_choosen_attributes = [];
        var ele = $('input');
        for (i = 0; i < ele.length; i++) {
            if (ele[i].checked)
                if (!detail_choosen_attributes.includes(ele[i].value)) {
                    detail_choosen_attributes.push(ele[i].value);
                }
        }

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        var data = {
            'product_id': $('#products_id').val(),
            'options_values_id': $(this).attr("value"),
            'options_id': $(this).attr("data-product-attribute"),
        }
        $.ajax({
            type: "POST",
            url: "/attribute-price",
            data: data,
            dataType: "json",
            success: function(response) {
                $(".old-price").html("");
                $(".old-price").append(response);
            }
        });

    });

    var enqdetail_choosen_attributes = [];
    var choosen_attributes_ary = [];

    function enqchooseAttributes(params, opid) {
        choosen_attributes_ary = [];
        enqdetail_choosen_attributes[opid] = params.value;

        // Now it can be used reliably with $.map()
        $.map(enqdetail_choosen_attributes, function(val, i) {
            if (val > 0)
                choosen_attributes_ary.push(val);
        });

    }

    // function chooseAttributes(param) {
    //     // option to price
    // }


    

    if ($('.ty-compact-list').length > 3) {
        $('.ty-compact-list:gt(2)').hide();
        $('.show-more').show();
    }
    $('.show-more').on('click', function() {
        $('.ty-compact-list:gt(2)').toggle();
        $(this).text() === 'Show more' ? $(this).text('Show less') : $(this).text('Show more');
    });

    
</script>
@endpush
        