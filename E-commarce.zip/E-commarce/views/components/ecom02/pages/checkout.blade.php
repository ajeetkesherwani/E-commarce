@php
$main_arr = [
'title'=>'Checkout Page',
'sublist' => [
[
'name'=>'HOME',
'link'=>url("/")
],
[
'name'=>'checkout',
'link'=>url()->full()
],
],
];
@endphp

<!-- BreadCumb Start Here-->
<x-Ecom02.SharedComponent.BreadCrumb :data="$main_arr" />
<!-- BreadCumb End Here-->

<!-- Start -->
<section class="section">
    <form action="{{route('placeOrder')}}" method="POST" id="placeOrderForm" novalidate="novalidate">
        @csrf
        <div class="container">
            <div class="row">
                <!-- Order Details Start-->
                <div class="col-md-5 col-lg-4 order-md-last">
                    <div class="card rounded shadow p-4 border-0">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <span class="h5 mb-0">
                                {{translation('CHECKOUT_ORDER_TITLE')}}
                            </span>
                        </div>
                        <ul class="list-group mb-3 border order-wrapper">

                            @if (!empty($list['cart_list']))
                            @foreach ($list['cart_list'] as $cart )
                            <li class="d-flex justify-content-between lh-sm p-3 border-bottom align-item-center">
                                <div>
                                    <img src="{{getFullImageUrl($cart->product->product_image ?? '')}}"
                                        onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                                        class="product_img img-fluid" alt="product_img">
                                </div>
                                <div>
                                    <h6 class="my-0">{{ $cart->product->products_name ?? ''}}&nbsp;<small
                                            class="text-muted">X {{ $cart->qty }}</small></h6>
                                    <span>
                                        @php
                                        $qty = (int) $cart->qty;
                                        $price = $cart->final_price ?? 0;
                                        echo currencyFormat($qty*$price);
                                        @endphp
                                    </span>
                                </div>
                            </li>
                            @endforeach
                            @endif
                        </ul>
                        <ul class="list-group mb-3 border">
                            <li class="d-flex justify-content-between p-3">
                                <span>
                                    <strong>{{translation('SHIPPING_METHODS')}}</strong>
                                </span>
                            </li>
                            @if (!empty($shippingMethodList) && sizeof($shippingMethodList) > 0 )
                            @foreach ($shippingMethodList as $shippingKey=>$shipping)
                            <li class="d-flex justify-content-between p-3">
                                <div class="form-check">
                                    <input id="{{ $shipping->method_key }}_id" value="{{ $shipping->method_key }}"
                                        name="shipping_method" type="radio" class="form-check-input ship-radio-choose"
                                        @if($shippingKey==0)checked @endif required="">
                                    <label class="form-check-label" for="{{ $shipping->method_key }}_id">
                                        {{$shipping->method_name }}
                                    </label>
                                </div>
                                <div class="d-flex">
                                    <img src="{{getSuperFullImageUrl($shipping->method_logo)}}" alt="parment_img"
                                        class="img-round payment-img "
                                        onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                                        height="20">
                                </div>
                            </li>
                            @endforeach
                            @else
                            <input type="radio" name="shipping_method" value="cod">
                            @endif
                            <li class="d-flex justify-content-between p-3" id="shippingHtml"></li>

                            @if (webFunctionStatus(config('constkey.is_coupon_enabled')))
                            @if(!session()->has('coupon_id'))
                            <div class="m-3" id="coupon_area">
                                <div class="form-group">
                                    <div class="input-group" id="couponform_area">
                                        <input type="text" class="form-control coupon" id="coupon_code"
                                            name="coupon_code" placeholder="{{translation('COUPON_CODE_PLACEHOLDER')}}">
                                        <span class="input-group-append">
                                            @auth
                                            <a href="javascript:void(0)" id="applyButton"
                                                class="btn btn-primary btn-apply coupon">
                                                {{translation('COUPON_APPLY_BUTTON')}}
                                            </a>
                                            @endauth
                                            @guest
                                            <a href="javascript:void(0)" id="cpnbtn"
                                                class="btn btn-primary btn-apply coupon">{{translation('COUPON_APPLY_BUTTON')}}
                                            </a>
                                            @endguest
                                        </span>
                                    </div>
                                    <div class="alert alert-danger alert-dismissible fade" id="coupon_alert"
                                        role="alert">
                                        <strong class="coupon_error"></strong>
                                        <button type="button" class="btn-close coupon_alt_btn"
                                            aria-label="Close"></button>
                                    </div>
                                </div>
                            </div>
                            @endif
                            @endif
                        </ul>
                        <!-- <ul class="list-group mb-3 border"> -->

                        <!-- </ul> -->

                        <ul class="list-group mb-3 border ">
                            <li class="d-flex justify-content-between p-3">
                                <span>{{translation('CHECKOUT_PRODUCT_SUBTOTAL')}}</span>
                                <strong>{{currencyFormat($list['total_product_price'])}}</strong>
                            </li>
                            {{-- <li class="d-flex justify-content-between p-3"><span>{{translation('SHIPPING')}}</span>
                                <strong>$0.00</strong></li> --}}
                            @if (!empty($list['coupon_discount']))
                            <li class="d-flex justify-content-between p-3 ">
                                <span>{{translation('COUPON_DISCOUNT')}}</span>
                                <strong>{{currencyFormat($list['coupon_discount'])}}</strong>
                            <li>
                                @endif
                            <li class="hidden coupon_disc_amount"></li>

                            @if(getSetting('ENABLE_TAX')=='1')
                            @if(getSetting('tax_type')=='exclusive')
                            @foreach (tax_calculate($list['product_total'])[0] as $tax_name=>$tax_prices)
                            <li class="d-flex justify-content-between p-3">
                                <span>{{$tax_name}} </span>
                                <strong>{{currencyFormat($tax_prices)}}</strong>
                            <li>
                                @endforeach
                            <li class="d-flex justify-content-between p-3">
                                <span>{{translation('CHECKOUT_PRODUCT_TOTAL')}} </span>
                                <strong
                                    class="subtotal">{{currencyFormat(tax_calculate($list['product_total'])[1])}}</strong>
                            </li>
                            @else
                            <li class="d-flex justify-content-between p-3">
                                <span>{{translation('CHECKOUT_PRODUCT_TOTAL')}} </span>
                                <strong class="subtotal">
                                    {{currencyFormat($list['product_total'])}}
                                </strong>
                            </li>
                            @endif
                            @else
                            <li class="d-flex justify-content-between p-3">
                                <span>{{translation('CHECKOUT_PRODUCT_TOTAL')}} </span>
                                <strong class="subtotal">
                                    {{currencyFormat($list['product_total'])}}
                                </strong>
                            </li>
                            @endif
                        </ul>
                    </div>
                </div>
                <!-- Order Details End-->

                <!-- Form Start -->
                
                <div class="col-md-7 col-lg-8">
                    <div class="card rounded shadow p-4 border-0">

                        <div class="d-flex justify-content-between">
                        <h4 class="mb-3">{{translation('BILLING_DETAILS_TITLE')}}</h4>
                            @if(!empty($addressList) && sizeof($addressList) > 0)
                            <div>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#newAddressModal">
                                <i class="fa fa-plus"></i> 
                                {{translation('NEW_ADDRESS_BUTTON')}}
                                </button>
                            </div>
                            @endif
                        </div>

                        @if(!empty($addressList) && sizeof($addressList) > 0)  
                        
                        <!-- Listings of Default addresses -->
                        <div class="row  billing-wrapper">
                            <div class="col-md-12">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>{{translation('DEFAULT_ADDRESS')}}</th>
                                        </tr>
                                    </thead>
                                    <tbody id="addressListBox">
                                        @foreach ($addressList as $addrKey=>$addressList)
                                        <tr>
                                            <td class="d-flex gap-3">
                                                <input type="radio" name="address_id" class="default_address"
                                                    id="add_{{$addressList->address_id}}"
                                                    value='{{$addressList->address_id}}' @if($addressList->is_default=='1') checked @else @if($addrKey==0) checked @endif @endif/>
                                                <label for="add_{{ $addressList->address_id }}">
                                                    {{ $addressList->customer_name.','. $addressList->customer_email}},
                                                    {{ $addressList->street_address.','. $addressList->city.',
                                                    '.$addressList->state }},
                                                    {{ $addressList->country_name.'-'. $addressList->zipcode }},
                                                    {{ $addressList->phone}}
                                                </label>
                                            </td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>     

                        @else

                        <div class="row g-3">
                            <div class="col-sm-6">
                                <label for="ContactName" class="form-label">{{translation('CONTACT_NAME')}}</label>
                                <input type="text" class="form-control" id="ContactName"
                                    placeholder="{{translation('CONTACT_NAME_PLACEHOLDER')}}" name="customer_name"
                                    value="{{old('customer_name')}}">
                                @if ($errors->has('customer_name'))
                                <div class="invalid-feedback">{{ $errors->first('customer_name') }}</div>
                                @endif
                            </div>

                            <div class="col-6">
                                <label for="username" class="form-label">{{translation('EMAIL')}}</label>
                                <div class="input-group has-validation">
                                    <input type="email" class="form-control" id="username"
                                        placeholder="{{translation('EMAIL_PLACEHOLDER')}}" name="customer_email"
                                        value="{{old('customer_email')}}">
                                    @if ($errors->has('customer_email'))
                                    <div class="invalid-feedback">{{ $errors->first('customer_email') }}</div>
                                    @endif
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <label for="lastName" class="form-label">{{translation('PHONE')}}</label>
                                <input type="text" class="form-control" id="lastName"
                                    placeholder="{{translation('PHONE_PLACEHOLDER')}}" name="customer_phone"
                                    value="{{old('customer_phone')}}">
                                @if ($errors->has('customer_phone'))
                                <div class="invalid-feedback">{{ $errors->first('customer_phone') }}</div>
                                @endif
                            </div>

                            <div class="col-6">
                                <label for="address" class="form-label">{{translation('STREET_ADDRESS')}}</label>
                                <input type="text" class="form-control" value="{{old('customer_address')}}"
                                    placeholder="{{translation('STREET_ADDRESS_PLACEHOLDER')}}" id="address"
                                    name="customer_address">
                                @if ($errors->has('customer_address'))
                                <div class="invalid-feedback">
                                    {{ $errors->first('customer_address') }}
                                </div>
                                @endif
                            </div>

                            <div class="col-md-6">
                                <label for="state" class="form-label">{{translation('CITY')}}</label>
                                <input type="text" class="form-control" id="address2"
                                    placeholder="{{translation('CITY_PLACEHOLDER')}}" name="customer_city"
                                    value="{{old('customer_city')}}">
                                @if ($errors->has('customer_city'))
                                <div class="invalid-feedback">
                                    {{ $errors->first('customer_city') }}
                                </div>
                                @endif
                            </div>

                            <div class="col-md-6">
                                <label for="state" class="form-label">{{translation('STATE')}}</label>
                                <input type="text" class="form-control" id="address2"
                                    placeholder="{{translation('STATE_PLACEHOLDER')}}" name="customer_state"
                                    value="{{old('customer_state')}}">
                                @if ($errors->has('customer_state'))
                                <div class="invalid-feedback">{{ $errors->first('customer_state') }}</div>
                                @endif
                            </div>

                            <div class="col-md-6">
                            @if(!empty($countries))
                                <label for="country" class="form-label">
                                    {{translation('COUNTRY')}}
                                </label>
                                <select class="form-select form-control" name="countries_id" id="country" required>
                                    <option selected value="" disabled>{{translation('COUNTRY_PLACEHOLDER')}}</option>
                                    @foreach($countries as $key=>$country)
                                        <option value="{{$country->countries_id ?? ''}}" @if($Ipcountry->countries_id==$country->countries_id) selected @endif>{{$country->countries_name ??''}}</option>
                                    @endforeach
                                </select>
    
                                @if ($errors->has('countries_id'))
                                    <div class="invalid-feedback">
                                        {{ $errors->first('countries_id') }}
                                    </div>
                                @endif
                            @endif
                            </div>

                            <div class="col-md-6">
                                <label for="zip" class="form-label">{{translation('ZIPCODE')}}</label>
                                <input type="text" class="form-control" id="zip"
                                    placeholder="{{translation('ZIPCODE_PLACEHOLDER')}}" name="customer_postcode"
                                    value="{{old('customer_postcode')}}">
                                @if ($errors->has('customer_postcode'))
                                    <div class="invalid-feedback">
                                        {{ $errors->first('customer_postcode')}}
                                    </div>
                                @endif
                            </div>
                        </div>

                        @endif
                        <!-- Shipping address is the same as my  billing address -->

                        <div class="form-check mt-4 pt-4 border-top">
                            <input type="checkbox" class="checkout-toggle form-check-input" id="same-address" name="is_shipping_diff">
                            <label class="form-check-label" for="same-address">{{translation('CHECKOUT_SHIP_DIFFRENT_ADDRESS')}}</label>
                        </div>

                        <div class="open-toggle" style="display: none;">
                            <div class="row g-3">
                                <div class="col-sm-6">
                                    <label for="contactName" class="form-label">{{translation('CONTACT_NAME')}}</label>
                                    <input type="text" class="form-control" id="contactName"
                                        placeholder="{{translation('CONTACT_NAME_PLACEHOLDER')}}"
                                        name="shipping_customer_name" value="{{old('shipping_customer_name')}}">
                                    
                                    @if ($errors->has('shipping_customer_name'))
                                    <div class="invalid-feedback">
                                        {{ $errors->first('shipping_customer_name') }}
                                    </div>
                                    @endif
                                </div>

                                <div class="col-6">
                                    <label for="username" class="form-label">{{translation('EMAIL')}}</label>
                                    <div class="input-group has-validation">
                                        {{-- <span class="input-group-text bg-light text-muted border">@</span> --}}
                                        <input type="email" class="form-control" id="username"
                                            placeholder="{{translation('EMAIL_PLACEHOLDER')}}"
                                            name="shipping_customer_email" value="{{old('shipping_customer_email')}}">
                                        
                                        @if ($errors->has('shipping_customer_email'))
                                        <div class="invalid-feedback">
                                            {{ $errors->first('shipping_customer_email') }}
                                        </div>
                                        @endif
                                    </div>
                                </div>

                                <div class="col-sm-6">
                                    <label for="phone" class="form-label">
                                        {{translation('PHONE')}}
                                    </label>
                                    <input type="text" class="form-control" id="phone"
                                        placeholder="{{translation('PHONE_PLACEHOLDER')}}"
                                        name="shipping_customer_phone" value="{{old('shipping_customer_phone')}}">
                                
                                    @if ($errors->has('shipping_customer_phone'))
                                    <div class="invalid-feedback">
                                        {{ $errors->first('shipping_customer_phone') }}
                                    </div>
                                    @endif
                                </div>

                                <div class="col-6">
                                    <label for="address" class="form-label">{{translation('STREET_ADDRESS')}}</label>
                                    <input type="text" class="form-control"
                                        placeholder="{{translation('STREET_ADDRESS_PLACEHOLDER')}}" id="address"
                                        value="{{old('shipping_customer_address')}}" name="shipping_customer_address">
                              
                                    @if ($errors->has('shipping_customer_address'))
                                    <div class="invalid-feedback">
                                        {{ $errors->first('shipping_customer_address') }}
                                    </div>
                                    @endif
                                </div>

                                <div class="col-md-6">
                                    <label for="state" class="form-label">{{translation('CITY')}}</label>
                                    <input type="text" class="form-control" id="address2"
                                        placeholder="{{translation('CITY_PLACEHOLDER')}}" name="shipping_customer_city"
                                        value="{{old('shipping_customer_city')}}">
                                   
                                    @if ($errors->has('shipping_customer_city'))
                                    <div class="invalid-feedback">
                                        {{ $errors->first('shipping_customer_city') }}
                                    </div>
                                    @endif
                                </div>

                                <div class="col-md-6">
                                    <label for="state" class="form-label">{{translation('STATE')}}</label>
                                    <input type="text" class="form-control" id="address2"
                                        placeholder="{{translation('STATE_PLACEHOLDER')}}"
                                        name="shipping_customer_state" value="{{old('shipping_customer_state')}}">
                                    @if ($errors->has('shipping_customer_state'))
                                    <div class="invalid-feedback">
                                        {{ $errors->first('shipping_customer_state') }}
                                    </div>
                                    @endif
                                </div>

                                <div class="col-md-6">
                                @if(!empty($countries))
                                    <label for="country" class="form-label">
                                        {{translation('COUNTRY')}}
                                    </label>
                                    <select class="form-select form-control" name="shipping_countries_id" required>
                                        <option selected value="" disabled>{{translation('COUNTRY_PLACEHOLDER')}}</option>
                                        @foreach($countries as $key=>$country)
                                            <option value="{{$country->countries_id ??''}}" @if($Ipcountry->countries_id==$country->countries_id) selected @endif>
                                                {{$country->countries_name ??''}}
                                            </option>
                                        @endforeach
                                    </select>
                                    
                                    @if ($errors->has('shipping_customer_country'))
                                        <div class="invalid-feedback">
                                            {{ $errors->first('shipping_customer_country') }}
                                        </div>
                                    @endif
                                @endif
                                </div>

                                <div class="col-md-6">
                                    <label for="zip" class="form-label">
                                        {{translation('ZIPCODE')}}
                                    </label>
                                    <input type="text" class="form-control" id="zip"
                                        placeholder="{{translation('ZIPCODE_PLACEHOLDER')}}"
                                        name="shipping_customer_postcode" value="{{old('shipping_customer_postcode')}}">
                                    @if ($errors->has('shipping_customer_postcode'))
                                        <div class="invalid-feedback">
                                            {{ $errors->first('shipping_customer_postcode') }}
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="row g-3 mt-2 pt-2 mb-3">
                            <div class="col-md-12">
                                <label for="Additionalinformation"
                                    class="form-label">{{translation('ADDITIONAL_INFORMATIONS')}}</label>
                                <textarea type="text" class="form-control" name="note"
                                    placeholder="{{translation('ORDER_NOTE_PLACEHOLDER')}}"></textarea>
                            </div>
                        </div>

                        <!--   payment start  -->
                        <h4 class="mb-3 mt-4 pt-4 border-top">{{translation('PAYMENT_TYPE')}}</h4>
                        @if (!empty($paymentList) && sizeof($paymentList) > 0 )
                            <div class="my-3">
                                @foreach ($paymentList as $payment)
                                <div class="form-check">
                                    <input type="radio" name="payment_method" class="payment-radio-choose payment-type"
                                        id="{{ $payment->method_key }}_id" value="{{ $payment->method_key }}" required>
                                    <label class="form-check-label" for="{{ $payment->method_key }}_id">
                                        {{ $payment->method_name }}
                                    </label>
                                    <img src="{{getSuperFullImageUrl($payment->method_logo)}}" alt="parment_img"
                                        class="img-round payment-img " height="20">
                                </div>
                                @endforeach
                            </div>
                        @endif
                        <!-- payment end -->
                        <button class="w-100 btn btn-primary" type="submit" value="Submit">{{translation('PLACE_ORDER')}}</button>
                    </div>
                </div>
                <!-- Form End -->
            </div>
        </div>
        </div>
    </form>
</section>
<!-- End -->

<!-- Modals Start Here-->

<!-- Login Form Start -->
<div class="modal fade checkout-form-wrap" id="login-popup" tabindex="-1" aria-hidden="true">
    <input type="hidden" name="login_source" id="login_source" value="checkout">
    <div class="modal-dialog  modal-lg modal-dialog-centered">
        <div class="modal-content rounded shadow border-0">
            <div class="modal-body p-0">

                <!--Login Start Here-->
                <div class="container-fluid px-0 sub" id="sublogin">
                    <div class="row align-items-center g-0">
                        <div class="col-lg-12 col-md-12">

                            <div class="modal-header">
                                <h5 class="modal-title">{{translation('LOGIN_TITLE')}}</h5>
                                <div class="alert alert-dismissible fade login_alert" role="alert">
                                    <strong id="alert_message"> here alert message come throw ajax </strong>
                                    <button type="button" class="btn-close login_alt_btn" aria-label="Close"></button>
                                </div>
                                <button type="button" class="btn btn-icon btn-close" data-bs-dismiss="modal" id="close-modal"><i class="uil uil-times fs-4 text-dark"></i></button>
                            </div>

                            <form class="login-form px-4 pb-4 needs-validation contact-form-style" novalidate
                                id="login-modal-form">
                                @csrf
                                <div class="row">
                                    <div class="col-lg-12 pt-3">
                                        <div class="mb-3">
                                            <label class="form-label">{{ translation('EMAIL') }}<span
                                                    class="text-danger">*</span></label>
                                            <div class="form-icon position-relative">
                                                <i data-feather="user" class="fea icon-sm icons"></i>
                                                <input type="email" class="form-control ps-5" name="login_email"
                                                    id="login_email" placeholder="{{translation('EMAIL_PLACEHOLDER')}}"
                                                    required="">
                                            </div>
                                            <span class="text-danger" id="email-logerror"></span>
                                        </div>
                                    </div>

                                    <div class="col-lg-12">
                                        <div class="mb-3">
                                            <label class="form-label">{{ translation('PASSWORD') }}<span
                                                    class="text-danger">*</span></label>
                                            <div class="form-icon position-relative">
                                                <i data-feather="key" class="fea icon-sm icons"></i>
                                                <input type="password" class="form-control ps-5 " name="login_Password" id="login_Password" placeholder="{{ translation('PASSWORD_PLACEHOLDER') }}" required="">
                                            </div>
                                            <span class="text-danger" id="email-logerror"></span>
                                            <span class="text-danger" id="invalid-creddential"></span>
                                        </div>
                                    </div>

                                    <div class="col-lg-12">
                                        <div class="d-flex justify-content-between">
                                            <div class="mb-3">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value=""
                                                        id="rememberMe">
                                                    <label class="form-check-label" for="rememberMe">{{
                                                        translation('REMEMBER_ME') }}</label>
                                                </div>
                                            </div>
                                            <p class="forgot-pass mb-0"><a href="{{url('/forgot-password')}}"
                                                    id="modalExForgPassBtn" class="text-dark fw-bold">{{translation('FORGOT_PASSWORD') }}?</a></p>
                                        </div>
                                    </div>

                                    <div class="col-lg-12 mb-0">
                                        <div class="d-grid">
                                            <button type="submit" class="btn btn-primary userLogin" id="modalSignInBtn">
                                                {{translation('SIGN_IN')}}
                                            </button>
                                        </div>
                                    </div>

                                    <div class="col-12 text-center">
                                        <p class="mb-0 mt-3"><small class="text-dark me-2">{{
                                            translation('DONT_HAVE_ACCOUNT') }}</small> <a href="javascript:void(0)"
                                            class="text-dark fw-bold" id="modalExchSignUpBtn">{{
                                            translation('SIGN_UP') }}</a></p>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!--Login End Here-->

                <!--Register Modal start-->
                <div class="container-fluid px-0 d-none" id="subregister">
                    <div class="row align-items-center g-0">
                        <div class="col-lg-12 col-md-12">
                            <div class="modal-header">
                                <h5 class="modal-title">{{translation('REGISTER_TITLE')}}</h5>
                                <button type="button" class="btn btn-icon btn-close" data-bs-dismiss="modal" id="close-modal"><i class="uil uil-times fs-4 text-dark"></i></button>
                            </div>
                            <form class="login-form p-4 needs-validation" novalidate id="register-modal-form">
                                @csrf
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <label class="form-label">{{ translation('NAME') }} <span
                                                    class="text-danger">*</span></label>
                                            <div class="form-icon position-relative">
                                                <i data-feather="user" class="fea icon-sm icons"></i>
                                                <input type="text" id="register_name" class="form-control ps-5"
                                                    name="register_name"
                                                    placeholder="{{translation('NAME_PLACEHOLDER')}}*" required="">
                                            </div>
                                            <span class="text-danger" id="register-name"></span>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <label class="form-label">{{ translation('EMAIL') }} <span
                                                    class="text-danger">*</span></label>
                                            <div class="form-icon position-relative">
                                                <i data-feather="mail" class="fea icon-sm icons"></i>
                                                <input type="email" class="form-control ps-5" id="register_email"
                                                    name="email" placeholder="{{translation('EMAIL_PLACEHOLDER')}}*"
                                                    required="">
                                            </div>
                                            <span class="text-danger" id="register-email"></span>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <label class="form-label">{{ translation('PASSWORD') }}<span
                                                    class="text-danger">*</span></label>
                                            <div class="form-icon position-relative">
                                                <i data-feather="key" class="fea icon-sm icons"></i>
                                                <input type="password" id="register_password" class="form-control ps-5"
                                                    name="password"
                                                    placeholder="{{translation('PASSWORD_PLACEHOLDER')}}*" required="">
                                            </div>
                                            <div class="invalid-feedback">
                                                {{translation('PLEASE_ENTER_VALID_8_DIGIT_PASSWORD')}}!
                                            </div>
                                            <span class="text-danger" id="register-password"></span>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <label class="form-label">{{translation('CONFIRM_PASSWORDS')}}<span
                                                    class="text-danger">*</span></label>
                                            <div class="form-icon position-relative">
                                                <i data-feather="key" class="fea icon-sm icons">

                                                </i>
                                                <input type="password" class="form-control ps-5"
                                                    name="password_confirmation" id="confirm_register_password"
                                                    placeholder="{{translation('CONFIRM_PASSWORDS_PLACEHOLDER')}}*"
                                                    required="">
                                            </div>
                                            <div class="invalid-feedback">
                                                {{translation('PLEASE_ENTER_VALID_8_DIGIT_PASSWORD')}}!
                                            </div>
                                            <span class="text-danger" id="register-password_confirmation"></span>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="d-grid">
                                            <button class="btn btn-primary register_btn" id="modalSignUpBtn" type="submit">
                                                {{translation('REGISTER_BUTTON') }}
                                            </button>
                                        </div>
                                    </div>

                                    <div class="mx-auto text-center">
                                        <p class="mb-0 mt-3"><small class="text-dark me-2">{{
                                            translation('ALREADY_REGISTER') }}</small> <a href="javascript:void(0);"
                                            id="modalExchSignInBtn"
                                            class="text-dark fw-bold">{{translation('SIGN_IN')}}</a></p>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- End of register modal -->

            </div>
        </div>
    </div>
</div>
<!--End of login register-->


  <!-- Add New Address Modal Start Here-->
  <div class="modal fade" id="newAddressModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">{{translation('ADD_ADDRESS')}}</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">X</button>
        </div>
        <div class="modal-body">
            <form id="modalAddressform" class="needs-validation" novalidate >
            <div class="row p-3">

                <div class="col-lg-6 col-md-6">
                    <div class="mb-3">
                        <label>{{translation('CONTACT_NAME')}} <span class="text-danger">*</span></label>
                        <input type="text" name="customer_name" class="form-control"
                            value="{{old('customer_name')}}" required>
                        <span class="text-danger add_customer_name"></span>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="mb-3">
                        <label>{{translation('EMAIL')}}<span
                                class="text-danger">*</span></label>
                        <input type="email" name="customer_email" value="{{old('customer_email')}}"
                            class="form-control" required>
                        <span class="text-danger add_customer_email"></span>
                    </div>
                </div>

                <div class="col-lg-6 ">
                    <div class="mb-3">
                        <label>{{translation('PHONE')}}<span
                                class="text-danger">*</span></label>
                        <input type="text" name="phone" value="{{old('phone')}}"
                            class="form-control" required>
                        <span class="text-danger add_phone"></span>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="mb-3">
                        <label>{{translation('STREET_ADDRESS')}}<span class="text-danger">*</span></label>
                        <input class="billing-address form-control" value="{{old('street_address')}}"
                            type="text" name="street_address" required>
                        <span class="text-danger add_street_address"></span>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="mb-3">
                        <label>{{translation('CITY')}}<span class="text-danger">*</span></label>
                        <input type="text" name="city" value="{{old('customer_city')}}"
                            class="form-control" required>
                        <span class="text-danger add_city"></span>
                    </div>
                </div>

                <div class="col-lg-6 ">
                    <div class="mb-20px">
                        <label>{{translation('STATE')}}<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="state" value="{{old('customer_state')}}"  required />
                        <span class="text-danger add_state"></span>
                    </div>
                </div>

                @if(!empty($countries))
                <div class="col-lg-6 ">
                    <div class="mb-3">
                        <label>{{translation('COUNTRY')}}<span class="text-danger">*</span></label>
                        <select name="countries_id" class="form-control" required>
                            <option selected value="" disabled>
                                {{translation('COUNTRY_PLACEHOLDER')}}
                            </option>
                            @foreach($countries as $key=>$country)
                            <option value="{{$country->countries_id ?? ''}}" @if($Ipcountry->
                                countries_id==$country->countries_id) selected
                                @endif>{{$country->countries_name ?? ''}}</option>
                            @endforeach
                        </select>
                        <span class="text-danger add_countries_id"></span>
                    </div>
                </div>
                @endif
                
                <div class="col-lg-6 ">
                    <div class="mb-3">
                        <label>{{translation('ZIPCODE')}}<span class="text-danger">*</span></label>
                        <input type="text" name="zipcode" value="{{old('customer_postcode')}}"
                            class="form-control" required>
                        <span class="text-danger add_zipcode"></span>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-primary float-right" id="addressformbutton">{{translation('SUBMIT')}}</button>
            </div>
         </form>
        </div>
    </div>
    </div>
</div>
<!-- Add New Address Modal End Here -->


@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
<script>
    $(document).ready(function () {

        // Add Address function  ajax start

        $(document).on('click', '#addressformbutton', function (e) {
        e.preventDefault();
        $('#modalAddressform').addClass('was-validated');
        if ($('#modalAddressform')[0].checkValidity() === false) {
            event.stopPropagation();
        } else {
        var newAddress = document.getElementById("modalAddressform");
        var formData = new FormData(newAddress);
        formData.append('page_source','checkout');
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: "POST",
            url: "{{url('account/add-address')}}",  
            data: formData,
            cache: false,
            contentType: false,
            processData: false,

            success: function (response) {
                if (response.status == 400) {
                    $.each(response.error, function (key, err_val) {
                        $('.add_' + key).text(err_val);
                    });
                } else {
                    var addressList= `<tr>
                    <td class="d-flex gap-3">
                        <input type="radio" name="default_address" class="default_address" checked
                            id="add_${response.addressData.address_id}"
                            value='${response.addressData.address_id}'/>
                        <label for="add_${response.addressData.address_id}">
                            ${response.addressData.customer_name},${response.addressData.customer_email},
                            ${response.addressData.street_address},${response.addressData.city},
                            ${response.addressData.state},
                            ${response.addressData.country_name}, ${response.addressData.zipcode},
                            ${response.addressData.phone}
                        </label>
                        </td>
                    </tr>`;

                    $("input[name='address_id']").removeAttr('checked');
                    $(addressList).prependTo("#addressListBox");
                    $('#modalAddressform').removeClass('was-validated');
                    $('#newAddressModal').modal('hide');
                    $('#modalAddressform').trigger("reset");
                    Notify('{{translation('SUCCESSFULLY_SEND')}}!', true);
                }
            }
        });
        }
    });
    //  Add Address End 

        $('#placeOrderForm').validate({
            rules: {
                customer_name: {
                    required: true
                },
                customer_last_name: {
                    required: true
                },
                customer_company: {
                    required: true
                },
                countries_id: {
                    required: true
                },
                customer_address: {
                    required: true
                },
                customer_city: {
                    required: true
                },
                customer_state: {
                    required: true
                },
                customer_postcode: {
                    required: true
                },
                customer_phone: {
                    required: true
                },
                customer_email: {
                    required: true
                },
                shipping_customer_name: {
                    required: true
                },
                shipping_customer_last_name: {
                    required: true
                },
                shipping_customer_company: {
                    required: true
                },
                shipping_customer_country: {
                    required: true
                },
                shipping_customer_address: {
                    required: true
                },
                shipping_customer_city: {
                    required: true
                },
                shipping_customer_state: {
                    required: true
                },
                shipping_customer_postcode: {
                    required: true
                },
                shipping_customer_phone: {
                    required: true
                },
                shipping_customer_email: {
                    required: true
                },
            },
            messages: {
                customer_name: {
                    required: 'Please enter name'
                },
                customer_last_name: {
                    required: 'Please enter last name'
                },
                customer_company: {
                    required: 'Please enter company name'
                },
                countries_id: {
                    required: 'Please select country'
                },
                customer_address: {
                    required: 'Please enter street address'
                },
                customer_city: {
                    required: 'Please enter street city'
                },
                customer_state: {
                    required: 'Please enter state'
                },
                customer_postcode: {
                    required: 'Please enter postcode'
                },
                customer_phone: {
                    required: 'Please enter phone number'
                },
                customer_email: {
                    required: 'Please enter email'
                },

                shipping_customer_name: {
                    required: 'Please enter name'
                },
                shipping_customer_last_name: {
                    required: 'Please enter last name'
                },
                shipping_customer_company: {
                    required: 'Please enter company name'
                },
                shipping_customer_country: {
                    required: 'Please select country'
                },
                shipping_customer_address: {
                    required: 'Please enter street address'
                },
                shipping_customer_city: {
                    required: 'Please enter street city'
                },
                shipping_customer_state: {
                    required: 'Please enter state'
                },
                shipping_customer_postcode: {
                    required: 'Please enter postcode'
                },
                shipping_customer_phone: {
                    required: 'Please enter phone number'
                },
                shipping_customer_email: {
                    required: 'Please enter email'
                },
            },

            errorElement: 'span',
            errorPlacement: function (error, element) {
                error.addClass('invalid-feedback');
                element.closest('.billing-info').append(error);
            },
            highlight: function (element, errorClass, validClass) {
                $(element).addClass('is-invalid');
                $(element).css("border", " 1px solid red")
            },
            unhighlight: function (element, errorClass, validClass) {
                $(element).removeClass('is-invalid');
                $(element).css("border", "1px solid #ebebeb")
            }
        });



        $(document).on('click', '.default_address', function () {
            var detail = JSON.parse($(this).val());
            console.log('detail', detail);
            $('input[name="customer_name"]').val();
            $('input[name="customer_last_name"]').val();
            $('input[name="customer_company"]').val();
            $('select[name="customer_country"]').val(detail.country_name);
            $('input[name="customer_address"]').val(detail.street_address);
            $('input[name="customer_city"]').val(detail.city);
            $('input[name="customer_state"]').val(detail.state);
            $('input[name="customer_postcode"]').val(detail.zipcode);
            $('input[name="customer_phone"]').val(detail.phone);
            $('input[name="customer_email"]').val();

        });

        $(document).on('click', '.payment-img', function () {
            $('.payment-img').removeClass('activePayment'); // removew old one
            $(this).addClass('activePayment'); // add new one
        });

     

        //Shipping ajax

        $(document).on('change', '.ship-radio-choose', function () {
            var methodKey = $(this).attr('value');
            var url = `{{ url('shipping-details/${methodKey}') }}`;

            $.ajax({
                url: url,
                type: "GET",
                success: function (response) {
                    console.log(response);
                    $('#shippingHtml').html("");
                    $('#shippingHtml').html(response.shippingHtml);
                }
            });
        });

    });

    $('.checkout-toggle').on('click', function () {
        $('.open-toggle').slideToggle(1000);
    });
    $(document).ready(function () {
        $(document).on('click', '#applyButton', function (e) {
            e.preventDefault();
            if ($('#coupon_code').val() != '') {
                var data = {
                    'coupon_code': $('#coupon_code').val(),
                }
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "/apply-coupon",
                    data: data,
                    dataType: "json",

                    beforeSend: function () {
                        $('#applyButton').addClass('disabled');
                        var html = '<i class="fa-solid fa-spinner fa-spin-pulse"></i> {{translation('APPLYING')}}...';
                        $('#sendRequestDemo').html(html);
                    },

                    success: function (response) {

                        if (response.status == 201) {
                            $('.coupon_error').text(response.message);
                            $('#coupon_alert').addClass('show');
                        }
                        if (response.status == 200) {

                            if (response.coupon_response.taxCalculation.length != 0) {
                                $taxhtml = '';
                                $.each(response.coupon_response.taxCalculation, function (key, tax_val) {
                                    $taxhtml += `<h4>${key}: <span>${tax_val}</span></h4>`;
                                });
                                $('.tax_block').html($taxhtml);
                            }

                            $('.subtotal').text(response.coupon_response.amount);
                            var coupon_html = `<li class="d-flex justify-content-between p-3"><span>{{translation('COUPON_DISCOUNT')}}</span>
                                    <strong class="subtotal">
                                        ${response.coupon_response.discount_amount}
                                    </strong>
                                </li>`;
                            $('.coupon_disc_amount').removeClass('hidden');
                            $('.coupon_disc_amount').html(coupon_html);

                            Notify('{{translation('APPLIED_SUCCESS_MSG')}}', true);
                            $('#coupon_code').val('');
                            var coupon_html = `<button type="button" class="btn btn-success">{{translation('COUPON_SUCCESS_MSG')}}</button>`;
                            $('#coupon_area').html(coupon_html);
                        }
                    },
                    complete: function (response) {
                        $('#couponForm').removeClass('was-validated');
                        $('#applyButton').removeClass('disabled');
                        $('#applyButton').html('{{translation('APPLY')}}');
                    }
                });
            }
            else {
                $('.coupon_error').text('{{translation('ERROR_COUPON_MSG')}}');
                $('#coupon_alert').addClass('show');
            }
        });
    });
    $('.coupon_alt_btn').click(function () {
        $('#coupon_alert').addClass('fade');
        $('#coupon_alert').removeClass('show');
    });

    $('.login_alt_btn').click(function () {
        $('.login_alert').addClass('fade');
        $('.login_alert').removeClass('show');
    });


    $("#cpnbtn").click(function () {
        $("#subregister").addClass('d-none');
        $("#forgot_password").addClass('d-none');
        $("#sublogin").removeClass('d-none');
        $("#login-popup").modal('show');
    });

    // Sign in to SignUp form

    $("#modalExchSignUpBtn").click(function () {
        $("#sublogin").addClass('d-none');
        $("#subregister").removeClass('d-none');
    });

    // Sign up to SignIn form

    $("#modalExchSignInBtn").click(function () {
        $("#sublogin").removeClass('d-none');
        $("#subregister").addClass('d-none');
    });

    // Forgot password button to forgot password form

    $("#modalExForgPassBtn").click(function () {
        $("#sublogin").addClass('d-none');
        $("#forgot_password").removeClass('d-none');
    });
    $(document).on('click', '#modalSignInBtn', function (e) {
        e.preventDefault();
        $('#login-modal-form').addClass('was-validated');
        if ($('#login-modal-form')[0].checkValidity() === false) {
            event.stopPropagation();
        } else {
            var data = {
                'email': $('#login_email').val(),
                'password': $('#login_Password').val(),
                'login_source': $('#login_source').val(),
                'remember': $('#rememberMe').val(),
            }
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "{{ url('/customer-login') }}",
                data: data,
                dataType: "json",

                beforeSend: function () {
                    $('#modalSignInBtn').addClass('disabled');
                    $('#modalSignInBtn').html(
                        ' <i class="fa-solid fa-spinner fa-spin-pulse"></i>  {{translation('LOGGING')}}....'
                    );
                },
                success: function (response) {
                    console.log(response);
                    if (response.status == "200") {
                        $('#login-modal-form').trigger("reset");
                        $('#login-modal-form').removeClass('was-validated');
                        $("#login-popup").modal('hide');
                        location.reload();
                    }

                    if (response.status == "201") {

                        $(".login_alert").addClass('alert-danger');
                        $(".login_alert").addClass('show');
                        $("#alert_message").html(response.message);
                        $('#modalSignInBtn').html('{{translation('SIGN_IN')}}');
                    }
                },

                complete: function (response) {
                    $('#modalSignInBtn').removeClass('disabled');
                    $('#modalSignInBtn').html('{{translation('SIGN_IN')}}');
                }
            });
        }
    });
    // Register Ajax start here

    $(document).on('click', '#modalSignUpBtn', function (e) {
        e.preventDefault();
        $('#register-modal-form').addClass('was-validated');
        if ($('#register-modal-form')[0].checkValidity() === false) {
            event.stopPropagation();
        } else {
            var data = {
                'name': $('#register_name').val(),
                'email': $('#register_email').val(),
                'password': $('#register_password').val(),
                'password_confirmation': $('#confirm_register_password').val(),
            }

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "{{ url('customer-register') }}",
                data: data,
                dataType: "json",

                beforeSend: function () {
                    $('#modalSignUpBtn').addClass('disabled');
                    $('#modalSignUpBtn').html(
                        '<i class="fa-solid fa-spinner fa-spin-pulse"></i> {{translation('REGISTERING')}}...'
                    );
                },

                success: function (response) {
                    if (response.status == 400) {
                        $.each(response.error, function (key, err_val) {
                            $('#' + 'register-' + key).text(err_val);
                        });
                    }
                    if (response.status == 200) {

                        $('#register-modal-form').trigger("reset");
                        $('#register-modal-form').removeClass('was-validated');
                        $("#sublogin").removeClass('d-none');
                        $(".login_alert").removeClass('alert-danger');
                        $(".login_alert").addClass('alert-success');
                        $("#alert_message").html("{{translation('REGISTER_SUCCESS_MSG')}}!");
                        $(".login_alert").addClass('show');
                        $("#subregister").addClass('d-none');
                    }
                },
                complete: function () {
                    $('#modalSignUpBtn').removeClass('disabled');
                    $('#modalSignUpBtn').html('{{translation('SIGN_UP')}}');
                }
            });
        }
    });
</script>
@endpush