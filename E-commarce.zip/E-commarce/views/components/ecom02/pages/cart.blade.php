      @php

$main_arr = [
  'title'=>'Cart',
  'sublist' => [
    [
    'name'=>'HOME',
    'link'=>url("/")
    ],
    [
    'name'=>'cart' ,
    'link'=>url("")
    ], 
  ]
];
@endphp
<!-- Hero Start -->
<x-Ecom02.SharedComponent.BreadCrumb :data="$main_arr" /> 
<!-- Hero End -->
<!-- Start -->
<section class="section" id="cart-table">
    @if (!empty($list['cart_list']) && sizeof($list['cart_list'])>0)
        <div class="container cart-page">
            <div class="row">
                <div class="col-12">
                    <div class="table-responsive bg-white border rounded">
                        <table class="table mb-0 table-center">
                            <thead>
                                <tr>
                                    <th class="border-bottom text-center py-3" style="min-width:20%;">{{translation('CART_PRODUCT_IMAGE')}}</th>
                                    <th class="border-bottom text-start py-3" style="min-width:30%; width:40%">{{translation('CART_PRODUCT_NAME')}}</th>
                                    <th class="border-bottom text-center py-3" style="min-width: 15%;">{{translation('CART_PRODUCT_UNIT_PRICE')}}</th>
                                    <th class="border-bottom text-center py-3" style="min-width: 20%;">{{translation('CART_PRODUCT_QUANTITY')}}</th>
                                    <th class="border-bottom text-center py-3" style="min-width:15% ;">{{translation('CART_SUBTOTAL')}}</th>
                                    <th class="border-bottom py-3" style="min-width:20px "></th>
                                </tr>
                            </thead>

                            <tbody>
                            @if (!empty($list['cart_list']))
                                @foreach ($list['cart_list'] as $cart )
                                    <tr class="shop-list" id="cart-table_{{$cart->cart_id}}">
                                        <td>
                                            <div class="text-center">
                                                <a href="{{url('product/'.$cart->product->product_slug)}}">
                                                    <img src="{{getFullImageUrl($cart->product->product_image)}}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" class="img-fluid avatar avatar-small " style="height:auto;" alt="{{ $cart->product->products_name ?? ''}}">
                                                </a>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-block align-items-center">
                                                
                                                    <a href="{{url('product/'.$cart->product->product_slug)}}">
                                                    <h6 class="mb-0">{{ $cart->product->products_name ?? ''}}</h6>
                                                    </a>
                                                
                                                @if (isset($cart->attributes) && !empty($cart->attributes))
                                                    <div class="flex-1 text-start d-flex">
                                                        @foreach ($cart->attributes as $attribute)
                                                            @if (isset($attribute->product_options))
                                                                <div>
                                                                    <h6 class="text-dark mb-0">{{ $attribute->product_options->products_options_name }}</h6>
                                                                    <p class="text-muted mb-0">{{ $attribute->products_options_values_name }}</p>
                                                                </div>
                                                            @endif
                                                        @endforeach
                                                    </div>     
                                                @endif
                                            </div>
                                        </td>
                                        <td class="text-center prd_prc__{{$cart->cart_id}}">
                                            {{ currencyFormat($cart->final_price ?? 0)}}
                                        </td>
                                        <td class="text-center qty-icons">
                                            <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" class="btn btn-icon btn-soft-primary minus cartqtybutton" >-</button>
                                            <input min="1" id="{{$cart->cart_id}}_qty" data-cart="{{$cart->cart_id}}" name="qtybutton" value="{{ $cart->qty }}" type="number" class="btn btn-icon btn-soft-primary qty-btn quantity">
                                            <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="btn btn-icon btn-soft-primary plus cartqtybutton">+</button>
                                        </td>
                                        <td class="text-center  total_price_{{$cart->cart_id}}"> 
                                            @php
                                                $qty = (int) $cart->qty;
                                                $price =$cart->final_price ?? 0;
                                                echo currencyFormat($qty*$price); 
                                            @endphp
                                        </td>
                                        <td class="h6 text-center"><a href="javascript:void(0)" onclick="actionOnCart({{$cart->cart_id}},'del')" class="text-danger"><i class="uil uil-times"></i></a>
                                        </td>
                                    </tr>

                                    @if($cart->product->products_prices !=null)
                                         <input type="hidden" hidden class="minordqty"  id="{{ $cart->cart_id }}_min_qty" value="{{$cart->product->products_prices->min('product_qty')}}">
                                         <input type="hidden" hidden class="ordqty" id="{{ $cart->cart_id }}_ord_qty"  value="{{$cart->qty}}">
                                    @endif

                                @endforeach                                   
                            @endif
                            </tbody>
                        </table>
                    </div>
                </div><!--end col-->
            </div><!--end row-->
            <div class="row">
                <div class="col-lg-8 col-md-6 mt-4 pt-2">
                    <a href="{{url('/')}}" class="btn btn-primary">{{translation('CONTINUE_TO_SHOP')}}</a>
                    <!--  <a href="javascript:void(0)" class="btn btn-soft-primary ms-2">Update Cart</a> -->
                </div>
                <div class="col-lg-4 col-md-6 ms-auto mt-4 pt-2">
                    <div class="table-responsive bg-white rounded border">
                        <table class="table table-center table-padding mb-0">
                            <tbody>
                                <tr>
                                    <td class="h6 ps-4 py-3 fw-bold">{{translation('CART_TOTAL')}}</td>
                                    <td class="text-end fw-bold pe-4 product_total">{{ currencyFormat($list['product_total'])}}</td>
                                </tr>
                                {{-- <tr class="bg-light">
                                    <td class="h6 ps-4 py-3"> GrandTotal</td>
                                    <td class="text-end fw-bold pe-4 grandAmount">
                                        {{ currencyFormat($list['grand_total']) }}
                                    </td>
                                </tr> --}}
                            </tbody>
                        </table>
                    </div>
                    <div class="mt-4 pt-2 text-end">
                        <a href="{{ url('checkout') }}" class="btn btn-primary">{{translation('PROCEED_CHECKOUT')}}</a>
                    </div>
                </div><!--end col-->
            </div><!--end row-->
        </div><!--end container-->
    @else
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-4 mx-auto">
                    <img src="{{ LoadAssets('assets/images/EmptyImages/Cart-Empty.jpg')}}" class="rounded mx-auto d-block" width="286px" height="200px" alt="{{getSetting('site_title')}} Cart-Empty">
                    <p class="h4 text-center text-dark mt-2">{{translation('EMPTY_CART_MSG')}}</p>
                    <div class="text-center my-3">
                        <a href="{{url('/')}}" class="btn btn-primary btn-lg btn-block" role="button" aria-pressed="true">{{translation('CONTINUE_TO_SHOP')}}</a>
                    </div>
                </div>
            </div>
        </div>
    @endif
</section><!--end section-->
<!-- End -->

@push('scripts')
<script>
    $(document).on("click", ".cartqtybutton",function () { 
        let cart_id = $(this).parent().find('input').data('cart');
        var min_ord_qty=$(`#${cart_id}_min_qty`).val();
        var ord_qty=$(`#${cart_id}_ord_qty`).val();
        var qty = $(`#${cart_id}_qty`).val();

        if(min_ord_qty !='undefined')
        {   
            if(Number(qty)<Number(min_ord_qty))
            {   
                Notify(`Please add minimum ${min_ord_qty} Qty.`, false);
                $(`#${cart_id}_qty`).val(ord_qty);
            }
            else
            {
            actionOnCart(cart_id, 'add'); 
            }
        }else{
            actionOnCart(cart_id, 'add');
        }
    });

    function actionOnCart(cart_id, type){
    var qty = $(`#${cart_id}_qty`).val();
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $.ajax({
        url:'{{ route("incDecDelCart") }}',
        method:'POST',
        data:{
            cart_id : cart_id,
            qty:qty, 
            type:type,
        },
        success:function(response){
            $('.count-cart-total').text(response.cart_response.total_count);
            if(response.cart_response.total_count > 0){
                $('.product_total').text(response.cart_response.products_total);
                $('.popup_cartTotal').text(response.cart_response.grand_totals);
                $('.grandAmount').text(response.cart_response.grand_totals);
                    $(response.cart_response.cart_list).each(function(key,value) {
                        if(cart_id==value.cart_id){
                            $('.prd_prc__'+value.cart_id).text(value.fin_price);
                            $('.total_price_'+value.cart_id).text(value.total);
                            $('.cart_popupQty_'+value.cart_id).text(value.qty);
                        } 
                    });  
                } else{ 
                    var html = `<div class="container">
                                <div class="row">
                                    <div class="col-12 col-lg-4 mx-auto">
                                        <img src="{{ LoadAssets('assets/images/EmptyImages/Cart-Empty.jpg')}}" class="rounded mx-auto d-block" width="286px" height="200px" alt="{{getSetting('site_title')}} Cart-Empty">
                                        <p class="h4 text-center text-dark mt-2">{{translation('EMPTY_CART_MSG')}}</p>
                                        <div class="text-center my-3">
                                            <a href="{{url('/')}}" class="btn btn-primary btn-lg btn-block" role="button" aria-pressed="true">{{translation('CONTINUE_TO_SHOP')}}</a>
                                        </div>
                                    </div>
                                </div>
                            </div>`;
                    $('.cart-page').html(html);
                    $('.popupDiv').html(html);
                } 
            var msg = type === 'del' ? '{{translation('CART_ITEM_REMOVED_MSG')}}!' : '{{translation('CART_ITEM_UPDATE_MSG')}}!';
            Notify(msg, true); 
            if(type === 'del'){
                $('#cart-table_'+cart_id).remove();
                $('#cart-total_'+cart_id).remove();
            }
        },
        error:function(error){
            Notify(error.message, false);
        }
    });

    }

</script>
@endpush