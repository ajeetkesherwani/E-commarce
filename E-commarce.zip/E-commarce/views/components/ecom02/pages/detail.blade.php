@php
$avgrating = AvgRating($products->product_id);
$currentURL = URL::current();

use App\Models\Ecom\Services\EcomService;
@endphp
<x-Ecom02.SharedComponent.BreadCrumb :data="$breadCumbArr" />
<!-- Hero End -->
<section class="section pb-0">
  <div class="container">
    <div class="row ">
      <div class="col-md-5">
        <!-- <div class="tiny-single-item">
          <div class="tiny-slide active">
            <img src="{{ getFullImageUrl($products->product_image) }}"
              onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
              data-zoom-image="{{ getFullImageUrl($products->product_image) }}"
              alt="{{ $products->products_name ?? '' }}" class="img-fluid rounded" alt="">
          </div>
          
          @if(!empty($products->products_to_gallery))
            @foreach ($products->products_to_gallery as $key => $data)
            @if(!empty($data))
            <div id="gallery" class="tiny-slide">
              <img src="{{$data}}"
                onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                class="img-fluid rounded" />
            </div>
            @endif
            @endforeach
          @endif

          
        </div> -->
        <div class="d-flex flex-column justify-content-center">
          <div class="product_carousel"> 
            <img src="{{ $products->image_url }}" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"  id="main_product_image" width="350"> 
          </div>
          @if (!empty($products->products_to_gallery) && sizeof($products->products_to_gallery)>0)
            <div class="thumbnail_images">
              <ul id="thumbnail">
                @foreach ($products->products_to_gallery as $key => $data)
                  @if(!empty($data))
                    <li>
                      <img onclick="changeImage(this)" src="{{$data}}" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'">
                    </li>
                  @endif
                @endforeach
              </ul>
            </div>
          @endif
      </div>
      </div>
      <!--end col-->
      

      <div class="col-md-7 mt-4 mt-sm-0 pt-2 pt-sm-0">
        <div class="section-title ms-md-4 p-brand">
          <h5 class="mb-0">{{ $products->products_name ?? '' }}</h5>

          @if(in_array($products->product_type_id, ['1', '2', '4']))
          @if (!empty($products->products_to_brand->brand_name))
          <p class="my-2">{{translation('PRODUCT_BRAND')}} :
            <span>
              <a href="{{ EcomService::url($products->products_to_brand->brand_id ?? '', 'brand') }}">{{$products->products_to_brand->brand_name ?? '' }}
              </a>
            </span>
          </p>
          @endif
          @endif

          <div class="col-lg-12 pt-1">
            <div class="d-flex shop-list align-items-center">
              <a href="javascript:void(0)" class="btn btn-icon btn-pills btn-soft-danger">
                <i data-feather="heart" onclick="addToWishListFromDetail({{ $products->product_id }})" title="Wishlist"
                  class="icons">
                </i>
              </a>
              @if (webFunctionStatus(config('constkey.is_cart_enabled')))
              <div class="qty-icons ms-2">
                <span class="mb-0">{{translation('ADD_TO_WISHLIST')}}
                </span>
              </div>
              @endif
            </div>
          </div>

          @if (!empty($avgrating))
          <ul class="list-unstyled text-warning h5 mb-0">
            <li class="list-inline-item">
              @for ($i = 0; $i<5 ; $i++) @if($i<$avgrating) <i class="mdi mdi-star"></i>
                @else
                <i class="mdi mdi-star-outline"></i>
                @endif
                @endfor
            </li>
          </ul>
          @endif

          @if(!empty($products->products_to_features) && sizeof($products->products_to_features)>0)
          <div class="mb-2 mt-3">
            <ul class="font-size-14 pl-3 ml-1 text-gray-110 feature-list">
              @foreach($products->products_to_features as $features)
              <li>{{$features->feature_title ?? ''}} : {{$features->feature_value ?? ''}}</li>
              @endforeach
            </ul>
          </div>
          @endif

          @if($products->products_prices !=null)
          <input type="hidden" hidden class="minordqty" value="{{$products->products_prices->min('product_qty')}}">
          @endif

          <form action="{{route('addUpdateToCart')}}" method="post" id="cartform">
            @csrf
            <div class="row mt-2">
              <div class="col-lg-12"> 
                @if (!empty($products->productAttribute))
                    @foreach ($products->productAttribute as $attribute)
                      <div class="d-flex align-items-center product-variants">
                        <h6 class="mb-0">{{ ucfirst($attribute->option_name ?? '') }} :</h6>
                          @if (isset($attribute->option_value_list) && !empty($attribute->option_value_list))
                            <ul class="list-unstyled mb-0 ms-3" id="attributes_{{ $attribute->options_id }}">
                                @foreach ($attribute->option_value_list as $idx => $option_value)
                                  <li class="list-inline-item input-container">
                                    <input class="input-radio" type="radio" attribute="{{ $attribute->options_id }}"
                                      name="attributes_{{ $attribute->options_id }}" {{ $idx==0 ? 'checked' : '' }}
                                      value="{{ $attribute->options_id }}_{{ $option_value->options_values_id }}"
                                      title="{{ $option_value->productOptionsValue->products_options_values_name }}">
                                    <span class="radio-label">
                                      {{$option_value->productOptionsValue->products_options_values_name }}
                                    </span>
                                  </li>
                                @endforeach
                            </ul>
                          @endif
                      </div>
                    @endforeach
                @endif
              </div>

              <!-- Wholesale Product List End here -->
              <div class="pricing-meta">
                @if($products->products_prices !=null)
                <div class="position-relative">
                  <div class="pricing-meta-head">
                    <div class="qty"><b>{{translation('PRODUCT_QTY')}}</b></div>
                    <div class="price"><b>{{translation('PRODUCT_PRICE')}}</b></div>
                  </div>
                  <div class="tiny-four-item">
                    @foreach($products->products_prices as $producprice)
                    <div>
                      <div class="qty"><b>{{$producprice->product_qty}}</b></div>
                      <div class="amount">{{currencyFormat($producprice->sale_price)}}</div>
                    </div>
                    @endforeach
                  </div>
                </div>
                @endif
              </div>
              <!-- Wholesale Product List End  here-->


              @if($products->products_prices!=null)
              <!-- Show Only Product is Price wholesale Product-->
              <h5 class="mt-3">
                {{translation('PRODUCT_PRICE')}} :
              @foreach($products->products_prices as $holeprice)
                @if($holeprice->discount_percent !='0')
                  <del class="text-danger ms-2 discount_amount">
                    {{currencyFormat($holeprice->max_sale_price) }}
                  </del>
                @endif
                <span class="old-price">
                  {{ currencyFormat($holeprice->sale_price ?? '0.00') }}
                </span>
                <span>
                  / {{$holeprice->product_qty}} Unit
                </span>
                @if($holeprice->discount_percent != '0')
                  <span class="text-success ms-1">
                    {{ currencyFormat( $holeprice->discount_percent )}}% {{translation('PRODUCT_DISCOUNT')}}
                  </span>
                @endif
                @break
              @endforeach
              </h5>
              <!-- End of wholesale product Price -->
              @else
              <h5 class="mt-3">
                {{translation('PRODUCT_PRICE')}} :
                <span class="mt-3">
                  @if($products->discount_type != 'no')
                    <del class="text-danger ms-2 discount_amount">{{currencyFormat($products->max_sale_price) }}
                    </del>
                  @endif 
                    <span class="old-price not-cut">
                      {{currencyFormat($products->sale_price ?? '0.00')}}
                    </span>
                  @if($products->discount_type != 'no')
                  @if($products->discount_type == 'flat')
                    <span class="text-success ms-2">
                      {{ currencyFormat($products->discount_amount) }} {{translation('PRODUCT_DISCOUNT')}}
                    </span>
                  @else
                    <span class="text-success ms-2">
                      {{ currencyFormat( $products->discount_amount )}}% {{translation('PRODUCT_DISCOUNT')}}
                    </span>
                  @endif
                  @endif
                </span>
              </h5>
              @endif

              <!--end col-->
              <div class="col-lg-12 pt-1">
                <div class="d-flex shop-list align-items-center">
                  <h6 class="mb-0">{{translation('PRODUCT_QUANTITY')}}
                  </h6>
                  @if (webFunctionStatus(config('constkey.is_cart_enabled')))
                  <div class="qty-icons ms-3 qty_buttons">
                    <button type="button" onclick="this.parentNode.querySelector('input[type=number]').stepDown()"
                      class="btn btn-icon btn-soft-primary minus qtybutton">-
                    </button>
                    @if($products->products_prices !=null)
                      @foreach($products->products_prices as $producprice)
                        <input type="number" min="{{$producprice->product_qty}}" onblur="QtyToPrice('page')" id="qtyItemAdd"
                          name="qty" value="{{$producprice->product_qty}}"
                          class="btn btn-icon btn-soft-primary qty-btn quantity">
                        @break
                      @endforeach
                    @else
                    <input type="number" min="1" id="qtyItemAdd" onblur="QtyToPrice('page')" name="qty" value="1"
                      class="btn btn-icon btn-soft-primary qty-btn quantity">
                    @endif
                    <button type="button" onclick="this.parentNode.querySelector('input[type=number]').stepUp()"
                      class="btn btn-icon btn-soft-primary qtybutton">+</button>
                    <input type="hidden" value="page" class="source">
                  </div>
                  @endif
                </div>
              </div>
              <!--end col-->
            </div>

            <!--end row-->
            <div class="mt-4 pt-2">
              <input type="hidden" name="product_slug" value="{{$products->product_slug}}">
              @if (webFunctionStatus(config('constkey.is_cart_enabled')))
              <button type="submit" class="btn btn-primary">{{translation('ADD_TO_CART')}}
              </button>
              @endif

              @if (webFunctionStatus(config('constkey.is_enquiry_enabled')))
              <a href="javascript:void(0)" onclick="showEnquiryForm()"
                class="btn btn-soft-primary ms-2">{{translation('PRODUCT_ENQUIRY_BUTTON')}}
              </a>
              @endif

            </div>
          </form>
          <div class="row mt-2 pt-2">
            <div class="col-lg-12 pt-1">
              <div class="d-flex shop-list align-items-center">
                <h6 class="mb-0">{{translation('PRODUCT_SHARE')}}
                </h6>
                <div class="qty-icons ms-3">
                  <ul class="list-unstyled social-icon foot-social-icon ">
                    <li class="list-inline-item">
                      <a href="https://www.facebook.com/sharer/sharer.php?u={{ $currentURL }}" target="_blank"
                        class="rounded">
                        <i data-feather="facebook" class="fea icon-sm fea-social">
                        </i>
                      </a>
                    </li>
                    <li class="list-inline-item">
                      <a href="https://www.instagram.com/?url={{$currentURL}}" target="_blank" class="rounded">
                        <i data-feather="instagram" class="fea icon-sm fea-social">
                        </i>
                      </a>
                    </li>
                    <li class="list-inline-item">
                      <a href="https://twitter.com/intent/tweet?text={{ $currentURL }}" target="_blank" class="rounded">
                        <i data-feather="twitter" class="fea icon-sm fea-social">
                        </i>
                      </a>
                    </li>
                    <li class="list-inline-item">
                      <a href="https://api.whatsapp.com/send?text={{ $currentURL }}" target="_blank" class="rounded">
                        <img class="" src="{{ LoadAssets('assets/images/icons/whatsapp-icon.png') }}"
                          style="height:18px; width:18px;">
                      </a>
                    </li>
                  </ul><!--end icon-->
                </div>
              </div>
            </div><!--end col-->
          </div><!--end row-->
        </div><!--end col-->
      </div><!--end row-->
    </div><!--end container-->
    <div class="container mt-100 mt-60">
      <div class="row">
        <div class="col-12">
          <ul
            class="nav nav-pills shadow flex-column flex-sm-row d-md-inline-flex mb-0 p-1 rounded position-relative overflow-hidden"
            id="pills-tab" role="tablist">
            <li class="nav-item m-1">
              <a class="nav-link py-2 px-5 active rounded" id="description-data" data-bs-toggle="pill"
                href="#description" role="tab" aria-controls="description" aria-selected="false">
                <div class="text-center">
                  <h6 class="mb-0">{{translation('PRODUCT_DESCRIPTION_TITLE')}}</h6>
                </div>
              </a>
              <!--end nav link-->
            </li>
            <!--end nav item-->
            <li class="nav-item m-1">
              <a class="nav-link py-2 px-5 rounded" id="additional-info" data-bs-toggle="pill" href="#additional"
                role="tab" aria-controls="additional" aria-selected="false">
                <div class="text-center">
                  <h6 class="mb-0">{{translation('PRODUCT_DETAILS_TITLE')}}
                  </h6>
                </div>
              </a>
              <!--end nav link-->
            </li>
            <!--end nav item-->
            <li class="nav-item m-1">
              <a class="nav-link py-2 px-5 rounded" id="review-comments" data-bs-toggle="pill" href="#review" role="tab"
                aria-controls="review" aria-selected="false">
                <div class="text-center">
                  <h6 class="mb-0">{{translation('PRODUCT_REVIEWS_TITLE')}}
                  </h6>
                </div>
              </a>
              <!--end nav link-->
            </li>
            <!--end nav item-->
          </ul>
          <div class="tab-content mt-5" id="pills-tabContent">
            <div class="card border-0 tab-pane fade show active" id="description" role="tabpanel"
              aria-labelledby="description-data">
              <p class="text-muted mb-0">{!! $products->products_description ?? '' !!}
              </p>
            </div>
            <div class="card border-0 tab-pane fade" id="additional" role="tabpanel" aria-labelledby="additional-info">
              <table class="table">
                @if (!empty($products) && in_array($products->product_type_id, ['1', '2', '4']))
                <tbody>
                  <tr>
                    <td style="width: 175px;">{{translation('PRODUCT_SKU')}}
                    </td>
                    <td class="text-muted">{{ $products->product_sku }}
                    </td>
                  </tr>
                  <tr>
                    <td>{{translation('PRODUCT_MODEL')}}
                    </td>
                    <td class="text-muted">{{ $products->product_model }}
                    </td>
                  </tr>
                  <tr>
                    <td>{{translation('PRODUCT_CONDITION')}}
                    </td>
                    <td class="text-muted">{{ $products->product_condition == 1 ? 'New' : 'Refurbished' }}
                    </td>
                  </tr>
                  <tr>
                    <td>{{translation('PRODUCT_BRAND_NAME')}}
                    </td>
                    <td class="text-muted">{{ $products->products_to_brand->brand_name ?? ''}}
                    </td>
                  </tr>
                  <tr>
                    @if(!empty($products->products_to_features) && sizeof($products->products_to_features)>0)
                    @foreach($products->products_to_features as $featKey=>$featVal)
                  <tr>
                    <td>{{$featVal->feature_title ?? ''}}
                    </td>
                    <td class="text-muted">{{$featVal->feature_value ?? ''}}
                    </td>
                  </tr>
                  @endforeach
                  @endif
                  </tr>
                </tbody>
                @endif
              </table>
            </div>
            <div class="card border-0 tab-pane fade" id="review" role="tabpanel" aria-labelledby="review-comments">
              <div class="row">
                <div class="col-lg-6 mt-4 mt-lg-0 pt-2 pt-lg-0">
                  <form class="ms-lg-4" id="reviewform">
                    <!-- @csrf -->
                    <div class="row">
                      <div class="col-12">
                        <h5>{{translation('PRODUCT_ADD_REVIEWS')}}
                        </h5>
                      </div>
                      <div class="col-12 mt-4">
                        <h6 class="small fw-bold">{{translation('PRODUCT_QUALITY_RATING')}}
                        </h6>
                        <div class="star-box">
                          <div class="rate">
                            <input type="radio" id="star5" name="quality_rating" class="quality_rating" value="5" />
                            <label for="star5" title="text">{{translation('RATING_5STAR')}}
                            </label>
                            <input type="radio" id="star4" name="quality_rating" class="quality_rating" value="4" />
                            <label for="star4" title="text">{{translation('RATING_4STAR')}}
                            </label>
                            <input type="radio" id="star3" name="quality_rating" class="quality_rating" value="3" />
                            <label for="star3" title="text">{{translation('RATING_3STAR')}}
                            </label>
                            <input type="radio" id="star2" name="quality_rating" class="quality_rating" value="2" />
                            <label for="star2" title="text">{{translation('RATING_2STAR')}}
                            </label>
                            <input type="radio" id="star1" name="quality_rating" class="quality_rating" value="1" />
                            <label for="star1" title="text">{{translation('RATING_1STAR')}}
                            </label>
                          </div>
                          <span class="text-danger" id="quality_rating">
                          </span>
                        </div>
                      </div>
                      <!--end col-->
                      <div class="col-12 mt-4">
                        <h6 class="small fw-bold">{{translation('PRODUCT_PRICE_RATING')}}
                        </h6>
                        <div class="star-box">
                          <div class="rate">
                            <input type="radio" id="stars5" name="price_rating" class="price_rating" value="5" />
                            <label for="stars5" title="text">{{translation('RATING_5STAR')}}
                            </label>
                            <input type="radio" id="stars4" name="price_rating" class="price_rating" value="4" />
                            <label for="stars4" title="text">{{translation('RATING_4STAR')}}
                            </label>
                            <input type="radio" id="stars3" name="price_rating" class="price_rating" value="3" />
                            <label for="stars3" title="text">{{translation('RATING_3STAR')}}
                            </label>
                            <input type="radio" id="stars2" name="price_rating" class="price_rating" value="2" />
                            <label for="stars2" title="text">{{translation('RATING_2STAR')}}
                            </label>
                            <input type="radio" id="stars1" name="price_rating" class="price_rating" value="1" />
                            <label for="stars1" title="text">{{translation('RATING_1STAR')}}
                            </label>
                          </div>
                          <span class="text-danger" id="price_rating">
                          </span>
                        </div>
                      </div>
                      <!--end col-->
                      @guest
                      <div class="col-lg-6">
                        <div class="mb-3">
                          <label class="form-label">{{translation('PRODUCT_REVIEW_NAME')}}
                            <span class="text-danger">*
                            </span>
                          </label>
                          <div class="form-icon position-relative">
                            <i data-feather="user" class="fea icon-sm icons">
                            </i>
                            <input id="name" name="customers_name" type="text"
                              placeholder="{{translation('PRODUCT_REVIEW_NAME_PLACEHOLDER')}}"
                              class="form-control customers_name ps-5" required="">
                            <span class="text-danger" id="customers_name">
                            </span>
                          </div>
                        </div>
                      </div>
                      <!--end col-->
                      <div class="col-lg-6">
                        <div class="mb-3">
                          <label class="form-label">{{translation('PRODUCT_REVIEW_EMAIL')}}
                            <span class="text-danger">*
                            </span>
                          </label>
                          <div class="form-icon position-relative">
                            <i data-feather="mail" class="fea icon-sm icons">
                            </i>
                            <input id="email" type="email" placeholder="{{translation('PRODUCT_REVIEW_EMAIL_PLACEHOLDER')}}"
                              name="customers_email" class="form-control customers_email ps-5" id="emailAddress"
                              required="">
                            <span class="text-danger" id="customers_email">
                            </span>
                          </div>
                        </div>
                      </div>
                      <!--end col-->
                      @endguest
                      <div class="col-md-12 mt-3">
                        <div class="mb-3">
                          <label class="form-label">{{translation('PRODUCT_REVIEW_TITLE')}}
                          </label>
                          <div class="form-icon position-relative">
                            <input placeholder="{{translation('PRODUCT_REVIEW_TITLE_PLACEHOLDER')}}" type="text" name="reviews_title"
                              class="form-control reviews_title" required />
                            <span class="text-danger" id="reviews_title">
                            </span>
                          </div>
                        </div>
                      </div>
                      <!--end col-->
                      <div class="col-md-12 mt-3">
                        <div class="mb-3">
                          <label class="form-label">{{translation('PRODUCT_YOUR_REVIEW')}}
                          </label>
                          <div class="form-icon position-relative">
                            <i data-feather="message-circle" class="fea icon-sm icons">
                            </i>
                            <textarea id="message" placeholder="{{translation('PRODUCT_REVIEW_MESSAGE_PLACEHOLDER')}}" rows="5" name="reviews_text"
                              class="form-control reviews_text ps-5" required=""></textarea>
                            <span class="text-danger" id="reviews_text"></span>
                          </div>
                        </div>
                      </div>
                      <!--end col-->
                      <input type="hidden" value="{{ $products->product_id }}" class="products_id" name="products_id">
                      <input type="hidden" value="0" name="reviews_read">
                      <div class="col-md-12">
                        <div class="send d-grid">
                          <button type="submit" class="btn btn-primary" id="reviewformbutton">{{translation('PRODUCT_REVIEW_SUBMIT')}}
                          </button>
                        </div>
                      </div>
                      <!--end col-->
                      <ul id="successlist">
                      </ul>
                    </div>
                    <!--end row-->
                  </form>
                  <!--end form-->
                </div>
                <!--end col-->
                <div class="col-lg-6">
                  <ul class="media-list list-unstyled mb-0">
                    @if (!$review_data->isEmpty())
                    <li>
                      @foreach ($review_data as $key => $data)
                      <div class="d-flex justify-content-between">
                        <div class="d-flex align-items-center">
                          <a class="pe-3" href="#">
                            <img src="{{ asset('profileimages/default-user.png') }}"
                              class="img-fluid avatar avatar-md-sm rounded-circle shadow" alt="img">
                          </a>
                          <div class="flex-1 commentor-detail">
                            <h6 class="mb-0">
                              <a href="javascript:void(0)" class="text-dark media-heading">{{ $data->customers_name }}
                              </a>
                            </h6>
                            <small class="text-muted">
                              @php
                              echo(date('d F,Y', strtotime($data->created_at ?? '')));
                              @endphp
                              <!-- 15th August, 2021 at 05:44 pm -->
                            </small>
                          </div>
                        </div>
                        <ul class="list-unstyled mb-0">
                          <span>
                            <b>{{translation('PRODUCT_QUALITY_RATING')}}
                            </b>
                          </span>
                          @php
                            $j = 0;
                            for ($i = 0; $i< $data->quality_rating; $i++) {
                              echo '<i class="ion-android-star"></i>';
                              $j++;
                            }
                              for ($k = 5; $k > $j; $k--) {
                              echo '<i class="ion-android-star-outline"></i>';
                            }
                          @endphp
                          <span>
                            <b>{{translation('PRODUCT_PRICE_RATING')}}
                            </b>
                          </span>
                            @php
                            $j = 0;
                            for ($i = 0; $i< $data->price_rating; $i++) {
                              echo '<i class="ion-android-star"></i>';
                              $j++;
                            }
                            for ($k = 5; $k > $j; $k--) {
                              echo '<i class="ion-android-star-outline"></i>';
                            }
                          @endphp
                        </ul>
                      </div>
                      <div class="mt-3">
                        <p class="text-muted fst-italic p-3 bg-light rounded">{{ $data->reviews_text }}
                        </p>
                      </div>
                      @endforeach
                      <div type="button" class="btn show-more"
                        style="background-color:red;color:white;border-radius:3px;display:none;">
                        {{translation('REVIEW_SHOW_MORE')}}

                      </div>
                    </li>
                    @endif
                  </ul>
                </div>
                <!--end col-->
              </div>
              <!--end row-->
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--end container-->
    <!-- Recent Add Product Area Start -->
    @if(in_array(config('constkey.section_related'), $cKey))
    @if (!$related_data->isEmpty())
    <div class="container mt-100 mt-60">
      <div class="row">
        <div class="col-12">
          <h5 class="mb-0">{{translation('PRODUCT_RELETED_TO_YOU')}}
          </h5>
          <p>{{translation('PRODUCT_WEEKLY_LINEUP')}}</p>
        </div>
        <!--end col-->
        <div class="col-12 mt-4">
          <div class="tiny-four-item">
            @foreach ($related_data as $key => $product)
            <x-Ecom02.shared-component.product viewtype="grid" :data="$product" />
            @endforeach
          </div>
        </div>
        <!--end col-->
      </div>
      <!--end row-->
    </div>
    <!--end container-->
    @endif
    @endif
</section>
<!--end section-->
<!--Starting of Enquiry Form Modal-->
@if (webFunctionStatus(config('constkey.is_enquiry_enabled')))
<div class="modal fade" id="EnquiryModal" tabindex="-1" aria-labelledby="productview-title" aria-hidden="true">
  <div class="modal-dialog  modal-lg modal-dialog-centered">
    <div class="modal-content rounded shadow border-0">
      <div class="modal-header border-bottom">
        <h5 class="modal-title" id="productview-title">{{translation('ENQUIRY_TITLE')}}
        </h5>
        <button type="button" class="btn btn-icon btn-close" data-bs-dismiss="modal" id="close-modal">
          <i class="uil uil-times fs-4 text-dark">
          </i>
        </button>
      </div>
      <div class="modal-body p-4">
        <div class="container-fluid px-0">
          <div class="card border-0 mt-2" style="z-index: 1">
            <div class="card-body p-0">
              <form id="enquiryform" class="enquiryformdata needs-validation" method="POST"
                enctype="multipart/form-data" novalidate>
                <input type="hidden" id="products_id" name="products_id" value="{{ $products->product_id }}">
                <div class="row">
                  <div class="col-md-6">
                    <div class="mb-3">
                      <label class="form-label">{{translation('ENQUIRY_NAME')}}
                        <span class="text-danger">*
                        </span>
                      </label>
                      <div class="form-icon position-relative">
                        <input name="customers_name" id="enqcustomers_name"
                          placeholder="{{translation('ENQUIRY_NAME_PLACEHOLDER')}}" type="text"
                          class="form-control @error('customers_name') is-invalid @enderror" required>
                        <span class="text-danger customers_name_enq">
                        </span>
                        <div class="invalid-feedback">
                          {{translation('ERROR_NAME')}}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="mb-3">
                      <label class="form-label">{{translation('ENQUIRY_EMAIL')}}
                        <span class="text-danger">*
                        </span>
                      </label>
                      <div class="form-icon position-relative">
                        <input name="email_address" id="email_address" type="email"
                          class="form-control @error('email_address') is-invalid @enderror"
                          placeholder="{{translation('ENQUIRY_EMAIL_PLACEHOLDER')}}" required>
                        <span class="text-danger email_address_enq">
                        </span>
                        <div class="invalid-feedback">
                          {{translation('ERROR_EMAIL')}}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="col-md-6">
                    <div class="mb-3">
                      <label class="form-label">{{translation('ENQUIRY_PHONE_NO')}}
                        <span class="text-danger">*
                        </span>
                      </label>
                      <div class="form-icon position-relative">
                        <input name="phone" id="phone" placeholder="{{translation('ENQUIRY_PHONE_NO_PLACEHOLDER')}}"
                          type="number" class="form-control @error('phone') is-invalid @enderror" >
                        <span class="text-danger phone_enq">
                        </span>
                        <div class="invalid-feedback">
                          {{translation('ERROR_PHONE')}}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="mb-3">
                      <label class="form-label">{{translation('ENQUIRY_QUANTITY')}}
                        <span class="text-danger">*
                        </span>
                      </label>
                      <div class="form-icon position-relative">
                        <input name="products_qty" id="products_qty"
                          placeholder="{{translation('ENQUIRY_QUANTITY_PLACEHOLDER')}}" aria-label="qty" onblur="qtyItm()"
                          type="number" class="form-control @error('products_qty') is-invalid @enderror" required>
                        <span class="text-danger products_qty_enq">
                        </span>
                        <div class="invalid-feedback">
                          {{translation('ERROR_QTY')}}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="row">
                  @php $max_option_id =0 @endphp
                  @if (!empty($products->productAttribute))
                  @foreach ($products->productAttribute as $attribute)
                  @if (isset($attribute->option_value_list) && !empty($attribute->option_value_list))
                  @php
                  if ($max_option_id < $attribute->options_id) {
                    $max_option_id = $attribute->options_id;
                    }
                    @endphp
                    <div class="col-md-6">
                      <div class="mb-3">
                        <label class="form-label">{{ ucfirst($attribute->option_name ?? '') }}
                          <span class="text-danger">*
                          </span>
                        </label>
                        <div class="form-icon position-relative">
                          <select onchange="enqchooseAttributes(this)" class="form-control" required
                            name="attribute_{{ $attribute->options_id }}" id="{{ $attribute->options_id }}">
                            <option selected="" disabled="">Select {{ ucfirst($attribute->option_name ?? '') }}</option>
                            @foreach ($attribute->option_value_list as $option_value)
                            <option value="{{ $option_value->options_values_id }}">
                              {{ $option_value->productOptionsValue->products_options_values_name }}
                            </option>
                            @endforeach
                          </select>
                          <span class="text-danger countries_id_enq">
                          </span>
                        </div>
                      </div>
                    </div>
                    @endif
                    @endforeach
                    @endif
                </div>
                <input type="hidden" id="max_option_id" name="max_option_id" value="3">
                <div class="row">
                  <div class="col-12">
                    <div class="mb-3">
                      <label class="form-label">{{translation('ENQUIRY_MESSAGE')}}
                        <span class="text-danger">*
                        </span>
                      </label>
                      <div class="form-icon position-relative">
                        <i data-feather="message-circle" class="fea icon-sm icons clearfix">
                        </i>
                        <textarea name="message" id="message" rows="4"
                          class="form-control ps-5 @error('products_qty') is-invalid @enderror"
                          placeholder="{{translation('ENQUIRY_MESSAGE_PLACEHOLDER')}}">
                        </textarea>
                        <span class="text-danger message_enq">
                        </span>
                      </div>
                    </div>
                  </div>
                  <div class="col-12">
                    <div class="mb-3">
                      <input type="checkbox" name="newsletter" id="myCheck" checked>
                      <label for="myCheck">{{translation('ENQUIRY_NEWSLETTER')}}
                      </label>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-4 mx-auto">
                    <div class="d-grid">
                      <button type="submit" id="enquirymodalformbutton" name="send"
                        class="btn btn-primary enquiry_btn">{{translation('ENQUIRY_SUBMIT')}}
                      </button>
                      <input type="reset" hidden>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
        <!--end container-->
      </div>
    </div>
  </div>
</div>
@endif
<!--Ending of Enquiry Form Modal-->
@push('scripts')
<script>
 
  // End of cart jquery

  $(document).on('click', '#enquirymodalformbutton', function (e) {
    e.preventDefault();
    $('#enquiryform').addClass('was-validated');
    if ($('#enquiryform')[0].checkValidity() === false) {
      event.stopPropagation();
    }
    else {
      let enquiryform = document.getElementById('enquiryform');
      let formData = new FormData(enquiryform);
      var URL = window.location.href;
      var arr = URL.split('/');
      formData.append('page_source', arr.pop());
      $.ajaxSetup({
        headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
      });
      $.ajax({
        type: "POST",
        url: "/storeProductEnquiry",
        data: formData,
        dataType: "json",
        contentType: false,
        cache: false,
        processData: false,
        beforeSend: function () {
          $("#enquirymodalformbutton").addClass('disabled');
          $("#enquirymodalformbutton").html('{{translation('SUBMITTING')}}...');
        },
        success: function (response) {
          if (response.status == 400) {
            $.each(response.error, function (key, err_val) {
              $('.' + key + '_enq').text(err_val);
            });
          }
          else {
            $('#enquiryform').trigger("reset");
            $('#EnquiryModal').modal('hide');
            Notify('{{translation('SUCCESSFULLY_SEND')}}', true);
          }
        },
        complete: function (response) {
          $('#enquirymodalformbutton').removeClass('disabled');
          $('#enquirymodalformbutton').html('{{translation('SUBMIT')}}');
        }
      });
    }
  });
  // Ending of Enquiry Form Modal


  var enqdetail_choosen_attributes = [];
  var choosen_attributes_ary = [];
  function enqchooseAttributes(params, opid) {
    choosen_attributes_ary = [];
    enqdetail_choosen_attributes[opid] = params.value;
    // Now it can be used reliably with $.map()
    $.map(enqdetail_choosen_attributes, function (val, i) {
      if (val > 0)
        choosen_attributes_ary.push(val);
    }
    );
  }

  $(document).ready(function () {
    $(document).on('click', '#reviewformbutton', function (e) {
      e.preventDefault();
      $('#reviewform').addClass('was-validated');
      if ($('#reviewform')[0].checkValidity() === false) {
        event.stopPropagation();
      } else {
        var data = {
          'customers_name': $('.customers_name').val(),
          'customers_email': $('.customers_email').val(),
          'quality_rating': $('.quality_rating:checked').val(),
          'price_rating': $('.price_rating:checked').val(),
          'reviews_title': $('.reviews_title').val(),
          'products_id': $('.products_id').val(),
          'reviews_read': $('.reviews_read').val(),
          'reviews_text': $('.reviews_text').val(),
        }
        $.ajaxSetup({
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
        });
        $.ajax({
          type: "POST",
          url: "/storereview",
          data: data,
          dataType: "json",
          success: function (response) {
            console.log(response);
            if (response.status == 400) {
              //design
              $.each(response.error, function (key, err_val) {
                $('#' + key).text(err_val);
              }
              );
            }
            else {
              $('#successlist').html("");
              Notify('{{translation('REVIEW_SUCCESS_MSG')}}', true);
              $('#reviewform').trigger("reset");
              $('#reviewform').removeClass('was-validated');
            }
          }
        });
      }
    });
  });
  // Show more jquery
  if ($('.ty-compact-list').length > 3) {
    $('.ty-compact-list:gt(2)').hide();
    $('.show-more').show();
  }
  $('.show-more').on('click', function () {
    $('.ty-compact-list:gt(2)').toggle();
    $(this).text() === 'Show more' ? $(this).text('Show less') : $(this).text('Show more');
  });
  // <!--End of Enquiry Form Ajax-->

  function qtyItm() {
    var qtyItem = $('#products_qty').val();
    if (qtyItem < 1) {
      $('#products_qty').val('1');
    }
  }
  function showEnquiryForm() {

$('#EnquiryModal').modal('show');
}
</script>

<script>
   function changeImage(element) {
    var main_prodcut_image = document.getElementById('main_product_image');
    main_prodcut_image.src = element.src;

}
</script>

@endpush