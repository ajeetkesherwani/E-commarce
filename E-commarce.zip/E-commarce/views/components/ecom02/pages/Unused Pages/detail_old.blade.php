@php
$avgrating = AvgRating($products->product_id);
$currentURL = URL::current();
use App\Models\Ecom\Services\EcomService;
@endphp
 <!-- Hero Start -->
        <section class="bg-half-170 banner_background bg-light d-table w-100">
            <div class="container">
                <div class="row mt-5 justify-content-center">
                    <div class="col-lg-12 text-center">
                        <div class="pages-heading">
                            <h4 class="title mb-0"> {{ $products->products_name ?? '' }} </h4>
                        </div>
                    </div><!--end col-->
                </div><!--end row-->
                
                <x-Ecom02.SharedComponent.BreadCrumb :data="$breadCumbArr" />

            </div> <!--end container-->
        </section><!--end section-->
        <div class="position-relative">
            <div class="shape overflow-hidden text-color-white">
                <svg viewBox="0 0 2880 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M0 48H1437.5H2880V0H2160C1442.5 52 720 0 720 0H0V48Z" fill="currentColor"></path>
                </svg>
            </div>
        </div>
        <!-- Hero End -->

        <section class="section pb-0">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-5">
                         @if (!empty($products->products_to_gallery))
                        <div class="tiny-single-item">
                             @foreach ($products->products_to_gallery as $key => $data)
                            <div class="tiny-slide"><img src="{{ getFullImageUrl($data->images_id) }}"
                            alt="{{ $data->images_name }}" class="img-fluid rounded"></div>
                             @endforeach
                        </div>
                         @endif
                    </div><!--end col-->

                    <div class="col-md-7 mt-4 mt-sm-0 pt-2 pt-sm-0">
                        <div class="section-title ms-md-4">
                            <!-- <h4 class="title">{{ $products->products_name ?? '' }}</h4> -->
                            @if(in_array($products->product_type_id, ['1', '2', '4']) && $products->products_to_brand->brand_name != '')
                            @if (!empty($products->products_to_brand))
                            
                                <p class="mt-0 py-2">Brand:<span> <a href="{{ EcomService::url($products->products_to_brand->brand_id ?? '', 'brand') }}">{{ $products->products_to_brand->brand_name ?? '' }}</a></span></p>
                            @endif
                            @endif

                            @php
                                $discounAmount=($products->sale_price)*$products->discount_amount/100;
                                $totalPrice=$products->sale_price+$discounAmount;
                            @endphp
                            <h5 class="text-muted"> @if($products->discount_type != 'no')
                              @if($products->discount_type == 'flat')
                              <del class="text-danger ms-2">{{
                                currencyFormat($products->sale_price+$products->discount_amount) }}</del>
                              @else
                              @php
                              $discounAmount=($products->sale_price)*$products->discount_amount/100;
                              $totalPrice=$products->sale_price+$discounAmount;
                              @endphp
                              <del class="text-danger ms-2">
                                {{ currencyFormat($totalPrice)}}
                              </del>
                              @endif
                              @endif
                              {{ currencyFormat($products->sale_price)}}

                              @if($products->discount_type != 'no')
                              @if($products->discount_type == 'flat')
                              <span class="text-success ms-1">
                                {{ currencyFormat($products->discount_amount) }}off
                              </span>
                              @else
                              <span class="text-success ms-1">
                                {{ currencyFormat( $products->discount_amount )
                                }}% off
                              </span>
                              @endif
                              @endif </h5>
                            <ul class="list-unstyled text-warning h5 mb-0">
                                <li class="list-inline-item">
                                  @if (!empty($avgrating))
                                   @for ($i = 1; $i < $avgrating; $i++)
                                   <i class="mdi mdi-star"></i>
                                   @endfor
                                  @endif 
                               </li>
                            </ul>
                            
                            <h5 class="mt-4 py-2">Overview :</h5>
                            <p class="text-muted">{!! $products->products_description ?? 'No Description' !!}</p>
                        
                            {{-- <ul class="list-unstyled text-muted">
                                <li class="mb-1"><span class="text-primary h5 me-2"><i class="uil uil-check-circle align-middle"></i></span> Digital Marketing Solutions for Tomorrow</li>
                                <li class="mb-1"><span class="text-primary h5 me-2"><i class="uil uil-check-circle align-middle"></i></span> Our Talented &amp; Experienced Marketing Agency</li>
                                <li class="mb-1"><span class="text-primary h5 me-2"><i class="uil uil-check-circle align-middle"></i></span> Create your own skin to match your brand</li>
                            </ul> --}}
                            
                              @if (webFunctionStatus(config('constkey.is_cart_enabled')) || webFunctionStatus(config('constkey.is_enquiry_enabled')))
                            <div class="row mt-4 pt-2">
                                <div class="col-lg-12">
                                    @if (!empty($products->productAttribute))
                                      @foreach ($products->productAttribute as $attribute)
                                <?php //print_r($attribute) ?>
                                    <div class="d-flex align-items-center">
                                        <h6 class="mb-0">{{ ucfirst($attribute->option_name ?? '') }} :</h6>
                                         @if (isset($attribute->option_value_list) && !empty($attribute->option_value_list))
                                        <ul class="list-unstyled mb-0 ms-3">
                                            @foreach ($attribute->option_value_list as $idx => $option_value)
                                            <li class="list-inline-item">
                                                <div class="btn btn-soft-primary ms-2">
                                                    <input class="input-radio" type="radio" data-product-attribute="{{$attribute->options_id}}"
                                                        name="attributes_{{$attribute->options_id}}" {{$idx==0?"checked":""}} value="{{ $option_value->options_values_id }}" title="{{ $option_value->productOptionsValue->products_options_values_name }}">
                                                    <span class="radio-label">{{ $option_value->productOptionsValue->products_options_values_name }}</span> 
                                                </div>
                                            </li> 
                                            @endforeach
                                        </ul>
                                           @endif
                                    </div>
                                      @endforeach
                                    @endif
                                </div><!--end col-->

                                <div class="col-lg-12 pt-4">
                                    <div class="d-flex shop-list align-items-center">
                                        <h6 class="mb-0">Quantity:</h6>
                                          @if (webFunctionStatus(config('constkey.is_cart_enabled')))
                                        <div class="qty-icons ms-3">
                                            <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" class="btn btn-icon btn-soft-primary minus">-</button>
                                            <input min="1" id="qtyItemAdd" name="qtybutton" type="number" value="1" class="btn btn-icon btn-soft-primary qty-btn quantity">
                                            <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="btn btn-icon btn-soft-primary plus">+</button>
                                        </div>
                                         @endif
                                    </div>
                                </div><!--end col-->
                            </div><!--end row-->
                            
                            <div class="mt-4 pt-2">
                                @if (webFunctionStatus(config('constkey.is_cart_enabled')))
                                <a href="javascript:void(0)" onclick="addToCartFromDetail({{ $products->product_id }})" class="btn btn-primary">Add to Cart</a>
                                @endif
                                @if (webFunctionStatus(config('constkey.is_enquiry_enabled')))
                                <a href="javascript:void(0)" onclick="showEnquiryForm()" class="btn btn-soft-primary ms-2">Enquiry Now</a>
                            </div>

                            <div class="row mt-2 pt-2">
                                <div class="col-lg-12 pt-1">
                                    <div class="d-flex shop-list align-items-center">
                                    <a href="javascript:void(0)" class="btn btn-icon btn-pills btn-soft-danger"><i data-feather="heart" onclick="addToWishListFromDetail({{ $products->product_id }})" title="Wishlist"
                              class="icons"></i></a>
                                          @if (webFunctionStatus(config('constkey.is_cart_enabled')))
                                        <div class="qty-icons ms-3">
                                          <h6 class="mb-0">Add to wishlist</h6>
                                        </div>
                                         @endif
                                    </div>
                                </div><!--end col-->

                                <div class="col-lg-12 pt-1">
                                    <div class="d-flex shop-list align-items-center">
                                    <h6 class="mb-0">Share:</h6>
                                        <div class="qty-icons ms-3">
                                        <ul class="list-unstyled social-icon foot-social-icon mb-0 mt-4">
                                            <li class="list-inline-item"><a href="https://www.facebook.com/sharer/sharer.php?u={{ $currentURL }}" target="_blank" class="rounded"><i data-feather="facebook" class="fea icon-sm fea-social"></i></a></li>
                            
                                            <li class="list-inline-item"><a href="https://www.instagram.com/?url={{$currentURL}}" target="_blank" class="rounded"><i data-feather="instagram" class="fea icon-sm fea-social"></i></a></li>
                                    
                                            <li class="list-inline-item"><a href="https://twitter.com/intent/tweet?text={{ $currentURL }}" target="_blank" class="rounded"><i data-feather="twitter" class="fea icon-sm fea-social"></i></a></li>
                                    
                                            <li class="list-inline-item"><a href="https://api.whatsapp.com/send?text={{ $currentURL }}" target="_blank" class="rounded"><img class="" src="{{ LoadAssets('assets/images/icons/whatsapp-icon.png') }}" style="height:18px; width:18px;"></a></li>
                                    
                                        </ul><!--end icon-->
                                        </div> 
                                    </div>
                                </div><!--end col-->
                              @endif
                        </div><!--end row-->
                    </div><!--end col-->
                </div><!--end row-->
            </div><!--end container-->

            <div class="container mt-100 mt-60">
                <div class="row">
                    <div class="col-12">
                        <ul class="nav nav-pills shadow flex-column flex-sm-row d-md-inline-flex mb-0 p-1 rounded position-relative overflow-hidden" id="pills-tab" role="tablist">
                            <li class="nav-item m-1">
                                <a class="nav-link py-2 px-5 active rounded" id="description-data" data-bs-toggle="pill" href="#description" role="tab" aria-controls="description" aria-selected="false">
                                    <div class="text-center">
                                        <h6 class="mb-0">Description</h6>
                                    </div>
                                </a><!--end nav link-->
                            </li><!--end nav item-->
                            
                            <li class="nav-item m-1">
                                <a class="nav-link py-2 px-5 rounded" id="additional-info" data-bs-toggle="pill" href="#additional" role="tab" aria-controls="additional" aria-selected="false">
                                    <div class="text-center">
                                        <h6 class="mb-0">Additional Information</h6>
                                    </div>
                                </a><!--end nav link-->
                            </li><!--end nav item-->

                            <li class="nav-item m-1">
                                <a class="nav-link py-2 px-5 rounded" id="review-comments" data-bs-toggle="pill" href="#review" role="tab" aria-controls="review" aria-selected="false">
                                    <div class="text-center">
                                        <h6 class="mb-0">Review</h6>
                                    </div>
                                </a><!--end nav link-->
                            </li><!--end nav item-->
                        </ul>
                        
                        <div class="tab-content mt-5" id="pills-tabContent">
                            <div class="card border-0 tab-pane fade show active" id="description" role="tabpanel" aria-labelledby="description-data">
                                <p class="text-muted mb-0">{!! $products->products_description ?? ' Message is None' !!}</p>
                            </div>

                            <div class="card border-0 tab-pane fade" id="additional" role="tabpanel" aria-labelledby="additional-info">
                                <table class="table">
                                      @if (!empty($products) && in_array($products->product_type_id, ['1', '2', '4']))
                                    <tbody>
                                        <tr>
                                            <td style="width: 175px;">Product Sku</td>
                                            <td class="text-muted">{{ $products->product_sku }}</td>
                                        </tr>

                                        <tr>
                                            <td>Product Model</td>
                                            <td class="text-muted">{{ $products->product_model }}</td>
                                        </tr>

                                        <tr>
                                            <td>Product Condition</td>
                                            <td class="text-muted">{{ $products->product_condition == 1 ? 'New' : 'Refurbished' }}</td>
                                        </tr>

                                        <tr>
                                            <td>Brand Name</td>
                                            <td class="text-muted">{{ $products->products_to_brand->brand_name }}</td>
                                        </tr>

                                        <tr>
                                            @if(!empty($products->products_to_features) && sizeof($products->products_to_features)>0)
                                                @foreach($products->products_to_features as $featKey=>$featVal)
                                                <tr>
                                                  <td>{{$featVal->feature_title ?? ''}}</td>
                                                  <td class="text-muted">{{$featVal->feature_value ?? ''}}</td>
                                                </tr>
                                                @endforeach
                                            @endif
                                        </tr>

                                    </tbody>
                                      @endif
                                </table>
                            </div>

                            <div class="card border-0 tab-pane fade" id="review" role="tabpanel" aria-labelledby="review-comments">
                                <div class="row">
                                    <div class="col-lg-6 mt-4 mt-lg-0 pt-2 pt-lg-0">
                                        <form class="ms-lg-4" id="reviewform">
                                          <!-- @csrf -->
                                            <div class="row">
                                                <div class="col-12">
                                                    <h5>Add your review:</h5>
                                                </div>
                                                <div class="col-12 mt-4">
                                                    <h6 class="small fw-bold">Quality Rating:</h6>
                                                    <div class="star-box">
                                                        <div class="rate">
                                                            <input type="radio" id="star5" name="quality_rating"
                                                                class="quality_rating" value="5" />
                                                            <label for="star5" title="text">5 stars</label>
                                                            <input type="radio" id="star4" name="quality_rating"
                                                                class="quality_rating" value="4" />
                                                            <label for="star4" title="text">4 stars</label>
                                                            <input type="radio" id="star3" name="quality_rating"
                                                                class="quality_rating" value="3" />
                                                            <label for="star3" title="text">3 stars</label>
                                                            <input type="radio" id="star2" name="quality_rating"
                                                                class="quality_rating" value="2" />
                                                            <label for="star2" title="text">2 stars</label>
                                                            <input type="radio" id="star1" name="quality_rating"
                                                                class="quality_rating" value="1" />
                                                            <label for="star1" title="text">1 star</label>
                                                        </div>
                                                        <span class="text-danger" id="quality_rating"></span>
                                                    </div>
                                                </div><!--end col-->
                                                <div class="col-12 mt-4">
                                                  <h6 class="small fw-bold">Price Rating:</h6>
                                                    <div class="star-box">
                                                        <div class="rate">
                                                            <input type="radio" id="stars5" name="price_rating"
                                                                class="price_rating" value="5" />
                                                            <label for="stars5" title="text">5 stars</label>
                                                            <input type="radio" id="stars4" name="price_rating"
                                                                class="price_rating" value="4" />
                                                            <label for="stars4" title="text">4 stars</label>
                                                            <input type="radio" id="stars3" name="price_rating"
                                                                class="price_rating" value="3" />
                                                            <label for="stars3" title="text">3 stars</label>
                                                            <input type="radio" id="stars2" name="price_rating"
                                                                class="price_rating" value="2" />
                                                            <label for="stars2" title="text">2 stars</label>
                                                            <input type="radio" id="stars1" name="price_rating"
                                                                class="price_rating" value="1" />
                                                            <label for="stars1" title="text">1 star</label>
                                                        </div>
                                                        <span class="text-danger" id="price_rating"></span>
                                                    </div>
                                                </div><!--end col-->
                                               
                                                <div class="col-md-12 mt-3">
                                                    <div class="mb-3">
                                                        <label class="form-label">Review Title:</label>
                                                        <div class="form-icon position-relative"> 
                                                            <input placeholder="Enter Your Review Title Here.." type="text"
                                                           name="reviews_title" class="form-control reviews_title" required />
                                                            <span class="text-danger" id="reviews_title"></span>
                                                        </div>
                                                    </div>
                                                </div><!--end col-->


                                                <div class="col-md-12 mt-3">
                                                    <div class="mb-3">
                                                        <label class="form-label">Your Review:</label>
                                                        <div class="form-icon position-relative">
                                                            <i data-feather="message-circle" class="fea icon-sm icons"></i>
                                                            <textarea id="message" placeholder="Your Comment" rows="5" name="reviews_text" class="form-control reviews_text ps-5" required=""></textarea>
                                                            <span class="text-danger" id="reviews_text"></span>
                                                        </div>
                                                    </div>
                                                </div><!--end col-->

                                                <input type="hidden" value="{{ $products->product_id }}"
                                                class="products_id" name="products_id">
                                                <input type="hidden" value="0" name="reviews_read">
                                                @guest
                                                <div class="col-lg-6">
                                                    <div class="mb-3">
                                                        <label class="form-label">Name <span class="text-danger">*</span></label>
                                                        <div class="form-icon position-relative">
                                                            <i data-feather="user" class="fea icon-sm icons"></i>
                                                            <input id="name" name="customers_name" type="text" placeholder="Name" class="form-control customers_name ps-5" required="">
                                                            <span class="text-danger" id="customers_name"></span>
                                                        </div>
                                                    </div>
                                                </div><!--end col-->
            
                                                <div class="col-lg-6">
                                                    <div class="mb-3">
                                                        <label class="form-label">Your Email <span class="text-danger">*</span></label>
                                                        <div class="form-icon position-relative">
                                                            <i data-feather="mail" class="fea icon-sm icons"></i>
                                                            <input id="email" type="email" placeholder="Email" name="customers_email" class="form-control customers_email ps-5" required="">
                                                            <span class="text-danger" id="customers_email"></span>
                                                        </div>
                                                    </div>
                                                </div><!--end col-->
                                                 @endguest
                                                <div class="col-md-12">
                                                    <div class="send d-grid">
                                                        <button type="submit" class="btn btn-primary" id="reviewformbutton">Submit</button>
                                                    </div>
                                                </div><!--end col-->
                                                <ul id="successlist">
                                            </ul>
                                            </div><!--end row-->
                                        </form><!--end form-->
                                    </div><!--end col-->
                                    <div class="col-lg-6">
                                        <ul class="media-list list-unstyled mb-0">
                                            @if (!$review_data->isEmpty())
                                            <li>
                                               @foreach ($review_data as $key => $data)
                                                <div class="d-flex justify-content-between">
                                                    <div class="d-flex align-items-center">
                                                        <a class="pe-3" href="#">
                                                            <img src="{{ asset('profileimages/default-user.png') }}" class="img-fluid avatar avatar-md-sm rounded-circle shadow" alt="img">
                                                        </a>
                                                        <div class="flex-1 commentor-detail">
                                                            <h6 class="mb-0"><a href="javascript:void(0)" class="text-dark media-heading">{{ $data->customers_name }}</a></h6>
                                                            <small class="text-muted">15th August, 2021 at 05:44 pm</small>
                                                        </div>
                                                    </div>
                                                    <ul class="list-unstyled mb-0">
                                                    <span><b>Quality Rating:</b></span>
                                                        @php
                                                        $j = 0;
                                                        for ($i = 0; $i < $data->quality_rating; $i++) {
                                                            echo '<i class="ion-android-star"></i>';
                                                            $j++;
                                                        }
                                                        for ($k = 5; $k > $j; $k--) {
                                                            echo '<i class="ion-android-star-outline"></i>';
                                                        }
                                                        @endphp 

                                                        <span><b>Price Rating:</b></span>
                                                    @php
                                                        $j = 0;
                                                        for ($i = 0; $i < $data->price_rating; $i++) {
                                                            echo '<i class="ion-android-star"></i>';
                                                            $j++;
                                                        }
                                                        for ($k = 5; $k > $j; $k--) {
                                                            echo '<i class="ion-android-star-outline"></i>';
                                                        }
                                                    @endphp 
                                                     
                                                    </ul>
                                                </div>
                                                <div class="mt-3">
                                                    <p class="text-muted fst-italic p-3 bg-light rounded">{{ $data->reviews_text }} </p>
                                                </div>
                                              @endforeach
                                               <div type="button" class="btn show-more" style="background-color:red;color:white;border-radius:3px;display:none;">Show
                                        more </div>
                                            </li>
                                             @endif
                                        </ul>
                                    </div><!--end col-->
                                </div><!--end row-->
                            </div>
                        </div>
                    </div>
                </div>
            </div><!--end container-->
            <!-- Recent Add Product Area Start -->
 @if(in_array(config('constkey.section_related'), $cKey))

 @if (!$related_data->isEmpty())
            <div class="container mt-100 mt-60">
                <div class="row">
                    <div class="col-12">
                        <h5 class="mb-0">You Might Also Like</h5>
                         <p>Add Related products to weekly line up</p>
                    </div><!--end col-->

                    <div class="col-12 mt-4">
                        <div class="tiny-four-item">
                          @foreach ($related_data as $key => $product)
                           <x-Ecom02.shared-component.product viewtype="grid" :data="$product" />
                          @endforeach
                        </div>
                    </div><!--end col-->
                </div><!--end row-->
            </div><!--end container-->
    @endif

    @endif
           
        </section><!--end section-->

        <!--Starting of Enquiry Form Modal-->
                <div class="modal fade" id="EnquiryModal" tabindex="-1" aria-labelledby="productview-title" aria-hidden="true">
            <div class="modal-dialog  modal-lg modal-dialog-centered">
                <div class="modal-content rounded shadow border-0">
                    <div class="modal-header border-bottom">
                        <h5 class="modal-title" id="productview-title">Enquiry Form</h5>
                        <button type="button" class="btn btn-icon btn-close" data-bs-dismiss="modal" id="close-modal"><i class="uil uil-times fs-4 text-dark"></i></button>
                    </div>
                    
                    <div class="modal-body p-4">
                      <div class="container-fluid px-0">
                        <div class="card border-0 mt-2" style="z-index: 1">
                           <div class="card-body p-0">
                             <form id="enquiryform" class="enquiryformdata needs-validation" method="POST" enctype="multipart/form-data" novalidate>
                                <input type="hidden" id="products_id" value="{{ $products->product_id }}">
                                    <div class="row">
                                       
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Name: <span class="text-danger">*</span></label>
                                                <div class="form-icon position-relative">
                                                    <input name="customers_name" id="enqcustomers_name" placeholder="Your Name"
                                                    type="text" class="form-control @error('customers_name') is-invalid @enderror" required >
                                                    <span class="text-danger customers_name_enq"></span>
                                                    <div class="invalid-feedback">
                                                       Please enter name.
                                                    </div>    
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Email: <span class="text-danger">*</span></label>
                                                <div class="form-icon position-relative">
                                                    <input name="email_address" id="email_address"  type="email" class="form-control @error('email_address') is-invalid @enderror" placeholder="Your Email :" required>
                                                    <span class="text-danger email_address_enq"></span>
                                                    <div class="invalid-feedback">
                                                       Please enter email.
                                                    </div> 
                                                </div>
                                              
                                            </div> 
                                        </div>                                     

                                        <!-- <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Company Name<span class="text-danger">*</span></label>
                                                <div class="form-icon position-relative">
                                                    <input id="company_name" name="company_name" placeholder="Company Name"
                                            type="text" class="form-control" >
                                                  <span class="text-danger company_name_enq"></span>
                                                </div>
                                            </div>
                                        </div> -->

                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Phone<span class="text-danger">*</span></label>
                                                <div class="form-icon position-relative">
                                                    <input name="phone" id="phone" placeholder="Phone" type="number" class="form-control @error('phone') is-invalid @enderror" required>
                                                 <span class="text-danger phone_enq"></span>
                                                 <div class="invalid-feedback">
                                                       Please enter phone number.
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Qty Needed <span class="text-danger">*</span></label>
                                                <div class="form-icon position-relative">
                                                    <input name="products_qty" id="products_qty" placeholder="Qty Needed"
                                        aria-label="qty" type="number" class="form-control @error('products_qty') is-invalid @enderror" required>
                                                  <span class="text-danger products_qty_enq"></span>
                                                  <div class="invalid-feedback">
                                                       Please enter product quantity.
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        </div>
                                        <!-- <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Country<span class="text-danger">*</span></label>
                                                <div class="form-icon position-relative">
                                                  @if (!empty($countriesdata))
                                                   <select name="countries_id" id="countries_id" class="form-control">
                                                        <option selected value="" disabled>Select Country</option>
                                                   @foreach ($countriesdata as $key => $data)
                                                        <option value="{{ $data->countries_id }}">{{ $data->countries_name }}</option>
                                                    @endforeach
                                                  </select>
                                                  @endif 
                                                  <span class="text-danger countries_id_enq"></span>
                                                </div>
                                            </div>
                                        </div> -->
                                                                              

                                        <!-- <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Attach File<span class="text-danger">*</span></label>
                                                <div class="form-icon position-relative">
                                                    <input name="enquiry_file" id="enquiry_file" type="file" placeholder="Enquiry File"
                                        style="display: block" class="form-control" >
                                                 <span class="text-danger enquiry_file"></span>
                                                </div>
                                            </div>
                                        </div> -->
                                        <div class="row">
                                        @if (!empty($products->productAttribute))
                                        @foreach ($products->productAttribute as $attribute)
                                            @if (isset($attribute->option_value_list) && !empty($attribute->option_value_list))
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">{{ ucfirst($attribute->option_name ?? '') }}<span class="text-danger">*</span></label>
                                                <div class="form-icon position-relative">
                                                   <select onchange="enqchooseAttributes(this)" class="form-control" required>
                                                    @foreach ($attribute->option_value_list as $option_value)
                                                      <!--   <option selected value="" disabled>Select Country</option> -->
                                                      <option value="{{ $option_value->options_values_id }}">{{ $option_value->productOptionsValue->products_options_values_name }}</option>
                                                      @endforeach
                                                  </select>
                                                  <span class="text-danger countries_id_enq"></span>
                                                </div>
                                            </div>                                             
                                        </div>
                                           @endif
                                        @endforeach
                                        @endif
                                        </div>
                                        <div class="row">
                                        <div class="col-12">
                                            <div class="mb-3">
                                                <label class="form-label">Enquiry Message <span class="text-danger">*</span></label>
                                                <div class="form-icon position-relative">
                                                    <i data-feather="message-circle" class="fea icon-sm icons clearfix"></i>
                                                    <textarea  name="message" id="message" rows="4" class="form-control ps-5 @error('products_qty') is-invalid @enderror" placeholder="Message :"></textarea>
                                                    <span class="text-danger message_enq"></span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-12">
                                            <div class="mb-3">
                                                <input type="checkbox" name="newsletter" id="myCheck" checked>
                                                <label for="myCheck">Get Latest Update</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-4 mx-auto">
                                            <div class="d-grid">
                                                <button type="submit" id="enquirymodalformbutton" name="send" class="btn btn-primary enquiry_btn">Submit</button>
                                                <input type="reset" hidden>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                      </div><!--end container-->
                   </div>
                </div>
            </div>
        </div>
        <!--Ending of Enquiry Form Modal-->
        @endif

@push('scripts')
    <script>
        $(document).on('click', '#enquirymodalformbutton', function(e) {
            e.preventDefault();
            $('#enquiryform').addClass('was-validated');
            if ($('#enquiryform')[0].checkValidity() === false) {
                event.stopPropagation();
            } else {
                let enquiryform = document.getElementById('enquiryform');
                let formData = new FormData(enquiryform);
                var URL = window.location.href;
                var arr = URL.split('/');
                formData.append('page_source', arr.pop());

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "/storeProductEnquiry",
                    data: formData,
                    dataType: "json",
                    contentType: false,
                    cache: false,
                    processData: false,
                    beforeSend: function() {
                        $("#enquirymodalformbutton").addClass('disabled');
                        $("#enquirymodalformbutton").html('Submiting...');
                    },
                    success: function(response) {
                        console.log(response);
                        if (response.status == 400) {
                            $.each(response.error, function(key, err_val) {
                                $('.' + key + '_enq').text(err_val);
                            });
                        } else {
                            // $("#enquirymodalformbutton").html('<p>Submitting</p>');
                            $('#enquiryform').trigger("reset");
                            $('#EnquiryModal').modal('hide');
                            Notify('Send Successfully', true);
                        }
                    },
                    complete: function(response) {
                        $('#enquirymodalformbutton').removeClass('disabled');
                        $('#enquirymodalformbutton').html('Submit');
                    }
                    // error: function (error) {
                    //     $(element).closest('.cls').removeClass('success').addClass('error');
                    //     $(".valid").css("color", "red");
                    //     }
                    // }

                });
            }

        });




        // Ending of Enquiry Form Modal


        let detail_choosen_attributes = [];

        function addToCartFromDetail(product_id) {

            var qtyItemAdd = $('#qtyItemAdd').val();
            let attributes = detail_choosen_attributes.join(',');
            if (attributes == '') {

                $('input[type="radio"]:checked').each(function() {
                    if (!detail_choosen_attributes.includes(this.value)) {
                        detail_choosen_attributes.push(this.value);
                    }
                    console.log(detail_choosen_attributes);
                });
                let attributes = detail_choosen_attributes.join(',');

                addToCart(product_id, qtyItemAdd, attributes);
            } else {
                addToCart(product_id, qtyItemAdd, attributes);
            }

        }

        $('.input-radio').on('click', function() {
            let detail_choosen_attributes = [];
            var ele = $('input');
            for (i = 0; i < ele.length; i++) {
                if (ele[i].checked)
                    if (!detail_choosen_attributes.includes(ele[i].value)) {
                        detail_choosen_attributes.push(ele[i].value);
                    }
            }

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            var data = {
                'product_id': $('#products_id').val(),
                'options_values_id': $(this).attr("value"),
                'options_id': $(this).attr("data-product-attribute"),
            }

            $.ajax({
                type: "POST",
                url: "/attribute-price",
                data: data,
                dataType: "json",
                success: function(response) {
                    $(".old-price").html("");
                    $(".old-price").append(response);
                }
            });

        });

        // function chooseAttributes(param) {
        //     // option to price
        // }


        $(document).ready(function() {
            //alert('hello');
            $(document).on('click', '#reviewformbutton', function(e) {
                e.preventDefault();

                var data = {
                    'customers_name': $('.customers_name').val(),
                    'customers_email': $('.customers_email').val(),
                    'quality_rating': $('.quality_rating:checked').val(),
                    'price_rating': $('.price_rating:checked').val(),
                    'reviews_title': $('.reviews_title').val(),
                    'products_id': $('.products_id').val(),
                    'reviews_read': $('.reviews_read').val(),
                    'reviews_text': $('.reviews_text').val(),

                }

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "/storereview",
                    data: data,
                    dataType: "json",
                    success: function(response) {
                        // console.log(response);
                        if (response.status == 400) {
                            //design

                            $.each(response.error, function(key, err_val) {
                                $('#' + key).text(err_val);
                            });
                        } else {
                            $('#successlist').html("");
                            Notify('Thank For Review Us', true);
                            $('#reviewform').trigger("reset");
                        }
                    }

                });
            });
        });

        // Show more jquery

        if ($('.ty-compact-list').length > 3) {
            $('.ty-compact-list:gt(2)').hide();
            $('.show-more').show();
        }
        $('.show-more').on('click', function() {
            $('.ty-compact-list:gt(2)').toggle();
            $(this).text() === 'Show more' ? $(this).text('Show less') : $(this).text('Show more');
        });

        // <!--End of Enquiry Form Ajax-->

        var enqdetail_choosen_attributes = [];
        var choosen_attributes_ary = [];

        function enqchooseAttributes(params, opid) {
            choosen_attributes_ary = [];
            enqdetail_choosen_attributes[opid] = params.value;

            // Now it can be used reliably with $.map()
            $.map(enqdetail_choosen_attributes, function(val, i) {
                if (val > 0)
                    choosen_attributes_ary.push(val);
            });

        }
    </script>
@endpush
