@php
$main_arr = [
'title'=>$brandFilters ?? '',
'sublist' => $breadCumbArr
];
$per_page=substr(url()->full(),-2);
if($per_page==00)
$per_page=substr(url()->full(),-3);
@endphp
 <!-- Hero Start -->
  <section class="bg-half-170 banner_background bg-light d-table w-100">
            <div class="container">
                <div class="row mt-5 justify-content-center">
                    <div class="col-lg-12 text-center">
                        <div class="pages-heading">
                            <h4 class="title mb-0">Brand</h4>
                        </div>
                    </div><!--end col-->
                </div><!--end row-->
                
               <!-- Breadcrumb Area Start -->
                <x-Ecom02.SharedComponent.BreadCrumb :data="$main_arr" />
                <!-- Breadcrumb Area End -->
            </div> <!--end container-->
        </section><!--end section-->
        <div class="position-relative">
            <div class="shape overflow-hidden text-color-white">
                <svg viewBox="0 0 2880 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M0 48H1437.5H2880V0H2160C1442.5 52 720 0 720 0H0V48Z" fill="currentColor"></path>
                </svg>
            </div>
        </div>
        <!-- Hero End -->

        <!-- Start Products -->
        <section class="section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-4 col-12">
                        <div class="card border-0 sidebar sticky-bar">
                            <div class="card-body p-0">
                                <!-- SEARCH -->
                                @if (webFunctionStatus(config('constkey.is_header_search_box_enabled')))
                                <div class="widget" id="itemSearch">
                                    <form role="search" method="get" id="searchform" class="searchform">
                                        <div class="input-group mb-3 border rounded">
                                            <input type="text" id="searchtext" autocomplete="off" name="searchtext" class="form-control border-0" placeholder="Search Keywords...">
                                            <button type="submit" id="searchbutton" class="input-group-text bg-white border-0 bg-transparent" id="searchsubmit"><i class="uil uil-search"></i></button>
                                        </div>
                                        <div class="searchItem hide">
                                           <div class="searchItemList"></div>
                                        </div>
                                        
                                    </form>
                                </div>
                                @endif
                                <!-- SEARCH -->

                              
                              
                                <!-- color -->
                                <!-- <div class="widget mt-4 pt-2">
                                    <h5 class="widget-title">Color</h5>
                                    <ul class="list-unstyled mt-4 mb-0">
                                        <li class="list-inline-item"><a href="javascript:void(0)" class="btn btn-sm btn-icon btn-pills btn-primary"><span class="d-none">.</span></a></li>
                                        <li class="list-inline-item"><a href="javascript:void(0)" class="btn btn-sm btn-icon btn-pills btn-danger"><span class="d-none">.</span></a></li>
                                        <li class="list-inline-item"><a href="javascript:void(0)" class="btn btn-sm btn-icon btn-pills btn-success"><span class="d-none">.</span></a></li>
                                        <li class="list-inline-item"><a href="javascript:void(0)" class="btn btn-sm btn-icon btn-pills btn-info"><span class="d-none">.</span></a></li>
                                        <li class="list-inline-item"><a href="javascript:void(0)" class="btn btn-sm btn-icon btn-pills btn-secondary"><span class="d-none">.</span></a></li>
                                        <li class="list-inline-item"><a href="javascript:void(0)" class="btn btn-sm btn-icon btn-pills btn-warning"><span class="d-none">.</span></a></li>
                                    </ul>
                                </div> -->
                                <!-- COlor -->

                                <!-- Top Products -->
                                <!-- <div class="widget mt-4 pt-2">
                                    <h5 class="widget-title">Top Products</h5>
                                    <ul class="list-unstyled mt-4 mb-0">
                                        <li class="d-flex align-items-center">
                                            <a href="javascript:void(0)">
                                                <img src="assets/images/shop/product/s1.jpg" class="img-fluid avatar avatar-small rounded shadow" style="height:auto;" alt="">
                                            </a>
                                            <div class="flex-1 content ms-3">
                                                <a href="javascript:void(0)" class="text-dark h6">T-Shirt</a>
                                                <h6 class="text-dark small fst-italic mb-0 mt-1">$18.00 <del class="text-danger ms-2">$22.00</del> </h6>
                                            </div>
                                        </li>
                                        <li class="d-flex align-items-center mt-2">
                                            <a href="javascript:void(0)">
                                                <img src="assets/images/shop/product/s3.jpg" class="img-fluid avatar avatar-small rounded shadow" style="height:auto;" alt="">
                                            </a>
                                            <div class="flex-1 content ms-3">
                                                <a href="javascript:void(0)" class="text-dark h6">Watch</a>
                                                <h6 class="text-dark small fst-italic mb-0 mt-1">$18.00 <del class="text-danger ms-2">$22.00</del> </h6>
                                            </div>
                                        </li>
                                        <li class="d-flex align-items-center mt-2">
                                            <a href="javascript:void(0)">
                                                <img src="assets/images/shop/product/s6.jpg" class="img-fluid avatar avatar-small rounded shadow" style="height:auto;" alt="">
                                            </a>
                                            <div class="flex-1 content ms-3">
                                                <a href="javascript:void(0)" class="text-dark h6">Coffee Cup</a>
                                                <h6 class="text-dark small fst-italic mb-0 mt-1">$18.00 <del class="text-danger ms-2">$22.00</del> </h6>
                                            </div>
                                        </li>
                                        <li class="d-flex align-items-center mt-2">
                                            <a href="javascript:void(0)">
                                                <img src="assets/images/shop/product/s8.jpg" class="img-fluid avatar avatar-small rounded shadow" style="height:auto;" alt="">
                                            </a>
                                            <div class="flex-1 content ms-3">
                                                <a href="javascript:void(0)" class="text-dark h6">Wooden Stools</a>
                                                <h6 class="text-dark small fst-italic mb-0 mt-1">$18.00 <del class="text-danger ms-2">$22.00</del> </h6>
                                            </div>
                                        </li>
                                    </ul>
                                </div> -->
                            </div>
                        </div>
                    </div><!--end col-->
                    @if(!empty($brandFilters) && sizeof($brandFilters)>0)
                    <div class="col-lg-9 col-md-8 col-12 mt-5 pt-2 mt-sm-0 pt-sm-0">
                        <div class="row align-items-center">
                        <div class="col-lg-5 col-md-3">
                                <div class="section-title">
                                     <h5 class="mb-0">{{translation('THERE_ARE')}}  {{translation('ITEMS')}}.</h5>
                                </div>
                            </div><!--end col-->
                            <div class="col-lg-1 col-md-1">
                            <h6 class="mb-0">{{translation('PER_PAGE')}}:</h6>
                            </div>
                            <div class="col-lg-2 col-md-1">
                                @if(in_array(config('constkey.listing_pagination'), $cKey))
                                <div class="section-title">
                                        <select class="form-select form-control" aria-label="Default select example" name="perPage" id="pagination">
                                            <option value="20" selected>20</option>
                                            <option value="40">40</option>
                                            <option value="80">80</option>
                                            <option value="200">200</option>
                                        </select>
                                </div>
                                @endif
                            </div>
                            <div class="col-lg-4 col-md-5 mt-4 mt-sm-0 pt-2 pt-sm-0">
                                <div class="d-flex justify-content-md-between align-items-center">
                                    <div class="form custom-form">
                                        @if(in_array(config('constkey.sidebar_filter'), $cKey))
                                        <div class="mb-0">
                                           <select class="form-select form-control" aria-label="Default select example" id="sortBy" id="sortBy" onChange="filterItem()">
                                              <option value="">{{translation('FILTER')}}</option>
                                              <option value="latest">{{translation('SHORT_BY_LATEST')}}</option>
                                              <option value="pricemintohigh">{{translation('PRICE_MIN_TO_HIGH')}}</option>
                                              <option value="pricehightomin">{{translation('PRICE_HIGH_TO_MIN')}}</option>
                                              <option value="atoz">{{translation('A_TO_Z')}}</option>
                                              <option value="ztoa">{{translation('Z_TO_A')}}</option>
                                              <option value="instock">{{translation('IN_STOCK')}}</option>
                                            </select>
                                        </div>
                                        @endif
                                    </div>
                                   
                                    <div class="mx-2 progridlist">
                                        <a href="javascript:void(0)" class="h5 text-muted"><i class="uil uil-apps"></i><i class="uil uil-list-ul"></i></a>
                                    </div>
                              
                                    <!-- <div class="progridlist">
                                        <a href="javascript:void(0)" class="h5 text-muted"><i class="uil uil-list-ul"></i></a> 
                                    </div> -->
                                </div>
                            </div><!--end col-->
                        </div><!--end row-->

                        <div class="row productgrid" id="filterProductData">  
                        @if(!empty($brandFilters))
                        @foreach($brandFilters as $product)
                        <x-Ecom02.shared-component.product viewtype="grid" :data="$product" />
                            @endforeach
                            @else
                            <div class="shop-image position-relative overflow-hidden my-3">
                                <img src="{{ LoadAssets('assets/images/EmptyImages/Wishlist-Empty.png')}}"
                                class="rounded mx-auto d-block" width="286px" height="200px"
                                alt="{{getSetting('site_title')}} Wishlist-Empty">
                            </div>
                            <p class="h4 text-center text-dark mt-3">Opps!! There is no product avaliable for this
                                category</p>
                            <div class="text-center my-3">
                                <a href="{{url('/')}}" class="btn btn-primary btn-lg btn-block" role="button"
                                    aria-pressed="true">Continue to shop</a>
                            </div> 
                            @endif

                            <!-- PAGINATION START -->
                            <div class="col-12 mt-4 pt-2">
                                <ul class="pagination justify-content-center mb-0">
                                    <li class="page-item"><a class="page-link" href="javascript:void(0)" aria-label="Previous"><i class="mdi mdi-arrow-left"></i> Prev</a></li>
                                    <li class="page-item active"><a class="page-link" href="javascript:void(0)">1</a></li>
                                    <li class="page-item"><a class="page-link" href="javascript:void(0)">2</a></li>
                                    <li class="page-item"><a class="page-link" href="javascript:void(0)">3</a></li>
                                    <li class="page-item"><a class="page-link" href="javascript:void(0)" aria-label="Next">Next <i class="mdi mdi-arrow-right"></i></a></li>
                                </ul>
                            </div><!--end col-->
                            <!-- PAGINATION END -->
                        </div><!--end row-->
                        <!-- List view product start -->
                        <div class="row productlist" id="filterProductData" style="display:none;">  
                        @if(!empty($brandFilters))
                        @foreach($brandFilters as $product)
                        <x-Ecom02.shared-component.product viewtype="list" :data="$product" />
                            @endforeach
                            @else
                            <div class="shop-image position-relative overflow-hidden my-3">
                                <img src="{{ LoadAssets('assets/images/EmptyImages/Wishlist-Empty.png')}}"
                                class="rounded mx-auto d-block" width="286px" height="200px"
                                alt="{{getSetting('site_title')}} Wishlist-Empty">
                            </div>
                            <p class="h4 text-center text-dark mt-3">Opps!! There is no product avaliable for this
                                category</p>
                            <div class="text-center my-3">
                                <a href="{{url('/')}}" class="btn btn-primary btn-lg btn-block" role="button"
                                    aria-pressed="true">Continue to shop</a>
                            </div> 
                            @endif

                            <!-- PAGINATION START -->
                            <div class="col-12 mt-4 pt-2">
                                <ul class="pagination justify-content-center mb-0">
                                    <li class="page-item"><a class="page-link" href="javascript:void(0)" aria-label="Previous"><i class="mdi mdi-arrow-left"></i> Prev</a></li>
                                    <li class="page-item active"><a class="page-link" href="javascript:void(0)">1</a></li>
                                    <li class="page-item"><a class="page-link" href="javascript:void(0)">2</a></li>
                                    <li class="page-item"><a class="page-link" href="javascript:void(0)">3</a></li>
                                    <li class="page-item"><a class="page-link" href="javascript:void(0)" aria-label="Next">Next <i class="mdi mdi-arrow-right"></i></a></li>
                                </ul>
                            </div><!--end col-->
                            <!-- PAGINATION END -->
                        </div><!--end row-->
                         <!-- List view product end -->
                    </div><!--end col-->
                    @else
                    <div class="shop-image position-relative overflow-hidden my-3">
                                <img src="{{ LoadAssets('assets/images/EmptyImages/Wishlist-Empty.png')}}"
                                class="rounded mx-auto d-block" width="286px" height="200px"
                                alt="{{getSetting('site_title')}} Wishlist-Empty">
                    </div>
                    <p class="h4 text-center text-dark mt-3">Opps!! There is no product avaliable for this
                                category</p>
                    <div class="text-center my-3">
                    <a href="{{url('/')}}" class="btn btn-primary btn-lg btn-block" role="button"
                                    aria-pressed="true">Continue to shop</a>
                    </div>
                    @endif
                </div><!--end row-->
            </div><!--end container-->
        </section><!--end section-->
        <!-- End Products -->
@push('scripts')
<script>

    $(".progridlist").click(function() {
        $(".productgrid").toggle();
        $(".productlist").toggle();
        });

</script>
@endpush