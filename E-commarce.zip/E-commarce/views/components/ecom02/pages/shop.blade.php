@php
$main_arr = [
'title'=>$sideFilter["cat_details"]->category_name ?? '',
'sublist' => $breadCumbArr
];
$ExtSize='';
$lSize='';
// Make conditions for div sizes

if(in_array(config('constkey.sidebar_filter'), $cKey) || in_array(config('constkey.sidebar_category'), $cKey))
{
$ExtSize="col-lg-9";
$lSize="col-md-12";
}
else
{
$ExtSize="col-lg-12";
$lSize="col-md-6";
}

// end of div sizes
$per_page=substr(url()->full(),-2);
if($per_page==00)
$per_page=substr(url()->full(),-3);
@endphp


<!-- Breadcrumb Area Start -->
<x-Ecom02.SharedComponent.BreadCrumb :data="$main_arr" />
<!-- Breadcrumb Area End -->


<!-- Hero End -->
<!-- Start Products -->
<section class="section">
    <div class="container">
        <form id="filterForm" action="{{url("/category/".urlencode($filtersData['slug']))}}" method="get">
            <input type="hidden" name="filter">
            <div class="row">
                <div class="col-lg-3 col-md-4 col-12">
                    <div class="card border-0 sidebar sticky-bar">
                        <div class="card-body p-0">
                            <!-- Categories -->
                            @if(in_array(config('constkey.sidebar_category'), $cKey))
                                @if($sideFilter)
                                    <div class="widget">
                                        @if(!$sideFilter['cat_list']->isEmpty())
                                            <h5 class="widget-title">{{translation('PRODUCT_CATEGORIES')}}</h5>
                                            <ul class="list-unstyled mt-4 mb-0 blog-categories">
                                                @foreach($sideFilter['cat_list'] as $key=>$cat)
                                                    <li>
                                                        <a href="{{url('category/'.$cat->categories_slug)}}">
                                                            {{ $cat->category_name ?? 'No Data' }}
                                                        </a>
                                                    </li>
                                                @endforeach
                                            </ul>
                                        @endif
                                    </div>
                                @else
                                    <div>
                                    </div>
                                @endif
                            @endif
                            @if((!empty($brandArray) && sizeof($brandArray)>0) )
                                <div class="main-heading mt-4">
                                    <h5>{{translation('PRODUCT_FILTER_BY')}}</h5>
                                    <hr>
                                </div>
                            @if(in_array(config('constkey.sidebar_filter'), $cKey))
                                <!--  Brand  -->
                                @if (!empty($brandArray) && sizeof($brandArray)>0)
                                    <div class="widget">
                                        <h5 class="widget-title">{{translation('PRODUCT_BRAND')}}</h5>
                                        <ul class="list-unstyled mt-4 mb-0 blog-categories">
                                            @foreach ($brandArray as $brands)
                                            <div class="form-check">
                                                <input type="checkbox" class="form-check-input optionChoose"
                                                    id={{$brands}} name="choosenBrands[]" onClick="filterItem()"
                                                    value="{{ $brands }}" @if(in_array($brands,$filtersData['brands'])) checked @endif>
                                                <label class="form-check-label" for="{{$brands}}"> {{ brandIDtoName($brands)}}</label>
                                            </div>
                                            <span class="checkmark"></span>
                                            @endforeach
                                        </ul>
                                    </div>
                                @else
                                    <div></div>
                                @endif
                            @endif
                            <!--  Brand -->
                            @if (!empty($productAttributes))
                            @foreach ($sideFilter['cat_details']->options as $option)
                            <div class="widget">
                                <h5 class="widget-title">{{ $optionName ?? '' }}</h5>
                                @if (!empty($option))
                                <ul class="list-unstyled mt-4 mb-0 blog-categories">
                                    @foreach ($option as $optionValue)
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input optionChoose"
                                            name="option_{{$optionName}}_[]" onClick="filterItem()"
                                            value="{{$optionValue}}" @if(in_array($optionValue,$filtersData['options'])) checked @endif>
                                        <label class="form-check-label" for="save-info">{{optIdToName($optionValue)}}</label>
                                    </div>
                                    <span class="checkmark"></span>
                                    @endforeach
                                </ul>
                                @endif
                            </div>
                            @endforeach
                            @endif
                            @endif
                            
                            <!--  Option -->

                            @if(in_array(config('constkey.section_related'), $cKey))
                            @if (!$products->isEmpty())
                            <!-- Top Products -->
                            <div class="widget mt-4 pt-2">
                                <h5 class="widget-title">{{translation('TOP_PRODUCT')}}</h5>
                                <ul class="list-unstyled mt-4 mb-0">
                                    @foreach ($products as $key => $products)
                                    <li class="d-flex align-items-center">
                                        <a href="javascript:void(0)">
                                            <img src="{{ getFullImageUrl($products->images_id) }}"
                                                alt="{{ $products->images_name }}"
                                                class="img-fluid avatar avatar-small rounded shadow"
                                                style="height:auto;">
                                        </a>
                                        <div class="flex-1 content ms-3">
                                            <a href="javascript:void(0)" class="text-dark h6">{{
                                                $products->products_name ?? '' }}</a>
                                            @php
                                            $discounAmount=($products->sale_price)*$products->discount_amount/100;
                                            $totalPrice=$products->sale_price+$discounAmount;
                                            @endphp
                                            <h6 class="text-dark small mb-0 mt-1">{{
                                                currencyFormat($products->sale_price ?? '0.00') }} <del
                                                    class="text-danger ms-2">{{ currencyFormat($totalPrice)}}</del>
                                            </h6>
                                        </div>
                                    </li>
                                    @endforeach
                                </ul>
                            </div>
                            @endif
                            @endif
                        </div>
                    </div>
                </div>
                <!--end col-->
                
                <div class="col-lg-9 col-md-8 col-12 mt-5 pt-2 mt-sm-0 pt-sm-0">
                   <div class="category-top-wrapper">
                   <div class="row align-items-center">
                        <div class="col-lg-3 col-sm-12">
                            @php
                                $item =  $products->total() ?? 1 ;
                                $data  = translation('PAGINATION_TOTAL_ITEM');
                                printf($data, $item);
                            @endphp
                        </div>
                        <!--end col-->
                       
                       
                        <div class="col-lg-9 col-xs-12 mt-4 mt-sm-0 pt-2 pt-sm-0">
                           <div class="d-md-flex justify-content-end align-items-center ">
                            <div class="d-flex gap-2 me-md-2">
                                    <div class="text-md-center m-md-auto">
                                    <div class="mb-0">{{translation('ITEM_PER_PAGE')}}:</div>
                                    </div>
                                    <div>
                                        @if(in_array(config('constkey.listing_pagination'), $cKey))
                                        <div class="section-title">
                                            <select class="form-select form-control" aria-label="Default select example"
                                                name="perPageItem"  onChange="filterItem()">
                                                <option value="20" @if($filtersData['perPageItem']==20) selected @endif>20</option>
                                                <option value="40" @if($filtersData['perPageItem']==40) selected @endif>40</option>
                                                <option value="80" @if($filtersData['perPageItem']==80) selected @endif>80</option>
                                                <option value="200" @if($filtersData['perPageItem']==200) selected @endif>200</option>
                                            </select>
                                        </div>
                                        @endif
                                    </div>
                                </div>
                                <div class="d-flex justify-content-md-between align-items-center">
                                    <div class="form custom-form">
                                        @if(in_array(config('constkey.sidebar_filter'), $cKey))
                                        <div class="mb-0">
                                            <select name="sortBy" class="form-select form-control"
                                                aria-label="Default select example" id="sortBy" onChange="filterItem()">
                                                <option value="" @if($filtersData['sortBy']==null) selected @endif>{{translation('FILTER')}}</option>
                                                <option value="latest" @if($filtersData['sortBy']=='latest') selected @endif>{{translation('SORT_BY_LATEST')}}</option>
                                                <option value="pricemintohigh" @if($filtersData['sortBy']=='pricemintohigh') selected @endif>{{translation('PRICE_MIN_TO_MAX')}}</option>
                                                <option value="pricehightomin" @if($filtersData['sortBy']=='pricehightomin') selected @endif>{{translation('PRICE_MAX_TO_MIN')}}</option>
                                                <option value="instock" @if($filtersData['sortBy']=='instock') selected @endif>{{translation('IN_STOCK')}}</option>
                                            </select>
                                        </div>
                                        @endif
                                    </div>

                                    <div class="mx-2 progridlist">
                                        <a href="javascript:void(0)" class="h5 text-muted">
                                            <i class="uil uil-apps"></i>
                                            <i class="uil uil-list-ul"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--end col-->
                    </div>
                   </div>
                    <!--end row-->

                    <!-- current selected category -->
                    <input style="display:none" type="checkbox" name="category" value='{{ $sideFilter['cat_details']->categories_id }}' checked />
                    <!-- end current category -->
                    @if(!empty($products) && sizeof($products)>0)
                    <div>
                        <div class="row productgrid" id="filterProductData">
                            @if(!empty($products) && sizeof($products)>0)
                            @foreach($products as $product)
                            <x-Ecom02.shared-component.product viewtype="grid" :data="$product" />
                            @endforeach
                            @else
                            <div class="shop-image position-relative overflow-hidden my-3">
                                <img src="{{ LoadAssets('assets/images/EmptyImages/Wishlist-Empty.png')}}"
                                    class="rounded mx-auto d-block" width="286px" height="200px"
                                    alt="{{getSetting('site_title')}} Wishlist-Empty">
                            </div>
                            <p class="h4 text-center text-dark mt-3">{{translation('EMPTY_CATEGORY_PRODUCT_MSG')}}
                                </p>
                            <div class="text-center my-3">
                                <a href="{{url('/')}}" class="btn btn-primary btn-lg btn-block" role="button"
                                    aria-pressed="true">{{translation('CONTINUE_TO_SHOP')}}</a>
                            </div>
                            @endif
                        </div>
                        <!--end row-->

                        <!-- List view product start -->
                        <div class="row productlist" style="display:none;">
                            @if(!empty($products) && sizeof($products)>0)
                            @foreach($products as $product)
                            <x-Ecom02.shared-component.product viewtype="list" :data="$product" />
                            @endforeach
                            @else
                            <div class="shop-image position-relative overflow-hidden my-3">
                                <img src="{{ LoadAssets('assets/images/EmptyImages/Wishlist-Empty.png')}}"
                                    class="rounded mx-auto d-block" width="286px" height="200px"
                                    alt="{{getSetting('site_title')}} Wishlist-Empty">
                            </div>
                            <p class="h4 text-center text-dark mt-3">{{translation('EMPTY_CATEGORY_PRODUCT_MSG')}}
                                </p>
                            <div class="text-center my-3">
                                <a href="{{url('/')}}" class="btn btn-primary btn-lg btn-block" role="button"
                                    aria-pressed="true">{{translation('CONTINUE_TO_SHOP')}}</a>
                            </div>
                            @endif
                        </div>
                        <!--end row-->
                        <!-- List view product end -->

                   
                        <input style="display:none" type="text" name="page" id="page" value="" />
                        <input style="display:none" type="text" name="options" id="options" value="" />
                        <input style="display:none" type="text" name="brands" id="brands" value="" />
                        

                        <!-- PAGINATION START -->
                        <input type="hidden" id="nextPage" value="1">
                        <div class="col-12 mt-4 pt-2 pro-pagination-style-wrapper">
                            {{ $products->links('vendor.pagination.for-ajax') }}
                        </div>
                        <!-- PAGINATION END -->
                    </div>
                    @else
                    <div class="shop-image position-relative overflow-hidden my-3">
                        <img src="{{ LoadAssets('assets/images/EmptyImages/Wishlist-Empty.png')}}"
                            class="rounded mx-auto d-block" width="286px" height="200px"
                            alt="{{getSetting('site_title')}} Wishlist-Empty">
                    </div>
                    <p class="h4 text-center text-dark mt-3">{{translation('EMPTY_CATEGORY_PRODUCT_MSG')}}
                        </p>
                    <div class="text-center my-3">
                        <a href="{{url('/')}}" class="btn btn-primary btn-lg btn-block" role="button"
                            aria-pressed="true">{{translation('CONTINUE_TO_SHOP')}}</a>
                    </div>
                    @endif
                </div>
                <!--end col-->
            </div>
            <!--end row-->
            <button type="submit" hidden id="filterFormButton"></button>
        </form>
    </div>
    <!--end container-->
</section>
<!--end section-->
<!-- End Products -->
@push('scripts')
<script>
    //  const optionList = {{ Illuminate\Support\Js:: from($sideFilter['cat_details'] -> options) }};
     const optionList = {{ Illuminate\Support\Js:: from($productAttributes) }};
    function filterItem(currentpage = 0) {
        var count = 0;
        for (const key in optionList) {
            count++;
        }
        $("html").scrollTop(0);
        var ChoosenAttributes = [];
        var brands = [];

        let brandHtml = $('input[name="choosenBrands[]"]:checked');
        if (brandHtml.length > 0) {
            brandHtml.each((label, data) => {
                brands.push(data.value);
            });
        }
        if (count > 0) {
            var i=0;
            for (const key in optionList) {
                let options = [];
                let optionHtml = $(`input[name="option_${key}_[]"]:checked`);
                if (optionHtml.length > 0) {
                    optionHtml.each((label, data) => {
                        options.push(data.value);
                    });
                }
                ChoosenAttributes[i] = options;
                i++;
            }
        }
        console.log( ChoosenAttributes);
        $('#page').val($('#nextPage').val());
        $('#options').val(ChoosenAttributes.toString());
        $('#brands').val(brands.toString());
        $("#filterForm").submit();

    }
    $(".progridlist").click(function () {
        $(".productgrid").toggle();
        $(".productlist").toggle();
    });
</script>
@endpush