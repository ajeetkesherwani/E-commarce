<section class="form-wrapper">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-5 col-md-8"> 
                <div class="card shadow rounded border-0 mt-4">
                    <div class="card-body">
                        <h4 class="card-title text-center">{{ translation('REGISTER_TITLE') }}</h4>  
                        <form class="login-form mt-4" action="{{ route('register') }}" method="post"  id="reg_form" novalidate="novalidate">
                          @csrf
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label class="form-label">{{ translation('NAME') }} <span class="text-danger">*</span></label>
                                        <div class="form-icon position-relative">
                                            <i data-feather="user" class="fea icon-sm icons"></i>
                                            <input type="text" class="form-control ps-5 @error('name') is-invalid @enderror" name="name" placeholder="{{ translation('NAME_PLACEHOLDER') }}" value="{{old('name')}}" required="">
                                        </div>
                                        @error('name')
                                            <span class="text-danger mb-5">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div><!--end col-->

                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label class="form-label">{{ translation('EMAIL') }} <span class="text-danger">*</span></label>
                                        <div class="form-icon position-relative">
                                            <i data-feather="mail" class="fea icon-sm icons"></i>
                                            <input type="email" class="form-control ps-5 @error('email') is-invalid @enderror"name="email" placeholder="{{ translation('EMAIL_PLACEHOLDER') }}" value="{{old('email')}}" required="">
                                        </div>
                                        @error('email')
                                            <span class="text-danger mb-5">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div><!--end col-->

                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label class="form-label">{{ translation('PASSWORD') }}<span class="text-danger">*</span></label>
                                        <div class="form-icon position-relative">
                                            <i data-feather="key" class="fea icon-sm icons"></i>
                                            <input type="password" id="password" class="form-control ps-5 @error('password') is-invalid @enderror" name="password" placeholder="{{ translation('PASSWORD_PLACEHOLDER') }}"  required="">
                                        </div>
                                        @error('password')
                                            <span class="text-danger mb-5">{{ $message }}</span>
                                        @enderror
                                        <div class="error-msg text-danger d-none"></div>
                                    </div>
                                </div><!--end col-->

                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label class="form-label">{{ translation('CONFIRM_PASSWORDS') }}<span class="text-danger">*</span></label>
                                        <div class="form-icon position-relative">
                                            <i data-feather="key" class="fea icon-sm icons"></i>
                                            <input type="password" id="confirmpassword" class="form-control ps-5 @error('password_confirmation') is-invalid @enderror" name="password_confirmation" placeholder="{{ translation('CONFIRM_PASSWORDS_PLACEHOLDER') }}" required="">
                                        </div>
                                        @error('password_confirmation')
                                            <span class="text-danger mb-5">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div><!--end col-->
                            
                                <div class="col-md-12">
                                    <div class="d-grid">
                                        <button class="btn btn-primary register_btn" type="submit">{{ translation('REGISTER_BUTTON') }}</button>
                                    </div>
                                </div><!--end col-->

                                <div class="mx-auto text-center">
                                    <p class="mb-0 mt-3"><small class="text-dark me-2">{{ translation('ALREADY_REGISTER') }}</small> <a href="{{ url('login') }}" class="text-dark fw-bold">{{translation('SIGN_IN')}}</a></p>
                                </div>
                            </div><!--end row-->
                        </form>
                    </div>
                </div>
            </div><!--end col-->
        </div><!--end row-->
    </div> <!--end container-->
</section><!--end section-->

@push('scripts')
<script>
    $(document).ready(function() {
        $(document).on('click', '.register_btn', function(e) {
             e.preventDefault();
            $('#reg_form').addClass('was-validated');
            if ($('#reg_form')[0].checkValidity() === false){
                event.stopPropagation();
            } 
            else {
                var passsword = $('#password').val();
                var confirmpasssword = $('#confirmpassword').val();
                if( passsword == confirmpasssword){
                    $('#reg_form').removeClass('was-validated');
                    $('#reg_form').submit();
                }
                else{
                    event.stopPropagation();
                    $('.error-msg').removeClass('d-none');
                    $('.error-msg').html('{{translation('ERROR_PASSWORD_AND_CONFIRM_PASSWORD_MSG')}}');
                    setTimeout(function() {
                        $(".error-msg").addClass("d-none");
                        $('.error-msg').html('');
                    }, 3000);
                }
            }
        });
    });
</script>
@endpush