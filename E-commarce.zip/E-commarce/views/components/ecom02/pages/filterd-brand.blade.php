<!-- Dynamic Product Load To  -->
<!-- Shop Tab Content Start -->



<div class="row">
   @if(!empty($products) && sizeof($products)>0)
     @foreach($products as $product)
       <x-Ecom02.shared-component.product viewtype="grid" :data="$product" />
     @endforeach
   @endif  
 </div><!--end row-->

 <!--  Pagination Area Start -->
<input type="hidden" id="nextPage" value="1">
 <!-- PAGINATION START -->
 <div class="col-12 mt-4 pt-2 pro-pagination-style-wrapper">
    {{ $products->links('vendor.pagination.for-ajax') }}    
  </div><!--end col-->
  <!-- PAGINATION END -->                               
        
<!--  Pagination Area End -->