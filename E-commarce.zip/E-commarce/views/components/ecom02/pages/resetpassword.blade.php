<section class="form-wrapper">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-5 col-md-8"> 
                <div class="card login-page shadow rounded border-0">
                    <div class="card-body">
                        <h4 class="card-title text-center">{{ translation('RESET_TITLE') }}</h4>  
                        <form class="login-form mt-4" action="{{ route('password.update') }}" method="post" id="reset_password_form"  novalidate="novalidate">
                            @csrf    
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="mb-3">
                                        <input type="hidden" name="email" placeholder="New Password"
                                            value="{{ Request::get('email')}}" />
                                        <input type="hidden" name="token" value="{{ Request::route('token')}}" />
                                        <label class="form-label">{{ translation('NEW_PASSWORD') }} <span class="text-danger">*</span></label>
                                        <div class="form-icon position-relative">
                                            <i data-feather="user" class="fea icon-sm icons"></i>
                                            <input type="password" class="form-control ps-5 @error('password') is-invalid @enderror" name="password" id="password" placeholder="{{ translation('NEW_PASSWORD_PLACEHOLDER') }}" required="">
                                        </div>
                                        @error('password')
                                            <span class="text-danger mb-5">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div><!--end col-->

                                <div class="col-lg-12">
                                    <div class="mb-3">
                                        <label class="form-label">{{ translation('CONFIRM_PASSWORDS') }} <span class="text-danger">*</span></label>
                                        <div class="form-icon position-relative">
                                            <i data-feather="key" class="fea icon-sm icons"></i>
                                            <input type="password" name="password_confirmation"
                                            placeholder="{{ translation('CONFIRM_PASSWORDS_PLACEHOLDER') }}" class="form-control ps-5 @error('password_confirmation') is-invalid @enderror" required="">
                                        </div>
                                        @error('password_confirmation')
                                            <span class="text-danger mb-5">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div><!--end col-->

                                <div class="col-lg-12 mb-0">
                                    <div class="d-grid">
                                        <button type="submit" class="btn btn-primary">{{ translation('CHANGE_PASSWORD_BUTTON') }}</button>
                                    </div>
                                </div><!--end col-->
                                
                            </div><!--end row-->
                        </form>
                    </div>
                </div><!---->
            </div><!--end col-->
        </div><!--end row-->
    </div> <!--end container-->
</section><!--end section-->


@push('scripts')

<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
<script>
    $(document).ready(function() {
        $('#reset_password_form').validate({
            rules: {
                password: {
                    required: true,
                    minlength: 6
                },
                password_confirmation: {
                    required: true,
                    minlength: 6,
                    equalTo : "#password"                   
                },
            },
            messages: {
                password: {
                        required: "Please enter a password",
                        minlength: "Password must be at least 6 characters",
                    },
                    password_confirmation: {
                        required: "Please enter confirm password",
                        minlength: "Confirm password must be at least 6 characters"
                    },
                },
            highlight: function(element) {
                $(element).addClass('is-invalid');
                $(element).css("border", " 1px solid red")
            },
            unhighlight: function(element, errorClass, validClass) {
                $(element).removeClass('is-invalid');
                $(element).css("border", "1px solid #ebebeb")
            }
        });
    });
 
</script>
@endpush