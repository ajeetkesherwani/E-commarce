<style>
	
    h1,h2,h3,h4,h5,h6,p{font-family: "Gill Sans", "Gill Sans MT", "Myriad Pro", "DejaVu Sans Condensed", Helvetica, Arial, "sans-serif";}
    ul li {font-family:"DejaVu Sans","sans-serif","Gill Sans", "Gill Sans MT", "Myriad Pro", "DejaVu Sans Condensed", Helvetica, Arial, "sans-serif";}
    
    table tr td {font-family: "Gill Sans", "Gill Sans MT", "Myriad Pro", "DejaVu Sans Condensed", Helvetica, Arial, "sans-serif";}
    
    table tr th {font-family: "Gill Sans", "Gill Sans MT", "Myriad Pro", "DejaVu Sans Condensed", Helvetica, Arial, "sans-serif";}
    
</style>


      {{-- @php
          header('Content-Type: text/html; charset=utf-8');
          mb_internal_encoding('utf-8'); 
      @endphp --}}
    <table width="850px"  style="margin: 0 auto; border: none;">
      <tr>
        <td style="border: none;"><h3>Invoice : {{$orderdetails['order_number'] ?? ''}}</h3>
          <p style="margin-top:10px;">Date : {{dateFormate($orderdetails['created_at'])}}</p></td>
      </tr>
      <tr width="100%" style="border-bottom: 1px solid #f00;">
        <td width="80%" style="border: none; padding: 20px 0px;"><h5>BILLED FROM<span style="font-size: 21px;"><br>
            ThemePixels, Inc.</span> </h5>
          <p style="margin-top: -15px;">201 Something St., Something Town, YT 242, Country 6546 <br>
            Tel No: 324 445-4544 <br>
            Email: youremail@companyname.com </p></td>
        <td width="20%" style="border: none;" ><div style="text-align: end;">
            <p>INVOICE NUMBER </p>
            <h1 style="color: darkgray;">{{$orderdetails['order_number'] ?? ''}} </h1>
          </div></td>
      </tr>
    </table>
    <table width="850px" border="0" style="margin: 0 auto; ">
      <tr width="100%">
        <td width="60%" style="padding: 20px 0px;"><h5>BILLING ADDRESS<span style="font-size: 21px;"><br>
            {{$orderdetails->address[0]['customer_name'] ?? ''}}</span> </h5>
          <p>{{$orderdetails->address[0]['customer_address'] ?? ''}} <br/> {{$orderdetails->address[0]['customer_city'] ?? ''}} {{$orderdetails->address[1]['customer_state'] ?? ''}} {{$orderdetails->address[1]['customer_country'] ?? ''}} {{$orderdetails->address[1]['customer_postcode'] ?? ''}}
            <br>
            Phone: {{$orderdetails->address[0]['customer_phone'] ?? ''}}<br>
            Email: {{$orderdetails->address[0]['customer_email'] ?? ''}}</p></td>
        {{-- <td  width="20%"><ul style="list-style: none;">
            <li style="padding-bottom: 5px;">Invoice Number</li>
            <li style="padding-bottom: 5px;">Product ID </li>
            <li style="padding-bottom: 5px;">Issue Date </li>
            <li style="padding-bottom: 5px;">Due Date </li>
          </ul></td> --}}
        {{-- <td  width="20%"><ul style="list-style: none; text-align: end;">
            <li style="padding-bottom: 5px;">DF032AZ00022</li>
            <li style="padding-bottom: 5px;">32334300</li>
            <li style="padding-bottom: 5px;"> January 20, 2019</li>
            <li style="padding-bottom: 5px;">April 21, 2019 </li>
          </ul></td> --}}
      </tr>
    </table>
    <table width="850px" style="margin: 0 auto; padding-top: 20px;">
      <thead>
        <tr>
          <th style="text-align: left; border-top: 1px solid #E9E7E7; border-bottom: 1px solid #E9E7E7; padding: 10px 0px; ">#</th>
          <th style="text-align: left; border-top: 1px solid #E9E7E7; border-bottom: 1px solid #E9E7E7; ">Item</th>
          <th style="text-align: center; border-top: 1px solid #E9E7E7; border-bottom: 1px solid #E9E7E7; ">Price </th>
          <th style="text-align: end; border-top: 1px solid #E9E7E7; border-bottom: 1px solid #E9E7E7; ">Qty</th>
          <th style="text-align: end; border-top: 1px solid #E9E7E7; border-bottom: 1px solid #E9E7E7; ">Total</th>
        </tr>
      </thead>
      <tbody>
        
        @foreach ($orderdetails->item as $key=>$item)
        <tr style="padding: 10px 0px;-">
          <td>{{$key+1}}</td>
          <td style="width: 500px;">{{$item->product->description[0]['products_name'] ?? ''}}
          
            @if(!empty($orderdetails['attrOptArray']) && sizeof($orderdetails['attrOptArray'])>0)
            @foreach($orderdetails['attrOptArray'][$item->product->product_id] as $attsubarr)
            @foreach($attsubarr as $attrkey=>$attrVal)
                <p>{{$attrkey}}  {{$attrVal}}</p>
            @endforeach
            @endforeach
            @endif
           
          </td>
          <td style="text-align: center;">{{currencyFormat($orderdetails['grand_total']/$item['qty']) ?? ''}}</td>
          <td style="text-align: center;">{{$item['qty'] ?? ''}}</td>
          <td style="text-align: end;">{{currencyFormat($orderdetails['grand_total']) ?? ''}}</td>
        </tr>
        @endforeach
      </tbody>
    </table>
    <table width="850px" border="0" style="margin: 0 auto; padding-top: 20px;">
      <tr>
        <td width="40%">
            {{-- <h5>NOTES</h5> --}}
          {{-- <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. </p></td> --}}
        <td width="10%"><ul style="list-style: none;">
            <li style="padding-bottom: 5px;">Sub-Total</li>
            <li style="padding-bottom: 5px;">Discount</li>
            <li style="padding-bottom: 5px;">Shipping Charge</li>
            <li style="padding-bottom: 5px;">Tax Amount</li>
            <li style="padding-bottom: 5px;">Total </li>
          </ul></td>
         
        <td width="10%"><ul style="list-style: none; text-align: end;">
            <li style="padding-bottom: 5px;">{{ currencyFormat($orderdetails['sub_total']) ??''}}</li>
            <li style="padding-bottom: 5px;">- {{ currencyFormat($orderdetails['discount_total']) ?? ''}}</li>
            <li style="padding-bottom: 5px;">{{ currencyFormat($orderdetails['shipping_total']) ?? ''}}</li>
            <li style="padding-bottom: 5px;">{{ currencyFormat($orderdetails['tax_amount']) ?? ''}}</li>
            <li style="padding-bottom: 5px;">&#8377;{{ $orderdetails['grand_total'] ?? ''}}</li>
          </ul></td>
      </tr>
    </table>
