@php

$main_arr = [
  'title'=>'Blog Post',
  'sublist' => [
    [
    'name'=>'HOME',
    'link'=>url("/")
    ],
    [
    'name'=>$blogDetail->post_title ,
    'link'=>url()->full()
    ], 
  ]
];
$currentURL = URL::current();
$url_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$url_segments = explode('/', $url_path);
$url_segment=$url_segments[2]; 
@endphp
<style>
      .blog-img-wrapper{
    height: 400px;
    overflow: hidden;
    width: 100%;
   }
</style>
<!-- Hero Start -->
{{-- <x-Ecom02.SharedComponent.BreadCrumb :data="$main_arr" />  --}}
    <!-- Start -->

    <section class="d-table w-100 mt-100">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-6 col-12">
                    <div class="card blog blog-detail border-0 shadow rounded">
                        <div class="blog-img-wrapper">
                            <img src="{{getFullImageUrl($blogDetail->img)}}"
                            alt="{{ $blogDetail->post_title ?? '' }}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" class="img-fluid rounded-top w-100" >
                        </div>
                        <div class="card-body">
                            <div class="text-center d-flex justify-content-between">
                                <h4 class="mt-3">{{ $blogDetail->post_title ?? '' }}</h4>
                
                                <ul class="list-unstyled mt-3">
                                    <li class="list-inline-item user text-muted me-2"><i class="mdi mdi-account"></i> {{ translation('ADMIN') }}</li>
                                    <li class="list-inline-item date text-muted"><i class="mdi mdi-calendar-check"></i>{{ date("d M, Y",
                                    strtotime($blogDetail->created_at)) }}</li>
                                </ul>
                            </div>
                
                            <p class="text-muted mt-3"></p><p><span >{!! $blogDetail->post_content ?? '' !!}</p><p></p>
                        </div>
                    </div>
                
                    
                </div>
                <!--end col-->

                <!-- START SIDEBAR -->
                <div class="col-lg-4 col-md-5 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0">
                    <div class="card border-0 sidebar sticky-bar ms-lg-4">
                        <div class="card-body p-0">
                            <!-- RECENT POST -->
                            <div class="widget mt-4">
                                <span class="bg-light d-block py-2 rounded shadow text-center h6 mb-0">
                                {{ translation('RECENT_POST') }}
                                </span>
                                <div class="mt-4">
                                @if (!empty($recentPost))
                                    @foreach ($recentPost->take(5) as $blog)
                                    <div class="d-flex align-items-center mt-3">
                                            <a href="{{ url('blog/'.$blog->slug) }}">
                                            <img src="{{getFullImageUrl($blog->img)}}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="{{ $blog->post_title ?? '' }}" class="avatar avatar-small rounded" style="width:116px; height:65px;">
                                            </a>
                                        <div class="flex-1 ms-3">
                                            <a href="{{ url('blog/'.$blog->slug) }}" class="d-block title text-dark">{{ $blog->post_title ?? '' }}</a>
                                            <span class="text-muted">{{ date("F d, Y", strtotime($blog->created_at)) }}</span>
                                        </div>
                                    </div>
                                    @endforeach
                                @endif   
                                </div>
                            </div>
                            <!-- RECENT POST -->
                            <!-- TAG CLOUDS -->
                            <!-- SOCIAL -->
                            <div class="widget mt-4">
                                <span class="bg-light d-block py-2 rounded shadow text-center h6 mb-0">
                                {{ translation('BLOG_SHARE') }}
                                </span>

                                <ul class="list-unstyled social-icon social text-center mb-0 mt-4">
                                    <li class="list-inline-item"><a href="https://www.facebook.com/sharer/sharer.php?u={{ $currentURL }}" target="_blank" class="rounded"><i data-feather="facebook" class="fea icon-sm fea-social"></i></a></li>
                                    <li class="list-inline-item"><a href="https://twitter.com/intent/tweet?text={{ $currentURL }}" target="_blank" class="rounded"><i data-feather="twitter" class="fea icon-sm fea-social"></i></a></li>
                                    <li class="list-inline-item"><a href="https://api.whatsapp.com/send?text={{ $currentURL }}" target="_blank" class="rounded">
                                        <img class="" src="{{ LoadAssets('assets/images/icons/whatsapp-icon.png') }}" style="height:18px; width:18px;">
                                        </a>
                                    </li>
                                </ul><!--end icon-->
                            </div>
                            <!-- SOCIAL -->
                        </div>
                    </div>
                </div><!--end col-->
                <!-- END SIDEBAR -->
            </div><!--end row-->
        </div><!--end container-->
    </section><!--end section-->
    <section>
        <div class="container">
            <div class="row">
                <!-- single item -->
                <div class="col-12 ">
                    <div class="tiny-four-item">
                        @foreach ($relatedPost as $blog)
                            @if($blog->slug!=$url_segment)
                                <x-Ecom02.SharedComponent.PostGrid :data="$blog" />
                            @endif
                        @endforeach
                        {{-- @foreach ($relatedPost as $blog)
                        @if($blog->slug!=$url_segment)
                            <x-Ecom02.SharedComponent.PostGrid :data="$blog" />
                        @endif
                    @endforeach --}}
                    </div>
                </div><!--end col-->
                {{-- <div class="tiny-four-item">
                    @if (!empty($relatedPost))
                        @foreach ($relatedPost as $blog)
                            @if($blog->slug!=$url_segment)
                                <x-Ecom02.SharedComponent.PostGrid :data="$blog" />
                            @endif
                        @endforeach
                    @endif
                </div> --}}
                <!-- single item -->
            </div>
        </div>
    </section>
    <!-- End -->

       

@push('scripts')
<script>
    $('#search').on('keyup',function(){
        $value=$(this).val();
        $.ajax({
            type : 'get',
            url : '{{URL::to('blogsearch')}}',
            data:{'search':$value},
            success:function(data){
                $('#searchBody').html(data);
            }
        });
    })
    </script>
    <script type="text/javascript">
    $.ajaxSetup({ headers: { 'csrftoken' : '{{ csrf_token() }}' } });
    </script>   
@endpush
        
     
