@php
$main_arr = [
'title'=>'Addreses',
'sublist' => [
[
'name'=>'HOME',
'link'=>url("/")
],
[
'name'=>'Address',
'link'=>url()->full()
],
]
];
@endphp


<!-- Bread cumb start here -->
<x-Ecom02.SharedComponent.BreadCrumb :data="$main_arr" />
<!-- Bread cumb end  here -->

<!-- Start -->
<section class="section">
    <div class="container">
        <div class="row">
            <!-- left side menubar start here -->
            <x-Ecom02.SharedComponent.left-side-menu />
            <!-- left side menubar end here -->

            <div class="col-md-8 col-12 mt-4 pt-2">
                <div class="shadow rounded" aria-labelledby="addresses">
                    <div class="d-md-flex justify-content-between px-4 py-3 border-bottom align-items-center">
                        <h6 class=" mb-0">{{translation('ADDRESS_TITLE')}}</h6>
                        <div>
                            <div class="d-flex align-items-center justify-content-center pointer border-dot add-address"  data-bs-toggle="modal" data-bs-target="#myModal"> 
                                <p class="mb-0"><a href="#"><i class="uil uil-edit align-middle"></i> {{translation('NEW_ADDRESS_BUTTON')}}</a></p>
                            </div>                                            
                        </div>
                    </div>
                    <div class="row CustomerAddress px-4 pb-3 d-flex">
                    <!-- ADDRESS DATA COME HERE FROM AJAX -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<!-- Starting Address Modals -->

<!-- Add Address Modal -->
<div class="modal fade" id="myModal" tabindex="-1" aria-labelledby="productview-title" aria-hidden="true">
    <div class="modal-dialog   modal-dialog-centered">
        <div class="modal-content rounded shadow border-0">
            <div class="modal-header border-bottom px-4">
                <h5 class="modal-title" id="productview-title">{{translation('ADD_ADDRESS')}}</h5>
                <button type="button" class="btn btn-icon btn-close" data-bs-dismiss="modal" id="close-modal"><i class="uil uil-times fs-4 text-dark"></i></button>
            </div>

            <div class="modal-body p-4">
                <div class="container-fluid px-0">
                    <div class="row">
                        <div>
                            <form class="needs-validation" novalidate  id="customeraddress">

                                <div class="form-floating mb-2">
                                    <input type="text" class="form-control" id="addcustname"
                                        placeholder="{{translation('NAME_PLACEHOLDER')}}" required>
                                    <label for="addcustname" class="form-label">
                                        {{translation('NAME')}}
                                        <span class="text-danger">*</span>
                                    </label>
                                    <span class="text-danger add_customer_name"></span>
                                </div>

                                <div class="form-floating mb-2">
                                    <input type="text" class="form-control" id="addcustemail"
                                        placeholder="{{translation('EMAIL_PLACEHOLDER')}}" required>
                                    <label for="addcustemail" class="form-label">
                                        {{translation('EMAIL')}}
                                        <span class="text-danger">*</span>
                                    </label>
                                    <span class="text-danger add_customer_email"></span>
                                </div>

                                <div class="form-floating mb-2">
                                    <input type="text" class="form-control" id="addsstreet"
                                        placeholder="{{translation('STREET_ADDRESS_PLACEHOLDER')}}" required>
                                    <label for="addsstreet" class="form-label">
                                        {{translation('STREET_ADDRESS')}}
                                        <span class="text-danger">*</span>
                                    </label>
                                    <span class="text-danger add_street_address"></span>
                                </div>

                                <div class="form-floating mb-2">
                                    <input type="text" class="form-control" id="addscity"
                                        placeholder="{{translation('CITY_PLACEHOLDER')}}" required>
                                    <label for="addscity" class="form-label">
                                        {{translation('CITY')}}
                                        <span class="text-danger">*</span>
                                    </label>
                                    <span class="text-danger add_city"></span>
                                </div>

                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" id="addsstate"
                                        placeholder="{{translation('STATE_PLACEHOLDER')}}" required>
                                    <label for="addsstate" class="form-label">
                                        {{translation('STATE')}}
                                        <span class="text-danger">*</span>
                                    </label>
                                    <span class="text-danger add_state"></span>
                                </div>

                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" id="addszipcode"
                                        placeholder="{{translation('ZIPCODE_PLACEHOLDER')}}" required>
                                    <label for="addszipcode" class="form-label">
                                        {{translation('ZIPCODE')}}
                                        <span class="text-danger">*</span>
                                    </label>
                                    <span class="text-danger add_zipcode"></span>
                                </div>

                                <div class="form-floating mb-3">
                                    @if(!empty($countriesdata))
                                    <select class="form-control form-select" id="addscountry" required>
                                        <option selected disabled value="">
                                            {{translation('COUNTRY_PLACEHOLDER')}}
                                            <span class="text-danger">*</span>
                                        </option>
                                        @foreach($countriesdata as $key=>$data)
                                        <option value="{{$data->countries_id}}">{{$data->countries_name}}</option>
                                        @endforeach
                                    </select>
                                    @endif
                                </div>

                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" id="addsphone"
                                        placeholder="{{translation('PHONE_PLACEHOLDER')}}" required>
                                    <label for="addszipcode" class="form-label">
                                        {{translation('PHONE')}}
                                        <span class="text-danger">*</span>
                                    </label>
                                    <span class="text-danger add_phone"></span>
                                </div>

                                <button class="btn btn-primary w-100" type="submit"
                                    id="addressformbutton">{{translation('SUBMIT')}}</button>
                                <input type="reset" hidden>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Address Modal-->

<!-- Update Address Modal -->

<!-- Start Update Address Modal -->
<div class="modal fade" id="updateAddressModal" tabindex="-1" aria-labelledby="productview-title" aria-hidden="true">
    <div class="modal-dialog  modal-lg modal-dialog-centered">
        <div class="modal-content rounded shadow border-0">
            <div class="modal-header border-bottom px-4">
                <h5 class="modal-title" id="productview-title">{{translation('UPDATED_ADDRESS')}}</h5>
                <button type="button" class="btn btn-icon btn-close" data-bs-dismiss="modal" id="close-modal">
                    <i class="uil uil-times fs-4 text-dark"></i></button>
            </div>
            <div class="modal-body p-4">
                <div class="container-fluid px-0">
                    <div class="row">
                        <input type="hidden" id="address_id">
                        <div>
                            <form class="needs-validation" novalidate id="customerUpdateAddress">
                                
                                <div class="form-floating mb-2">
                                    <input type="text" class="form-control" id="customer_name" placeholder="{{translation('NAME_PLACEHOLDER')}}" required> 
                                    <label for="customer_name" class="form-label">{{translation('NAME')}}</label>
                                    <span class="text-danger addup_customer_name"></span>
                                </div>

                                <div class="form-floating mb-2">
                                    <input type="text" class="form-control" id="customer_email" placeholder="{{translation('EMAIL_PLACEHOLDER')}}" required> 
                                    <label for="customer_email" class="form-label">{{translation('EMAIL')}}</label>
                                    <span class="text-danger addup_customer_email"></span>
                                </div>

                                <div class="form-floating mb-2">
                                    <input type="text" class="form-control" id="street_address" placeholder="{{translation('STREET_ADDRESS')}}" required> 
                                    <label for="street_address" class="form-label">{{translation('STREET_ADDRESS')}}</label>
                                    <span class="text-danger addup_street_address"></span>
                                </div>

                                <div class="form-floating mb-2">
                                    <input type="text" class="form-control" id="city" placeholder="{{translation('CITY')}}" required>
                                    <label for="city" class="form-label">
                                        {{translation('CITY')}}</label>
                                    <span class="text-danger addup_city"></span>
                                </div>

                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" id="state"
                                        placeholder="{{translation('STATE')}}" required>
                                    <label for="state" class="form-label">{{translation('STATE')}}</label>
                                    <span class="text-danger addup_state"></span>
                                </div>

                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" id="zipcode"
                                        placeholder="{{translation('ZIP_CODE_PLACEHOLDER')}}" required>
                                    <label for="zipcodeS" class="form-label">{{translation('ZIPCODE')}}</label>
                                    <span class="text-danger addup_zipcode"></span>
                                </div>

                                <div class="form-floating mb-3">
                                    @if(!empty($countriesdata))
                                    <select class="form-control form-select" id="countries_id" required>
                                        <option selected disabled value="">{{translation('SELECT_COUNTRY')}}</option>
                                        @foreach($countriesdata as $key=>$data)
                                        <option value="{{$data->countries_id}}" class="updcountry">
                                            {{$data->countries_name}}</option>
                                        @endforeach
                                    </select>
                                    @endif
                                </div>
                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" id="phone"
                                        placeholder="{{translation('PHONE_PLACEHOLDER')}}" required>
                                    <label for="phone" class="form-label">{{translation('PHONE')}}</label>
                                    <span class="text-danger addup_phone"></span>
                                </div>
                                <button class="btn btn-primary w-100" type="submit" id="updateAddressButton">{{translation('SUBMIT')}}</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--  End Update Address Modal -->

<!-- Start Delete Address Modal -->
<div class="modal fade" id="DeleteAddressModal" tabindex="-1" aria-labelledby="productview-title" aria-hidden="true">
    <div class="modal-dialog  modal-lg modal-dialog-centered">
        <div class="modal-content rounded shadow border-0">
            <div class="modal-header border-bottom">
                <h5 class="modal-title" id="productview-title">{{translation('DELETE_ADDRESS')}}</h5>
                <button type="button" class="btn btn-icon btn-close" data-bs-dismiss="modal" id="close-modal"><i class="uil uil-times fs-4 text-dark"></i></button>
            </div>

            <div class="modal-body p-4">
                <div class="container-fluid px-0">
                    <div class="row">
                            <div class="text-center">
                                {{-- <h5 class="mb-3 text-center">{{translation('UPDATE_ADDRESS')}}</h5> --}}
                                <div class="form-floating mb-3">
                                    <input type="hidden" id="delete_add_id">
                                    <h5>{{translation('DELETE_ADDRESS_CONFIRM')}} ?</h5>
                                </div>
                                <button type="button" class="btn btn-secondary my-2"
                                    data-bs-dismiss="modal">{{translation('CLOSE_BUTTON')}}</button>
                                <button type="button"
                                    class="btn btn-primary delete_add_cnf ">{{translation('DELETE_CONFIRMATION_BUTTON')}}</button>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Delete Address Modal -->

@push('scripts')
<script>
    // Start address script

    function loadaddresss() {
        $.ajax({
            url: "{{url('account/show-address')}}",
            type: "GET",
            dataType: 'json',
            success: function (response) {
                var addressHtml = ``;
                $.each(response.address, function (key, value) {
                    var is_default = value.is_default;
                    checked = '';
                    if (is_default === 1) checked = "checked";
                    addressHtml += `<div class="col-lg-6 mt-4 d-flex border py-3">
                                        <div>
                                            <div class="address-cont">
                                                <p>${value.customer_name}</p>
                                                <p>${value.customer_email}</p>
                                                <p>${value.street_address}</p>
                                                <p>${value.city}</p>
                                                <p>${value.state}, ${value.zipcode}</p>
                                                <p>${value.country_name}</p>
                                                <p class="mb-0">${value.phone}</p>
                                            </div>
                                     <div class="d-flex align-items-center mt-2 gap-3">
                                        <form action="/action_page.php">
                                        <div class="form-check form-switch">
                                            <input class="form-check-input mySwitch" type="checkbox" id="mySwitch"  name="darkmode" value="${value.address_id}" ${checked}>
                                            <label class="form-check-label mb-0" for="mySwitch">Make {{translation('DEFAULT')}}</label>
                                        </div>
                                        </form>
                               
                                <div class="entries-edit-delete  d-flex flex-row justify-content-end flex-grow-1 gap-2">
                                    <a href="javascript:void(0);" class="edit edit_address" value="${value.address_id}"><button class="btn btn-primary">{{translation('EDIT_BUTTON')}}</button></a> 
                                    <a href="javascript:void(0);" class="delete_address" value="${value.address_id}"><button class="btn btn-delete">{{translation('DELETE_BUTTON')}}</button></a>
                                </div>
                            </div>
                            </div>
                            </div>
                            </div>
                            </div>`;
                });

                $('.CustomerAddress').html(addressHtml);
            }
        });
    }

    // load all address through ajax
    
    loadaddresss();

    $(document).ready(function () {

        // add function  ajax
        $(document).on('click', '#addressformbutton', function (e) {
            e.preventDefault();
            $('#customeraddress').addClass('was-validated');
            if ($('#customeraddress')[0].checkValidity() === false) {
                event.stopPropagation();
            } else {
            var data = {
                'customer_name': $('#addcustname').val(),
                'customer_email': $('#addcustemail').val(),
                'street_address': $('#addsstreet').val(),
                'city': $('#addscity').val(),
                'state': $('#addsstate').val(),
                'zipcode': $('#addszipcode').val(),
                'countries_id': $('#addscountry').val(),
                'phone': $('#addsphone').val(),
            }
            //console.log(data);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "{{url('account/add-address')}}",
                data: data,
                dataType: "json",
                success: function (response) {
                    if (response.status == 400) {
                        $.each(response.error, function (key, err_val) {
                            $('.add_' + key).text(err_val);
                        });
                    } else {
                        $('#myModal').modal('hide');
                        $('#customeraddress').removeClass('was-validated');
                        $('#customeraddress').trigger("reset");
                        Notify('{{translation('SUCCESSFULLY_SEND')}}', true);
                        loadaddresss();

                    }
                }

            });
            }
        });


        //delete modal
        $(document).on("click", ".delete_address", function (e) {
            e.preventDefault();
            debugger;
            var addId = $(this).attr('value');
            $('#delete_add_id').val(addId);
            $('#DeleteAddressModal').modal('show');
        });

        // final delete
        $(document).on("click", ".delete_add_cnf", function (e) {
            e.preventDefault();
            var address_id = $('#delete_add_id').val();
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url: "{{ url('account/delete-address/') }}",
                type: "POST",
                data: {
                    address_id: address_id
                },
                success: function (response) {
                    console.log(response);
                    $('#DeleteAddressModal').modal('hide');
                    Notify('{{translation('DELETE_SUCCESS_MSG')}}!', true);
                    loadaddresss();
                }
            });
        });



        //Edit Address
        $(document).on("click", ".edit_address", function (e) {
            e.preventDefault();
            var addrsId = $(this).attr('value');
            $('#updateAddressModal').modal('show');
            var url = `{{url('account/address/${addrsId}/edit')}}`;

            $.ajax({
                url: url,
                type: "GET",
                success: function (response) {
                    if (response.status == 400) {
                        $('#errorlist').html("");
                        $('#errorlist').addClass("alert alert-danger");
                        $('#errorlist').append('<p>' + response.message + '</p>');
                    }
                    else {
                        $.each(response.addressdata, function (key, adds_val) {
                            $('#' + key).val(adds_val);

                        });
                    }
                }
            });

        });


        //update Address

        $(document).on("click", "#updateAddressButton", function (e) {
            e.preventDefault();
            $('#customerUpdateAddress').addClass('was-validated');

            if ($('#customerUpdateAddress')[0].checkValidity() === false) {
                event.stopPropagation();
            } else {
            var data = {
                'customer_name': $('#customer_name').val(),
                'customer_email': $('#customer_email').val(),
                'street_address': $('#street_address').val(),
                'city': $('#city').val(),
                'state': $('#state').val(),
                'zipcode': $('#zipcode').val(),
                'countries_id': $('#countries_id').val(),
                'phone': $('#phone').val(),
                'address_id': $("#address_id").val(),
            }

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "{{url('account/update-address')}}",
                data: data,
                dataType: "json",
                success: function (response) {
                    console.log(response);
                    if (response.status == 400) {
                        $.each(response.error, function (key, err_val) {
                            $('.addup_' + key).text(err_val);
                        });
                    }
                    else {
                        $('#updateAddressModal').modal('hide');
                         $('#customeraddress').removeClass('was-validated');
                        Notify('{{translation('ADDRESS_UPDATE_SUCCESS_MSG')}}!', true);
                        loadaddresss();
                    }

                }
            });
            }
        });

        // Make default address 

        var switchStatus = false;
        $(document).on('click', '.mySwitch', function () {
            if ($(this).is(':checked')) {
                var data = { 'address_id': $(this).val(), }
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{url('account/makedefault-address')}}",
                    data: data,
                    dataType: "json",
                    success: function (response) {
                        console.log(response);
                        if (response.status == 400) {
                            Notify('Some thing error !', false);
                            loadaddresss();
                        }
                        else {
                            Notify('{{translation('DEFAULT_ADDRESS_SUCCESS_MSG')}}', true);
                            loadaddresss();
                        }

                    }
                });
            }
        });

    });

// End address script 

</script>
@endpush