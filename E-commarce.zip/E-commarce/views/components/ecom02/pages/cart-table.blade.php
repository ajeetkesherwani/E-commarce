<!-- Start -->
        <section class="section">
             @if (!empty($list['cart_list']) && sizeof($list['cart_list'])>0)
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="table-responsive banner_background bg-white shadow rounded">
                            <table class="table mb-0 table-center">
                                <thead>
                                    <tr>
                                        <th class="border-bottom py-3" style="min-width:20px "></th>
                                        <th class="border-bottom text-start py-3" style="min-width: 300px;">Image</th>
                                        <th class="border-bottom text-start py-3" style="min-width: 300px;">Product Name</th>
                                        <th class="border-bottom text-center py-3" style="min-width: 160px;">Price</th>
                                        <th class="border-bottom text-center py-3" style="min-width: 160px;">Qty</th>
                                        <th class="border-bottom text-end py-3 pe-4" style="min-width: 160px;">Total</th>
                                    </tr>
                                </thead>

                                <tbody>
                                     @if (!empty($list['cart_list']))
                                    @foreach ($list['cart_list'] as $cart )
                                    <tr class="shop-list">
                                        <td class="h6 text-center"><a href="javascript:void(0)" onclick="actionOnCart({{$cart->cart_id}},'del')" class="text-danger"><i class="uil uil-times"></i></a></td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                              <a href="{{url('product/'.$cart->product->product_slug)}}">
                                                <img src="{{getFullImageUrl($cart->product->product_image)}}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="{{ $cart->product->products_name ?? ''}}" class="img-fluid avatar avatar-small rounded shadow" style="height:auto;" alt="">
                                               <!--  <h6 class="mb-0 ms-3">{{ $cart->product->products_name ?? ''}}</h6> -->
                                               </a>
                                            </div>
                                        </td>
                                        <td>
                                        <div class="d-block align-items-center">
                                            <div class="w-100 d-block">
                                              <a href="{{url('product/'.$cart->product->product_slug)}}">
                                                <h6 class="mb-0 ms-3">{{ $cart->product->products_name ?? ''}}</h6>
                                               </a>
                                            </div>

                                               @if (isset($cart->attributes) && !empty($cart->attributes))
                                               <div class="flex-1 text-start ms-3 d-flex">
                                                    @foreach ($cart->attributes as $attribute)
                                                      @if (isset($attribute->product_options))
                                                      <div class="ms-3">
                                                        <h6 class="text-dark mb-0">{{ $attribute->product_options->products_options_name }}</h6>
                                                        <p class="text-muted mb-0">{{ $attribute->products_options_values_name }}</p>
                                                      </div>
                                                        @endif
                                                    @endforeach
                                                </div>     
                                                @endif
                                            </div>
                                        </td>
                                        <td class="text-center">{{ currencyFormat($cart->final_price ?? 0)}}</td>
                                        <td class="text-center qty-icons">
                                            <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" class="btn btn-icon btn-soft-primary minus qtybutton">-</button>
                                            <input min="1" id="{{$cart->cart_id}}_qty" data-cart="{{$cart->cart_id}}" name="qtybutton" value="{{ $cart->qty }}" type="number" class="btn btn-icon btn-soft-primary qty-btn quantity">
                                            <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="btn btn-icon btn-soft-primary plus qtybutton">+</button>
                                        </td>
                                        <td class="text-end fw-bold pe-4"> @php
                                            $qty = (int) $cart->qty;
                                            $price =$cart->final_price ?? 0;
                                            echo currencyFormat($qty*$price); 
                                        @endphp</td>
                                    </tr>
                                    @endforeach                                   
                                @endif
                                </tbody>
                            </table>
                        </div>
                    </div><!--end col-->
                </div><!--end row-->
                <div class="row">
                    <div class="col-lg-8 col-md-6 mt-4 pt-2">
                        <a href="{{url('/')}}" class="btn btn-primary">Shop More</a>
                       <!--  <a href="javascript:void(0)" class="btn btn-soft-primary ms-2">Update Cart</a> -->
                    </div>
                    <div class="col-lg-4 col-md-6 ms-auto mt-4 pt-2">
                        <div class="table-responsive bg-white rounded shadow">
                            <table class="table table-center table-padding mb-0">
                                <tbody>
                                    <tr>
                                        <td class="h6 ps-4 py-3">Subtotal</td>
                                        <td class="text-end fw-bold pe-4">{{ currencyFormat($list['grand_total']) }}</td>
                                    </tr>
                                   <!--  <tr>
                                        <td class="h6 ps-4 py-3">Taxes</td>
                                        <td class="text-end fw-bold pe-4">$ 219</td>
                                    </tr> -->
                                    <tr class="bg-light">
                                        <td class="h6 ps-4 py-3"> GrandTotal</td>
                                        <td class="text-end fw-bold pe-4">{{ currencyFormat($list['grand_total']) }}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="mt-4 pt-2 text-end">
                            <a href="{{ url('checkout') }}" class="btn btn-primary">Proceed to checkout</a>
                        </div>
                    </div><!--end col-->
                </div><!--end row-->
            </div><!--end container-->
            @else
            <img src="{{ LoadAssets('assets/images/EmptyImages/Cart-Empty.jpg')}}" class="rounded mx-auto d-block" width="286px" height="200px" alt="{{getSetting('site_title')}} Cart-Empty">
            <p class="h4 text-center text-dark mt-2">Your cart is empty !</p>
            <div class="text-center my-3">
            <a href="{{url('/')}}" class="btn btn-primary btn-lg btn-block" role="button" aria-pressed="true">Continue to shop </a>
            </div>
            @endif
        </section><!--end section-->
        <!-- End -->