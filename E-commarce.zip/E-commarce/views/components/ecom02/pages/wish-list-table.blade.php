  @php

$main_arr = [
  'title'=>'',
  'sublist' => [
    [
    'name'=>'HOME',
    'link'=>url("/")
    ],
    [
    'name'=>'wishlist' ,
    'link'=>url("")
    ], 
  ]
];
@endphp
  <!-- Hero Start -->
        <section class="bg-half-170 banner_background bg-light d-table w-100">
            <div class="container">
                <div class="row mt-5 justify-content-center">
                    <div class="col-lg-12 text-center">
                        <div class="pages-heading">
                            <h4 class="title mb-0">{{translation('WISHLIST_TITLE')}}</h4>
                        </div>
                    </div><!--end col-->
                </div><!--end row-->
                <x-Ecom02.SharedComponent.BreadCrumb :data="$main_arr" />
        </section><!--end section-->
        <div class="position-relative">
            <div class="shape overflow-hidden text-color-white">
                <svg viewBox="0 0 2880 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M0 48H1437.5H2880V0H2160C1442.5 52 720 0 720 0H0V48Z" fill="currentColor"></path>
                </svg>
            </div>
        </div>
        <!-- Hero End -->

        <!-- Start -->
        <section class="section">
            @if (!empty($wishlist_item) && sizeof($wishlist_item)>0)
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="table-responsive bg-white shadow rounded">
                            @if (!empty($wishlist_item) && sizeof($wishlist_item)>0)
                            <table class="table mb-0 table-center">
                                <thead>
                                    <tr>
                                        <th class="border-bottom py-3" style="min-width:20px "></th>
                                        <th class="border-bottom text-start py-3" style="min-width: 300px;">{{translation('WISHLIST_PRODUCT_IMAGE')}}</th>
                                        <th class="border-bottom text-center py-3" style="min-width: 160px;">{{translation('WISHLIST_PRODUCT_NAME')}}</th>
                                        <th class="border-bottom text-center py-3" style="min-width: 160px;">{{translation('WISHLIST_PRODUCT_SKU')}}</th>
                                        <th class="border-bottom text-end py-3 pe-4" style="min-width: 160px;">{{translation('WISHLIST_UNIT_PRICE')}}</th>
                                        <th class="border-bottom text-end py-3 pe-4">{{translation('WISHLIST_ACTION')}}</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    @foreach ($wishlist_item as $key=>$data )
                                    <tr class="shop-list">
                                        <td class="h6 text-center"><a href="javascript:void(0)" class="text-danger" onclick="actionOnWishlist({{$data->wishlist_id}})"><i class="uil uil-times"></i></a></td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                 <a href="{{url('product/'.$data->product->product_slug)}}"><img src="{{getFullImageUrl($data->product->product_image)}}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="{{ $data->product->products_name ?? ''}}" class="img-fluid avatar avatar-small rounded shadow" style="height:auto;">
                                               <!--  <h6 class="mb-0 ms-3">{{ $data->product->products_name ?? ''}}</h6> -->
                                             </a>
                                            </div>
                                        </td>
                                        <td class="text-center">{{ $data->product->products_name ?? ''}}</td>
                                        <td class="text-center">{{ $data->product->product_sku ?? ''}}</td>
                                        <td class="text-end fw-bold pe-4">{{ currencyFormat($data->product->sale_price ?? 0)}}</td>
                                        <td class="text-center">
                                        <a href="{{url('product/'.$data->product->product_slug)}}">
                                             <i data-feather="eye" class="icons"> view </a> 
                                        </td>
                                    </tr> 
                                    @endforeach  
                                </tbody>
                            </table>
                             @endif
                        </div>
                    </div><!--end col-->
                </div><!--end row-->
            </div><!--end container-->
             @else
                <img src="{{ LoadAssets('assets/images/EmptyImages/Wishlist-Empty.png')}}" class="rounded mx-auto d-block" width="286px" height="200px" alt="{{getSetting('site_title')}} Wishlist-Empty">
                <p class="h4 text-center text-dark mt-3">{{translation('EMPTY_WISHLIST_MSG')}}!</p>
                <div class="text-center my-3">
                <a href="{{url('/')}}" class="btn btn-primary btn-lg btn-block" role="button" aria-pressed="true">{{translation('CONTINUE_TO_SHOP')}}</a>
                </div>
                @endif
        </section><!--end section-->
        <!-- End -->
{{-- Delete Wishlist Ajax --}}