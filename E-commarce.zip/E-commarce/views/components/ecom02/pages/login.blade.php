 <!-- Hero Start -->
        <section class="bg-auth-home bg-circle-gradiant d-table w-100">
            <div class="bg-overlay bg-overlay-white"></div>
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-5 col-md-8"> 
                        <div class="card login-page shadow rounded border-0">
                            <div class="card-body">
                                <h4 class="card-title text-center">{{ translation('LOGIN_TITLE') }}</h4>
                                @include('alertMsg')
                                @error('failed')
                                    <strong class="text-danger" style="margin-top:-50px;">{{ $message }}</strong>
                                @enderror
                                <form class="login-form mt-4 needs-validation" action="{{ route('login') }}" method="post" id="Login_Form" novalidate="novalidate">
                                  @csrf
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="mb-3">
                                                <label class="form-label">{{ translation('EMAIL') }}<span class="text-danger">*</span></label>
                                                <div class="form-icon position-relative">
                                                    <i data-feather="user" class="fea icon-sm icons"></i>
                                                    <input type="email" class="form-control ps-5 @error('email') is-invalid @enderror" name="email" placeholder="{{ translation('EMAIL_PLACEHOLDER') }}" value="{{old('email')}}" required="">
                                                </div>
                                                @error('email')
                                                <strong class="text-danger mb-5">{{ $message }}</strong>
                                                @enderror
                                            </div>
                                        </div><!--end col-->

                                        <div class="col-lg-12">
                                            <div class="mb-3">
                                                <label class="form-label">{{ translation('PASSWORD') }}<span class="text-danger">*</span></label>
                                                <div class="form-icon position-relative">
                                                    <i data-feather="key" class="fea icon-sm icons"></i>
                                                    <input type="password" class="form-control ps-5 @error('password') is-invalid @enderror" name="password" placeholder="{{ translation('PASSWORD_PLACEHOLDER') }}" required="">
                                                </div>
                                                @error('password')
                                                <strong class="text-danger mb-5">{{ $message }}</strong>
                                                @enderror
                                            </div>
                                        </div><!--end col-->

                                        <div class="col-lg-12">
                                            <div class="d-flex justify-content-between">
                                                <div class="mb-3">
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                                        <label class="form-check-label" for="flexCheckDefault">{{ translation('REMEMBER_ME') }}</label>
                                                    </div>
                                                </div>
                                                <p class="forgot-pass mb-0"><a href="{{url('/forgot-password')}}" class="text-dark fw-bold">{{ translation('FORGOT_PASSWORD')}} ?</a></p>
                                            </div>
                                        </div><!--end col-->

                                        <div class="col-lg-12 mb-0">
                                            <div class="d-grid">
                                                <button class="btn btn-primary userLogin">{{ translation('SIGIN_BUTTON') }}</button>
                                            </div>
                                        </div><!--end col-->

                                        <div class="col-12 text-center">
                                            <p class="mb-0 mt-3"><small class="text-dark me-2">{{ translation('DONT_HAVE_ACCOUNT') }}</small> <a href="{{url('/register')}}" class="text-dark fw-bold">{{ translation('SIGN_UP') }}</a></p>
                                        </div><!--end col-->
                                    </div><!--end row-->
                                </form>
                            </div>
                        </div><!---->
                    </div><!--end col-->
                </div><!--end row-->
            </div> <!--end container-->
        </section><!--end section-->
        <!-- Hero End -->
        @push('scripts')

<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
<script>
    $(document).ready(function() {
        $(document).on('click', '.userLogin', function(e) {
             e.preventDefault();
            $('#Login_Form').addClass('was-validated');
            if ($('#Login_Form')[0].checkValidity() === false) {
                event.stopPropagation();
            } 
            else {
                $('#Login_Form').validate({
                    rules: {
                        email: {
                            required: true,
                            email: true,
                            maxlength: 150
                        },
                        password: {
                            minlength: 6,
                            required: true
                        },
                    },
                    messages: {
                        email: {
                                required: "Please enter email",
                                email: "Please enter valid email",
                                maxlength: "Email cannot be more than 150 characters.",
                            },
                            password: {
                                required: "Please enter password",
                                minlength: "Password must be at least 6 characters."
                            },
                        },
                });
                $('#Login_Form').removeClass('was-validated');
                $('#Login_Form').submit();
            }
        });
    });
 
</script>
@endpush