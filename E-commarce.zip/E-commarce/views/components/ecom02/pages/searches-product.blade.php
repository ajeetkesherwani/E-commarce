@php
$main_arr = [
'title'=>$searchQuery ?? 'Shop Products',
'sublist' => [
[
'name'=>'HOME',
'link'=>url("/")
],
[
'name'=>'Search Result',
'link'=>url()->full()
],
]
];
$per_page=substr(url()->full(),-2);
if($per_page==00)
$per_page=substr(url()->full(),-3);
@endphp
        <!-- Breadcrumb Area Start -->
        <x-Ecom02.SharedComponent.BreadCrumb :data="$main_arr" />
        <!-- Breadcrumb Area End -->

    <!-- Start Products -->
    <section class="section">
        @if(!empty($product_count) )
            <div class="container">
                <form id="filterForm" action="{{url("/search/".urlencode($searchQuery))}}" method="get">
                <input type="hidden" name="filter">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-12 mt-5 pt-2 mt-sm-0 pt-sm-0">
                        <div class="row align-items-center">
                            <div class="col-lg-4 col-md-3">
                                <div class="section-title">
                                @if(!empty($product_count))
                                 <h6 class="mb-0">
                                    @php
                                        $item =  $product_count ?? 1 ;
                                        $data  = translation('PAGINATION_TOTAL_ITEM');
                                        printf($data, $item);
                                    @endphp
                                </h6>
                                @endif
                                </div>  
                            </div><!--end col-->
                             <div class="col-lg-1 col-md-1">
                            <h6 class="mb-0">{{translation('ITEM_PER_PAGE')}}:</h6>
                            </div>
                            <div class="col-lg-2 col-md-1">
                             
                                <div class="section-title">
                                        <select class="form-select form-control" aria-label="Default select example" name="perPageItem" onChange="filterItem()">
                                            <option value="20" @if($filtersData['perPageItem']==20) selected @endif>20</option>
                                            <option value="40" @if($filtersData['perPageItem']==40) selected @endif>40</option>
                                            <option value="80" @if($filtersData['perPageItem']==80) selected @endif>80</option>
                                            <option value="200" @if($filtersData['perPageItem']==200) selected @endif>200</option>
                                        </select>
                                </div>
                             
                            </div>
                            <div class="col-lg-4 col-md-5 mt-4 mt-sm-0 pt-2 pt-sm-0">
                                <div class="d-flex justify-content-md-between align-items-center">
                                    <div class="form custom-form">
                                   
                                        <div class="mb-0">
                                            <select name="sortBy" class="form-select form-control"
                                            aria-label="Default select example" id="sortBy" onChange="filterItem()">
                                            <option value="" @if($filtersData['sortBy']==null) selected @endif>{{translation('FILTER')}}</option>
                                            <option value="latest" @if($filtersData['sortBy']=='latest') selected @endif>{{translation('SORT_BY_LATEST')}}</option>
                                            <option value="pricemintohigh" @if($filtersData['sortBy']=='pricemintohigh') selected @endif>{{translation('PRICE_MIN_TO_MAX')}}</option>
                                            <option value="pricehightomin" @if($filtersData['sortBy']=='pricehightomin') selected @endif>{{translation('PRICE_MAX_TO_MIN')}}</option>
                                            <option value="atoz" @if($filtersData['sortBy']=='atoz') selected @endif>{{translation('A_TO_Z')}}</option>
                                            <option value="ztoa" @if($filtersData['sortBy']=='ztoa') selected @endif>{{translation('Z_TO_A')}}</option>
                                            <option value="instock" @if($filtersData['sortBy']=='instock') selected @endif>{{translation('IN_STOCK')}}</option>
                                        </select>
                                        </div>
                                   
                                    </div>
                                    <input type="hidden" name="searchQuery" value="{{$searchQuery}}" id="searchQuery">

                                    <div class="mx-2 progridlist">
                                        <a href="javascript:void(0)" class="h5 text-muted">
                                            <i class="uil uil-apps"></i>
                                            <i class="uil uil-list-ul"></i>
                                        </a> 
                                    </div>
                                </div>
                            </div><!--end col-->
                        </div><!--end row-->

                        <div  id="filterProductData">
                            <div class="row productgrid" id="filterProductData">
                                @if(!empty($products) && sizeof($products)>0)
                                    @foreach($products as $product)
                                    <x-Ecom02.shared-component.product viewtype="grid" :data="$product" />
                                    @endforeach
                                @endif    
                            </div><!--end row-->
                          <!-- List view product start -->
                          <div id="filterProductData" class="row productlist" style="display:none;">
                            @if(!empty($products) && sizeof($products)>0)
                                @foreach($products as $product)
                                <x-Ecom02.shared-component.product viewtype="list" :data="$product" />
                                @endforeach
                            @endif    
                        </div><!--end row-->
                          <!-- List view product end -->
                        </div>

                        <input style="display:none" type="text" name="page" id="page" value="" />
                     

                     <!-- PAGINATION START -->
                     <input type="hidden" id="nextPage" value="1">
                    <div class="col-12 mt-4 pt-2 pro-pagination-style-wrapper">
                      {{ $products->links('vendor.pagination.for-ajax') }}    
                    </div>
                    <!-- PAGINATION END -->

                    </div><!--end col-->
                </div><!--end row-->
                <button type="submit" hidden id="filterFormButton"></button>
                </form>
            </div><!--end container-->
            @else
        <img src="{{ LoadAssets('assets/images/EmptyImages/Cart-Empty.jpg')}}" class="rounded mx-auto d-block" width="286px" height="200px" alt="{{getSetting('site_title')}} Search-Empty">
        <p class="h4 text-center text-dark mt-2">{{ translation('EMPTY_SEARCH_PRODUCT_MSG') }}</p>
        <div class="text-center my-3">
        <a href="{{url('/')}}" class="btn btn-primary btn-lg btn-block" role="button" aria-pressed="true">{{ translation('CONTINUE_TO_SHOP') }}</a>
        </div>
    @endif
</section><!--end section--> 
        <!-- End Products -->
@push('scripts')
<script>
   
    
    function filterItem(){
        $("html").scrollTop(0);
        $('#page').val($('#nextPage').val());
        $("#filterForm").submit();
        }

    $(".progridlist").click(function() {
        $(".productgrid").toggle();
        $(".productlist").toggle();
        });
</script>
@endpush