@php

$main_arr = [
'title'=>'Latest Order',
'sublist' => [
[
'name'=>'HOME',
'link'=>url("/")
],
[
'name'=>'Dashboard',
'link'=>url("/account/dashboard")
],
]
];

$imgurl = url($user_data->profile_photo ?? 'https://cdn.pixabay.com/photo/2020/07/01/12/58/icon-5359553_960_720.png');
@endphp


<!-- Bread cumb start here -->
<x-Ecom02.SharedComponent.BreadCrumb :data="$main_arr" />
<!-- Bread cumb end  here -->
<!-- Start -->
<section class="section">
    <div class="container">
        <div class="row mt-1">
            <!-- left side menubar start here -->
            <x-Ecom02.SharedComponent.left-side-menu />
            <!-- left side menubar end here -->
            <div class="col-md-8 col-12">
                <div class="row">
                    <div class="col-md-3 mt-4 pt-sm-0">
                        <div class="d-flex features feature-primary key-feature align-items-center p-3 rounded shadow mb-4">
                            <!-- <img src="{{LoadAssets('assets/images/job/Codepen.svg')}}" class="avatar avatar-ex-sm" alt=""> -->
                            <div class="flex-1 content ">
                                <h4 class="title mb-0">{{$totalOrder}}</h4>
                                <p class="text-muted mb-0">{{ translation('TOTAL_ORDER')}}</p>
                            </div>
                        </div>
                    </div>
                    <!--end col-->

                    <div class="col-md-3 mt-4  pt-sm-0">
                        <div class="d-flex features feature-primary key-feature align-items-center p-3 rounded shadow mb-4">
                            <!-- <img src="{{LoadAssets('assets/images/job/Codepen.svg')}}" class="avatar avatar-ex-sm" alt=""> -->
                            <div class="flex-1 content ">
                                <h4 class="title mb-0">{{$deliverdOrder}}</h4>
                                <p class="text-muted mb-0">{{ translation('ORDER_DELIVERED')}}</p>
                            </div>
                        </div>
                    </div>
                    <!--end col-->

                    <div class="col-md-3 mt-4  pt-sm-0">
                        <div class="d-flex features feature-primary key-feature align-items-center p-3 rounded shadow mb-4">
                            <!-- <img src="{{LoadAssets('assets/images/job/Codepen.svg')}}" class="avatar avatar-ex-sm" alt=""> -->
                            <div class="flex-1 content ">
                                <h4 class="title mb-0">{{$inprogressOrder}}</h4>
                                <p class="text-muted mb-0">{{ translation('ORDER_PROGRESS') }}</p>
                            </div>
                        </div>
                    </div>
                    <!--end col-->

                    <div class="col-md-3 mt-4 pt-sm-0">
                        <div class="d-flex features feature-primary key-feature align-items-center p-3 rounded shadow mb-4">
                            <!-- <img src="{{LoadAssets('assets/images/job/Codepen.svg')}}" class="avatar avatar-ex-sm" alt=""> -->
                            <div class="flex-1 content ">
                                <h4 class="title mb-0">{{$pendingOrder}}</h4>
                                <p class="text-muted mb-0">{{ translation('ORDER_PENDING') }}</p>
                            </div>
                        </div>
                    </div>
                    <!--end col-->
                </div><!--  end row  -->
                <div class="tab-content" id="pills-tabContent">
                    <div class=" shadow rounded p-3" id="dash" role="tabpanel"
                        aria-labelledby="dashboard">
                        <h6 class="text-muted mb-3">
                            <span class="text-danger">
                                {{ translation('LATEST_ORDER') }}
                            </span>
                        </h6>
                        <div class="table-responsive bg-white rounded border">
                            <table class="table mb-0 table-center table-nowrap">
                                <thead>
                                    <tr>
                                        <th scope="col" class="border-bottom ">{{translation('ORDER_SL_NO')}}</th>
                                        <th scope="col" class="border-bottom">{{ translation('ORDER_NO')}}</th>
                                        <th scope="col" class="border-bottom">{{ translation('ORDER_PAYMENT_TYPE')}}</th>
                                        <th scope="col" class="border-bottom">{{ translation('ORDER_TOTAL_QTY')}}</th>
                                        <th scope="col" class="border-bottom">{{ translation('ORDER_TOTAL_PRICE')}}</th>
                                        <th scope="col" class="border-bottom">{{ translation('ORDER_PAYMENT_STATUS')}}</th>
                                        <th scope="col" class="border-bottom">{{ translation('ORDER_STATUS')}}</th>
                                    </tr>
                                </thead>
                                <tbody> 
                                    @if(!empty($latestOrder) && count($latestOrder)>0)
                                    @foreach ($latestOrder as $key=>$item)
                                    <tr>
                                        <th scope="row" class="text-center">{{$key+1}}</th>
                                        <td class="text-center">{{$item->order_number}}</td>
                                        <td class="text-center">{{$item->payment_type}}</td>
                                        <td class="text-center">{{$item->total_qty}}</td>
                                        <td>{{currencyFormat($item->grand_total)}}</td>
                                        @switch($item->payment_status)
                                            @case(0)
                                                <td class="text-success text-center"><span class="badge badge-pill badge-warning bg-warning">{{ translation('PENDING')}}</span></td>
                                            @break
                                            @case(1)
                                                <td class="text-muted text-center><span class="badge badge-pill badge-success bg-success">{{ translation('ORDER_PAID')}}</span></td>
                                            @break
                                            @default
                                                <td class="text-danger text-center">
                                                    <span class="badge badge-pill badge-danger bg-danger">{{ translation('ORDER_FAILED')}}</span>
                                                </td>
                                            @break
                                        @endswitch

                                        @switch($item->order_status)
                                            @case(1)
                                                <td class="text-success">
                                                    <span class="badge badge-pill badge-warning bg-warning">{{ translation('PENDING')}}</span>
                                                </td>
                                            @break
                                            @case(2)
                                                <td class="text-muted">
                                                    <span class="badge badge-pill badge-info bg-info"> {{ translation('IN_PROGRESS') }}</span>
                                                </td>
                                            @break
                                            @case(3)
                                                <td class="text-success">
                                                    <span class="badge badge-pill badge-primary bg-primary"> {{ translation('DISPATCH')}}</span>
                                                </td>
                                            @break
                                            @default
                                                <td class="text-danger text-center">
                                                    <span class="badge badge-pill badge-danger bg-success"> {{ translation('DELIVERED') }}</span>
                                                </td>
                                            @break
                                        @endswitch
                                    </tr>
                                    @endforeach
                                    @else
                                        <tr>
                                            <td scope="col" class="border-bottom text-center" colspan="7">
                                                {{translation('ORDER_EMPTY_MSG')}}
                                            </td>
                                        </tr>
                                    @endif
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end col-->
    </div>
    <!--end row-->
    </div>
    <!--end container-->
</section>
<!--end section-->
