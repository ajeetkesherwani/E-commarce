@php
$main_arr = [
  'title'=>'Contact-us',
  'sublist' => [
    [
    'name'=>'HOME',
    'link'=>url("/")
    ],
    [
    'name'=>'Contact',
    'link'=>url()->full()
    ], 
  ]
];
@endphp

 <!-- Breadcome Start Here-->
<x-Ecom02.SharedComponent.BreadCrumb :data="$main_arr" /> 
<!-- bre3adcome end here -->
<!-- Shape Start -->
<div class="position-relative">
    <div class="shape overflow-hidden text-color-white">
        <svg viewBox="0 0 2880 48" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 48H1437.5H2880V0H2160C1442.5 52 720 0 720 0H0V48Z" fill="currentColor"></path>
        </svg>
    </div>
</div>
<!--Shape End-->

<!-- Start Contact -->
<section class="section pb-0">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="card border-0 text-center features feature-primary feature-clean">
                    <div class="icons text-center mx-auto">
                        <i class="uil uil-phone d-block rounded h3 mb-0"></i>
                    </div>
                    <div class="content mt-4">
                        <h5 class="fw-bold">{{translation('PHONE')}}</h5>
                        <p class="text-muted">{{getSetting('footer_about_description') ?? ''}}</p>
                        <a href="tel:{{ getSetting('contact_phone')}}" class="read-more">{{ getSetting('contact_phone')}}</a>
                    </div>
                </div>
            </div><!--end col-->
            <div class="col-md-4 mt-4 mt-sm-0 pt-2 pt-sm-0">
                <div class="card border-0 text-center features feature-primary feature-clean">
                    <div class="icons text-center mx-auto">
                        <i class="uil uil-envelope d-block rounded h3 mb-0"></i>
                    </div>
                    <div class="content mt-4">
                        <h5 class="fw-bold">{{translation('EMAIL')}}</h5>
                        <p class="text-muted">{{getSetting('footer_about_description') ?? ''}}</p>
                        <a href="mailto:{{ getSetting('contact_email') }}" class="read-more">{{ getSetting('contact_email')}}</a>
                    </div>
                </div>
            </div><!--end col-->
            
            <div class="col-md-4 mt-4 mt-sm-0 pt-2 pt-sm-0">
                <div class="card border-0 text-center features feature-primary feature-clean">
                    <div class="icons text-center mx-auto">
                        <i class="uil uil-map-marker d-block rounded h3 mb-0"></i>
                    </div>
                    <div class="content mt-4">
                        <h5 class="fw-bold">{{translation('CONTACT_ADDRESS')}}</h5>
                        <p class="text-muted">{{getSetting('contact_address')}} {{getSetting('contact_city')}} {{getSetting('contact_state')}}  {{$countryName->countries_name ?? ''}}</p>
                    </div>
                </div>
            </div><!--end col-->
        </div><!--end row-->
    </div><!--end container-->

    <div class="container mt-100 mt-60">
        <div class="row align-items-center">
            <div class="col-lg-5 col-md-6 pt-2 pt-sm-0 order-2 order-md-1">
                <div class="card shadow rounded border-0">
                    <div class="card-body py-5">
                        <h4 class="card-title">{{translation('CONTACT_TITLE')}}</h4>
                        <div class="custom-form mt-3">
                        <form class="contact-form-style" id="contact-form" novalidate="novalidate">
                            @csrf
                                <p id="error-msg" class="mb-0"></p>
                                <div id="simple-msg"></div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label">{{translation('NAME')}}<span class="text-danger">*</span></label>
                                            <div class="form-icon position-relative">
                                                <i data-feather="user" class="fea icon-sm icons"></i>
                                                <input name="name" id="name" placeholder="{{translation('NAME_PLACEHOLDER')}}" type="text" class="form-control ps-5" required>
                                                <span class="text-danger" id="customers_name" ></span>
                                                @if ($errors->has('name'))
                                                <span class="text-danger">{{ $errors->first('name') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label">{{translation('EMAIL')}}<span class="text-danger">*</span></label>
                                            <div class="form-icon position-relative">
                                                <i data-feather="mail" class="fea icon-sm icons"></i>
                                                <input  name="email"  id="email" placeholder="{{translation('EMAIL_PLACEHOLDER')}}" type="email" class="form-control ps-5" required>
                                                <span class="text-danger" id="email_address" ></span>
                                                @if ($errors->has('email'))
                                                <span class="text-danger">{{ $errors->first('email') }}</span>
                                                @endif
                                            </div>
                                        </div> 
                                    </div><!--end col-->

                                    <div class="col-12">
                                        <div class="mb-3">
                                            <label class="form-label">{{translation('PHONE')}}</label>
                                            <div class="form-icon position-relative">
                                                <i data-feather="book" class="fea icon-sm icons"></i>
                                                <input  name="phone" id="phone" placeholder="{{translation('PHONE_PLACEHOLDER')}}" class="form-control ps-5" required >
                                                <span class="text-danger" id="phone" ></span>
                                                @if ($errors->has('subject'))
                                                <span class="text-danger">{{ $errors->first('subject') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div><!--end col-->

                                    <div class="col-12">
                                        <div class="mb-3">
                                            <label class="form-label">{{translation('MESSAGE')}}<span class="text-danger">*</span></label>
                                            <div class="form-icon position-relative">
                                                <i data-feather="message-circle" class="fea icon-sm icons clearfix"></i>
                                                <textarea name="message"  id="messages" placeholder="{{translation('MESSAGE_PLACEHOLDER')}}" rows="4" class="form-control ps-5"></textarea>
                                                <span class="text-danger" id="message" ></span>
                                                @if ($errors->has('message'))
                                                <span class="text-danger">{{ $errors->first('message') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="d-grid">
                                            <button type="submit" id="contactusbtn" name="send" class="btn btn-primary">{{translation('SUBMIT')}}</button>
                                            <input type="reset" hidden id="configreset" value="Reset">
                                        </div>
                                    </div><!--end col-->
                                </div><!--end row-->
                            </form>
                            {{-- {!!shortCodeToForm('FORM_CONTACT')!!} --}}
                        </div><!--end custom-form-->
                    </div>
                </div>
            </div><!--end col-->

            <div class="col-lg-7 col-md-6 order-1 order-md-2">
                <div class="card border-0">
                    <div class="card-body p-0">
                        <img src="{{ LoadAssets('assets/images/contact.jpg')}}" alt="{{getSetting('site_title')}}-contact" class="img-fluid">
                    </div>
                </div>
            </div><!--end col-->
        </div><!--end row-->
    </div><!--end container-->

    <div class="container-fluid mt-100 mt-60">
        
    </div><!--end container-->
</section><!--end section-->
<!-- End contact -->
@push('scripts')
<script>
    $(document).ready(function(e){
        $(document).on('click', '#contactusbtn', function (e) {
            e.preventDefault();
            $('#contact-form').addClass('was-validated');
            if ($('#contact-form')[0].checkValidity() === false) {
                event.stopPropagation();
            } else {
                var data = {
                    'customers_name': $('#name').val(),
                    'email_address': $('#email').val(),
                    'phone': $('#phone').val(),
                    'message': $('#messages').val(),
                }
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "/contactstore",
                    data: data,
                    dataType: "json",
                    beforeSend: function() {
                    $("#contactusbtn").addClass('disabled');
                        var html = '<i class="fa-solid fa-spinner fa-spin-pulse"></i> {{translation('SUBMITTING')}}...';
                        $("#contactusbtn").html(html);
                    },
                    success: function (response) {
                        if (response.status == 400) {
                            $.each(response.error, function (key, err_val) {
                                $('#' + key).text(err_val);
                            });
                        }
                        else {
                            Notify('{{translation('CONTACT_SUCCESS_MSG')}}', true);
                            $('#contact-form').trigger("reset");
                        }
                    },
                    complete: function(response) {
                        $('#contactusbtn').removeClass('disabled');
                        $('#contact-form').removeClass('was-validated');
                        $('#contactusbtn').html('{{translation('SUBMIT')}}');
                    }
                });
            }
        });
    });
</script>
@endpush
