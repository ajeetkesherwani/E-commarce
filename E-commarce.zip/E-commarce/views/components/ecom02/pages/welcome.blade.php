@php
$home_page_middle_group_1= bannerKey('home_page_middle_banner_1');
$home_page_middle_group_2= bannerKey('home_page_middle_banner_2');
 
// Banner-1
$size1=12;
$count=count($home_page_middle_group_1);
if($count>0)
{
    $size1=$size1/$count;
}
else {
    $size1=12;
}

// Banner-2

$size2=12;
$count=count($home_page_middle_group_2);
if($count>0)
{
    $size2=$size2/$count;
}
else {
    $size2=12;
}

use App\Models\Ecom\Services\EcomService;
$slider_data= bannerKey('home_page_slider','slider');

@endphp

@if(!empty($templateComponentKey))
 @foreach ($templateComponentKey as $templateComponentKey)
    
    @switch($templateComponentKey->component_key)

        @case($templateComponentKey->component_key == config('constkey.home_slider'))

        <!-- Hero Start -->
        @if(!empty($slider_data))
        <section class="home-slider position-relative">
            <div id="carouselExampleInterval" class="carousel slide carousel-fade" data-bs-ride="carousel">
                <div class="carousel-indicators">
                    @foreach($slider_data as $key=>$data)
                    <button type="button" data-bs-target="#carouselExampleInterval" data-bs-slide-to="{{$key}}" class="active" aria-current="true" aria-label="Slide {{$key}}"></button>
                    @endforeach
                </div>
                <div class="carousel-inner">
                        @foreach($slider_data as $key=>$data)
                    <div class="carousel-item {{$key+1==sizeof($slider_data) ? 'active':''}}" data-bs-interval="3000">
                        <div class="bg-home slider-rtl-2 d-flex align-items-center" style="background-image: url({{$data->image ?? $data->banners_title }}) ;">
                            <div class="bg-overlay bg-overlay-white opacity-5"></div>
                        </div>
                     </div>
                    @endforeach
                </div>
            </div>
        </section><!--end section-->
        <!-- Hero End -->
        @endif
        @break
   
        @case($templateComponentKey->component_key == config('constkey.home_banner_1'))
         <!-- Banner Area Start -->
        @if(!empty($home_page_middle_group_1))
        <!-- Features Start -->
        <div class="container-fluid mt-4">
            <div class="row">
                 @if(!empty($home_page_middle_group_1))
                         @foreach($home_page_middle_group_1 as $home_page_middle_group_1_Val)
                <div class="col-lg-{{$size1}} col-md-{{$size1}} col-sm-12 col-xs-12  mt-4 pt-2"> 
                    <div class="card shop-features border-0 rounded overflow-hidden">
                        <a href="{{$home_page_middle_group_1_Val->banners_url}}">
                            <img src="{{$home_page_middle_group_1_Val->image}}"
                            onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                            alt="{{getSetting('site_title')}}-{{$home_page_middle_group_1_Val->banners_title}}" class="img-fluid" style=" height: 213px; width: 426px;" />
                        </a>
                    </div>               
                </div><!--end col-->
                 @endforeach
                   @endif
            </div><!--end row-->
        </div><!--end container-->
         @endif
            <!-- Banner Area End -->
        @break
        <!-- Features End -->
    
      @case($templateComponentKey->component_key == config('constkey.home_banner_2'))
        <!-- Banner Area Start -->
       @if(!empty($home_page_middle_group_2))
       <!-- Features Start -->
       <div class="container-fluid mt-4">
           <div class="row">
                @if(!empty($home_page_middle_group_2))
                        @foreach($home_page_middle_group_2 as $home_page_middle_group_2_Val)
               <div class="col-lg-{{$size2}} col-md-{{$size1}} col-sm-12 col-xs-12  mt-4 pt-2"> 
                   <div class="card shop-features border-0 rounded overflow-hidden">
                       <a href="{{$home_page_middle_group_2_Val->banners_url}}">
                           <img src="{{$home_page_middle_group_2_Val->image}}"
                           onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                           alt="{{getSetting('site_title')}}-{{$home_page_middle_group_2_Val->banners_title}}" class="img-fluid" style=" height: 213px; width: 426px;" />
                       </a>
                   </div>               
               </div><!--end col-->
                @endforeach
                  @endif
           </div><!--end row-->
       </div><!--end container-->
        @endif
           <!-- Banner Area End -->
       @break
        
        <!-- Start popular category-->
        <section class="section">
            
            @case($templateComponentKey->component_key == config('constkey.popular_category'))
                @if (!empty($popular_category) && sizeof($popular_category) > 0 )
            <!-- Start Categories -->
            <div class="container mt-100 mt-60">
                <div class="row">
                    <div class="col-12">
                        <h3 class="mb-0">{{ translation('POPULAR_CATEGORIES') }}</h3>
                        <p class="text-muted">{{ translation('ADD_POPULAR_CATEGORIES_TO_WEEK') }}</p>
                    </div><!--end col-->
                </div><!--end row-->
                <div class="row">
                    @foreach($popular_category as $key=>$value)
                    <div class="col-lg-2 col-md-4 col-6 mt-4 pt-2">
                        <div class="card features feature-primary explore-feature border-0 rounded text-center">
                            <div class="card-body">
                            <a href="{{ EcomService::url($value->categories_id , 'category')}}">
                                <img src="{{getFullImageUrl($value->categories_image)}}"
                                alt="{{$value->category_name ?? ''}}" 
                                onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" class="avatar avatar-small rounded-circle shadow-md"/>
                            </a>           
                                <div class="content mt-3">
                                    <h6 class="mb-0"><a href="{{url('category/'.$value->categories_slug)}}" class="title text-dark">{{$value->category_name ?? 'Test cat'}}</a></h6>
                                </div>
                            </div>
                        </div>
                    </div><!--end col-->
                      @endforeach
                </div><!--end row-->
            </div><!--end container-->
            <!-- Start popular Categories -->
             @endif
            @break
           
            @case($templateComponentKey->component_key == config('constkey.home_brand'))
            <!-- Brand area start -->
            @if(!empty($brand_data))
            <div class="container mt-100 mt-60">
            <div class="row">
            <div class="col-12 mt-4">
                <div class="tiny-brand">
                      @foreach($brand_data as $key=>$data)
                   <a href="{{url('brand/'.$data->brand_slug)}}"> <div class="tiny-slide">
                        <div class="card shop-list border-0 position-relative m-2">
                            <div class="position-relative overflow-hidden">
                            <img src="{{getFullImageUrl($data->brand_icon)}}" 
                                onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                                alt="{{$data->brand_name}}" class="img-fluid" style="height: 115px;" />
                            </div>
                        </div>
                    </div>
                </a>
                    @endforeach
                </div>
            </div><!--end col-->
            </div><!--end row-->
            </div><!--end container-->
             @endif
                <!-- Brand area end -->
        @break

            @case($templateComponentKey->component_key == config('constkey.feature_product'))    
            <!-- featured-group -->
            @if(!empty($featureGroupList))
            
            @foreach($featureGroupList as $featureGroup)
            @if(!empty($featureGroup->featured_product) && sizeof($featureGroup->featured_product) > 0 )
            <!-- Product display start -->
            <div class="container mt-100 mt-60">
                <div class="row">
                    <div class="col-12">
                        <h3 class="mb-0">{{translation($featureGroup->group_name)}}</h3>
                    </div><!--end col-->
                    <div class="col-12 mt-2">
                        <div class="tiny-four-item">
                        @foreach ($featureGroup->featured_product as $featured_product )
                        @if(!empty($featured_product->product))
                        <x-Ecom02.shared-component.product-slider viewtype="grid" :data="$featured_product->product" />
                        @endif
                        @endforeach 
                        </div>
                    </div><!--end col-->
                </div><!--end row-->
            </div><!--end container-->
            @endif
            @endforeach
            @endif 
            @break
            <!-- Product display end -->

            @case($templateComponentKey->component_key == config('constkey.home_testimonial'))
            <!-- Testimonial Area Start -->
            @if(!empty($webTestimonialList))
            <!-- Start testimonials -->

            <div class="container mt-100 mt-60">
                <div class="row justify-content-center">
                    <div class="col-12 text-center">
                        <div class="section-title mb-4 pb-2">
                            <h4 class="title mb-4">Client Testimonials<span class="text-primary"></span></h4>
                            <p class="text-muted para-desc mx-auto mb-0">What our happy customers says !</p>
                        </div>
                    </div><!--end col-->
                </div><!--end row-->

                <div class="row justify-content-center">
                    <div class="col-lg-12 mt-4">
                        <div class="tiny-three-item">
                           @foreach($webTestimonialList as $key=>$data)
                            <div class="tiny-slide">
                                <div class="d-flex client-testi m-1">
                                    <img src="{{ $data->user_data->profile_photo ?? 'https://cdn.pixabay.com/photo/2020/07/01/12/58/icon-5359553_960_720.png' }}"
                                    onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"    
                                    alt="{{getSetting('site_title')}}-User" class="avatar avatar-small client-image rounded shadow"/>
                                    <div class="card flex-1 content p-3 shadow rounded position-relative">
                                        <p class="text-muted mt-2">{{ Str::limit($data->testimonial_text, 120) }}</p>
                                        <h6 class="text-primary">{{ !empty($data->user_data) ?  $data->user_data->first_name : '' }} {{ !empty($data->user_data) ? $data->user_data->last_name : ''}}<small class="text-muted">{{ !empty($data->user_data) ? $data->user_data->email : ''}}</small></h6>
                                    </div>
                                </div>
                            </div>
                           @endforeach
                        </div>
                    </div><!--end col-->
                </div><!--end row-->
            </div><!--end container-->
              @endif
            <!-- Testimonial Area end -->

        @break
        @case($templateComponentKey->component_key == config('constkey.home_blog'))
        <!-- Blog Area Start -->
 
        @if (!empty($blog) && sizeof($blog)>0)
        <div class="container mt-100 mt-60">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <div class="section-title text-center text-md-start">
                            <h3 class="mb-1">All News or Blog Post</h3>
                            <p class="text-muted mb-0 para-desc"> <span class="text-color fw-bold">{{ translation('LATEST_BLOGS') }}</span> {{translation('BLOG_DESCRIPTION') }}</p>
                        </div>
                    </div><!--end col-->
                </div><!--end row-->
                <div class="row">
      
                  @foreach ($blog as $blog)
                    <x-Ecom02.SharedComponent.PostGrid :data="$blog" />        
                  @endforeach
                    <div class="col-12 mt-4 pt-2 pb-4">
                        <div class="text-center">
                            <a href="{{ url('blog') }}" class="btn btn-primary">See More <i data-feather="arrow-right" class="fea icon-sm"></i></a>
                        </div>
                    </div><!--end col-->
               
                </div><!--end row-->
            </div><!--end container-->
            @endif
        <!-- Blog Area End -->
        @break
            <!-- End testimonials -->
        </section><!--end section-->
        <!-- End -->
     @endswitch     
     @endforeach
    @endif
    
        <!-- Footer Start -->
     
        <!-- Footer End -->

