@push('styles')
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;600&display=swap');
body { font-family: 'IBM Plex Sans', sans-serif;

}
.border-top{
border-color: #f4f4f4!important;
}
#orderInvoice{
  font-size:13px!important;
}
</style>
@endpush
<div class="checkout-area mtb-60px">
  <div class="container">
    <div class=" col-lg-12 col-md-12 col-sm-12 col-12 ">
      <div class="content ">
          <div class="container pd-x-0 pd-lg-x-10 pd-xl-x-0">
            <div class="row">
              <div class="col-sm-6">
                  <img src="{{ getImageUrlWithKey('invoice_logo') }}"  onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" style="margin-bottom: .5rem; width:40%" alt="logo_img"> 
              </div><!-- col -->
              @if(!empty(getSetting('invoice_biller_address')))
                <div class="col-sm-6 text-end d-none d-md-block">
                  <p>{{getSetting('invoice_biller_address')}}</p>
                </div><!-- col -->
              @endif
              </div>
              <div class="row mt-5">
              <div class="col-sm-6 col-lg-6">
                <label class="fw-bold">{{translation('INVOICE_TO_ORDER')}}</label>
                <h6 class="tx-15 mg-b-10">{{$orderdetails->address[0]['customer_name'] ?? ''}}</h6>
                <p class="mb-0">{{$orderdetails->address[0]['customer_address'] ?? ''}}, {{$orderdetails->address[0]['customer_city'] ?? ''}} <br>
                  {{$orderdetails->address[1]['customer_state'] ?? ''}}<br>{{$orderdetails->address[1]['customer_country'] ?? ''}}   {{$orderdetails->address[1]['customer_postcode'] ?? ''}}</p>
                <p >Tel: {{$orderdetails->address[0]['customer_phone'] ?? ''}}</p>
              </div><!-- col -->
              <div class="col-sm-6 col-lg-6 ">
                <ul class="list-unstyled ">
                  <li class="d-flex justify-content-between">
                    <span class="fw-bold">{{translation('INVOICE_NUMBER')}} :</span>
                    <span>{{$orderdetails['order_number'] ?? ''}}</span>
                  </li>
                  <li class="d-flex justify-content-between">
                    <span class="fw-bold">{{translation('INVOICE_DATE')}}: </span>
                    <span>{{dateFormate($orderdetails['created_at'])}}</span>
                  </li>
                  @if(getSetting('invoice_show_tax_number')=='1' && !empty(getSetting('invoice_tax_number')))
                  <li class="d-flex justify-content-between">
                    <span class="fw-bold">{{translation('INVOICE_TAX_NUMBER')}} :</span>
                    <span>{{getSetting('invoice_tax_number')}}
                  </span>
                  </li>
                  @endif
                </ul>
              </div><!-- col -->
            </div><!-- row -->
            @if(!empty($orderdetails->item))
            <div class="table-responsive mt-4">
              <table class="table table-invoice mb-2">
                <thead>
                  <tr style="background: #f4f4f4;">
                    <th class="w-50 mw-100 ">{{translation('ITEM')}}</th>
                    <th class="text-center">{{translation('UNIT_PRICE')}}  </th>
                    <th class="text-center">{{translation('QUANTITY')}} </th>
                    <th class="text-center">{{translation('TAX')}} </th>
                    <th class="text-end">{{translation('TOTAL')}}</th>
                  </tr>
                </thead>
                <tbody>
                  @foreach ($orderdetails->item as $key=>$item)
                  <tr>
                    <td class=" tx-color-03">{{$item->product->description[0]['products_name'] ?? ''}}
                        @if(!empty($orderdetails['attrOptArray']))
                        @foreach($orderdetails['attrOptArray'][$item->product->product_id] as $attsubarr)
                        @foreach($attsubarr as $attrkey=>$attrVal)
                            <p>{{$attrkey}} : {{$attrVal}}</p>
                        @endforeach
                        @endforeach
                        @endif
                    </td>
                    <td class="text-center">{{ currencyFormat($item['unit_price']-( $item['tax_amount']/$item['qty'] ) )}}</td>
                    <td class="text-center">{{$item['qty'] ?? ''}}</td>
                    @if(!empty(tax_calculate($item['total_price'],$item['tax_id'])))
                    <td class="text-center"> {{currencyFormat(array_sum(tax_calculate($item['total_price'],$item['tax_id'])[0]))}}</td>
                    @else
                    <td></td>
                    @endif
                    <td class="text-end">{{currencyFormat($item['total_price']) ?? ''}}</td>
                  </tr>
                  @endforeach
                </tbody>
              </table>
            </div>
            @endif
            <div class="row justify-content-between">
              <div class="col-sm-6 col-lg-6"></div><!-- col -->

               <!-- Calculation for exclusive and inclusive tax -->
               @php
                if(getSetting('tax_type')=='inclusive')
                  $subtotal=($orderdetails['sub_total']-$orderdetails['tax_amount']);
                else
                  $subtotal=$orderdetails['sub_total'];
               @endphp

              <div class="col-sm-6 col-lg-5 ">
                <ul class="list-unstyled ">
                  <li class="d-flex justify-content-between px-2 py-1">
                    <span>{{translation('SUBTOTALL_WITHOUT_TAX')}}</span>
                    <span>{{ currencyFormat($subtotal)}}</span>
                  </li>
                       
                  @if($orderdetails['discount_total'] !=0)
                    <li class="d-flex justify-content-between border-top px-2 py-1">
                      <span>{{translation('COUPON_DISCOUNT')}}</span>
                      <span>{{ currencyFormat($orderdetails['discount_total']) ?? ''}}</span>
                    </li>
                  @endif

                  @if($orderdetails['shipping_total'] !=0)
                      <li class="d-flex justify-content-between border-top px-2  py-1">
                        <span>{{translation('SHIPPING_CHARGE')}}</span>
                        <span>{{ currencyFormat($orderdetails['shipping_total']) ?? ''}}</span>
                      </li>
                    @endif

                    @if($orderdetails['tax_amount'] !=0)
                      <li class="d-flex justify-content-between border-top px-2 py-1">
                        <span>{{translation('TAX_AMOUNT')}}</span>
                        <span>{{ currencyFormat($orderdetails['tax_amount']) ?? ''}}</span>
                      </li>
                    @endif

                  <li class="d-flex justify-content-between px-2 py-1" style="background: #f4f4f4;">
                    <strong>{{translation('TOTAL')}} </strong>
                    <strong>{{ currencyFormat($orderdetails['grand_total']) ?? ''}}</strong>
                  </li>
                </ul>
    
              </div><!-- col -->
            </div><!-- row -->
            <div class="row  mt-3">
              <div class="col-sm-6 col-lg-6">
                @if(!empty(getSetting('invoice_bank_account')))
                <label class="fw-bold">{{translation('ITEMS_CONDITION')}}</label>
                <p class="mb-0" >{{getSetting('invoice_term_and_condition')}}</p>
                @endif
              </div><!-- col -->
              @if(getSetting('invoice_show_bank_account')=='1' && !empty(getSetting('invoice_bank_account')))
              <div class="col-sm-6 col-lg-5  offset-md-1">
                  <label class="fw-bold">{{translation('BANK_DETAILS')}}</label>
                  <p >{{getSetting('invoice_bank_account')}}</p>
              </div><!-- col -->
              @endif
            </div>
            <div>
              <div class="term" >
                @if(!empty(getSetting('invoice_note')))
                {{getSetting('invoice_note')}}
                @endif
              </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-lg-4 d-flex">
                @if(!empty(getSetting('email')))
                  <span class="fw-bold">{{translation('EMAIL')}} :</span>
                  {{getSetting('email')}}
                @endif
              </div>
              <div class="col-lg-4 text-lg-center">
                @if(!empty(getSetting('phone')))
                  <span class="fw-bold">{{translation('CALL')}} :</span>
                  {{getSetting('phone')}}
                @endif
              </div>
              <div class="col-lg-4 text-lg-end d-flex">
                @if(!empty(getSetting('application_domain')))
                  <span class="fw-bold">{{translation('WEBSITE')}} :</span>
                  {{getSetting('application_domain')}}
                @endif
              </div>
            </div>
          </div><!-- container -->
        </div>
    </div>
  </div>
</div>