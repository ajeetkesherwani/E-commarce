@php
$main_arr = [
  'title'=>$PageData->pages_title,
  'sublist' => [
    [
    'name'=>'HOME',
    'link'=>url("/")
    ],
    [
    'name'=>$PageData->pages_title,
    'link'=>url()->full()
    ], 
  ]
];
@endphp

<!--  About Area Start -->
        <section class="bg-half-170 banner_background bg-light d-table w-100">
            <div class="container">
                <div class="row mt-5 justify-content-center">
                    <!-- <div class="col-lg-12 text-center">
                        <div class="pages-heading">
                            <h4 class="title mb-0"> About Us </h4>
                        </div>
                    </div> --><!--end col-->
                </div><!--end row-->
                <x-Ecom02.SharedComponent.BreadCrumb :data="$main_arr" /> 
            </div> <!--end container-->
        </section><!--end section-->
        <div class="position-relative">
            <div class="shape overflow-hidden text-color-white">
                <svg viewBox="0 0 2880 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M0 48H1437.5H2880V0H2160C1442.5 52 720 0 720 0H0V48Z" fill="currentColor"></path>
                </svg>
            </div>
        </div>
        <!-- Hero End -->

        <!-- Start -->
        <section class="section">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-9">
                        <div class="section-title text-center">
                            <p class="text-muted mb-0">{!!$PageData->pages_content!!}</p>
                        </div>
                    </div><!--end col-->
                </div><!--end row-->
            </div><!--end container-->
        </section><!--end section-->
        <!-- End -->
<!--  About Area End -->