@php
$order_number = $list->order_number;
@endphp
 <!-- Hero Start -->
<section class="bg-home bg-light d-flex align-items-center mt-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="text-center">
                    {{-- <div class="icon d-flex align-items-center justify-content-center bg-soft-primary rounded-circle mx-auto" style="height: 90px; width:90px;">
                        <i class="uil uil-thumbs-up align-middle h1 mb-0"></i>
                    </div> --}}
                    <h1 class="my-4 fw-bold">{{ translation('ORDER_THANK_YOU_MSG') }}</h1>
                    <h5 class="my-4 fw-bold">{{ translation('ORDER_SUCCESS_MSG') }}</h5>
                        <p>{{translation('ORDER_NUMBER')}}<strong class="font-dark">{{$list->order_number}}</strong></p>
                        <p class=" mb-0">{{ translation('ORDER_SUCCESS_NOTE') }}</p>
                    <p>
                        <a href="mailto:{{getSetting('contact_email')}}">
                            {{getSetting('contact_email')}}</a>
                        {{translation('CALL_US')}} <a href="tel:{{getSetting('contact_phone')}}">
                                {{getSetting('contact_phone')}}</a>
                    </p>
                    <!-- <p class="text-muted para-desc mx-auto">Payment Method : {{ $list->payment_type }} </p>
                    <p class="text-muted para-desc mx-auto">Payment Status : {{ ($list->payment_status == 2) ? 'PAID' : (($list->payment_status == 1) ? 'PENDING' : 'FAILED') }}</p> -->
                    <a href="{{url('/order/'.$list->order_number.'/download-invoice')}}" class="btn btn-soft-primary mt-3">{{ translation('ORDER_DOWNLOAD_INVOICE') }}</a>
                </div>
            </div><!--end col-->
        </div><!--end row-->
    </div> <!--end container-->
</section><!--end section-->
<!-- Hero End -->