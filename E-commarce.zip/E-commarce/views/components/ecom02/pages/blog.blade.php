@php

$main_arr = [
  'title'=>'Blogs',
  'sublist' => [
    [
    'name'=>'HOME',
    'link'=>url("/")
    ],
    [
    'name'=>'Blog' ,
    'link'=>url()->full()
    ], 
  ]
];
@endphp
<!-- Hero Start -->
{{-- <section class="bg-half-170 banner_background bg-light d-table w-100">
    <div class="container">
        <div class="row mt-5 justify-content-center">
            <div class="col-lg-12 text-center">
                <div class="pages-heading">
                    <h4 class="title mb-0"> Blogs & News </h4>
                </div>
            </div><!--end col-->
        </div><!--end row-->
        <x-Ecom02.SharedComponent.BreadCrumb :data="$main_arr" /> 
    </div> <!--end container-->
</section><!--end section--> --}}
        {{-- <div class="position-relative">
            <div class="shape overflow-hidden text-color-white">
                <svg viewBox="0 0 2880 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M0 48H1437.5H2880V0H2160C1442.5 52 720 0 720 0H0V48Z" fill="currentColor"></path>
                </svg>
            </div>
        </div> --}}
        <!-- Hero End -->
     @if(!empty($allBlog) && sizeof($allBlog)>0)
        <!-- Start -->
        <section class="section mt-5">
            <div class="container">
                <div class="row">
                {{-- content start here --}}
                    @foreach($allBlog as $blogKey=>$blogData)
                    <div class="col-lg-4 col-md-6 mb-4 pb-2 d-flex">
                        <div class="card blog blog-primary border-0 shadow rounded overflow-hidden">
                            <div class="position-relative overflow-hidden">
                            <a href="{{url('blog/'.$blogData->slug)}}">
                                <img src="{{getFullImageUrl($blogData->img)}} " alt="{{getSetting('site_title')}} Not-Found" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" class="img-fluid" >
                            </a>
                                <!-- <div class="position-absolute top-0 start-0 mt-2 ms-2">
                                    <a href="javascript:void(0)" class="badge badge-link bg-primary">{{$blogData->post_title ?? ''}}</a>
                                </div> -->
                            </div>
                            <div class="card-body content">
                                <ul class="list-unstyled mb-2">
                                    <li class="list-inline-item text-muted small me-3"><i class="uil uil-calendar-alt text-dark h6 me-1"></i>
                                            @php
                                               echo(date('d F,Y', strtotime($blogData->created_at ?? '')));
                                            @endphp</li>
                                    <!-- <li class="list-inline-item text-muted small"><i class="uil uil-clock text-dark h6 me-1"></i>5 min read</li> -->
                                </ul>
                                <a href="{{url('blog/'.$blogData->slug)}}" class="text-dark title h5">{{$blogData->post_excerpt ?? ''}}</a>
                                
                                <div class="mt-2">
                                    <a href="{{url('blog/'.$blogData->slug)}}">{{translation('READ_MORE')}} <i data-feather="arrow-right" class="fea icon-sm"></i></a>
                                </div>
                            </div>
                        </div>
                    </div><!--end col-->
                    @endforeach
                {{-- endof content --}}

                    <!-- PAGINATION START -->
                    <div class="col-12">
                        <ul class="pagination justify-content-center mb-0">
                        {{ $allBlog->links('vendor.pagination.semantic-ui') }}
                            <!-- <li class="page-item"><a class="page-link" href="javascript:void(0)" aria-label="Previous">Prev</a></li>
                            <li class="page-item active"><a class="page-link" href="javascript:void(0)">1</a></li>
                            <li class="page-item"><a class="page-link" href="javascript:void(0)">2</a></li>
                            <li class="page-item"><a class="page-link" href="javascript:void(0)">3</a></li>
                            <li class="page-item"><a class="page-link" href="javascript:void(0)" aria-label="Next">Next</a></li> -->
                        </ul>
                    </div><!--end col-->
                    <!-- PAGINATION END -->
                </div><!--end row-->
            </div><!--end container-->
        </section><!--end section-->
        <!-- End -->
        @endif
