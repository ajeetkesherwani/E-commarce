@php
$main_arr = [
'title' => $sideFilter['current_brand']->brand_name ?? '',
'sublist' => $breadCumbArr,
];
$ExtSize = '';
$lSize = '';

// Make conditions for div sizes

if (in_array(config('constkey.sidebar_filter'), $cKey) || in_array(config('constkey.sidebar_category'), $cKey)) {
$ExtSize = 'col-lg-12';
$lSize = 'col-md-12';
} else {
$ExtSize = 'col-lg-12';
$lSize = 'col-md-12';
}
// end of div sizes
$per_page=substr(url()->full(),-2);
if($per_page==00)
$per_page=substr(url()->full(),-3);

@endphp
<x-Ecom02.SharedComponent.BreadCrumb :data="$main_arr" />

<div class="position-relative">
    <div class="shape overflow-hidden text-color-white">
        <svg viewBox="0 0 2880 48" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 48H1437.5H2880V0H2160C1442.5 52 720 0 720 0H0V48Z" fill="currentColor"></path>
        </svg>
    </div>
</div>
<!-- Hero End -->

<!-- Start Products -->
<section class="section">
<form id="filterForm" action="{{url("/brand/".urlencode($filtersData['slug']))}}" method="get">
        <input type="hidden" name="filter">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-5 col-md-3">
                <div class="section-title">
                    <h5 class="mb-0">{{translation('THERE_ARE')}} {{ count($products) ?? 1 }} {{translation('ITEMS')}}.
                    </h5>
                </div>
            </div>
            <!--end col-->
            <div class="col-lg-1 col-md-1">
                <h6 class="mb-0">{{translation('ITEM_PER_PAGE')}}:</h6>
            </div>
            <div class="col-lg-2 col-md-1">
                @if(in_array(config('constkey.listing_pagination'), $cKey))
                <div class="section-title">
                    <select class="form-select form-control" aria-label="Default select example" name="perPageItem"
                        onChange="filterItem()">
                        <option value="20" @if($filtersData['perPageItem']==20) selected @endif>20</option>
                        <option value="40" @if($filtersData['perPageItem']==40) selected @endif>40</option>
                        <option value="80" @if($filtersData['perPageItem']==80) selected @endif>80</option>
                        <option value="200" @if($filtersData['perPageItem']==200) selected @endif>200</option>
                    </select>
                </div>
                @endif
            </div>

            <div class="col-lg-3 col-md-5 mt-4 mt-sm-0 pt-2 pt-sm-0">
                <div class="d-flex justify-content-md-between align-items-center">
                    <div class="form custom-form">
                        @if(in_array(config('constkey.sidebar_filter'), $cKey))
                        <div class="mb-0">
                            <select name="sortBy" class="form-select form-control" aria-label="Default select example"
                                id="sortBy" onChange="filterItem()">
                                <option value="" @if($filtersData['sortBy']==null) selected @endif>
                                    {{translation('FILTER')}}</option>
                                <option value="latest" @if($filtersData['sortBy']=='latest' ) selected @endif>
                                    {{translation('SORT_BY_LATEST')}}</option>
                                <option value="pricemintohigh" @if($filtersData['sortBy']=='pricemintohigh' ) selected
                                    @endif>{{translation('PRICE_MIN_TO_MAX')}}</option>
                                <option value="pricehightomin" @if($filtersData['sortBy']=='pricehightomin' ) selected
                                    @endif>{{translation('PRICE_MAX_TO_MIN')}}</option>
                                <option value="atoz" @if($filtersData['sortBy']=='atoz' ) selected @endif>
                                    {{translation('A_TO_Z')}}</option>
                                <option value="ztoa" @if($filtersData['sortBy']=='ztoa' ) selected @endif>
                                    {{translation('Z_TO_A')}}</option>
                                <option value="instock" @if($filtersData['sortBy']=='instock' ) selected @endif>
                                    {{translation('IN_STOCK')}}</option>
                            </select>
                        </div>
                        @endif
                    </div>
                    <input style="display:none" type="hidden" name="brands" value='{{ $sideFilter['current_brand']->brand_id }}' />

                    <div class="mx-2 progridlist">
                        <a href="javascript:void(0)" class="h5 text-muted"><i class="uil uil-apps"></i><i class="uil uil-list-ul"></i></a>
                    </div>
                </div>
            </div>
            <!--end col-->
        </div>
        <!--end row-->
        @if(!empty($products) && sizeof($products)>0)
        <div class="row productgrid" id="filterProductData">
            @if(!empty($products) && sizeof($products)>0)
            @foreach($products as $product)
            <x-Ecom02.shared-component.product viewtype="grid" :data="$product" />
            @endforeach
            @else
            <div class="shop-image position-relative overflow-hidden my-3">
                <img src="{{ LoadAssets('assets/images/EmptyImages/Wishlist-Empty.png')}}"
                    class="rounded mx-auto d-block" width="286px" height="200px"
                    alt="{{getSetting('site_title')}} Wishlist-Empty">
            </div>
            <p class="h4 text-center text-dark mt-3">{{translation('EMPTY_BRAND_PRODUCT_MSG')}}
                </p>
            <div class="text-center my-3">
                <a href="{{url('/')}}" class="btn btn-primary btn-lg btn-block" role="button"
                    aria-pressed="true">{{translation('CONTINUE_TO_SHOP')}}</a>
            </div>
            @endif
        </div>
        <!--end row-->

        <!-- List view product start -->
        <div class="row productlist" id="filterProductData" style="display:none;">
            @if(!empty($products) && sizeof($products)>0)
            @foreach($products as $product)
            <x-Ecom02.shared-component.product viewtype="list" :data="$product" />
            @endforeach
            @else
            <div class="shop-image position-relative overflow-hidden my-3">
                <img src="{{ LoadAssets('assets/images/EmptyImages/Wishlist-Empty.png')}}"
                    class="rounded mx-auto d-block" width="286px" height="200px"
                    alt="{{getSetting('site_title')}} Wishlist-Empty">
            </div>
            <p class="h4 text-center text-dark mt-3">{{translation('EMPTY_BRAND_PRODUCT_MSG')}}
                </p>
            <div class="text-center my-3">
                <a href="{{url('/')}}" class="btn btn-primary btn-lg btn-block" role="button"
                    aria-pressed="true">{{translation('CONTINUE_TO_SHOP')}}</a>
            </div>
            @endif
        </div>
        <!-- List view product end -->

        <input style="display:none" type="text" name="page" id="page" value="" />

           <!-- PAGINATION START -->
           <input type="hidden" id="nextPage" value="1">
           <div class="col-12 mt-4 pt-2 pro-pagination-style-wrapper">
            {{ $products->links('vendor.pagination.for-ajax') }}
           </div>
           <!-- PAGINATION END -->
    </div>

    @else
    <div class="shop-image position-relative overflow-hidden my-3">
        <img src="{{ LoadAssets('assets/images/EmptyImages/Wishlist-Empty.png')}}" class="rounded mx-auto d-block"
            width="286px" height="200px" alt="{{getSetting('site_title')}} Wishlist-Empty">
    </div>
    <p class="h4 text-center text-dark mt-3">{{translation('EMPTY_BRAND_PRODUCT_MSG')}}
        </p>
    <div class="text-center my-3">
        <a href="{{url('/')}}" class="btn btn-primary btn-lg btn-block" role="button" aria-pressed="true">{{translation('CONTINUE_TO_SHOP')}} </a>
    </div>
    @endif
    </div>
    </div>
    <button type="submit" hidden id="filterFormButton"></button>
</form>
</section>

<!-- End Products -->
@push('scripts')
<script>

    function filterItem() {
        $("html").scrollTop(0);
        $('#page').val($('#nextPage').val());
        $("#filterForm").submit();
    }

    $(".progridlist").click(function () {
        $(".productgrid").toggle();
        $(".productlist").toggle();
    });

</script>
@endpush