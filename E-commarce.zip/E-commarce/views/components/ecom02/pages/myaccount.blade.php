@php

$main_arr = [
'title'=>'My Account',
'sublist' => [
[
'name'=>'HOME',
'link'=>url("/")
],
[
'name'=>'My Profile',
'link'=>url("account/profile")
],
]
];

$imgurl = url($user_data->profile_photo ?? 'https://cdn.pixabay.com/photo/2020/07/01/12/58/icon-5359553_960_720.png');
@endphp

<!-- Bread cumb start here -->
 <x-Ecom02.SharedComponent.BreadCrumb :data="$main_arr" />
<!-- Bread cumb end  here -->

<!-- Start -->
<section class="section">
    <div class="container">
        {{-- <div class="row align-items-end">
        <x-Ecom02.SharedComponent.UserImage/>
        </div> --}}
        <!--end row-->
        <div class="row">
            <!-- left side menubar start here -->
            <x-Ecom02.SharedComponent.left-side-menu />
            <!-- left side menubar end here -->
            <div class="col-md-8 col-12 mt-4 pt-2">
                <div class=" shadow rounded p-4" aria-labelledby="account-details">
                    <form class="needs-validation edit_user_form" novalidate>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-4">
                                    <label class="form-label">{{ translation('NAME') }}</label>
                                    <span class="text-danger">*</span>
                                    <div class="form-icon position-relative">
                                        <i data-feather="user" class="fea icon-sm icons"></i>
                                        <input  placeholder="{{translation("NAME_PLACEHOLDER")}}" type="text" class="form-control ps-5" id="name" required value="{{ $userData->first_name ?? '' }}">
                                        <span class="text-danger name"></span>
                                    </div>
                                </div>
                            </div>
                            <!--end col-->
                            <div class="col-md-6">
                                <div class="mb-4">
                                    <label class="form-label">{{ translation('PHONE') }}</label>
                                    <div class="form-icon position-relative">
                                        <i data-feather="user-check" class="fea icon-sm icons"></i>
                                        <input type="text" placeholder="{{translation('PHONE_PLACEHOLDER')}}" class="form-control ps-5" id="contact"  value="{{ $userData->contact ?? '' }}">
                                    </div>
                                </div>
                            </div>
                            <!--end col-->
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">{{translation('EMAIL')}}</label>
                                    <div class="form-icon position-relative">
                                        <i data-feather="mail" class="fea icon-sm icons"></i>
                                        <input name="email" type="email" class="form-control ps-5" id="email" required
                                            value="{{ $userData->email ?? '' }}" readonly>
                                    </div>
                                </div>
                            </div>
                            <!--end col-->
                            {{-- Email Verify Message Work Start--}}

                            @if (!empty($userData->email_verified_at))
                                <div class="col-lg-6 col-md-6">
                                    <div class="verified billing-info">
                                        <input type="hidden" id="user_email"
                                            value="{{ $userData->email }}">
                                        <input type="hidden" id="user_id"
                                            value="{{ $userData->customer_id }}">
                                        <input type="hidden" id="first_name"
                                            value="{{ $userData->first_name }}">
                                        <label class="custom-control-label" for="customControlInline">
                                            {{translation('EMAIL_VERIFY')}}
                                        </label>
                                        <a href="javascript:void(0)" class="btn btn-pills btn-soft-primary ps-2" id="resendEmailbutton">{{translation('EMAIL_VERIFIED_BUTTON')}}</a>
                                    </div>
                                </div>
                            @else
                                <div class="col-lg-6 col-md-6 m-auto">
                                    <div class=" verified billing-info">
                                        <label class="custom-control-label mb-0" for="customControlInline">
                                            <i class="fa fa-check bg-success text-white me-2" aria-hidden="true"></i>{{translation('EMAIL_VERIFIED')}}
                                        </label>
                                    </div>
                                </div>
                            @endif

                        {{-- End of Email Verify Message Work --}}

                            <!--end col-->
                        </div>
                        <!--end row-->
                        <!-- </form> -->

                        <div>
                            <input class="btn btn-primary checkout-toggle2" id="passwordCheckbox" value="1"
                                type="checkbox">
                            <label class="form-check-label" for="passwordCheckbox">
                                {{translation('CHANGE_PASSWORD_BUTTON')}}
                            </label>
                        </div>
                        <!-- <form> -->
                        <div class="row open-toggle2" style="display: none;">
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label class="form-label">{{translation('NEW_PASSWORD')}} </label>
                                    <span class="text-danger">*</span>
                                    <div class="form-icon position-relative">
                                        <i data-feather="key" class="fea icon-sm icons"></i>
                                        <input type="password" class=" ps-5" placeholder="{{translation('NEW_PASSWORD_PLACEHOLDER')}}" name="password" id="password">
                                        <span class="text-danger password"></span>
                                    </div>
                                </div>
                            </div>
                            <!--end col-->

                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label class="form-label">{{translation('CONFIRM_PASSWORDS')}}</label>
                                    <span class="text-danger">*</span>
                                    <div class="form-icon position-relative">
                                        <i data-feather="key" class="fea icon-sm icons"></i>
                                        <input type="password" class="ps-5"
                                            placeholder="{{translation('CONFIRM_PASSWORDS_PLACEHOLDER')}}" name="confirmpassword" id="confirmpassword">
                                        <span class="text-danger password"></span>
                                        <span class="text-danger confirmpassword"></span>
                                    </div>
                                </div>
                            </div>
                            <!--end col-->
                            <span class="text-danger d-none" id="ConfirmPasswordCheck">
                            {{translation('ERROR_PASSWORD_AND_CONFIRM_PASSWORD_MSG')}} 
                            </span>
                        </div>
                        <!--end row-->
                        <div class="col-lg-12 mt-3 mb-0">
                            <button class="btn btn-primary" id="updateprofile">{{ translation('UPDATE_BUTTON') }}</button>
                        </div>
                    </form>
                </div>
                <!--end teb pane-->
            </div>
        </div>
        <!--end col-->
    </div>
    <!--end row-->
    </div>
    <!--end container-->
</section>
<!--end section-->
<!-- End -->

@push('scripts')
<script>

    $('.checkout-toggle2').on('click', function () {
        $('.open-toggle2').slideToggle(1000);
    });

    $(document).ready(function () {
        $(document).on('click', '#updateprofile', function (e) {
            e.preventDefault();
            $('.edit_user_form').addClass('was-validated');
            if ($('.edit_user_form')[0].checkValidity() === false) {
                event.stopPropagation();
            } else {
                if ($("#passwordCheckbox").prop('checked') == true) {
                    $('.edit_user_form').addClass('was-validated');
                    var passwordCheckbox = $('#passwordCheckbox').val();
                    if($('#password').val() == $('#confirmpassword').val()){
                        var passwordCheckbox = $('#passwordCheckbox').val();
                    }else{
                        checkPassword();
                    }
                } else {
                    var passwordCheckbox = 0;
                }
            e.preventDefault();
            var data = {
                'name': $('#name').val(),
                'contact': $('#contact').val(),
                'password': $('#password').val(),
                'confirmpassword': $('#confirmpassword').val(),
                'passwordCheckbox': passwordCheckbox,
            }

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "{{url('account/update-profile')}}",
                data: data,
                dataType: "json",
                success: function (response) {
                    if (response.status == 400) {
                        $.each(response.error, function (key, err_val) {
                            $('.' + key).text(err_val);
                        });
                    } else {
                        Notify('{{translation('PROFILE_UPDATE_MSG')}}', true);
                        $('#passwordCheckbox').prop('checked', false);
                        $('#cpasstoggle').hide(2000);
                        // location.reload();
                    }
                }
            });
            }
        });
    });
            // Resend Verify email

            $(document).on('click', '#resendEmailbutton', function(e) {
                $.ajaxSetup({
                    headers: {
                        "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr(
                            "content"
                        ),
                    },
                });

                var email = $('#user_email').val();
                var customer_id = $('#user_id').val();
                var first_name = $('#first_name').val();
               
                $.ajax({
                    type: "POST",
                    url: "{{ url('resend-email') }}",
                    data: {
                        'email': email,
                        'customer_id': customer_id,
                        'first_name': first_name,
                        
                    },
                    beforeSend: function() {
                            $("#resendEmailbutton").addClass('disabled');
                        },
                    dataType: "json",
                    success: function(response) {
                        if (response.status == 200) {
                            Notify("{{translation('EMAIL_SUCCESS_MSG')}}", true);
                            $("#resendEmailbutton").removeClass('disabled');

                        }
                    },
                    error: function(data) {
                        console.log(data);
                    },
                });
            });
            $("#passwordCheckbox").on("click",function() {
                if ($("#passwordCheckbox").prop('checked') == true){
                    $('#password').addClass('form-control');
                    $('#confirmpassword').addClass('form-control');
                    $('#password').attr('required',' ');
                    $('#confirmpassword').attr('required',' ');
                }
                else
                {
                    $('#password').removeAttr('required');
                    $('#confirmpassword').removeAttr('required'); 
                }
                $(".password-section").toggle(1000);
            });
            function checkPassword(e){
                $('#ConfirmPasswordCheck').removeClass('d-none');
                    e.stopPropagation();
            }
</script>
@endpush