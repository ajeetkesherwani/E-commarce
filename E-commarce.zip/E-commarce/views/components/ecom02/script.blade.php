        <!-- JAVASCRIPT -->
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="{{ LoadAssets('assets/libs/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
        <script src="{{ LoadAssets('assets/libs/feather-icons/feather.min.js') }}"></script>
        <!-- SLIDER -->
        <script src="{{ LoadAssets('assets/libs/tiny-slider/min/tiny-slider.js') }}"></script>
        <!-- Main Js -->
        <script src="{{ LoadAssets('assets/js/plugins.init.js') }}"></script><!--Note: All init js like tiny slider, counter, countdown, maintenance, lightbox, gallery, swiper slider, aos animation etc.-->
        <script src="{{ LoadAssets('assets/js/app.js') }}"></script><!--Note: All important javascript like page loader, menu, sticky menu, menu-toggler, one page menu etc. -->
       <!-- // toastify -->
       <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
       <script>

    function Notify(msg, status) {
        Toastify({
            text: msg,
            className: "info",
            duration: 2000,
            close: true,
            gravity: "bottom", // `top` or `bottom`
            position: "right", // `left`, `center` or `right`
            style: {
                background: status ? "green" : "red",
            }
        }).showToast();

    }

     // Custome form submitted

     $(".customFrom").on('submit',function(e){
         e.preventDefault();
    let formData = $(this).serialize();
   
    /*Ajax Request Header setup*/
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $.ajax({
        url: "{{ route('customFormSubmit')}}",
        method: 'post',
        data: formData,
        success: function(response){
            if(response.status == 0){
                 $.each(response.message, function(i, v) {
                    //$('.result').append(v); 
                    $('#'+i+'-error').html(v);
                });
            } else{
                $('.result').append(response.message);
                Notify('Data send successfully',true);
                $('.customFrom').trigger("reset");
            }
        },

    });

});
</script>

@if(getsetting('newsletter_popup')=='yes')
    @if(empty(Cache::get("loaditem")))
        <script>

            window.onload = function showNewsLatter() {
                $.ajax({
                    url: "/onloadnewslatter",
                    success: function (response) {
                        $(".newsmodal").html(response);
                        $('#onloadModal').modal('show');
                    },
                    error: function (error) {
                    },
                });
            }
        </script>
    @endif
@endif

<script>
        // Attribute to price

    function attributeToprice(page_source='') {
      let detail_choosen_attributes = [];
      attr_id = 0;

      if (page_source=='quickView')
        var ele = $(".modal_input-radio");
      else
        var ele = $(".input-radio");

      $(ele).each(function (i) {
        if (this.checked) {
          if (!detail_choosen_attributes.includes(this.value)) {
            var aVal = this.value.split('_');
            detail_choosen_attributes.push({ options_id: aVal[0], options_values_id: aVal[1] });
          }
        }
      });

      $.ajaxSetup({
        headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
      });

      if (page_source=='quickView')
        {
            var data = {
                'product_id': $('.modal_products_id').val(),
                'OrderdQty' : $('.modal_qtyItemAdd').val(),
                'attribute_array': detail_choosen_attributes,
            }
        }
        else
        {
            var data = {
                'product_id': $('#products_id').val(),
                'OrderdQty' : $('#qtyItemAdd').val(),
                'attribute_array': detail_choosen_attributes,
            }
        }

      $.ajax({
        type: "POST",
        url: "/attribute-price",
        data: data,
        dataType: "json",
        success: function (response) {
          if (response.isdiscount == 'yes') {
            $('.discount_amount').text(response.totalDiscountPrice);
          }
          $(".old-price").text(response.final_price);
        }
      });

    }

    // Onload Document function call

    $(document).ready(function() {
        attributeToprice();
    });


     // Onclick Attributes function call
      $(document).on('click', '.input-radio', function() {
        attributeToprice();
    });

    $(document).on('click', '.modal_input-radio', function() {
        attributeToprice('quickView');
    });

</script>

<script>

    //  Calculate Wholesale Price and Normal Price  on  Qty Start
  
    $(document).on('click', '.qtybutton', function () {
          var page_source=$(this).closest('.qty_buttons').find(".source").val();
          ValidateMinQty(page_source);
      });
  
      function QtyToPrice(page_source) {
          ValidateMinQty(page_source);
      }
  
      //  Calculate Wholesale Price and Normal Price  on  Qty End
  
      //Validate Minimum Qty
      function ValidateMinQty(page_source){
      var min_ord_qty = $('.minordqty').val();
      var qtyItemAdd = $('#qtyItemAdd').val();
  
      var alertHtml = `<div class="alert alert-danger alert-dismissible fade show" role="alert">
                      <strong>Sorry !</strong> Please Add minimum ${min_ord_qty} Qty.
                      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                      </div>`;
      if (min_ord_qty != 'undefined') {
          if (Number(qtyItemAdd) < Number(min_ord_qty)) {
              $('#qtyItemAdd').val(min_ord_qty);
              $('.qty_alert').html(alertHtml);
          }
          else {
              if(qtyItemAdd<1)
              $('#qtyItemAdd').val(1);
              attributeToprice(page_source);
          }
      } 
      else {
          attributeToprice(page_source);
      }
      }
  
</script>

<script>
    function addToCart(product_id, qty = 1, attributes_id = '',product_slug = '', source = '') {
        var url = "https://dev03.e-nnovation.net/images"
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
            url: '{{ route("addUpdateToCart") }}',
            method: 'POST',
            data: {
                qty: qty,
                attributes_id: attributes_id,
                product_id: product_id,
                product_slug: product_slug,
                source: source,
            },
            success: function (response) {
                  $('.count-cart-total').html(response.data.total_count);
                  Notify('Item Added To Cart !', true);
              
                 var html = '';

                $.each(response.data.cartlist, function (i, e) {
                    var salePrice = e.product.sale_price;
                    var quantity = e.qty;
                    var calculate = (salePrice * quantity);
                html += '<div class="pb-4">'
                        +'<a href="javascript:void(0)" class="d-flex align-items-center">'
                        +'<img src="' + e.product.products_main_image + '" class="shadow rounded" style="max-height: 64px;" alt="">'
                        +' <div class="flex-1 text-start ms-3">'
                        +'<h6 class="text-dark mb-0">' + e.product.description[0].products_name + '</h6>'
                        +'<p class="text-muted mb-0">' +   e.product.sale_price + '*' + e.qty +'</p>'
                        +'</div>'
                        +'<h6 class="text-dark mb-0">'+(e.product.sale_price * e.qty)+'</h6>'
                        +'</a>'
                        +'</div>'
                        });

                html +=`<div class="d-flex align-items-center justify-content-between pt-4 border-top">
                        <h6 class="text-dark mb-0">Total :</h6>
                        <h6 class="text-dark mb-0">${response.data.total_amount} </h6>
                        </div>  <div class="mt-3 text-center">
                        <a href="{{ url('cart')}}" class="btn btn-primary me-2">View Cart</a>
                        <a href="{{ url('checkout') }}" class="btn btn-primary">Checkout</a>
                        </div>
                        <p class="text-muted text-start mt-1 mb-0">*T&C Apply</p>`;
                        
                        $('#cart-item-sidebar').html(html);

                },
            error: function (error) {
                Notify("Some Error In Add To Cart", false);
            }
        });

    }

     //Wishlist Ajax start
         
     function addToWishListFromDetail(product_id) {
            $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
            url: '{{ route("addUpdateToWishList") }}',
            method: 'POST',
            data: {
                product_id: product_id,
            },
            success: function (response) {
                $('.count-wishlist-total').text(response.wish_list_item_count);
                $( "#count-wishlist-div" ).load(window.location.href + " #count-wishlist-div" );                             
                var html = '';
                if(response.wish_list_item_count > 0){
                 html += ` <div class="text-center">
                       <div class="icon d-flex align-items-center justify-content-center bg-soft-danger rounded-circle mx-auto" style="height: 95px; width:95px;">
                           <h1 class="mb-0">
                               <i class="uil uil-heart align-middle"></i>
                           </h1>
                       </div>
                       <div class="mt-4">
                           <p class="text-muted t">There are ${response.wish_list_item_count} item avaliable in your wishlist</p>
                           <a href="{{url('wishlist')}}" class="btn btn-outline-primary"> View Wishlist</a>
                       </div>
                   </div>`;
                   var html1 = `<div class="mt-4">
                                <p class="text-muted t wishlist_count">There are ${response.wish_list_item_count} item avaliable in your wishlist</p>
                                <a href="{{url('wishlist')}}" class="btn btn-primary"> View Wishlist</a>
                                </div>`; 
                   $('.wislist_Div').html(html1);
                   $('.wislist_Div').addClass('text-center');
                   var wishlist =`<i class="uil uil-heart align-middle"></i>`;
                    $('.wish_list').html(wishlist);
                }else{
                    html+=`<div class="text-center">
                            <div class="icon d-flex align-items-center justify-content-center bg-soft-danger rounded-circle mx-auto" style="height: 95px; width:95px;">
                                <h1 class="mb-0">
                                    <i class="uil uil-heart-break align-middle"></i>
                                </h1>
                            </div>
                            <div class="mt-4">
                                <h4>Your wishlist is empty.</h4>
                                <p class="text-muted">Create your first wishlist request...</p>
                                <a href="{{url('/')}}" class="btn btn-primary btn-lg btn-block" role="button" aria-pressed="true">Continue to shop </a>
                            </div>
                        </div>`;
                    var wishlist =`<i class="uil uil-heart-break align-middle"></i>`;
                    $('.wish_list').html(wishlist);
                    var html =`<h4>Your wishlist is empty.</h4>
                                <p class="text-muted">Create your first wishlist request...</p>
                                <a href="{{url('/')}}" class="btn btn-primary btn-lg btn-block" role="button" aria-pressed="true">Continue to shop </a>`;
                        $('.wislist_Div').html(html);
                    $('.count-wishlist-total').text(response.wish_list_item_count);
                }
                $('.wishlist-body').html(html);

                Notify('Item Added To WishList !', true);
                $(".ion-android-favorite-outline").addClass('whishlist-active');
            },
            error: function (error) {
                Notify('Please Login to add products in Wishlist!');
            }
        });;
        }

    //End of Wishlist Ajax 

    function showfunction(slug) {
        var Callurl = `{{ url('showproduct')}}/` + slug;
        
        $.ajaxSetup({
            headers: {
                "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
            },
        });

        $.ajax({
            type: "POST",
            url: Callurl,
            data: {
                slug: slug,
            },
            success: function (response) {

                $("#product-detail-modal").html(response);
                $('#productModalShow').modal('show');
                attributeToprice('quickView');
            },
            error: function (error) { },
        });
    }


    let choosen_attributes = [];

    function addToCartFromModalDetail(product_id) {
        let mdl_chosen_attr = [];
        var qtyItemAdd = $('#qtyItemAdd').val();
        var product_slug = $('#productSlug').val();
        var source = $('#source').val();
        let attributes = choosen_attributes.join(',');
        if (attributes == '') {

            $('input[type="radio"]:checked').each(function() {
                if (!mdl_chosen_attr.includes(this.value)) {
                    mdl_chosen_attr.push(this.value);
                }
            });
            let attributes = mdl_chosen_attr.join(',');

            addToCart(product_id, qtyItemAdd, attributes, product_slug, source);
        } else {
            addToCart(product_id, qtyItemAdd, attributes, product_slug, source);
        }
    }

    function chooseModalAttributes(params) {
        if (!choosen_attributes.includes(params.value)) {
            choosen_attributes.push(params.value);
        }
    }

    // Modal Subscriptions

    $(document).ready(function () {
        $(document).on('click', '#modal_subscribe', function (e) {
            e.preventDefault();
            $('#newsltrModalForm').addClass('was-validated');
          if ($('#newsltrModalForm')[0].checkValidity() === false) {
                event.stopPropagation();
          } else {
            var data = {
                'customer_email': $('#customeremail').val(),
            }
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "/newslatterstore",
                data: data,
                dataType: "json",

                beforeSend: function() {
                $("#modal_subscribe").addClass('disabled');
                $("#modal_subscribe").html('{{translation('SUBMITTING')}}...');
                },
                success: function (response) {
                    if (response.status == 400) {
                        $('#email_err').text(response.error.customer_email);
                    }
                    else {
                        $('#onloadModal').modal('hide');
                        Notify("{{translation('SUBSCRIBE_SUCCESS_MSG')}}", true);
                    }
                },
                complete: function() {
                $('#newsltrModalForm').removeClass('was-validated');
                $("#modal_subscribe").removeClass('disabled');
                $("#modal_subscribe").html('{{translation('SUBMIT')}}');
                }
            });
          }
        });  
    });

</script>

<script>
// Wholesale Price tabel carosol
// $(document).ready(function(){
//  $('.qty-carousel').slick({
//    centerMode: true,
//    nav:true,
//    centerPadding: '2px',
//    slidesToShow: 5,
//    responsive: [
//      {
//        breakpoint: 768,
//        settings: {
//          arrows: false,
//          centerMode: true,
//          centerPadding: '60px',
//          slidesToShow: 4
//        }
//      },
//      {
//        breakpoint: 480,
//        settings: {
//          arrows: false,
//          centerMode: true,
//          centerPadding: '40px',
//          slidesToShow: 1
//        }
//      }
//    ]
//  });
//  });
// </script>