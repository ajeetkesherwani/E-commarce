<section class="page_error mx-auto">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 ">
                <div class="col-sm-10 text-center mx-auto">
                    <div class="page_heading">
                        <img src="{{asset('images/404.svg')}}" class="img-fluid" alt="error_img">
                    </div>
                    <div class="contant_box">
                        <h3>
                            Oops! Page not found
                        </h3>
                        <p>Sorry! The page you are looking for does not exist. It might have been moved or deleted.</p>

                        <a href="javascript:history.back()" class="link_error btn">Go Back</a>
                        <a href="{{url('/')}}" class="link_error btn  btn_border">Back to Homepage</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>