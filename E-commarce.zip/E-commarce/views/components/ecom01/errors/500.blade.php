<section class="page_error mx-auto">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 ">
                <div class="col-sm-10 text-center mx-auto">
                    <div class="page_heading">
                        <img src="{{asset('images/500.svg')}}" class="img-fluid" alt="error_img">
                    </div>
                    <div class="contant_box">
                        <h3>
                            Oops! Something went wrong
                        </h3>
                        <p>Server Error 500. We apologise and fixing the problem.
                            
                            Please try again at a later stage.
                        </p>

                        <a href="" class="link_error btn">Go Back</a>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>