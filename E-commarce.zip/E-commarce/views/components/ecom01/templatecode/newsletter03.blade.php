<section class="sign-up-newsletter ">
    <div class="container text-center">
        <div class="row">
            <div class="col-lg-10 col-sm-12 mx-auto">
                <h2>{{translation('NEWSLETTER_TITLE')}}</h2>
                <div class="newsletter-text-up my-3">
                    <p><span>{{translation('NEWSLETTER_SUBTITLE')}}</span></p>
                </div>
                <div class="block ">
                    <div class="content">
                        <form class="col-lg-4 col-sm-12 mx-auto form subscribe position-relative validate needs-validation" action=""
                            method="post" id="newslatterform" novalidate>
                            @csrf
                            <div class="field ">
                                <div class="control">
                                    <label for="newsletter" class="w-100">
                                        <input name="customer_email" required
                                            type="email" id="sign-newsletter" placeholder="{{translation('NEWSLETTER_EMAIL_PLACEHOLDER')}}"
                                            class="ps-3 email form-control">
                                            <p class="text-danger mail_error" style="font-size:16px;"></p>
                                    </label>
                                </div>
                            </div>
                            <div class=" actions">
                                <button class="subscribe-button" id="mc-embedded-subscribe" title="Sign up" type="submit" aria-label="Subscribe"><span>{{translation('SIGN_UP')}}</span></button>
                            </div>
                            <input type="reset" hidden id="configreset" value="Reset">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>