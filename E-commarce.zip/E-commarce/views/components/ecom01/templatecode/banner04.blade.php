@if(!empty($banner_data))
  <section>
    <div class="container-fluid px-0">
        <img src="{{getFullImageUrl($banner_data->banners_image)}}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="{{$banner_data->banners_title}} class="img-fluid" alt="img">
    </div>
  </section>
@endif