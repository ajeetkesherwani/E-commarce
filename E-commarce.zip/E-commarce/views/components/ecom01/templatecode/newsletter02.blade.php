<div id="mc_embed_signup" class="subscribe-form">
<form id="newslatterform" class="validate needs-validation" 
name="mc-embedded-subscribe-form" method="post" novalidate>
@csrf
<div id="mc_embed_signup_scroll" class="mc-form">
    <input class="form-control subscriber_name" type="text" placeholder="{{translation('NAME')}}" name="customer_name" required />
        <p class="text-danger subscriber_name_error" style="font-size:16px;"></p>
    <input class="form-control email" type="email" placeholder="{{translation('NEWSLETTER_EMAIL_PLACEHOLDER')}}" name="customer_email" required />
    <p class="text-danger mail_error" style="font-size:16px;"></p>
    <div class="clear">
        <input id="mc-embedded-subscribe" class="button" type="submit" name="subscribe" value="{{translation('SIGN_UP')}}"/>
        <input type="reset" hidden id="configreset" value="Reset">
    </div>
</div>
</form>
</div>
