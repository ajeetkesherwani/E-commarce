@php
use App\Models\Ecom\Services\EcomService;
use App\Models\WishList;
$wishlistAry = WishList::getProductsAry();
@endphp

@if(!empty($featureGroupList))
    @foreach($featureGroupList as $featureGroup)
        @if(!empty($featureGroup->featured_product) && sizeof($featureGroup->featured_product) > 0 )
            <section class="product-card-category my-md-5 mtb-70px">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <!-- Section Title -->
                            <div class="section-title underline-shape underline-shape-bottom">
                                <h3>{{$featureGroup->group_name}}</h3>
                                <p>{{$featureGroup->group_title}}</p>
                            </div>
                            <!-- Section Title -->
                        </div>
                    </div>
                    
    <!-------------------- Slider View Start------------------------>

                @if($viewType == 'slider')
                    <!-- Best Sell Slider Carousel Start -->
                    <div class="best-sell-slider owl-carousel owl-nav-style-3">
                    @foreach ($featureGroup->featured_product as $featured_product )
                        @if(!empty($featured_product->product))
                            @php
                            $avgrating=AvgRating($featured_product->product->product_id);
                            @endphp
                            <!-- Product Single Item -->
                            <div class="product-card-wrapper">
                                <div class="product">
                                    <div class="product-img position-relative">
                                        <a href="{{ EcomService::url($featured_product->product->product_id , 'product')}}" >
                                            <img  src="{{getFullImageUrl($featured_product->product->product_image)}}"
                                                    onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                                                    alt="{{$featured_product->product->products_name ?? ''}}" class="img-fluid">
                                        </a>
                                        <div class="add-to-link">
                                            <ul>
                                                @if (webFunctionStatus(config('constkey.is_cart_enabled')))
                                                    <li>
                                                        <a href="{{ url('product/'.$featured_product->product->product_slug) }}" title="Add to Cart"><i class="ion-bag"></i></a>
                                                    </li>
                                                @endif

                                                @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))
                                                    <li>
                                                        <a href="javascript:void(0);"
                                                            onclick="addToWishListFromDetail({{ $featured_product->product->product_id }})"
                                                            title="wishlist">
                                                            @if(in_array($featured_product->product->product_id, $wishlistAry))
                                                            <i class="ion-android-favorite-outline whishlist-active"></i>
                                                            @else
                                                            <i class="ion-android-favorite-outline"></i>
                                                            @endif
                                                        </a>
                                                    </li>
                                                @endif

                                                <li>
                                                    <a class="quick_view"
                                                        onclick="showfunction('{{ $featured_product->product->product_slug }}')"
                                                        title="Quick View">
                                                        <i class="ion-ios-search-strong"></i>
                                                    </a>
                                                </li>

                                            </ul>
                                        </div>
                                    </div>

                                    <div class="card-information py-md-3">
                                        <div class="list-product">
                                            <div>
                                                <h2>
                                                    <a href="{{ EcomService::url($featured_product->product->product_id , 'product')}}"
                                                        class="product-link">
                                                        {{ $featured_product->product->products_name ?? '' }}
                                                    </a>
                                                </h2>
                                                <a class="inner-link" href="{{ EcomService::url($featured_product->product->product_id , 'product')}}"><span>{{
                                                    $featured_product->product->product_model ?? '' }}</span>
                                                </a>

                                                <div class="pricing-meta mb-1">
                                                    @if($featured_product->product->products_prices!=null)
                                                    @foreach($featured_product->product->products_prices as $holeprice)
                                                        <ul>
                                                            @if($holeprice->discount_percent !='0')
                                                                <del class="text-danger ms-2">
                                                                    {{currencyFormat($holeprice->max_sale_price) }}
                                                                </del>
                                                            @endif
                                                            <li class=" not-cut">
                                                                {{ currencyFormat($holeprice->sale_price ?? '0.00') }} 
                                                            </li>
                                                            @if($holeprice->discount_percent != '0')
                                                                <span class="discount-price ms-1">
                                                                    {{ currencyFormat( $holeprice->discount_percent )}}% {{translation('PRODUCT_DISCOUNT')}}
                                                                </span>
                                                            @endif
                                                        </ul>
                                                        @break
                                                    @endforeach
                                                    @else
                                                        <ul>
                                                            @if($featured_product->product->discount_type != 'no')
                                                                <del class="text-danger ms-2">
                                                                    {{currencyFormat($featured_product->product->max_sale_price) }}
                                                                </del>
                                                            @endif
                                                            <li class=" not-cut">
                                                                {{ currencyFormat($featured_product->product->sale_price ?? '0.00') }} 
                                                            </li>
                                                            @if($featured_product->product->discount_type != 'no')
                                                                @if($featured_product->product->discount_type == 'flat')
                                                                    <span class="discount-price ms-1">
                                                                        {{ currencyFormat($featured_product->product->discount_amount) }} {{translation('PRODUCT_DISCOUNT')}}
                                                                    </span>
                                                                @else
                                                                    <span class="discount-price ms-1">
                                                                        {{ currencyFormat( $featured_product->product->discount_amount )}}% {{translation('PRODUCT_DISCOUNT')}}
                                                                    </span>
                                                                @endif
                                                            @endif
                                                        </ul>
                                                    @endif
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endif
                    @endforeach
                    </div>
                    <!-- Best Sell Slider Carousel End -->
                @endif
                </div>
            </section>
        @endif
    @endforeach
@endif