@if(!empty($banner_data))
  <section>
    <div class="container-fluid px-0">
        <a href="{{$banner_data->banners_url}}">
             <img src="{{getFullImageUrl($banner_data->banners_image)}}" class="img-fluid" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="{{$banner_data->banners_title}}">
        </a>
      </div>
  </section>
@endif