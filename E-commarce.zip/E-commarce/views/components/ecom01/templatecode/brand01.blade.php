@if (!empty($brand_data))
    <div class="brand-slider owl-carousel owl-nav-style owl-nav-style-2">
        @foreach ($brand_data as $key => $data)
            <div class="brand-slider-item">
                @if (empty($data->brand_slug))
                    {{ brandIDtoSlug($data->brand_id) }}
                @endif
                <a href="{{ url('brand/' . $data->brand_slug ?? '') }}">
                    <img src="{{ getFullImageUrl($data->brand_icon) }}" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" alt="{{ $data->brand_name }}" /></a>
            </div>
        @endforeach
    </div>
@endif
