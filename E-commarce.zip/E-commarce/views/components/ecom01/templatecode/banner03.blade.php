<section>
  <div class="container-fluid px-0">
      <img src="https://e-nnovation.net/design/work/Dev01/landing-page/images/Corporate-Uniforms-Banner.jpg" class="img-fluid" alt="img">
  </div>
</section>