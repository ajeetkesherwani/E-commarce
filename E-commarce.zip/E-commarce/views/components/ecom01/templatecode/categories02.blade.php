<div class="container-fluid my-md-5 my-2">
    <div class="row">
    <ul class="d-md-flex justify-content-between gap-2">
        @if (!empty($popular_category) && sizeof($popular_category) > 0 )
           @foreach($popular_category as $key=>$value)
                
                    <li class="mb-2 position-relative">
                        <a href="{{ App\Models\Ecom\Services\EcomService::url($value->categories_id , 'category')}}">
                            <img src="{{getFullImageUrl($value->categories_image)}}" class="img-fluid" alt="{{$value->category_name ?? ''}}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'">
                                <div class="image-categorie-name">
                                    <h4>{{$value->categories_slug}}</h4>
                                </div>
                            </a>
                        
                    </li>
               
            @endforeach
        @endif
    </ul>
    </div>
</div>
