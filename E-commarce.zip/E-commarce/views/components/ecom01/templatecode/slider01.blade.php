<div class="slider-area">
  <div class="home-slider owl-carousel slider-hm8 owl-dot-style">
      @if(!empty($slider_data))
        @foreach($slider_data->sliderImages as $key=>$data)
            <a href="{{$data->sliders_url}}">
                <div class="slider-height-10 d-flex align-items-start justify-content-start bg-img"
                    style="background-image: url({{getFullImageUrl($data->sliders_image)}});">
                </div>
            </a>
        @endforeach
      @endif
  </div>
</div>