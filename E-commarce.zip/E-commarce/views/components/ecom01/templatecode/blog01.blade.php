@if (!empty($blog_data) && sizeof($blog_data)>0)
    <div class="blog-slider-active owl-carousel owl-nav-style-3">
      @foreach ($blog_data as $blog)
      <article class="blog-post">
        <div class="blog-post-top">
          <div class="blog-img banner-wrapper">
            <a href="{{ url('blog/'.$blog->slug) }}">
              <img src="{{getFullImageUrl($blog->img) ?? LoadAssets('assets/images/blog-image/blog-16.jpg') }} " onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                alt="{{getSetting('site_title')}} Not-Found" />
            </a>
          </div>
        </div>
        <div class="blog-post-content">
          <h4 class="blog-post-heading">
            <a href="{{ url('blog/'.$blog->slug) }}">
              {{ $blog->post_title ?? ''}}
            </a>
          </h4>
          <p class="blog-text">
            {{ $blog->post_excerpt ?? ''}}
          </p>
          <a class="read-more-btn" href="{{ url('blog/'.$blog->slug) }}">
            {{translation('READ_MORE')}}
            <i class="ion-android-arrow-dropright-circle"></i>
          </a>
        </div>
      </article>
      @endforeach
    </div>
@endif