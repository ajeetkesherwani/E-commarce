@if(!empty($banner_data))
                <div class="banner-wrapper banner-box">
                    <a href="{{$banner_data->banners_url}}"><img src="{{getFullImageUrl($banner_data->banners_image)}}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="{{$banner_data->banners_title}}"/></a>
                </div>
@endif