@if (!empty($popular_category) && sizeof($popular_category) > 0 )
<div class="category-slider-2 owl-carousel owl-nav-style-3">
    @foreach($popular_category as $key=>$value)
    <div class="category-item">
        <div class="category-list">
            <div class="category-thumb">
                <a href="{{ App\Models\Ecom\Services\EcomService::url($value->categories_id , 'category')}}">
                    <img src="{{getFullImageUrl($value->categories_image)}}" alt="{{$value->category_name ?? ''}}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" />
                </a>
            </div>
            <div class="desc-listcategoreis">
                <div class="name_categories">
                    <h4>{{$value->category_name ?? 'Test cat'}}</h4>
                </div>
                <a href="{{url('category/'.$value->categories_slug)}}"> {{translation('SHOP_NOW')}} 
                    <i class="ion-android-arrow-dropright-circle d-md-block d-lg-block d-none"></i></a>
            </div>
        </div>
    </div>
    @endforeach
</div>
@endif