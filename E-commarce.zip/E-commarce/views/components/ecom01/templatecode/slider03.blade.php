  <!-- Slider Area Start -->
  <div class="slider-area">
    <div class="owl-carousel slider-home-16 owl-nav-style owl-nav-style-2">

      @if(!empty($slider_data))
         @foreach($slider_data->sliderImages as $key=>$data)
        <!-- Slider Single Item Start -->
        <div class="slider-height-16 d-flex align-items-end justify-content-end bg-img"
            style="background-image: url({{getFullImageUrl($data->sliders_image)}});background-position:center">
        </div>
        <!-- Slider Single Item End -->
        @endforeach
      @endif
    </div>
</div>
<!-- Slider Area End -->