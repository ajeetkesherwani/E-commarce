<!-- Testimonial Area Start -->
@if($testimonial_data->isNotEmpty())
<div class="testi-slider owl-carousel owl-dot-style">
    <!-- Single item -->
    @foreach($testimonial_data as $key=>$data)
    <div class="testi-slider-wrapper">
        <div class="testi-slider-inner">
            <div class="testi-content">
                <div class="testi-content-text">
                    {{$data->testimonial_text}}
                </div>
                <div class="author-text">
                    <h4>{{ !empty($data->user_data) ? $data->user_data->first_name : '' }} 
                    {{ !empty($data->user_data) ? $data->user_data->last_name : ''}}<span>
                    {{!empty($data->user_data) ? $data->user_data->email : ''}}</span></h4>
                </div>
            </div>
        </div>
    </div>
    @endforeach
    <!-- Single item -->
</div>
@endif
<!-- Testimonial Area end -->
