@push('styles')
<style>
  .action_btn {
    padding: 10px 0px;
  }
</style>
@endpush

@php
// dd($orderdetails);
$main_arr = [
'title'=>translation('MY_ORDER'),
'sublist' => [
[
'name'=>translation('HOME'),
'link'=>url("/")
],
[
'name'=>translation('ORDERS'),
'link'=>url()->full()
],
]
];
@endphp

<x-Ecom01.SharedComponent.BreadCrumb :data="$main_arr" />

<!-- Breadcrumb Area End -->
<!-- cart area start -->
<div class="cart-main-area mtb-60px">
  <div class="container">
 
    <div class="row">
      <div class="mx-auto col-lg-3 ">
        {{-- Left Side Menubar Component Start --}}
        <x-Ecom01.SharedComponent.left-side-menu />
        {{--Right Side Menubar Component Start --}}
      </div>
      <div class="col-lg-9 col-md-9 col-sm-12 col-9">
        <form action="#">
          <div class="table-content table-responsive cart-table-content">
            <table style="text-align:center;">
              <thead>
                <tr>
                  <th>{{translation('ORDER_NO')}}</th>
                  <th>{{translation('TOTAL_ORDER')}}</th>
                  <th>{{translation('ORDER_PAYMENT_STATUS')}}</th>
                  <th>{{translation('ORDER_STATUS')}}</th>
                  <th>{{translation('ORDER_ACTION')}}</th>
                </tr>
              </thead>
              <tbody>
                @if(!empty($orderdetails) && count($orderdetails)>0)
                @foreach($orderdetails as $key=>$data)
                <tr>
                  <td class="product-thumbnail"><a href="javascript:void(0);"
                      onclick="showOrderInvoiceModal('{{$data->order_number}}')">{{$data->order_number}}</a></td>
                  <td class="product-price-cart">{{ currencyFormat($data->grand_total)}}</td>

                  @switch($data->payment_status)
                  @case(1)
                  <td><span class="badge badge-pill badge-success bg-success">{{translation('ORDER_PAID')}}</span></td>
                  @break
                  @case(2)
                  <td><span class="badge badge-pill badge-warning bg-warning">{{translation('ORDER_FAILED')}}</span></td>
                  @break
                  @default
                  <td><span class="badge badge-pill badge-danger bg-danger bg-danger">{{translation('PENDING')}}</span>
                  </td>
                  @break
                  @endswitch

                  @switch($data->order_status)
                  @case(2)
                  <td><span class="badge badge-pill badge-success bg-info">{{translation('IN_PROGRESS')}}</span></td>
                  @break
                  @case(3)
                  <td><span class="badge badge-pill badge-warning bg-warning">{{translation('DISPATCH')}}</span></td>
                  @break
                  @case(4)
                  <td><span class="badge badge-pill badge-warning bg-success">{{translation('DELIVERED')}}</span></td>
                  @break
                  @default
                  <td><span class="badge badge-pill badge-danger bg-danger">{{translation('PENDING')}}</span></td>
                  @break
                  @endswitch

                  <td class="product-wishlist-cart action_btn">
                    <a href="javascript:void(0);" onclick="showOrderInvoiceModal('{{$data->order_number}}')"><span
                        class="material-symbols-outlined">{{translation('VISIBILITY')}}</span></a>
                    <a href="{{url('/account/'.$data->order_number.'/download-invoice')}}"><span
                        class="material-symbols-outlined">{{translation('DOWNLOADING')}}</span></a>
                  </td>
                </tr>
                @endforeach
                @else
                <tr>
                  <td class="mx-auto twxt-center">{{translation('ORDER_EMPTY_MSG')}}<td>                
                  </tr>
                @endif
              </tbody>
            </table>
          </div>
        </form>
        {{-- Pagination --}}
        <div class="row">
          <div class="col-md-12 d-flex justify-content-center p-2">
            {!! $orderdetails->links('vendor.pagination.simple-default') !!}
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

{{-- Starting of order invoice modal --}}


<div class="modal fade invoice-pop-up bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
  aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="orderInvoice">
        {{--  --}}
      </div>
    </div>
  </div>
</div>

{{-- order invoice modal area end --}}

@push('scripts')
<script>

  function showOrderInvoiceModal(orderNumber) {

    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      }
    });
    $.ajax({
      type: "POST",
      url: "{{url('account/show-order-invoice')}}",
      data: { order_number: orderNumber },
      dataType: "json",
      success: function (response) {
        $('#orderInvoice').html(response.orderDeatil_html);
        $('.bd-example-modal-lg').modal('show');
      },
      error: function (data) {

      }
    });

  };

  // Jquery for hide modal

  $(".productmodalbtn").click(function () {
    $(".bd-example-modal-lg").modal('hide');
  });

</script>
@endpush