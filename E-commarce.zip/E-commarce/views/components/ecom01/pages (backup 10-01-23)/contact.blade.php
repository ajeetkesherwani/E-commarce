@php

$main_arr = [
  'title'=>translation('CONTACT_US'),
  'sublist' => [
    [
    'name'=>translation('HOME'),
    'link'=>url("/")
    ],
    [
    'name'=>translation('CONTACT'),
    'link'=>url()->full()
    ], 
  ]
];
@endphp

<!-- Breadcrumb Area start -->
<x-Ecom01.SharedComponent.BreadCrumb :data="$main_arr" /> 
<!-- Breadcrumb Area End -->

<!-- contact area start -->
<div class="contact-area mtb-60px">
    <div class="container">
		<div class="custom-row-2 mb-3">
            <div class="col-lg-4 col-md-5">
                <div class="contact-info-wrap">
                    <div class="single-contact-info">
                        <div class="contact-icon">
                            <i class="fa fa-phone"></i>
                        </div>
                        <div class="contact-info-dec">
                            <p>
                                <a href="tel:{{ getSetting('contact_phone')}}" class="link-dark">
                                    {{ getSetting('contact_phone')}}
                                </a>
                            </p>
                        </div>
                    </div>
                    <div class="single-contact-info">
                        <div class="contact-icon">
                            <i class="fa fa-globe"></i>
                        </div>
                        <div class="contact-info-dec">
                            <p><a href="mailto:{{ getSetting('contact_email') }}">{{ getSetting('contact_email')}}</a></p>
                        </div>
                    </div>
                    <div class="single-contact-info">
                        <div class="contact-icon">
                            <i class="fa fa-map-marker"></i>
                        </div>
                        <div class="contact-info-dec">
                            <p>{{getSetting('contact_address')}} {{getSetting('contact_city')}} {{getSetting('contact_state')}}  {{$countryName->countries_name ?? ''}}</p>
                        </div>
                    </div>
                    <div class="contact-social">
                        <h3>{{translation('FOLLOW_US')}}</h3>
                        <div class="social-info">
                            <ul>
                                @if(!empty(socialLinks('facebook_url')))
                                <li>
                                    <a href="{{socialLinks('facebook_url')}}" target="_blank"><i class="ion-social-facebook"></i></a>
                                </li>
                                @endif
                                @if(!empty(socialLinks('twitter_url')))
                                <li>
                                    <a href="{{socialLinks('twitter_url')}}" target="_blank"><i class="ion-social-twitter"></i></a>
                                </li>
                                @endif
                                @if(!empty(socialLinks('youtube_url')))
                                <li>
                                    <a href="{{socialLinks('youtube_url')}}" target="_blank"><i class="ion-social-youtube"></i></a>
                                </li>
                                @endif
                                @if(!empty(socialLinks('google_url')))
                                <li>
                                    <a href="{{socialLinks('google_url')}}" target="_blank"><i class="ion-social-google"></i></a>
                                </li>
                                @endif
                                @if(!empty(socialLinks('instagram_url')))
                                <li>
                                    <a href="{{socialLinks('instagram_url')}}" target="_blank"><i class="ion-social-instagram"></i></a>
                                </li>
                                @endif
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-8 col-md-7">
                <div class="contact-form">
                    <div class="contact-title mb-30">
                        <h2>{{translation('CONTACT_TITLE')}}</h2>
                    </div>
                    <form class="contact-form-style needs-validation" novalidate id="contact-form" action="{{url('/contactstore')}}" method="POST">
                        @csrf
                        <div class="row">
                            <div class="col-lg-6">
                                <input name="name" id="name" class="form-control" placeholder="{{translation('NAME_PLACEHOLDER')}}" type="text" required/>
                                <span class="text-danger" id="customers_name" ></span>
                                @if ($errors->has('name'))
                                <span class="text-danger">{{ $errors->first('name') }}</span>
                                @endif
                            </div>
                            <div class="col-lg-6">
                                <input name="email" class="form-control"  id="email" placeholder="{{translation('EMAIL_PLACEHOLDER')}}" type="email" required/>
                                <span class="text-danger" id="email_address" ></span>
                                @if ($errors->has('email'))
                                <span class="text-danger">{{ $errors->first('email') }}</span>
                                @endif
                            </div>
                            <div class="col-lg-12">
                                <input name="phone" class="form-control" id="phone" placeholder="{{translation('PHONE_PLACEHOLDER')}}" type="text" required/>
                                <span class="text-danger" id="subject" ></span>
                                @if ($errors->has('phone'))
                                <span class="text-danger">{{ $errors->first('Phone') }}</span>
                                @endif
                            </div>
                            <div class="col-lg-12">
                                <textarea name="message" class="form-control" id="messages" placeholder="{{translation('MESSAGE_PLACEHOLDER')}}" required></textarea>
                                <span class="text-danger" id="message" ></span>
                                @if ($errors->has('message'))
                                <span class="text-danger">{{ $errors->first('message') }}</span>
                                @endif
                            </div>
                            <button class="col-lg-4" type="button" id="contactusbtn">{{translation('SUBMIT')}}</button>
                            <input type="reset" hidden id="configreset" value="Reset">
                        </div>
                    </form>

                    {{-- {!!shortCodeToForm('FORM_CONTACT')!!} --}}
                    <!-- <p class="form-messege"></p>-->
                </div>
            </div>
        </div>
		

        
    </div>
</div>

<!-- contact area end -->

@push('scripts')
<script>
    $(document).ready(function () {
        $(document).on('click', '#contactusbtn', function (e) {
            e.preventDefault();
            $('#contact-form').addClass('was-validated');
            if ($('#contact-form')[0].checkValidity() === false) {
                event.stopPropagation();
            } else {
            var data = {
                'customers_name': $('#name').val(),
                'email_address': $('#email').val(),
                'phone': $('#phone').val(),
                'message': $('#messages').val(),
            }
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "/contactstore",
                data: data,
                dataType: "json",
                beforeSend: function() {
                 $("#contactusbtn").addClass('disabled');
                 var html = '<i class="fa-solid fa-spinner fa-spin-pulse"></i> {{translation('SUBMITTING')}}...';
                 $("#contactusbtn").html(html);
                },

                success: function (response) {
                    if (response.status == 400) {
                        $.each(response.error, function (key, err_val) {
                            $('#' + key).text(err_val);
                        });

                    }
                    else {
                        Notify('{{translation('CONTACT_SUCCESS_MSG')}}', true);
                        $('#contact-form').trigger("reset");
                    }
                },
                complete: function(response) {
                        $('#contactusbtn').removeClass('disabled');
                        $('#contact-form').removeClass('was-validated');
                        $('#contactusbtn').html('{{translation('SUBMIT')}}');
                    }

            });
           }
        });
    });
</script>
@endpush