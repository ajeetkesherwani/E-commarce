@php
$main_arr = [
'title' => $sideFilter['cat_details']->category_name ?? '',
'sublist' => $breadCumbArr,
];

$ExtSize = '';
$lSize = '';

// Make conditions for div sizes

if ((in_array(config('constkey.sidebar_filter'), $cKey))) 
{
    $ExtSize = 'col-lg-9';
    $lSize = 'col-md-12';
} 
else {
    $ExtSize = 'col-lg-12';
    $lSize = 'col-md-6';
 }
$per_page=substr(url()->full(),-2);
if($per_page==00)
$per_page=substr(url()->full(),-3);

@endphp

<x-Ecom01.SharedComponent.BreadCrumb :data="$main_arr"/>
<!-- Breadcrumb Area End -->

<!-- Shop Category Area End -->
<div class="shop-category-area">
    <div class="container">
        <form id="filterForm" action="{{url("/category/".urlencode($filtersData['slug']))}}" method="get">
        <input type="hidden" name="filter">
            <div class="row">

                <!-- Left Side Sidebar Filter Start -->
                <div class="col-lg-3 col-md-12  mb-res-md-60px mb-res-sm-60px ">
                    <div class="left-sidebar">

                        <!-- current selected category -->
                        <input style="display:none" type="checkbox" name="category" value='{{ $sideFilter['cat_details']->categories_id }}' checked />
                        <!-- end current category -->
                    
                        @if (in_array(config('constkey.sidebar_category'), $cKey))
                            @if ($sideFilter)
                                <div class="sidebar-heading">
                                    <div class="sidebar-widget  categorie-wrap">
                                        <div class="main-heading">
                                            <h2>{{ translation('PRODUCT_CATEGORIES') }}</h2>
                                        </div>
                                        <div class="sidebar-widget-list">
                                            @if (!$sideFilter['cat_list']->isEmpty())
                                            <ul>
                                                @foreach ($sideFilter['cat_list'] as $key => $cat)
                                                <li>
                                                    <div class="sidebar-widget-list-left">
                                                        <a href="{{ url('category/' . $cat->categories_slug) }}">{{
                                                            $cat->category_name ?? 'No Data' }}
                                                        </a>
                                                    </div>
                                                </li>
                                                @endforeach
                                            </ul>
                                            @else
                                            <ul>
                                                <li>
                                                    @if(!empty($sideFilter['cat_details']))
                                                    <div class="sidebar-widget-list-left">
                                                        <a href="{{ url('category/'.$sideFilter['cat_details']->categories_slug) }}">{{
                                                            $sideFilter['cat_details']->category_name ?? '' }}
                                                        </a>
                                                    </div>
                                                    @endif
                                                </li>
                                            </ul>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            @endif
                        @endif

                        @if (in_array(config('constkey.sidebar_filter'), $cKey) && (sizeof($productAttributes)>0 || sizeof($brandArray)>0))
                            @if (!empty($brandArray) && sizeof($brandArray)>0)
                                <div class="main-heading mt-3">
                                    <h2>{{ translation('PRODUCT_FILTER_BY') }}</h2>
                                </div>
                                <!-- Brand Filter Start -->
                                <div class="sidebar-widget">
                                    <h4 class="pro-sidebar-title">{{ translation('PRODUCT_BRAND') }}</h4>
                                    <div class="sidebar-widget-list">
                                        <ul>
                                            @foreach ($brandArray as $brands)
                                            <li>
                                                <div class="sidebar-widget-list-left">
                                                    <input type="checkbox" name="choosenBrands[]" onClick="filterItem()" value="{{ $brands}}" @if(in_array($brands,$filtersData['brands'])) checked @endif  />
                                                    <a href="#">
                                                        {{ brandIDtoName($brands)}}
                                                    </a>
                                                    <span class="checkmark"></span>
                                                </div>
                                            </li>
                                            @endforeach
                                        </ul>
                                    </div>
                                </div>
                              <!-- Brand Filter End -->
                            @else
                               <div></div>
                            @endif
                    
                            <!-- Attribute Options start-->
                            @if(!empty($productAttributes) && sizeof($productAttributes)>0)
                                @foreach ($productAttributes as $optionName=>$option)
                                    <div class="sidebar-widget mt-30">
                                        <h4 class="pro-sidebar-title"> {{ $optionName ?? '' }}</h4>
                                        <div class="sidebar-widget-list">
                                            @if (!empty($option))
                                            <ul>
                                                @foreach ($option as $optionValue)
                                                <li>
                                                    <div class="sidebar-widget-list-left">
                                                        <input type="checkbox" class="optionChoose"
                                                            name="option_{{$optionName}}_[]" onClick="filterItem()"
                                                            value="{{ $optionValue }}" 
                                                            @if(in_array($optionValue,$filtersData['options'])) checked @endif />
                                                        <a href="#">{{optIdToName($optionValue)}}
                                                        </a>
                                                        <span class="checkmark"></span>
                                                    </div>
                                                </li>
                                                @endforeach
                                            </ul>
                                            @endif
                                        </div>
                                    </div>
                                @endforeach
                            @endif
                            <!-- Attributeb Options End-->
                        @endif
                        <input style="display:none" type="text" name="page" id="page" value="" />
                        <input style="display:none" type="text" name="options" id="options" value="" />
                        <input style="display:none" type="text" name="brands" id="brands" value="" />
                    </div>
                </div>
                <!-- Left Side Filter End -->

                <div class="{{ $ExtSize }}  col-md-12  shop-grid-section">
                     <!-- Right Side Top Filter Start -->
                    <div class="shop-top-bar"> 
                        <div class="shop-tab nav mb-res-sm-15 align-items-center">
                            <a class="active" href="#shop-1" data-bs-toggle="tab">
                                <i class="fa fa-th show_grid"></i>
                            </a>
                            <a href="#shop-2" data-bs-toggle="tab">
                                <i class="fa fa-list-ul"></i>
                            </a>
                            @if (in_array(config('constkey.listing_pagination'), $cKey))
                            <span>
                                @php
                                    $item =  $products->total() ?? 1 ;
                                    $data  = translation('PAGINATION_TOTAL_ITEM');
                                    printf($data, $item);
                                @endphp
                            </span>
                            @endif
                        </div>
                        @if (in_array(config('constkey.listing_pagination'), $cKey))
                            
                           
                            <div class="select-shoing-wrap gap-2">
                                <p>{{ translation('ITEM_PER_PAGE') }}:</p>
                                <select name="perPageItem" class="filter_style" onChange="filterItem()">
                                    <option value="20" @if($filtersData['perPageItem']==20) selected @endif>20</option>
                                    <option value="40" @if($filtersData['perPageItem']==40) selected @endif>40</option>
                                    <option value="80" @if($filtersData['perPageItem']==80) selected @endif>80</option>
                                    <option value="200" @if($filtersData['perPageItem']==200) selected @endif>200</option>
                                </select>
                            </div>
                         @endif
                       
                        @if (in_array(config('constkey.sidebar_filter'), $cKey))
                        <div class="select-shoing-wrap select-shoing-wrap-filter">
                            <div class="shot-product">
                                <p>{{ translation('SORT_BY') }}: </p>
                            </div>
                            <div class="shop-select">
                                <select name="sortBy" class="filter_style" id="sortBy" onChange="filterItem()">
                                    <option value=""
                                        @if($filtersData['sortBy']==null) 
                                            selected 
                                        @endif>
                                            {{ translation('FILTER') }}
                                        </option>
                                    <option value="latest" @if($filtersData['sortBy']=='latest') selected @endif>{{ translation('SORT_BY_LATEST') }}</option>
                                    <option value="pricemintohigh" @if($filtersData['sortBy']=='pricemintohigh') selected @endif>{{ translation('PRICE_MIN_TO_MAX') }}</option>
                                    <option value="pricehightomin" @if($filtersData['sortBy']=='pricehightomin') selected @endif>{{ translation('PRICE_MAX_TO_MIN') }}</option>
                                    <option value="instock"  @if($filtersData['sortBy']=='instock') selected @endif>{{ translation('IN_STOCK') }}</option>
                                </select>
                            </div>
                        </div>
                        @endif
                    </div>
                    <!-- Right Side Top Filter End -->
                    
                     <!-- Product Listing Start -->

                    <div class="shop-bottom-area mt-35" id="filterProductData">
                        <div class="tab-content jump">
                            <!-- Grid View Start -->
                            <div id="shop-1" class="tab-pane active">
                                <div class="row d-flex">
                                    @if (!empty($products) && sizeof($products) > 0)
                                    @foreach ($products as $product)
                                    <div class="col-xl-3 col-md-6 col-lg-4 col-sm-6 col-xs-12 d-flex">
                                        <x-ecom01.shared-component.product viewtype="grid" :data="$product" />
                                    </div>
                                    @endforeach
                                    @else
                                    <img src="{{ LoadAssets('assets/images/EmptyImages/Wishlist-Empty.png') }}"
                                        class="rounded mx-auto d-block" width="286px" height="200px"
                                        onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                                        alt="{{ getSetting('site_title') }} Wishlist-Empty">
                                    <p class="h4 text-center text-dark mt-3">{{ translation('EMPTY_CATEGORY_PRODUCT_MSG') }}
                                        </p>
                                    <div class="text-center my-3">
                                        <a href="{{ url('/') }}" class="btn btn-primary btn-lg btn-block" role="button"
                                            aria-pressed="true">{{ translation('CONTINUE_TO_SHOP') }}</a>
                                    </div>
                                    @endif
                                </div>
                            </div>
                            <!-- Grid View End -->

                            <!-- List View Start -->
                            <div id="shop-2" class="tab-pane">
                                @if (!empty($products) && sizeof($products) > 0)
                                <div class="row">
                                    @foreach ($products as $product)
                                    <div class="col-12 {{ $lSize }}">
                                        <x-ecom01.shared-component.product viewtype="list" :data="$product" />
                                    </div>
                                    @endforeach
                                </div>
                                @else
                                <img src="{{ LoadAssets('assets/images/EmptyImages/Wishlist-Empty.png') }}"
                                    class="rounded mx-auto d-block" width="286px" height="200px"
                                    onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                                    alt="{{ getSetting('site_title') }} Wishlist-Empty">
                                <p class="h4 text-center text-dark mt-3">{{ translation('EMPTY_CATEGORY_PRODUCT_MSG') }} 
                                    </p>
                                <div class="text-center my-3">
                                    <a href="{{ url('/') }}" class="btn btn-primary btn-lg btn-block" role="button"
                                        aria-pressed="true">{{ translation('CONTINUE_TO_SHOP') }}</a>
                                </div>
                                @endif
                            </div>
                            <!-- List View End -->
                        </div>
                  
                        <!--  Pagination Area Start -->
                        @if(isset($products->links))
                            <div class="pro-pagination-style text-center">
                            <input type="hidden" value="1" id="nextPage">
                                <div class="row">
                                    <div class="col-md-12 d-flex justify-content-center p-2">
                                        {{ $products->links('vendor.pagination.for-ajax') }}
                                    </div>
                                </div>
                            </div>
                        @endif
                        <!--  Pagination Area End -->

                        <!-- Category description Start -->
                        @if (!empty($categoryDesc) && sizeof($products) > 0)
                        <div class="row">
                            <div class="col-lg-12 d- p-2">
                                <div class="card">
                                    <div class="card-body">
                                        {!! $categoryDesc->categories_description ?? '' !!}
                                    </div>
                                </div>
                            </div>
                        </div>
                        @endif
                        <!-- Category description End-->

                    </div>
                      <!-- Product Listing End -->
                </div>
            </div>
            <button type="submit" hidden id="filterFormButton"></button>
        </form>
    </div>
</div>


@push('scripts')
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
    //  const optionList = {{ Illuminate\Support\Js:: from($sideFilter['cat_details'] -> options) }};
     const optionList = {{ Illuminate\Support\Js:: from($productAttributes) }};
    function filterItem(currentpage = 0) {
        var count = 0;
        for (const key in optionList) {
            count++;
        }
        $("html").scrollTop(0);
        var ChoosenAttributes = [];
        var brands = [];

        let brandHtml = $('input[name="choosenBrands[]"]:checked');
        if (brandHtml.length > 0) {
            brandHtml.each((label, data) => {
                brands.push(data.value);
            });
        }
        if (count > 0) {
            var i=0;
            for (const key in optionList) {
                let options = [];
                let optionHtml = $(`input[name="option_${key}_[]"]:checked`);
                if (optionHtml.length > 0) {
                    optionHtml.each((label, data) => {
                        options.push(data.value);
                    });
                }
                ChoosenAttributes[i] = options;
                i++;
            }
        }
        console.log( ChoosenAttributes);

        $('#page').val($('#nextPage').val());
        $('#options').val(ChoosenAttributes.toString());
        $('#brands').val(brands.toString());
        $("#filterForm").submit();
    }
</script>
@endpush
