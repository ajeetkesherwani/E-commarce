
@php

$main_arr = [
'title'=>'',
'sublist' => [
[
'name'=>translation('HOME'),
'link'=>url("/")
],
[
'name'=>translation('ADDRESS'),
'link'=>url()->full()
],
]
];
@endphp

<x-Ecom01.SharedComponent.BreadCrumb :data="$main_arr" />
<!-- section area start -->
<div class="checkout-area mtb-60px">
    <div class="container">
        <div class="row">
            <div class="mx-auto col-lg-3 ">
                <x-Ecom01.SharedComponent.left-side-menu /> <!-- left menu -->
            </div>
            <div class="mx-auto col-lg-9">
                <div class="checkout-wrapper">
                    <div id="faq" class="panel-group">
                        <div class="panel panel-default single-my-account">
                            <div class="panel-heading my-account-title">
                                <h3 class="panel-title">{{translation('ADDRESS_TITLE')}}</h3>
                            </div>
                            <div id="" class="">
                                <div class="panel-body">
                                    <div class="myaccount-info-wrapper">
                                        <div class="entries-wrapper">
                                            <div class="row d-flex CustomerAddress">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<span class="text-danger errorlist"></span>
{{-- Starting All Modal --}}


<!-- Add Address Modal -->
<div class="modal" id="myModal">
    <div class="modal-dialog" style="max-width: 40% !important;">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header">
                <h6 class="modal-title">{{translation('ADD_ADDRESS')}}</h6>
                <button type="button" class="btn-close " data-bs-dismiss="modal"></button>
            </div>

            <!-- Modal body -->
            <div class="modal-body p-3">
                <form class="needs-validation" novalidate id="custAddAddress">
                    <div class="row">

                        <div class="form-group col-md-12 ">
                            <input type="text" class="form-control form-input" id="addcustname"
                                placeholder="{{translation('NAME_PLACEHOLDER')}}" required>
                            <span class="text-danger add_customer_name"></span>
                        </div>

                        <div class="form-group col-md-12 ">
                            <input type="email" class="form-control form-input" id="addcustemail"
                                placeholder="{{translation('EMAIL_PLACEHOLDER')}}" required>
                            <span class="text-danger add_customer_email"></span>
                        </div>

                        <div class="form-group col-md-12 ">
                            <input type="text" class="form-control form-input" id="addsstreet"
                                placeholder="{{translation('STREET_ADDRESS_PLACEHOLDER')}}" required>
                            <span class="text-danger add_street_address"></span>
                        </div>
                        
                        <div class="form-group col-md-12">
                            <input type="text" class="form-control form-input" id="addscity"
                                placeholder="{{translation('CITY_PLACEHOLDER')}}" required>
                            <span class="text-danger add_city"></span>
                        </div>
                        <div class="form-group col-md-12">
                            <input type="text" class="form-control form-input" id="addsstate"
                                placeholder="{{translation('STATE_PLACEHOLDER')}}" required>
                            <span class="text-danger add_state"></span>
                        </div>
                        <div class="form-group col-md-12">
                            <input type="text" class="form-control form-input" id="addszipcode"
                                placeholder="{{translation('ZIPCODE_PLACEHOLDER')}}" required>
                            <span class="text-danger add_zipcode"></span>
                        </div>
                        <div class="form-group col-md-12">
                            @if(!empty($countriesdata))
                            <select class="form-control form-input" id="addscountry"
                                aria-label="Default select example" required> 
                                <option selected disabled value="">{{translation('COUNTRY_PLACEHOLDER')}}</option>
                                @foreach($countriesdata as $key=>$data)
                                <option value="{{$data->countries_id}}">{{$data->countries_name}}</option>
                                @endforeach
                            </select>
                            @endif
                        </div>
                        <div class="form-group col-md-12">
                            <input type="text" class="form-control form-input" id="addsphone"
                                placeholder="{{translation('PHONE_PLACEHOLDER')}}" required>
                            <span class="text-danger add_phone"></span>
                        </div>
                        <div class="form-group col-md-12">
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary"
                                    id="addressformbutton">{{translation('SUBMIT')}}</button>
                                <input type="reset" hidden>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

{{-- Update Address Modal --}}
<div class="modal" id="updateAddressModal">
    <div class="modal-dialog" style="max-width: 40% !important;">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header">
                <h6 class="modal-title">{{translation('UPDATED_ADDRESS')}}</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <!-- Modal body -->
            <div class="modal-body p-3">
                <form id="custUpdateAddress" class="needs-validation" novalidate>
                    <div class="row">
                        <input type="hidden" id="address_id">
                        
                        <div class="form-group col-md-12">
                            <label for="inputEmail4">{{translation('NAME')}}</label>
                            <input type="text" class="form-control" id="customer_name" placeholder="{{translation('NAME_PLACEHOLDER')}}" required>
                            <span class="text-danger addup_customer_name"></span>
                        </div>

                        <div class="form-group col-md-12">
                            <label for="inputEmail4">{{translation('EMAIL')}}</label>
                            <input type="text" class="form-control" id="customer_email" placeholder="{{translation('EMAIL_PLACEHOLDER')}}" required>
                            <span class="text-danger addup_customer_email"></span>
                        </div>

                        <div class="form-group col-md-12">
                            <label for="inputEmail4">{{translation('STREET_ADDRESS')}}</label>
                            <input type="text" class="form-control" id="street_address" placeholder="{{translation('STREET_ADDRESS_PLACEHOLDER')}}" required>
                            <span class="text-danger addup_street_address"></span>
                        </div>
                        <div class="form-group col-md-12">
                            <label for="inputPassword4">{{translation('CITY')}}</label>
                            <input type="text" class="form-control" id="city" placeholder="{{translation('CITY_PLACEHOLDER')}}" required>
                            <span class="text-danger addup_city"></span>
                        </div>
                        <div class="form-group col-md-12">
                            <label for="inputEmail4">{{translation('STATE')}}</label>
                            <input type="text" class="form-control" id="state" placeholder="{{translation('STATE_PLACEHOLDER')}}" required>
                            <span class="text-danger addup_state"></span>
                        </div>
                        <div class="form-group col-md-12">
                            <label for="inputPassword4">{{translation('ZIPCODE')}}</label>
                            <input type="text" class="form-control" id="zipcode" placeholder="{{translation('ZIPCODE_PLACEHOLDER')}}" required>
                            <span class="text-danger addup_zipcode"></span>
                        </div>
                        @if(!empty($countriesdata))
                        <div class="form-group col-md-12">
                            <label for="countries_id">{{translation('COUNTRY')}}</label>
                            <select class="form-input form-control" id="countries_id" required aria-label="Default select example" >
                                <option selected disabled value="" >{{translation('COUNTRY_PLACEHOLDER')}}</option>
                                @foreach($countriesdata as $key=>$data)
                                <option value="{{$data->countries_id}}" class="updcountry">{{$data->countries_name}}
                                </option>
                                @endforeach
                            </select>
                        </div>
                        @endif
                        <div class="form-group col-md-12">
                            <label for="inputPassword4">{{translation('PHONE')}}</label>
                            <input type="text" class="form-control" id="phone" placeholder="{{translation('PHONE_PLACEHOLDER')}}" required>
                            <span class="text-danger addup_phone"></span>
                        </div>
                        <div class="form-group col-md-12 mt-2">
                            <button type="submit" class="btn btn-primary"
                                id="updateAddressButton">{{translation('SUBMIT')}}</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="DeleteAddressModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header justify-space-between">
                <h5 class="modal-title" id="exampleModalLabel">{{translation('DELETE_ADDRESS')}}</h5>
                <button type="button" class="close modal-close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="delete_add_id">
                <h4 class="p-2">{{translation('DELETE_ADDRESS_CONFIRM')}}?</h4>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary modal-close" data-dismiss="modal">{{translation('CLOSE_BUTTON')}}</button>
                <button type="button" class="btn btn-primary delete_add_cnf ">{{translation('DELETE_CONFIRMATION_BUTTON')}}</button>
            </div>
        </div>
    </div>
</div>

{{-- end modal --}}

<!-- script push to footer -->
@push('styles')
<style>
    .form-input {
        margin: 10px 0px;
    }
</style>
@endpush

@push('scripts')
<script>

    function loadaddresss() {
        $.ajax({
            url: "{{url('account/show-address')}}",
            type: "GET",
            dataType: 'json',
            success: function (response) {
                var addressHtml = `<div class="col-lg-6  col-md-6">
                    <div class="d-flex align-items-center justify-content-center pointer border-dot mr-6"  data-bs-toggle="modal" data-bs-target="#myModal">                   
                                    <div class=" mt-3">
                                            <span type="button" class="material-symbols-outlined icon-dash symbol-pd">
                                                add
                                            </span>
                                        </div>   
                                        </div>                                            
                                    </div>`;

                $.each(response.address, function (key, value) {
                    var is_default = value.is_default;
                    checked = '';
                    if (is_default === 1) checked = "checked";

                    addressHtml += `<div class="col-lg-6 col-md-6  align-items-center ">
                        <div class="entries-info border m-1">
                            <p>${value.customer_name}</p>
                            <p>${value.customer_email}</p>
                            <p>${value.street_address}</p>
                            <p>${value.city}</p>
                            <p>${value.state} , ${value.zipcode}</p>
                            <p>${value.country_name}</p>
                            <p>${value.phone}</p>
                            <div class="entries-edit-delete  d-flex flex-row justify-content-between align-items-center py-2 flex-grow-1">
                            <div class="">
                             <form action="/action_page.php">
                               <div class="form-check form-switch">
                                 <input class="form-check-input mySwitch" type="checkbox" id="mySwitch"  name="darkmode" value="${value.address_id}" ${checked}>
                                 <label class="form-check-label" for="mySwitch">{{translation('DEFAULT')}}</label>
                               </div>
                             </form>
                            </div>    
                            <div>
                                <a href="javascript:void(0);" class="edit edit_address" value="${value.address_id}">{{translation('EDIT_BUTTON')}}</a> <a href="javascript:void(0);" class="delete_address" value="${value.address_id}">{{translation('DELETE_BUTTON')}}</a>
                            </div>
                            </div>
                            </div>
                            </div>`;
                   });

                $('.CustomerAddress').html(addressHtml);
            }
        });
    }

    // load all address through ajax
    loadaddresss();


    $(document).ready(function () {

        // add function  ajax
        $(document).on('click', '#addressformbutton', function (e) {
            e.preventDefault();
            $('#custAddAddress').addClass('was-validated');
            if ($('#custAddAddress')[0].checkValidity() === false) {
                event.stopPropagation();
            } else {
            var data = {
                'customer_name': $('#addcustname').val(),
                'customer_email': $('#addcustemail').val(),
                'street_address': $('#addsstreet').val(),
                'city': $('#addscity').val(),
                'state': $('#addsstate').val(),
                'zipcode': $('#addszipcode').val(),
                'countries_id': $('#addscountry').val(),
                'phone': $('#addsphone').val(),
            }
            //console.log(data);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "{{url('account/add-address')}}",
                data: data,
                dataType: "json",
                success: function (response) {
                    if (response.status == 400) {
                        $.each(response.error, function (key, err_val) {
                            $('.add_' + key).text(err_val);
                        });
                    } else {
                        $('#custAddAddress').removeClass('was-validated');
                        $('#myModal').modal('hide');
                        $('#custAddAddress').trigger("reset");
                        Notify('{{translation('SUCCESSFULLY_SEND')}}!', true);
                        loadaddresss();
                    }
                }
            });
          }
        });


        //delete modal
        $(document).on("click", ".delete_address", function (e) {
            e.preventDefault();
            var addId = $(this).attr('value');
            $('#delete_add_id').val(addId);
            $('#DeleteAddressModal').modal('show');
        });

        // final delete
        $(document).on("click", ".delete_add_cnf", function (e) {
            e.preventDefault();
            var address_id = $('#delete_add_id').val();
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url: "{{ url('account/delete-address/') }}",
                type: "POST",
                data: {
                    address_id: address_id
                },
                success: function (response) {
                    console.log(response);
                    $('#DeleteAddressModal').modal('hide');
                    Notify('{{translation('DELETE_SUCCESS_MSG')}}!', true);
                    loadaddresss();
                }
            });
        });

        //Edit Address

        $(document).on("click", ".edit_address", function (e) {
            e.preventDefault();
            var addrsId = $(this).attr('value');;
            $('#updateAddressModal').modal('show');
            var url = `{{url('account/address/${addrsId}/edit')}}`;

            $.ajax({
                url: url,
                type: "GET",
                success: function (response) {
                    if (response.status == 400) {
                        $('#errorlist').html("");
                        $('#errorlist').addClass("alert alert-danger");
                        $('#errorlist').append('<p>' + response.message + '</p>');
                    }
                    else {
                        $.each(response.addressdata, function (key, adds_val) {
                            $('#' + key).val(adds_val);

                        });
                    }
                }
            });

        });


        //update Address

        $(document).on("click", "#updateAddressButton", function (e) {
            e.preventDefault();
            $('#custUpdateAddress').addClass('was-validated');
            if ($('#custUpdateAddress')[0].checkValidity() === false) {
                event.stopPropagation();
            } else {
            var data = {
                'customer_name': $('#customer_name').val(),
                'customer_email': $('#customer_email').val(),
                'street_address': $('#street_address').val(),
                'city': $('#city').val(),
                'state': $('#state').val(),
                'zipcode': $('#zipcode').val(),
                'countries_id': $('#countries_id').val(),
                'phone': $('#phone').val(),
                'address_id': $("#address_id").val(),
            }
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "{{url('account/update-address')}}",
                data: data,
                dataType: "json",
                success: function (response) {
                    console.log(response);
                    if (response.status == 400) {
                        $.each(response.error, function (key, err_val) {
                            $('.addup_' + key).text(err_val);
                        });
                    }
                    else {
                        $('#custUpdateAddress').removeClass('was-validated');
                        $('#updateAddressModal').modal('hide');
                        Notify('{{translation('ADDRESS_UPDATE_SUCCESS_MSG')}}!', true);
                        loadaddresss();
                    }

                }
            });
           }
        });

        // Make default address 

        var switchStatus = false;
        $(document).on('click', '.mySwitch', function () {
            if ($(this).is(':checked')) {
                var data = { 'address_id': $(this).val(), }
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{url('account/makedefault-address')}}",
                    data: data,
                    dataType: "json",
                    success: function (response) {
                        console.log(response);
                        if (response.status == 400) {
                            Notify('Some thing error !', false);
                            loadaddresss();
                        }
                        else {
                            Notify('{{translation('DEFAULT_ADDRESS_SUCCESS_MSG')}}!', true);
                            loadaddresss();
                        }

                    }
                });
            }
        });

        $(document).on('click', '.modal-close', function (e) {
            $('#DeleteAddressModal').modal('hide');
        });

    });
</script>
@endpush