@php
$main_arr = [
    'title' => translation('MY_ACCOUNT'),
    'sublist' => [
        [
            'name' => translation('HOME'),
            'link' => url('/'),
        ],
        [
            'name' => translation('MY_ACCOUNT'),
            'link' =>url()->full()
        ],
    ],
];
@endphp

<x-Ecom01.SharedComponent.BreadCrumb :data="$main_arr" />
<!-- account area start -->
<div class="checkout-area mtb-60px">
    <div class="container">
        <div class="row">
            <div class="mx-auto col-lg-3 ">
                {{-- Left Side Menubar Component Start --}}
                <x-Ecom01.SharedComponent.left-side-menu />
                {{-- Right Side Menubar Component Start --}}
            </div>
            <div class="mx-auto col-lg-9">
                <div class="checkout-wrapper">
                    <div id="faq" class="panel-group">
                        <div class="panel panel-default single-my-account">
                            <div class="panel-heading my-account-title">
                                <h3 class="panel-title">{{ translation('ACCOUNT_TITLE') }}</h3>
                            </div>
                            <div id="my-account-1" class="">
                                <form class="needs-validation edit_user_form" novalidate>
                                    <div class="panel-body">
                                        <div class="myaccount-info-wrapper">
                                            <div class="row">
                                                <div class="col-lg-6 col-md-6">
                                                    <div class="billing-info">
                                                        <label>{{ translation('NAME') }}<span class="text-danger">*</span></label>
                                                        <input type="text" class="form-control" id="name" value="{{ $userData->first_name ?? '' }}"  required/>
                                                        <span class="text-danger name"></span>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6 col-md-6">
                                                    <div class="billing-info">
                                                        <label>{{ translation('PHONE') }}</label>
                                                        <input type="text" id="contact" class="form-control" value="{{ $userData->contact ?? '' }}"/>
                                                        <span class="text-danger contact"></span>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6 col-md-6">
                                                    <div class="billing-info">
                                                        <label>{{ translation('EMAIL') }}</label>
                                                        <input type="email" id="email" class="form-control" value="{{ $userData->email ?? '' }}" readonly required />
                                                    </div>
                                                </div>

                                                {{-- Email Verify Message Work Start--}}

                                                @if (empty($userData->email_verified_at))
                                                    <div class="col-lg-6 col-md-6">
                                                        <div class="verified billing-info">
                                                            <input type="hidden" id="user_email"
                                                                value="{{ $userData->email }}">
                                                            <input type="hidden" id="user_id"
                                                                value="{{ $userData->customer_id }}">
                                                            <input type="hidden" id="first_name"
                                                                value="{{ $userData->first_name }}">
                                                            <label class="custom-control-label"
                                                                for="customControlInline">{{translation('EMAIL_VERIFY')}}</label>
                                                            <a href="javascript:void(0)" class="btn btn-outline-primary"
                                                                id="resendEmailbutton">{{translation('EMAIL_VERIFIED_BUTTON')}}</a>

                                                        </div>
                                                    </div>
                                                @else
                                                <div class="col-lg-6 col-md-6">
                                                  <div class=" verified billing-info">
                                                      <label class="custom-control-label" for="customControlInline">
                                                        <i class="fa fa-check bg-success text-white" aria-hidden="true"></i> {{translation('EMAIL_VERIFIED')}}
                                                        </label>
                                                  </div>
                                              </div>
                                                @endif
                                            {{-- End of Email Verify Message Work --}}
                                            </div>

                                            <div class="row">
                                                <div class="col">
                                                    <div class="billing-info">
                                                        <input class="checkout-toggle2" id="passwordCheckbox"
                                                            value="1"
                                                            style=" width: 4%; height: 15px; text-align: left;"
                                                            type="checkbox">
                                                        <label>{{ translation('CHANGE_PASSWORD_BUTTON') }}</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="p-0">
                                                <div class="row checkout-account-toggle open-toggle2 mb-30"  id="cpasstoggle">
                                                    <div class="col-lg-12">
                                                    <div class="row">
                                                        <div class="col-lg-6 col-md-6">
                                                            <div class="billing-info">
                                                                <label>{{ translation('NEW_PASSWORD') }}</label>
                                                                <input type="password" name="password" id="password" />
                                                                <span class="text-danger password"></span>
                                                            </div>
                                                        </div>

                                                        <div class="col-lg-6 col-md-6">
                                                            <div class="billing-info">
                                                                <label>{{ translation('CONFIRM_PASSWORDS') }}</label>
                                                                <input type="password" name="confirmpassword" id="confirmpassword" />
                                                                <span class="text-danger confirmpassword"></span>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-12">
                                                            <span class="text-danger d-none" id="ConfirmPasswordCheck">{{translation('ERROR_PASSWORD_AND_CONFIRM_PASSWORD_MSG')}}
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                                </div>
                                                <div class="billing-back-btn">
                                                    <div class="billing-btn">
                                                        <button type="submit"
                                                            id="updateprofile">{{translation('UPDATE_BUTTON')}}</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')
    <script>
        $(document).ready(function() {
            $(document).on('click', '#updateprofile', function(e) {
                e.preventDefault();
                $('.edit_user_form').addClass('was-validated');
                if ($('.edit_user_form')[0].checkValidity() === false) {
                    event.stopPropagation();
                } else {

                if ($("#passwordCheckbox").prop('checked') == true) {
                    $('.edit_user_form').addClass('was-validated');
                    if($('#password').val() == $('#confirmpassword').val()){
                        var passwordCheckbox = $('#passwordCheckbox').val();
                    }else{
                        checkPassword();
                    }
                } else {
                    var passwordCheckbox = 0;
                }
                var data = {
                    'name': $('#name').val(),
                    'contact': $('#contact').val(),
                    'password': $('#password').val(),
                    'confirmpassword': $('#confirmpassword').val(),
                    'passwordCheckbox': passwordCheckbox,
                }
                debugger;
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{ url('account/update-profile') }}",
                    data: data,
                    dataType: "json",
                    success: function(response) {
                        if (response.status == 400) {
                            $.each(response.error, function(key, err_val) {
                                $('.' + key).text(err_val);
                            });
                        } else {
                            $('.edit_user_form').removeClass('was-validated');
                            Notify('{{translation('PROFILE_UPDATE_MSG')}}', true);
                            $('#passwordCheckbox').prop('checked', false);
                            $('#cpasstoggle').hide(2000);
                            location.reload();
                        }
                    }
                });
               }
            });

            // Resend Verify email

            $(document).on('click', '#resendEmailbutton', function(e) {
                $.ajaxSetup({
                    headers: {
                        "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr(
                            "content"
                        ),
                    },
                });
                var email = $('#user_email').val();
                var customer_id = $('#user_id').val();
                var first_name = $('#first_name').val();
                $.ajax({
                    type: "POST",
                    url: "{{ url('resend-email') }}",
                    data: {
                        'email': email,
                        'customer_id': customer_id,
                        'first_name': first_name,
                    },
                    dataType: "json",
                    success: function(response) {
                        if (response.status == 200) {
                            Notify("{{translation('EMAIL_SEND_SUCCESSFULLY')}}!", true);
                        }
                    },
                    error: function(data) {
                        console.log(data);
                    },
                });
            });
            $("#passwordCheckbox").on("click",function() {
                if ($("#passwordCheckbox").prop('checked') == true){
                    $('#password').attr('required',' ');
                    $('#confirmpassword').attr('required',' ');
                }else
                {
                    $('#password').removeAttr('required');
                    $('#confirmpassword').removeAttr('required'); 
                }
                 $(".password-section").toggle(1000);
            });
        });
        function checkPassword(e) {
            $('#ConfirmPasswordCheck').removeClass('d-none');
            e.stopPropagation();
        }
    </script>
@endpush
