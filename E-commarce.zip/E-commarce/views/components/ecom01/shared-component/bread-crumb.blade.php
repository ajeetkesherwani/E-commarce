<div class="container">
    <div class="row pt-md-3">
      <div class="col-md-5 col-12">
        <div class="breadcrumb-content text-left">
         
          @if (!empty($sublist))
          <ul class="breadcrumb-links d-flex">
            @foreach ($sublist as $key=>$list)
              <li>
                @if($key<sizeof($sublist) )
                  <a href="{{ $list['link'] }}">{{ $list['name'] }}</a>
                @endif
              </li>
            @endforeach
            </ul>
          @endif
        </div>
      </div>
      
      
    </div>
    <!-- <div class="row">
      <div class="col-3"></div>
      <div class="col-md-9 col-12">
          <div class="breadcrumb-content text-uppercase">
            <h1 class="breadcrumb-hrading text-uppercase">{{ $title }}</h1>
          </div>
      </div>
    </div> -->
  </div>