@php
$urlSegment = Request::segment(2);
$imgurl = url($user_data->profile_photo ?? asset('images/testimonial.webp'));
@endphp
<div class="left-dashboard">
    {{-- <form method="post" enctype="multipart/form-data" id="changeProfileImage">
        <label for="fileToUpload">
            <div class="profile-picc" style="background-image: url('{{ $imgurl }}')">
                <span class="glyphicon glyphicon-camera"></span>
                <span>{{ translation('CHANGE_IMAGE') }}</span>
            </div>
        </label>
        <input type="File" name="fileToUpload" id="fileToUpload" />
        <h5 class="card-title text-center text-uppercase pt-2">
            {{ Auth::user()->first_name }} {{ Auth::user()->last_name }}
        </h5>
    </form> --}}


    <div class="list-group" id="#nav">
        <a href="{{ url('account/dashboard') }}"
            class="list-group-item list-group-item-action {{ $urlSegment == 'dashboard' ? 'active' : '' }}">
            <i class="fa-sharp fa-solid fa-house" style="margin-right:10px"></i>
            {{ translation('ACCOUNT_DASHBOARD') }}
        </a>
        <a href="{{ url('account/my-account') }}"
            class="list-group-item list-group-item-action {{ $urlSegment == 'my-account' ? 'active' : '' }}">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" style="margin-right:10px"><path fill="currentcolor" fill-rule="nonzero" d="M7 0C3.138 0 0 3.138 0 7c0 3.684 2.855 6.706 6.47 6.978l.022.002c.168.012.337.02.508.02.171 0 .34-.008.508-.02l.022-.002C11.145 13.706 14 10.684 14 7c0-3.862-3.138-7-7-7zm0 .609A6.387 6.387 0 0 1 13.391 7c0 1.75-.702 3.331-1.838 4.484-.521-.323-1.256-.4-1.801-.581-.616-.204-1.349-.517-1.535-.86.736-.093 2.435-.407 2.435-1.1a.304.304 0 0 0-.1-.225c-.21-.19-.197-1.18-.188-1.975.019-1.512.04-3.225-.845-4.09-.348-.34-.805-.513-1.358-.515-.282-.195-.687-.305-1.15-.305h-.005c-3.173.228-3.25 3.19-3.3 5.149-.02.737-.04 1.572-.255 1.762a.305.305 0 0 0-.103.228c0 .66 1.222.916 2.435 1.071-.172.356-1.206.71-1.826.914-.538.177-1.05.216-1.514.524A6.368 6.368 0 0 1 .61 7 6.387 6.387 0 0 1 7 .609z"></path></svg>
            {{ translation('ACCOUNT_TITLE') }}
        </a>
        <a href="{{ url('account/orders') }}"
            class="list-group-item list-group-item-action {{ $urlSegment == 'orders' ? 'active' : '' }} ">
           <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" style="margin-right:10px"><path fill="currentcolor" d="M2.013 0a.89.89 0 0 0-.893.892v2.162h.227c.342 0 .646.16.867.402.215-.968 1.603-1.443 4.226-1.443 2.956 0 4.562.505 4.786 1.487.22-.25.543-.411.901-.411h.193V.893c0-.495-.418-.893-.928-.893h-9.38zM6.44 2.572c-1.355 0-3.637.147-3.693 1.112l-.2 1.548-.158 1.147-.114.901h-.262a1.473 1.473 0 0 0-.403.061c-.035.01-.071.023-.105.035-.06.022-.112.042-.166.07-.013.007-.022.02-.035.027-.063.036-.127.07-.184.113-.078.06-.145.136-.21.21-.012.014-.024.021-.035.035A1.516 1.516 0 0 0 .7 8.12c-.013.028-.023.058-.035.088-.026.068-.054.135-.07.21-.004.017-.005.035-.009.052a1.473 1.473 0 0 0-.026.262v1.908h12.32V8.732c0-.09-.01-.177-.026-.262l-.009-.053a1.454 1.454 0 0 0-.061-.21c-.011-.029-.03-.059-.044-.087a1.366 1.366 0 0 0-.07-.131 1.36 1.36 0 0 0-.105-.158c-.01-.014-.023-.02-.035-.035a1.466 1.466 0 0 0-.21-.21c-.057-.043-.121-.077-.184-.114-.013-.006-.022-.02-.035-.026-.054-.03-.107-.048-.166-.07-.034-.012-.069-.025-.105-.035a1.455 1.455 0 0 0-.402-.061h-.263l-.122-.954-.114-.875-.236-1.741c-.064-1.077-3.554-1.138-4.253-1.138zm0 .56c2.36 0 3.595.42 3.701.63l.28 2.153c-.414.07-1.645.245-3.701.245s-3.287-.174-3.701-.245l.288-2.179c.007-.12.583-.604 3.133-.604zm-5.548.482a.663.663 0 0 0-.638.639v1.54c0 .355.298.673.638.673h.42c.356 0 .674-.297.674-.639v-1.54c0-.355-.298-.673-.639-.673H.892zm11.236.035a.64.64 0 0 0-.64.638v1.54c0 .354.287.64.64.64h.42a.663.663 0 0 0 .638-.64v-1.54a.64.64 0 0 0-.639-.638h-.42zM5.205 7.56h3.028c.192 0 .346.114.411.28.02.051.035.106.035.166v1.348a.44.44 0 0 1-.446.446H5.206a.44.44 0 0 1-.446-.446V8.006a.46.46 0 0 1 .035-.166.433.433 0 0 1 .411-.28zM2.152 8.68h1.295c.112 0 .193.08.193.193v.735c0 .111-.08.192-.193.192H2.152a.186.186 0 0 1-.192-.193v-.734c0-.112.08-.193.192-.193zm7.84 0h1.295c.112 0 .193.08.193.193v.735c0 .111-.08.192-.193.192H9.992a.186.186 0 0 1-.192-.193v-.734c0-.112.08-.193.192-.193zM.56 11.2v1.4h12.32v-1.4H.56zm0 1.96c0 .463.377.84.84.84h1.12c.463 0 .84-.377.84-.84H.56zm9.52 0c0 .463.377.84.84.84h1.12c.463 0 .84-.377.84-.84h-2.8z"></path></svg>
            {{ translation('ACCOUNT_ORDER_TITLE') }}
        </a>
        <a href=" {{ url('account/addreses') }}"
            class="list-group-item list-group-item-action {{ $urlSegment == 'addreses' ? 'active' : '' }} ">
            <i class="fa-regular fa-address-book" style="margin-right:10px;font-size: 15px;"></i>
            {{ translation('ACCOUNT_ADDRESS_TITLE') }}
        </a>
    </div>
</div>



@push('scripts')
    <script>
        $(document).ready(function() {
            $("#fileToUpload").change(function() {
                $.ajaxSetup({
                    headers: {
                        "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr(
                            "content"
                        ),
                    },
                });
                var profileimage = document.getElementById("changeProfileImage");
                var formData = new FormData(profileimage);
                $.ajax({
                    type: "POST",
                    url: "{{ url('account/change-image') }}",
                    data: formData,
                    cache: false,
                    contentType: false,
                    processData: false,
                    success: function(response) {
                        if (response.status == 400) {} else {
                            Notify("{{translation('PROFILE_IMAGE_UPDATED')}}", true);
                            location.reload();
                        }
                    },
                    error: function(data) {
                        console.log(data);
                    },
                });
            });
        });
    </script>
@endpush
