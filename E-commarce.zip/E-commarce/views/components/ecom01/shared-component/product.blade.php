@php
$avgrating=AvgRating($product->product_id);
use App\Models\Ecom\Services\EcomService;
use App\Models\WishList;
$wishlistAry = WishList::getProductsAry();
@endphp

@if($viewtype == 'grid')
<div class="product-inner-item mb-60px d-flex justify-content-center">
    <article class="list-product ">
        <ul class="product-flag">
            @if(!empty($product->feature_name))
                @foreach($product->feature_name as $productFeature)
                    <li>
                        {{$productFeature}}
                    </li>
                @endforeach
            @endif
        </ul>
        <div class="img-block text-center">
            <a href="{{ EcomService::url($product->product_id , 'product')}}" class="thumbnail">
                <img class="first-img" src="{{ $product->image_url }}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="{{$product->products_name ?? ''}}" />
            </a>
            <div class="add-to-link">
                <ul>
                    @if (webFunctionStatus(config('constkey.is_cart_enabled')))
                        <li>
                            <a href="{{ url('product/'.$product->product_slug) }}" title="View Details">
                                <i class="ion-eye"></i></a>
                        </li>
                    @endif
                    @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))
                    <li>
                        <a href="javascript:void(0);" onclick="addToWishListFromDetail({{ $product->product_id }})"
                            title="wishlist">
                            @if(in_array($product->product_id, $wishlistAry))
                            <i class="ion-android-favorite-outline whishlist-active"></i>
                            @else
                            <i class="ion-android-favorite-outline"></i>
                            @endif
                        </a>
                    </li>
                    @endif
                    <li>
                        <a class="quick_view" onclick="showfunction('{{ $product->product_slug }}')" title="Quick View">
                            <i class="ion-ios-search-strong"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="product-decs text-center">
            <a class="inner-link" href="{{ EcomService::url($product->product_id , 'product')}}"><span>{{
                $product->product_model ?? '' }}</span></a>
            <h2>
                <a href="{{ EcomService::url($product->product_id , 'product')}}" class="product-link"
                    title="{{ $product->products_name ?? '' }}">
                    {{sortStringName($product->products_name ?? '')}}</a>
            </h2>
            @if(!empty($avgrating))
                <div class="rating-product">
                    @for($i=0;$i<5;$i++) 
                        @if($i<$avgrating) 
                            <i class="ion-android-star"></i>
                        @else
                            <i class="ion-android-star-outline"></i>
                        @endif
                    @endfor
                </div>
            @endif
            <div class="pricing-meta">
            
            @if($product->products_prices!=null)
            @foreach($product->products_prices as $holeprice)
                <ul>
                    @if($holeprice->discount_percent !='0')
                        <del class="text-danger ms-2">
                            {{currencyFormat($holeprice->max_sale_price) }}
                        </del>
                    @endif
                    <li class=" not-cut">
                        {{ currencyFormat($holeprice->sale_price ?? '0.00') }} 
                    </li>
                    @if($holeprice->discount_percent != '0')
                        <span class="discount-price ms-1">
                            {{ currencyFormat( $holeprice->discount_percent )}}% {{translation('PRODUCT_DISCOUNT')}}
                        </span>
                    @endif
                </ul>
                @break
            @endforeach
            @else
                <ul>
                    @if($product->discount_type != 'no')
                        <del class="text-danger ms-2">
                            {{currencyFormat($product->max_sale_price) }}
                        </del>
                    @endif
                    <li class=" not-cut">
                        {{ currencyFormat($product->sale_price ?? '0.00') }} 
                    </li>
                    @if($product->discount_type != 'no')
                      @if($product->discount_type == 'flat')
                        <span class="discount-price ms-1">
                            {{ currencyFormat($product->discount_amount) }} {{translation('PRODUCT_DISCOUNT')}}
                        </span>
                      @else
                      <span class="discount-price ms-1">
                        {{ currencyFormat( $product->discount_amount )}}% {{translation('PRODUCT_DISCOUNT')}}
                      </span>
                      @endif
                    @endif
                </ul>
            @endif
            </div>
        </div>
    </article>
</div>
@endif

@if($viewtype == 'list')

<div class="shop-list-wrap mb-30px scroll-zoom ">
    <div class="row list-product m-0px">
        <div class="col-md-12">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <div class="left-img">
                        <div class="img-block text-center">
                            <a href="{{ EcomService::url($product->product_id , 'product')}}" class="thumbnail">
                                <img class="first-img" src="{{ $product->image_url }}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="{{$product->products_name ?? ''}}" />
                            </a>
                            <div class="add-to-link">
                                <ul>
                                    @if (webFunctionStatus(config('constkey.is_cart_enabled')))
                                    <li>
                                        <a href="{{ url('product/'.$product->product_slug) }}" title="View Details">
                                            <i  class="ion-eye"></i></a>
                                    </li>
                                    @endif
                                    @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))
                                    <li>
                                        <a href="javascript:void(0);"
                                            onclick="addToWishListFromDetail({{ $product->product_id }})"
                                            title="wishlist">
                                            @if(in_array($product->product_id, $wishlistAry))
                                            <i class="ion-android-favorite-outline whishlist-active"></i>
                                            @else
                                            <i class="ion-android-favorite-outline"></i>
                                            @endif
                                        </a>
                                    </li>
                                    @endif

                                    <li>
                                        <a class="quick_view" onclick="showfunction('{{ $product->product_slug }}')"
                                            title="Quick View">
                                            <i class="ion-ios-search-strong"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <ul class="product-flag">
                            @if(!empty($product->feature_name))
                                @foreach($product->feature_name as $productFeature)
                                    <li>{{$productFeature}}</li>
                                @endforeach
                            @endif
                        </ul>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                    <div class="product-desc-wrap">
                        <div class="product-decs text-start">

                            <h2>
                                <a href="{{ EcomService::url($product->product_id , 'product')}}" class="product-link">
                                    {{ $product->products_name ?? '' }}
                                </a>
                            </h2>
                            <a class="inner-link" href="{{ EcomService::url($product->product_id , 'product')}}"><span>{{
                                    $product->product_model ?? '' }}</span></a>
                            @if(!empty($avgrating))
                            <div class="rating-product">
                                @for($i=0;$i<5;$i++) 
                                    @if($i<$avgrating) 
                                        <i class="ion-android-star"></i>
                                    @else
                                        <i class="ion-android-star-outline"></i>
                                    @endif
                                @endfor
                            </div>
                            @endif
                            <div class="pricing-meta mb-1">
                                @if($product->products_prices!=null)
                                @foreach($product->products_prices as $holeprice)
                                    <ul>
                                        @if($holeprice->discount_percent !='0')
                                            <del class="text-danger ms-2">
                                                {{currencyFormat($holeprice->max_sale_price) }}
                                            </del>
                                        @endif
                                        <li class="old-price not-cut">
                                            {{ currencyFormat($holeprice->sale_price ?? '0.00') }} 
                                        </li>
                                        @if($holeprice->discount_percent != '0')
                                            <span class="discount-price ms-1">
                                                {{ currencyFormat( $holeprice->discount_percent )}}% {{translation('PRODUCT_DISCOUNT')}}
                                            </span>
                                        @endif
                                    </ul>
                                    @break
                                @endforeach
                                @else
                                    <ul>
                                        @if($product->discount_type != 'no')
                                            <del class="text-danger ms-2">
                                                {{currencyFormat($product->max_sale_price) }}
                                            </del>
                                        @endif
                                     
                                        <li class=" not-cut">
                                            {{ currencyFormat($product->sale_price ?? 0.00) }} 
                                        </li>
                                      
                                        @if($product->discount_type != 'no')
                                          @if($product->discount_type == 'flat')
                                            <span class="discount-price ms-1">
                                                {{ currencyFormat($product->discount_amount) }} {{translation('PRODUCT_DISCOUNT')}}
                                            </span>
                                          @else
                                          <span class="discount-price ms-1">
                                            {{ currencyFormat( $product->discount_amount )}}% {{translation('PRODUCT_DISCOUNT')}}
                                          </span>
                                          @endif
                                        @endif
                                    </ul>
                                @endif
                                </div>
                            <div class="product-intro-info">
                                <p>{!! Str::limit( strip_tags($product->products_description) ?? '',150) !!}</p>
                            </div>
                            <div class="product-intro-info mt-2">
                                @foreach($product->products_to_features as $featKey=>$featVal)
                                <p><span>{{$featVal->feature_title ?? ''}}: </span>{{$featVal->feature_value ?? ''}}</p>
                                @endforeach
                            </div>
                            {{-- <div class="product-intro-info">
                                <p>
                                   {{ $product->products_description ?? '' }} 
                                </p>
                                 <p>Comfortable cotton-blend fabrication.</p>
                                <p>
                                    Classic varsity jacket features brand
                                    details throughout.
                                </p>
                                <p>Flat knit collar.</p> 
                            </div> -->
                            <div class="in-stock">
                                Availability: <span> {{ $product->stock_qty }}</span>
                            </div> --}}
                        </div>
                         {{-- <div class="add-to-link">
                            <ul>
                               @auth
                                <li>
                                    <a href="javascript:void(0);" onclick="addToWishListFromDetail({{ $product->product_id }})" title="Wishlist"
                                        >
                                        @if(in_array($product->product_id, $wishlistAry))
                                        <i class="ion-android-favorite-outline whishlist-active"></i>
                                        @else
                                        <i class="ion-android-favorite-outline"></i>
                                        @endif
                                    </a>
                                </li>
                                @endauth
                                <li>
                                    <a href="{{ EcomService::url($product->product_id , 'product')}}" title="View Details"
                                        ><i class="ion-eye"></i
                                    ></a>
                                </li>
                            </ul>
                        </div> --}}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endif
