<script src="{{ LoadAssets('assets/js/vendor/vendor.min.js') }}"></script>
<script src="{{ LoadAssets('assets/js/plugins/plugins.min.js') }}"></script>
<script src="{{ LoadAssets('assets/js/main.js') }}"></script>
<!-- // toastify -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"
    integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>


<script>
    function Notify(msg, status) {
        if (status == true)
            toastr['success'](msg)
        else
            toastr['error'](msg)
    }

    toastr.options = {
        "closeButton": true,
        "debug": false,
        "newestOnTop": true,
        "progressBar": false,
        "positionClass": "toast-top-right",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "1000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    }
</script>

@if (getsetting('newsletter_popup') == 'yes')
    @if (empty(Cache::get('loaditem')))
        <script>
            window.onload = function showNewsLatter() {
                $.ajax({
                    url: "/onloadnewslatter",
                    success: function(response) {
                        $(".newsmodal").html(response);
                        $('#onloadModal').modal('show');
                    },
                    error: function(error) {

                    },
                });
            }
        </script>
    @endif
@endif

<script>
    $(document).ready(function () {
        $(document).on('click', '#modal_subscribe', function (e) {
            e.preventDefault();
            $('#newsltrModalForm').addClass('was-validated');
          if ($('#newsltrModalForm')[0].checkValidity() === false) {
                event.stopPropagation();
          } else {
            var data = {
                'customer_email': $('#customeremail').val(),
            }
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "/newslatterstore",
                data: data,
                dataType: "json",

                beforeSend: function() {
                $("#modal_subscribe").addClass('disabled');
                $("#modal_subscribe").html('Submitting...');
                },
                success: function (response) {
                    if (response.status == 400) {
                        $('#email_err').text(response.error.customer_email);
                    }
                    else {
                        $('#onloadModal').modal('hide');
                        Notify("{{translation('SUBSCRIBE_SUCCESS_MSG')}}", true);
                    }
                },
                complete: function() {
                $('#newsltrModalForm').removeClass('was-validated');
                $("#modal_subscribe").removeClass('disabled');
                $("#modal_subscribe").html('{{translation('SUBMIT')}}');
                }
            });
          }
        });  
    });

</script>

<script>
    /*Enquiry Form Modal */
    function showEnquiryForm() {

        $('#EnquiryModal').modal('show');
    }
</script>

<script>
    // Wholesale Price tabel carosol

    $(document).ready(function() {
        $('.qty-carousel').slick({
            centerMode: true,
            nav: true,
            centerPadding: '2px',
            slidesToShow: 5,
            responsive: [{
                    breakpoint: 768,
                    settings: {
                        arrows: false,
                        centerMode: true,
                        centerPadding: '60px',
                        slidesToShow: 4
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        arrows: false,
                        centerMode: true,
                        centerPadding: '40px',
                        slidesToShow: 1
                    }
                }
            ]
        });
    });

    $(document).ready(function(){
        $('.your-class').slick();
    });

    $('.modal').on('shown.modal', function (e) {
        $('.your-class').slick('setPosition');
        $('.qty-carousel').addClass('open');
    })

</script>

<script>
    function addToCart(product_id, qty = 1, attributes_id = '', product_slug = '', source = '') {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url: '{{ route('addUpdateToCart') }}',
            method: 'POST',
            data: {
                qty: qty,
                attributes_id: attributes_id,
                product_id: product_id,
                product_slug: product_slug,
                source: source,
            },
            success: function(response) {
                if (response.status == 200) {
                    $('.count-cart-total').html(response.data.total_count_html);
                    Notify('Item Added To Cart !', true);
                } else {
                    Notify(response.Message, false);
                }
            },
            error: function(error) {
                Notify("Some Error In Add To Cart", false);
            }
        });

    }

    //Wishlist Ajax start

    function addToWishListFromDetail(product_id) {
        var element = this;
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
            url: '{{ route('addUpdateToWishList') }}',
            method: 'POST',
            data: {
                product_id: product_id,
            },
            success: function(response) {
                $('.count-wishlist-total').html(response.wish_list_item_html);
                Notify('Item Added To WishList !', true);

                if ($(element).hasClass('ion-android-favorite-outline')) {
                    $(element).removeClass('ion-android-favorite-outline').addClass('ion-android-favorite');
                }
            },
            error: function(error) {
                Notify('Please Login to add products in Wishlist!');
            }
        });
    }
    //End of Wishlist Ajax 


    let choosen_attributes = [];

    function addToCartFromModalDetail(product_id) {
        let mdl_chosen_attr = [];
        var qtyItemAdd = $('#qtyItemAdd').val();
        var product_slug = $('#productSlug').val();
        var source = $('.source').val();
        let attributes = choosen_attributes.join(',');
        if (attributes == '') {

            $('input[type="radio"]:checked').each(function() {
                if (!mdl_chosen_attr.includes(this.value)) {
                    mdl_chosen_attr.push(this.value);
                }
            });
            let attributes = mdl_chosen_attr.join(',');

            addToCart(product_id, qtyItemAdd, attributes, product_slug, source);
        } else {
            addToCart(product_id, qtyItemAdd, attributes, product_slug, source);
        }
    }

    function chooseModalAttributes(params) {
        if (!choosen_attributes.includes(params.value)) {
            choosen_attributes.push(params.value);
        }
    }

    // Custome form submitted

    $(".customFrom").on('submit', function(e) {
        e.preventDefault();
        $('.customFrom').addClass('was-validated');
        if ($('.customFrom')[0].checkValidity() === false) {
            event.stopPropagation();
        } else {
            let formData = $(this).serialize();

            /*Ajax Request Header setup*/
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $.ajax({
                url: "{{ route('customFormSubmit') }}",
                method: 'post',
                data: formData,
                beforeSend: function() {
                    $(".customFrom :submit").addClass('disabled');
                    $(".customFrom :submit").html('Submitting...');
                },
                success: function(response) {
                    if (response.status == 0) {
                        $.each(response.message, function(i, v) {
                            $('#' + i + '-error').html(v);
                        });
                    } else {
                        $('.customFrom').removeClass('was-validated');
                        Notify('Data send successfully', true);
                        $('.customFrom').trigger("reset");
                    }
                },
                complete: function() {
                    $('.customFrom').removeClass('was-validated');
                    $(".customFrom :submit").removeClass('disabled');
                    $(".customFrom :submit").html('Submit');
                }
            });
        }

    });


    //  Calculate Wholesale Price and Normal Price  on  Qty Start

    $(document).on('click', '.qtybutton', function () {
        var page_source=$(this).parent().closest('.pro-details-quality').find(".source").val();
        ValidateMinQty(page_source);
    });

    function QtyToPrice(page_source) {
        ValidateMinQty(page_source);
    }

    //  Calculate Wholesale Price and Normal Price On Qty End

    //Validate Minimum Qty
    function ValidateMinQty(page_source){
        var min_ord_qty = $('.minordqty').val();
        var qtyItemAdd = $('#qtyItemAdd').val();
        


        var alertHtml = `<div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong>Sorry !</strong> Please Add minimum ${min_ord_qty} Qty.
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>`;
        if (min_ord_qty != 'undefined') {
            if (Number(qtyItemAdd) < Number(min_ord_qty)) {
                $('#qtyItemAdd').val(min_ord_qty);
                $('.qty_alert').html(alertHtml);
            }
            else {
                if(qtyItemAdd<1)
                $('#qtyItemAdd').val(1);
                attributeToprice(page_source);
            }
        } 
        else {
            attributeToprice(page_source);
        }
    }


    // Attribute to Price

    function attributeToprice(page_source='') {

        var detail_choosen_attributes = [];
        attr_id = 0;
        if (page_source=='quickView')
        var ele = $(".modal_input-radio");
        else
        var ele = $(".input-radio");

    
        $(ele).each(function(i) {
            if (this.checked) {
                if (!detail_choosen_attributes.includes(this.value)) {
                    var aVal = this.value.split('_');
                    detail_choosen_attributes.push({
                        options_id: aVal[0],
                        options_values_id: aVal[1]
                    });
                }
            }
        });

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        if (page_source=='quickView')
        {
            var data = {
                'product_id': $('.modal_products_id').val(),
                'OrderdQty' : $('.modal_qtyItemAdd').val(),
                'attribute_array': detail_choosen_attributes,
            }
        }
        else
        {
            var data = {
                'product_id': $('#products_id').val(),
                'OrderdQty' : $('#qtyItemAdd').val(),
                'attribute_array': detail_choosen_attributes,
            }
        }

    
        $.ajax({
            type: "POST",
            url: "/attribute-price",
            data: data,
            dataType: "json",
            success: function(response) {
                if (response.isdiscount == 'yes') {
                    $('.discount_amount').text(response.totalDiscountPrice);
                }
                $(".old-price").text(response.final_price);
            }
        });

    }

    // Onclick Attributes function call

    $(document).on('click', '.input-radio', function() {
        attributeToprice();
    });

    $(document).on('click', '.modal_input-radio', function() {
        attributeToprice('quickView');
    });

    // Onload Document function call

    $(document).ready(function() {
        attributeToprice();
    });


    // Quick View of product

    function showfunction(slug) {
        var Callurl = `{{ url('showproduct') }}/` + slug;
        $.ajaxSetup({
            headers: {
                "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
            },
        });
        $.ajax({
            type: "POST",
            url: Callurl,
            data: {
                slug: slug,
            },
            success: function(response) {
                $("#product-detail-modal").html(response);
                $('#productModalShow').modal('show');
                attributeToprice('quickView');
            },
            error: function(error) {},
        });
    }
</script>
