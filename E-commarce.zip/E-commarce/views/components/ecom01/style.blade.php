<link rel="shortcut icon" type="image/x-icon" href="{{ getImageUrlWithKey('website_favicon') }}" />
<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800&display=swap"
    rel="stylesheet" />
<link rel="stylesheet" href="https://fonts.sandbox.google.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

<link rel="stylesheet" href="{{ LoadAssets('assets/css/vendor/vendor.min.css') }}">
<link rel="stylesheet" href="{{ LoadAssets('assets/css/plugins/plugins.min.css') }}">
<link rel="stylesheet" href="{{ LoadAssets('assets/css/style.min.css') }}">
<link rel="stylesheet" href="{{ LoadAssets('assets/css/responsive.min.css') }}">
<link rel="stylesheet" href="{{ LoadAssets('assets/css/default.css') }}">
<!-- // toastify  -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" integrity="sha512-vKMx8UnXk60zUwyUnUPM3HbQo8QfmNx7+ltw8Pm5zLusl1XIfwcxo8DbWCqMGKaWeNxWA8yrx5v3SaVpMvR3CA==" crossorigin="anonymous" referrerpolicy="no-referrer" />


@push('styles')
<style>
    body {
    font-family: <?php  echo templateSettings("theme_font"); ?>, sans-serif !important;
    font-size: 14px;
    line-height: 24px;
    color: <?php  echo templateSettings("theme_color"); ?>;
    background-color:<?php  echo templateSettings("theme_bg_color"); ?>;
    }
h1,
h2,
h3,
h4,
h5,
h6 {
    color:#000;
    font-weight: 600;
}

.header-buttom-nav{
    background-image: linear-gradient(to right top, #3b61b9, #395eb4, #385caf, #3659ab, #3557a6);
}
h2 {
    font-size: 2.2rem;
}
.section-title p {
    color: #022b89;
    font-weight: 600;
    letter-spacing: 0.02rem;
}
.footer-area {
    color: #666;
    background: #efefef;
}
.footer-herading {
    color:<?php  echo templateSettings("theme_color"); ?>;
    border-bottom: 1px solid #e3e3e3;
}
.footer-herading {
    font-size: 16px;
    font-weight: 700;
    line-height: 24px;
}
.section-title.underline-shape:after, .footer-herading:after, #scrollUp ,.item-quantity-tag, .pro-details-cart a,
.Place-order button, .enquiry-form .enquiry_btn, .enquiry-form .prdtbtn-close{
    background: #3b61b9;
    color:#fff
}
.product-link:hover {
    color: #3b61b9;
}

.pro-details-cart a:hover {
    background: #253237;
}
</style>    
@endpush