@php
$avgrating = AvgRating($products->product_id);
$currentURL = URL::current();
use App\Models\Ecom\Services\EcomService;
@endphp
<x-Theme1.SharedComponent.BreadCrumb :data="$breadCumbArr" />
<!-- Breadcrumb Area End -->
<!-- Shop details Area start -->
<section class="product-details-area mtb-60px">
    <div class="container">
        <div class="row">
            <div class="col-xl-6 col-lg-6 col-md-12">
                <div class="product-details-img product-details-tab">
                    <div class="zoompro-wrap zoompro-2">
                        <div class="zoompro-border zoompro-span text-center"> <img class="zoompro"
                                src="{{ getFullImageUrl($products->product_image) }}"
                                onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                                data-zoom-image="{{ getFullImageUrl($products->product_image) }}"
                                alt="{{ $products->products_name ?? '' }}" />
                        </div>
                    </div>
                    @if (!empty($products->products_to_gallery))
                        <div id="gallery" class="product-dec-slider-2">
                            <a class="active" data-image="{{ getFullImageUrl($products->product_image) }}"
                                data-zoom-image="{{ getFullImageUrl($products->product_image) }}"> <img
                                    src="{{ getFullImageUrl($products->product_image) }}"
                                    onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                                    alt="{{ $products->products_name }}" />
                            </a>

                            @foreach ($products->products_to_gallery as $key => $data)
                                <a class="active" data-image="{{ getFullImageUrl($data->images_id) }}"
                                    data-zoom-image="{{ getFullImageUrl($data->images_id) }}"> <img
                                        src="{{ getFullImageUrl($data->images_id) }}"
                                        onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                                        alt="{{ $data->images_name }}" />
                                </a>
                            @endforeach
                        </div>
                    @endif
                </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-12">
                <div class="product-details-content">
                    
                    <h1> {{ $products->products_name ?? '' }} </h1>
                    @if (in_array($products->product_type_id, ['1', '2', '4']) && $products->products_to_brand != '')
                        @if (!empty($products->products_to_brand))
                            <p class="reference">Brand:<span class="read-review"> <a
                                        href="{{ EcomService::url($products->products_to_brand->brand_id ?? '', 'brand') }}">{{ $products->products_to_brand->brand_name ?? '' }}</a></span>
                            </p>
                        @endif
                    @endif
                    <div class="pro-details-rating-wrap">

                        @if (!empty($avgrating))
                            <div class="rating-product">
                                @for ($i = 1; $i < $avgrating; $i++)
                                    <i class="ion-android-star"></i>
                                @endfor
                            </div>
                        @endif

                        @if (in_array(config('constkey.section_review'), $cKey))
                            <span class="read-review">
                                <a class="reviews" href="#read_review">Read reviews
                                    ({{ $review_count ?? '' }})</a>
                            </span>
                        @endif
                    </div>
                    <div class="pricing-meta">
                        <ul>
                            <li class="old-price not-cut">
                                {{ currencyFormat($products->sale_price ?? '0.00') }} </li>
                        </ul>
                    </div>
                    {{-- <p> {{ $products->products_description ?? 'No Description' }} </p> --}}

                    {{-- <div class="pro-details-list">
                      <ul>
                        <li>- 0.5 mm Dail</li>
                        <li>- Inspired vector icons</li>
                        <li>- Very modern style</li>
                      </ul>
                    </div> --}}



                    @if (webFunctionStatus(config('constkey.is_cart_enabled')) ||
                        webFunctionStatus(config('constkey.is_enquiry_enabled')))

                        <div class="product-variants js-product-variants">


                            @if (!empty($products->productAttribute))
                                @foreach ($products->productAttribute as $attribute)
                                    <?php //print_r($attribute)
                                    ?>
                                    <div class="clearfix product-variants-item">

                                        <span class="control-label">{{ ucfirst($attribute->option_name ?? '') }} :
                                        </span>


                                        @if (isset($attribute->option_value_list) && !empty($attribute->option_value_list))
                                            <ul id="attributes_{{ $attribute->options_id }}">

                                                @foreach ($attribute->option_value_list as $idx => $option_value)
                                                    <li class="input-container float-sm-start">
                                                        <label>
                                                            {{--  --}}
                                                            <input class="input-radio" type="radio"
                                                                data-product-attribute="{{ $attribute->options_id }}"
                                                                name="attributes_{{ $attribute->options_id }}"
                                                                {{ $idx == 0 ? 'checked' : '' }}
                                                                value="{{ $option_value->options_values_id }}"
                                                                title="{{ $option_value->productOptionsValue->products_options_values_name }}">
                                                            <span
                                                                class="radio-label">{{ $option_value->productOptionsValue->products_options_values_name }}</span>
                                                        </label>
                                                    </li>
                                                @endforeach

                                            </ul>
                                        @endif
                                    </div>
                                @endforeach
                            @endif

                        </div>

                        <div class="pro-details-quality">
                            <!-- show cart button -->
                            @if (webFunctionStatus(config('constkey.is_cart_enabled')))
                                <div class="cart-plus-minus">
                                    <input class="cart-plus-minus-box" type="text" id="qtyItemAdd" name="qtybutton"
                                        value="1" />
                                </div>
                                <div class="pro-details-cart btn-hover"> <a href="javascript:void(0);"
                                        onclick="addToCartFromDetail({{ $products->product_id }})"> +
                                        Add To Cart </a> </div>
                            @endif
                            <!-- show enquiry button -->
                            @if (webFunctionStatus(config('constkey.is_enquiry_enabled')))
                                <div class="pro-details-cart btn-hover"> <a href="javascript:void(0);"
                                        onclick="showEnquiryForm()"> Enquiry Now </a> </div>
                            @endif
                        </div>
                    @endif

                    @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))
                        <div class="pro-details-wish-com">
                            <div class="pro-details-wishlist"> <a href="javascript:void(0);"
                                    onclick="addToWishListFromDetail({{ $products->product_id }})"><i
                                        class="ion-android-favorite-outline"></i>Add to wishlist</a> </div>
                        </div>
                    @endif

                    @if (in_array(config('constkey.section_social_share'), $cKey))
                        <div class="pro-details-social-info"> <span>Share</span>
                            <div class="social-info">
                                <ul>
                                    <li> <a href="https://www.facebook.com/sharer/sharer.php?u={{ $currentURL }}"
                                            target="_blank"><i class="ion-social-facebook"></i></a> </li>
                                    <li> <a href="https://twitter.com/intent/tweet?text={{ $currentURL }}"
                                            target="_blank"> <i class="ion-social-twitter"></i></a> </li>
                                    {{-- <li> <a href="https://www.instagram.com/?url={{$currentURL}}" target="_blank"><i
                                            class="ion-social-instagram"></i></a> </li> --}}
                                    <li> <a href="https://api.whatsapp.com/send?text={{ $currentURL }}"
                                            target="_blank"><i class="ion-social-whatsapp"></i></a> </li>
                                </ul>
                            </div>
                        </div>
                    @endif

                    @if (!empty($returnpolicy))
                        <div class="pro-details-policy">
                            <ul>
                                <li> <img src="{{ LoadAssets('assets/images/icons/policy.png') }}"
                                        onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                                        alt="" />
                                    @foreach ($returnpolicy as $policy)
                                        <span> {{ $policy->return_policy_text }}</span>
                                    @endforeach


                                </li>
                            </ul>
                        </div>
                    @endif

                </div>
            </div>
        </div>
    </div>
</section>

<!-- Shop details Area End -->
<!-- product details description area start -->
<div class="description-review-area mb-60px">
    <div class="container">
        <div class="description-review-wrapper">
            <div class="description-review-topbar nav"> <a data-bs-toggle="tab" href="#des-details1">Description</a> <a
                    class="active" data-bs-toggle="tab" href="#des-details2">Product Details</a>

                @if (in_array(config('constkey.section_review'), $cKey))
                    <a data-bs-toggle="tab" id="read_review" href="#des-details3">Reviews</a>
                @endif

            </div>
            <div class="tab-content description-review-bottom">
                <div id="des-details2" class="tab-pane active">
                    <div class="product-anotherinfo-wrapper">

                        @if (!empty($products) && in_array($products->product_type_id, ['1', '2', '4']))
                            <ul>
                                <li><span>Product Sku</span>{{ $products->product_sku }}</li>
                                <li><span>Product Model</span>{{ $products->product_model }}</li>
                                <li>
                                    <span>Product
                                        Condition</span>{{ $products->product_condition == 1 ? 'New' : 'Refurbished' }}
                                </li>
                                <li><span>Brand
                                        Name</span>{{ !empty($products->products_to_brand) ? $products->products_to_brand->brand_name : '' }}
                                </li>
                                @if (!empty($products->products_to_features) && sizeof($products->products_to_features) > 0)
                                    @foreach ($products->products_to_features as $featKey => $featVal)
                                        <li><span>{{ $featVal->feature_title ?? '' }}</span>{{ $featVal->feature_value ?? '' }}
                                        </li>
                                    @endforeach
                                @endif
                            </ul>
                        @endif
                    </div>
                </div>
                <div id="des-details1" class="tab-pane">
                    <div class="product-description-wrapper">
                        <p>{!! $products->products_description ?? ' Message is None' !!}</p>
                    </div>
                </div>
                <div id="des-details3" class="tab-pane">
                    <div class="row">
                        @if (!$review_data->isEmpty())
                            <div class="col-lg-7">

                                <div class="review-wrapper">
                                    @foreach ($review_data as $key => $data)
                                        <div class="single-review ty-compact-list">
                                            <div class="review-img">
                                                <img src="{{ asset('Image/default_user.png') }}"
                                                    onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                                                    alt="" style="height:80px;width:80px;" />
                                            </div>
                                            <div class="review-content">
                                                <div class="review-top-wrap">
                                                    <div class="review-left">
                                                        <div class="review-name">
                                                            <h4><b>{{ $data->customers_name }}</b></h4>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="review-bottom">
                                                    <p> {{ $data->reviews_text }} </p>
                                                </div>
                                                <div class="rating-product"> <span><b>Quality Rating:</b></span>
                                                    @php
                                                        $j = 0;
                                                        for ($i = 0; $i < $data->quality_rating; $i++) {
                                                            echo '<i class="ion-android-star"></i>';
                                                            $j++;
                                                        }
                                                        for ($k = 5; $k > $j; $k--) {
                                                            echo '<i class="ion-android-star-outline"></i>';
                                                        }
                                                    @endphp </div>
                                                <div class="rating-product"><span><b>Price Rating:</b></span>
                                                    @php
                                                        $j = 0;
                                                        for ($i = 0; $i < $data->price_rating; $i++) {
                                                            echo '<i class="ion-android-star"></i>';
                                                            $j++;
                                                        }
                                                        for ($k = 5; $k > $j; $k--) {
                                                            echo '<i class="ion-android-star-outline"></i>';
                                                        }
                                                    @endphp </div>
                                            </div>
                                        </div>
                                    @endforeach
                                    <div type="button" class="btn show-more"
                                        style="background-color:red;color:white;border-radius:3px;display:none;">Show
                                        more </div>
                                </div>

                            </div>
                        @endif
                        <div class="col-lg-5">
                            <div class="ratting-form-wrapper pl-50">
                                <h3><b>Add a Review</b></h3>
                                <br />
                                <div class="ratting-form">
                                    <form id="reviewform">
                                        <div class="star-box"> <span>Quality Rating:</span>
                                            <div class="rate">
                                                <input type="radio" id="star5" name="quality_rating"
                                                    class="quality_rating" value="5" />
                                                <label for="star5" title="text">5 stars</label>
                                                <input type="radio" id="star4" name="quality_rating"
                                                    class="quality_rating" value="4" />
                                                <label for="star4" title="text">4 stars</label>
                                                <input type="radio" id="star3" name="quality_rating"
                                                    class="quality_rating" value="3" />
                                                <label for="star3" title="text">3 stars</label>
                                                <input type="radio" id="star2" name="quality_rating"
                                                    class="quality_rating" value="2" />
                                                <label for="star2" title="text">2 stars</label>
                                                <input type="radio" id="star1" name="quality_rating"
                                                    class="quality_rating" value="1" />
                                                <label for="star1" title="text">1 star</label>
                                            </div>
                                            <span class="text-danger" id="quality_rating"></span>
                                        </div>
                                        <div class="star-box"> <span>Price Rating:</span>
                                            <div class="rate">
                                                <input type="radio" id="stars5" name="price_rating"
                                                    class="price_rating" value="5" />
                                                <label for="stars5" title="text">5 stars</label>
                                                <input type="radio" id="stars4" name="price_rating"
                                                    class="price_rating" value="4" />
                                                <label for="stars4" title="text">4 stars</label>
                                                <input type="radio" id="stars3" name="price_rating"
                                                    class="price_rating" value="3" />
                                                <label for="stars3" title="text">3 stars</label>
                                                <input type="radio" id="stars2" name="price_rating"
                                                    class="price_rating" value="2" />
                                                <label for="stars2" title="text">2 stars</label>
                                                <input type="radio" id="stars1" name="price_rating"
                                                    class="price_rating" value="1" />
                                                <label for="stars1" title="text">1 star</label>
                                            </div>
                                            <span class="text-danger" id="price_rating"></span>
                                        </div>
                                        <div class="row"> @guest
                                                <div class="col-md-6">
                                                    <div class="rating-form-style mb-10">
                                                        <input placeholder="Enter Your Name Here.." type="text"
                                                            name="customers_name" class="customers_name" />
                                                    </div>
                                                    <span class="text-danger" id="customers_name"></span>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="rating-form-style mb-10">
                                                        <input placeholder="Enter Your Email Here.." type="email"
                                                            name="customers_email" class="customers_email" />
                                                    </div>
                                                    <span class="text-danger" id="customers_email"></span>
                                                </div>
                                            @endguest
                                            <div class="col-md-12">
                                                <div class="rating-form-style mb-10">
                                                    <input placeholder="Enter Your Review Title Here.." type="text"
                                                        name="reviews_title" class="reviews_title" required />
                                                </div>
                                                <span class="text-danger" id="reviews_title"></span>
                                            </div>
                                            <input type="hidden" value="{{ $products->product_id }}"
                                                class="products_id" name="products_id">
                                            <input type="hidden" value="0" name="reviews_read">
                                            <div class="col-md-12">
                                                <div class="rating-form-style form-submit">
                                                    <textarea placeholder="Enter Your Review" name="reviews_text" class="reviews_text" required></textarea>
                                                    <span class="text-danger" id="reviews_text"></span>
                                                    <input type="submit" id="reviewformbutton" value="Submit" />
                                                </div>
                                            </div>
                                            <ul id="successlist">
                                            </ul>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- product details description area end -->
<!-- Recent Add Product Area Start -->
@if (in_array(config('constkey.section_related'), $cKey))

    @if (!$related_data->isEmpty())
        <section class="recent-add-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <!-- Section Title -->
                        <div class="section-title">
                            <h2>You Might Also Like</h2>
                            <p>Add Related products to weekly line up</p>
                        </div>
                        <!-- Section Title -->
                    </div>
                </div>
                <!-- Recent Product slider Start -->
                <div class="recent-product-slider owl-carousel owl-nav-style">
                    <!-- Single Item -->

                    @foreach ($related_data as $key => $product)
                        <x-theme1.shared-component.product viewtype="grid" :data="$product" />
                    @endforeach
                    <!-- Single Item -->
                </div>
                <!-- Recent product slider end -->
            </div>
        </section>
    @endif

@endif
<!-- Recent product area end -->

<!--Starting of Enquiry Form Modal-->
@if (webFunctionStatus(config('constkey.is_enquiry_enabled')))
    <div class="modal fade enquiry-form" id="EnquiryModal" tabindex="-1" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog prdtmodal-dialog">
            <div class="modal-content">
                <div class="row pt-4">
                    <div class="col-md-12 pb-1">
                        <button type="button" class="btn-close prdtbtn-close" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                    </div>
                    <h3 class="text-center text-uppercase enquiry_heading">Enquiry Form</h3>
                </div>
                <div class="container">
                    <form id="enquiryform" class="enquiryformdata required needs-validation" method="POST"
                        enctype="multipart/form-data" novalidate>
                        <input type="hidden" id="products_id" name="products_id"
                            value="{{ $products->product_id }}">

                        <div class="row modal-body">
                            <div class="row">
                                <div class="col-md-6 col-12 py-2">
                                    <input type="text" name="customers_name" id="enqcustomers_name"
                                        class="form-control enquiry_form " placeholder="Your Name" required>
                                        <div class="invalid-feedback">
                                            Please enter your name.
                                          </div>
                                    <span class="text-danger customers_name_enq"></span>
                                </div>
                                <div class="col-md-6 col-12 py-2">
                                    <input type="email" class="form-control enquiry_form " name="email_address"
                                        id="email_address" placeholder="Your Email" aria-label="email" required>
                                        <div class="invalid-feedback">
                                            Please enter your email.
                                        </div>
                                    <span class="text-danger email_address_enq"></span>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-12 py-2 ">
                                    <input type="text" class="form-control enquiry_form" name="phone" id="phone" placeholder="Phone">
                                </div>
                                {{-- <div class="col-md-6 col-12 py-2">
                                    <input type="text" name="company_name" id="company_name"
                                        class="form-control enquiry_form " placeholder="Company Name" required>
                                    <span class="text-danger customers_name_enq"></span>
                                </div> --}}
                                <div class="col-md-6 col-12 py-2">
                                    <input type="number" class="form-control enquiry_form " name="products_qty"
                                        id="products_qty" placeholder="Qty Needed" aria-label="qty" required>
                                        <div class="invalid-feedback">
                                            Please enter product quantity.
                                        </div>
                                    <span class="text-danger products_qty_enq"></span>
                                </div>
                            </div>
                            <div class="row">
                                @php $max_option_id =0 @endphp
                                @if (!empty($products->productAttribute))

                                    @foreach ($products->productAttribute as $attribute)
                                        @if (isset($attribute->option_value_list) && !empty($attribute->option_value_list))
                                            @php
                                                
                                                if ($max_option_id < $attribute->options_id) {
                                                    $max_option_id = $attribute->options_id;
                                                }
                                                
                                            @endphp
                                            <div class="col-md-6 col-12 py-2">
                                                <select aria-label="Default select example"
                                                    name="attribute_{{ $attribute->options_id }}"
                                                    id="{{ $attribute->options_id }}"
                                                    style="width:100%; height: 38px !important;  padding:0 8px"
                                                    class="enquiry_form" required>
                                                    <option selected="" disabled="">Select
                                                        {{ ucfirst($attribute->option_name ?? '') }}</option>
                                                    @foreach ($attribute->option_value_list as $option_value)
                                                        <option value="{{ $option_value->options_values_id }}">
                                                            {{ $option_value->productOptionsValue->products_options_values_name }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        @endif
                                    @endforeach

                                @endif
                            </div>
                            <input type="hidden" id="products_id" name="max_option_id"
                                value="{{ $max_option_id }}">

                            <div class="row">
                                <div class="col-md-12 col-12 py-2">
                                    <textarea type="text" name="message" id="message" class="form-control enquiry_form "
                                        placeholder="Enquiry Message" aria-label="Enquiry Message" style="height:100px;"></textarea>
                                    <span class="text-danger message_enq"></span>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-7 col-12 py-2">
                                    <input class="form-control enquiry_form " name="enquiry_file" id="enquiry_file"
                                        type="file" placeholder="Enquiry File">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-7 col-12 py-2">
                                    <input type="checkbox" name="newsletter" checked id="myCheck">
                                    <label for="myCheck">Get Latest Update</label>
                                </div>
                                <div class="col-md-5 col-12 py-2">
                                    <div class="txt-right prdttxt-right">
                                        <button type="submit" class="btn enquiry_btn"
                                            id="enquirymodalformbutton">Submit</button>
                                        <input type="reset" hidden="">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endif

@push('scripts')
    <script>
        $(document).on('click', '#enquirymodalformbutton', function(e) {
            e.preventDefault();
            $('#enquiryform').addClass('was-validated');
            if ($('#enquiryform')[0].checkValidity() === false) {
                event.stopPropagation();
            } else {
                let enquiryform = document.getElementById('enquiryform');
                let formData = new FormData(enquiryform);
                var URL = window.location.href;
                var arr = URL.split('/');
                formData.append('page_source', arr.pop());

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "/storeProductEnquiry",
                    data: formData,
                    dataType: "json",
                    contentType: false,
                    cache: false,
                    processData: false,
                    beforeSend: function() {
                        $("#enquirymodalformbutton").addClass('disabled');
                        var html = '<i class="fa-solid fa-spinner fa-spin-pulse"></i> Submitting...';
                        $("#enquirymodalformbutton").html(html);
                    },
                    success: function(response) {
                        console.log(response);
                        if (response.status == 400) {
                            $.each(response.error, function(key, err_val) {
                                $('.' + key + '_enq').text(err_val);
                            });
                        } else {
                            $('#enquiryform').trigger("reset");
                            $('#EnquiryModal').modal('hide');
                            Notify('Send Successfully', true);
                        }
                    },
                    complete: function(response) {
                        $('#enquirymodalformbutton').removeClass('disabled');
                        $('#enquiryform').removeClass('was-validated');
                        $('#enquirymodalformbutton').html('Submit');
                    }

                });
            }

        });




        // Ending of Enquiry Form Modal


        let detail_choosen_attributes = [];
        

        function addToCartFromDetail(product_id) {

            var qtyItemAdd = $('#qtyItemAdd').val();
            let attributes = detail_choosen_attributes.join(',');
            if (attributes == '') {

                $('input[type="radio"]:checked').each(function() {
                    if (!detail_choosen_attributes.includes(this.value)) {
                        detail_choosen_attributes.push(this.value);
                    }
                    console.log(detail_choosen_attributes);
                });
                let attributes = detail_choosen_attributes.join(',');

                addToCart(product_id, qtyItemAdd, attributes);
            } else {
                addToCart(product_id, qtyItemAdd, attributes);
            }

        }

        $('.input-radio').on('click', function() {
            detail_choosen_attributes = [];
            var ele = $('input');
            for (i = 0; i < ele.length; i++) {
                if (ele[i].checked)
                    if (!detail_choosen_attributes.includes(ele[i].value)) {
                        if($.isNumeric(ele[i].value))
                        detail_choosen_attributes.push(ele[i].value);
                    }
                    //console.log(detail_choosen_attributes);
            }

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            var data = {
                'product_id': $('#products_id').val(),
                'options_values_id': $(this).attr("value"),
                'options_id': $(this).attr("data-product-attribute"),
            }

            $.ajax({
                type: "POST",
                url: "/attribute-price",
                data: data,
                dataType: "json",
                success: function(response) {
                    $(".old-price").html("");
                    $(".old-price").append(response);
                }
            });

        });

        var enqdetail_choosen_attributes = [];
        var choosen_attributes_ary = [];

        function enqchooseAttributes(params, opid) {
            choosen_attributes_ary = [];
            enqdetail_choosen_attributes[opid] = params.value;

            // Now it can be used reliably with $.map()
            $.map(enqdetail_choosen_attributes, function(val, i) {
                if (val > 0)
                    choosen_attributes_ary.push(val);
            });

        }

        // function chooseAttributes(param) {
        //     // option to price
        // }


        $(document).ready(function() {
            //alert('hello');
            $(document).on('click', '#reviewformbutton', function(e) {
                e.preventDefault();

                var data = {
                    'customers_name': $('.customers_name').val(),
                    'customers_email': $('.customers_email').val(),
                    'quality_rating': $('.quality_rating:checked').val(),
                    'price_rating': $('.price_rating:checked').val(),
                    'reviews_title': $('.reviews_title').val(),
                    'products_id': $('.products_id').val(),
                    'reviews_read': $('.reviews_read').val(),
                    'reviews_text': $('.reviews_text').val(),

                }

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "/storereview",
                    data: data,
                    dataType: "json",
                    success: function(response) {
                        // console.log(response);
                        if (response.status == 400) {
                            //design

                            $.each(response.error, function(key, err_val) {
                                $('#' + key).text(err_val);
                            });
                        } else {
                            $('#successlist').html("");
                            Notify('Thank For Review Us', true);
                            $('#reviewform').trigger("reset");
                        }
                    }

                });
            });
        });

        // Show more jquery

        if ($('.ty-compact-list').length > 3) {
            $('.ty-compact-list:gt(2)').hide();
            $('.show-more').show();
        }
        $('.show-more').on('click', function() {
            $('.ty-compact-list:gt(2)').toggle();
            $(this).text() === 'Show more' ? $(this).text('Show less') : $(this).text('Show more');
        });

        // <!--End of Enquiry Form Ajax-->

       
    </script>
@endpush
