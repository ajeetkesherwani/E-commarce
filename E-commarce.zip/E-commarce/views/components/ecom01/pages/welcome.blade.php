<!--
    templateComponentKey : consit all key of component
    foreach : to shoq itemm in sort order that's why we run loop inside loop we
    if() : check each step and verify key
 -->
@php
$home_page_middle_group_1= bannerKey('home_page_middle_banner_1');
$home_page_middle_group_2= bannerKey('home_page_middle_banner_2');

// Banner-1
$banner_group_size1=12;
$count=count($home_page_middle_group_1);
if($count>0)
{
$banner_group_size1=$banner_group_size1/$count;
}
else {
$banner_group_size1=12;
}

// Banner-2
$banner_group_size2=12;

$count=count($home_page_middle_group_2);
if($count>0)
{
$banner_group_size2=$banner_group_size2/$count;
}
else {
$banner_group_size2=12;
}

use App\Models\Ecom\Services\EcomService;

@endphp


@if(!empty($templateComponentKey))
@foreach ($templateComponentKey as $templateComponentKey)
@switch($templateComponentKey->component_key)
@case($templateComponentKey->component_key == config('constkey.home_slider'))
<!-- Slider Arae Start -->
<div class="slider-area">
    <div class="slider-active-3 owl-carousel slider-hm8 owl-dot-style">
        @php
        $slider_data= bannerKey('home_page_slider','slider');
        @endphp
        @if(!empty($slider_data))
        @foreach($slider_data as $key=>$data)
        <a href="{{$data->banners_url}}">
            <div class="slider-height-10 d-flex align-items-start justify-content-start bg-img"
                style="background-image: url({{$data->image ?? $data->banners_title }});">
            </div>
        </a>
        @endforeach
        @endif
    </div>
</div>
<!-- Slider Arae End -->

@break

@case($templateComponentKey->component_key == config('constkey.popular_category'))
@if (!empty($popular_category) && sizeof($popular_category) > 0 )
<!-- Category Area Start -->
<section class="categorie-area categorie-area-2 ptb-70px">
    <div class="container pb-3">
        <div class="row">
            <div class="col-md-12 text-center">
                <!-- Section Title -->
                <div class="section-title mt-res-sx-30px mt-res-md-30px underline-shape">
                    <h2>{{ translation('POPULAR_CATEGORIES') }}</h2>
                    <p>{{ translation('ADD_POPULAR_CATEGORIES_TO_WEEK') }}</p>
                </div>
                <!-- Section Title -->
            </div>
        </div>
        <!-- Category Slider Start -->
        <div class="category-slider-2 owl-carousel owl-nav-style-3">
            <!-- Single item -->
            @foreach($popular_category as $key=>$value)
            <div class="category-item">
                <div class="category-list">
                    <div class="category-thumb">
                        <a href="{{ EcomService::url($value->categories_id , 'category')}}">
                            <img src="{{getFullImageUrl($value->categories_image)}}"
                                alt="{{$value->category_name ?? ''}}"
                                onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" />
                        </a>
                    </div>
                    <div class="desc-listcategoreis">
                        <div class="name_categories">
                            <h4>{{$value->category_name ?? 'Test cat'}}</h4>
                        </div>
                        <a href="{{url('category/'.$value->categories_slug)}}"> Shop Now <i
                                class="ion-android-arrow-dropright-circle"></i></a>
                    </div>
                </div>
            </div>
            @endforeach
            <!-- End of Single item -->
        </div>
    </div>
</section>
<!-- Category Area End  -->


@endif
@break



@case($templateComponentKey->component_key == config('constkey.home_banner_1'))

<!-- Banner Area Start -->
@if(!empty($home_page_middle_group_1))
<div class="banner-3-area mt-0px mb-100px">
    <div class="container pt-3">
        <div class="row">
            @if(!empty($home_page_middle_group_1))
            @foreach($home_page_middle_group_1 as $home_page_middle_group_1_Val)
            <div
                class="col-lg-{{$banner_group_size1}} col-md-{{$banner_group_size1}} col-sm-12 col-xs-12 mb-res-xs-30 mb-res-sm-30">
                <div class="banner-wrapper banner-box">
                    <a href="{{$home_page_middle_group_1_Val->banners_url}}"><img
                       src="{{$home_page_middle_group_1_Val->image}}"
                       onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                       alt="{{getSetting('site_title')}}-{{$home_page_middle_group_1_Val->banners_title}}" /></a>
                </div>
            </div>
            @endforeach
            @endif
        </div>
    </div>
</div>
@endif

@break

@case($templateComponentKey->component_key == config('constkey.feature_product'))

<!-- featured-group -->
@if(!empty($featureGroupList))
@foreach($featureGroupList as $featureGroup)
@if(!empty($featureGroup->featured_product) && sizeof($featureGroup->featured_product) > 0 )
<section class="recent-add-area mt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <!-- Section Title -->
                <div class="section-title underline-shape">
                    <h2>{{translation($featureGroup->group_name)}}</h2>
                    <p>{{translation($featureGroup->group_title)}}</p>
                </div>
                <!-- Section Title -->
            </div>
        </div>
        <!-- Recent Product slider Start -->
        <div class="best-sell-slider owl-carousel owl-nav-style-3">
            <!-- Product Single Item -->

            @foreach ($featureGroup->featured_product as $featured_product )
            @if(!empty($featured_product->product))
            <x-ecom01.shared-component.product viewtype="grid" :data="$featured_product->product" />
            @endif
            @endforeach
        </div>
        <!-- Recent Area Slider End -->
    </div>
</section>
@endif
@endforeach
@endif
<!-- end feature group -->
@break

@case($templateComponentKey->component_key == config('constkey.home_banner_2'))

<!-- Banner Area Start -->
@if(!empty($home_page_middle_group_2))
<div class="banner-3-area mt-0px mb-100px">
    <div class="container pt-3">
        <div class="row">
            @if(!empty($home_page_middle_group_2))
            @foreach($home_page_middle_group_2 as $home_page_middle_group_2_Val)
            <div
                class="col-lg-{{$banner_group_size2}}  col-md-{{$banner_group_size2}} col-sm-12 col-xs-12 mb-res-xs-30 mb-res-sm-30">
                <div class="banner-wrapper banner-box">
                    <a href="{{$home_page_middle_group_2_Val->banners_url}}"><img
                            src="{{$home_page_middle_group_2_Val->image}}"
                            onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                            alt="{{getSetting('site_title')}}-{{$home_page_middle_group_2_Val->banners_title}}" /></a>
                </div>
            </div>
            @endforeach
            @endif
        </div>
    </div>
</div>
@endif

@break

@case($templateComponentKey->component_key == config('constkey.home_blog'))
<!-- Blog area Start -->
@if (!empty($blog) && sizeof($blog)>0 )
<section class="blog-area mb-30px">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <!-- Section title -->
                <div class="section-title underline-shape mt-50">
                    <h2>{{ translation('LATEST_BLOGS') }}</h2>
                    <p>{{translation('BLOG_DESCRIPTION') }}</p>
                </div>
                <!-- Section title -->
            </div>
        </div>
        <!-- Blog Slider Start -->
        <div class="blog-slider-active owl-carousel owl-nav-style-3">
            <!-- single item -->
            @foreach ($blog as $blog)
            <x-Ecom01.SharedComponent.PostGrid :data="$blog" />
            @endforeach
            <!-- single item -->
        </div>
        <!-- Blog Slider Start -->
    </div>
</section>
<!-- Blog Area End -->
@endif

@break

@case($templateComponentKey->component_key == config('constkey.website_feature'))

<!-- website feature tag -->
@if(!empty($web_features))
<section class="static-area mtb-60px">
    <div class="container">
        <div class="static-area-wrap">
            <div class="row">
                <!-- Static Single Item Start -->
                @foreach($web_features as $key=>$feature_data)
                <div class="col-lg-3 col-xs-12 col-md-6 col-sm-6">
                    <div class="single-static pb-res-md-0 pb-res-sm-0 pb-res-xs-0">
                        <img src="{{getFullImageUrl($feature_data->feature_icon)}}"
                            alt="{{getSetting('site_title')}}-{{$feature_data->feature_title}}"
                            onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                            class="img-responsive" />
                        <div class="single-static-meta">
                            <h4>{{$feature_data->feature_title}}</h4>
                            <p>{{$feature_data->feature_subtitle}}</p>
                        </div>
                    </div>
                </div>
                @endforeach
                <!-- Static Single Item End -->
            </div>
        </div>
    </div>
</section>
@endif
<!--end  website feature tag -->
@break

@case($templateComponentKey->component_key == config('constkey.home_testimonial'))
<!-- Testimonial Area Start -->
@if($webTestimonialList->isNotEmpty())
<section class="testimonial-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <!-- Section Title -->
                <div class="section-title" style="color: white;">
                    <h2 class="text-white text-center text-uppercase" style="font-size: 24px;">Client Testimonials</h2>
                    <p class="text-white text-center text-uppercase">What our happy customers says !</p>
                </div>
                <!-- Section Title -->
            </div>
        </div>
        <!-- Testimonial Slider Start -->
        <div class="testi-slider owl-carousel owl-dot-style">
            <!-- Single item -->
            @foreach($webTestimonialList as $key=>$data)
            <div class="testi-slider-wrapper">
                <div class="testi-slider-inner">
                    <div class="testi-img">
                        {{-- <img src="{{LoadAssets('assets/images/testimonial-image/1.png')}}" alt="" /> --}}
                        <img src="{{ $data->user_data->profile_photo ?? 'https://cdn.pixabay.com/photo/2020/07/01/12/58/icon-5359553_960_720.png' }}"
                            onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                            alt="{{getSetting('site_title')}}-User" />
                    </div>
                    <div class="testi-content">
                        <div class="testi-content-text">
                            {{$data->testimonial_text}}
                        </div>
                        <div class="author-text">
                            <h4>{{ !empty($data->user_data) ? $data->user_data->first_name : '' }} {{!empty($data->user_data) ? $data->user_data->last_name : ''}}
                            <span>
                                {{!empty($data->user_data) ? $data->user_data->email : ''}}</span>
                            </h4>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
            <!-- Single item -->
        </div>
        <!-- Testimonial Slider End -->
    </div>
</section>
@endif
<!-- Testimonial Area end -->

@break

@case($templateComponentKey->component_key == config('constkey.home_brand'))
<!-- Brand area start -->
@if(!empty($brand_data))
<div class="brand-area">
    <div class="container">
        <div class="brand-slider owl-carousel owl-nav-style owl-nav-style-2">
            @foreach($brand_data as $key=>$data)
            <div class="brand-slider-item">
                <a href="{{url('brand/'.$data->brand_slug)}}">
                    <img src="{{getFullImageUrl($data->brand_icon)}}"
                        onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                        alt="{{$data->brand_name}}" /></a>
            </div>
            @endforeach
        </div>
    </div>
</div>
@endif
<!-- Brand area end -->
@break

@endswitch
@endforeach
@endif


<!--Starting of Newslatter Modal-->
<div class="modal newsmodal" id="onloadModal">
    {{-- <div class="modal-dialog newslatter_modal_dialog">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header">
                <section class="pop-up-from">
                    <div class="content newsmodal">

                    </div>
                </section>
                <button type="button" class="btn-close" id="btnnewslatter" data-bs-dismiss="modal"></button>
            </div>
        </div>
    </div> --}}
</div>


<!--Ending of NewsLatter Modal-->


@push('scripts')
<script>
    $(document).ready(function () {
        //alert('hello');
        $(document).on('click', '#modal_subscribe', function (e) {
            e.preventDefault();
            var data = {
                // 'company_name': $('#companyname').val(),
                // 'customer_name': $('#customername').val(),
                'customer_email': $('#customeremail').val(),
            }
            console.log(data);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "/newslatterstore",
                data: data,
                dataType: "json",
                success: function (response) {

                    if (response.status == 400) {
                        $('#email_err').text(response.error.customer_email);
                    }
                    else {
                        $('#onloadModal').modal('hide');
                        Notify("Subscribed Successfully", true);

                    }
                }
            });
        });
    });


// $("#btnnewslatter").click(function () {
// $('#onloadModal').fadeOut('slow');
//     });

</script>
@endpush