@php

$main_arr = [
'title' =>translation('CHECKOUT_PAGE'),
'sublist' => [
[
'name' => translation('HOME'),
'link' => url('/'),
],
[
'name' => translation('CHECKOUT'),
'link' =>url()->full()
],
],
];
@endphp

<x-Ecom01.SharedComponent.BreadCrumb :data="$main_arr" />
<!-- Breadcrumb Area End -->
<!-- checkout area start -->
<div class="checkout-area mt-60px mb-40px">
    <div class="container">
        <form action="{{route('placeOrder')}}" method="POST" id="placeOrderForm" novalidate="novalidate">
            @csrf
            <div class="row">
                <div class="col-lg-8 ">
                    <div class="billing-info-wrap p-md-5 p-2 py-3 pb-md-3 bg-white rounded billing-info-section">
                
                        <div class="d-flex justify-content-between">
                            <h3>{{translation('BILLING_DETAILS_TITLE')}}</h3>
                            @if(!empty($addressList) && sizeof($addressList) > 0)
                            <div>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#newAddressModal">
                                <i class="fa fa-plus"></i> 
                                {{translation('CHECKOUT_ADD_ADDRESS_BUTTON')}}
                                </button>
                            </div>
                            @endif
                        </div>

                        @if(!empty($addressList) && sizeof($addressList) > 0)
                        <div class="row  billing-wrapper">
                            <div class="col-md-12">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>{{translation('DEFAULT_ADDRESS')}}</th>
                                        </tr>
                                    </thead>
                                    <tbody id="addressListBox">
                                        @foreach ($addressList as $addrKey=>$addressList)
                                        <tr>
                                            <td class="d-flex gap-3">
                                                <input type="radio" name="address_id" class="default_address"
                                                    id="add_{{$addressList->address_id}}"
                                                    value='{{$addressList->address_id}}' @if($addressList->is_default=='1') checked @else @if($addrKey==0) checked @endif @endif/>
                                                <label for="add_{{ $addressList->address_id }}">
                                                    {{ $addressList->customer_name.','. $addressList->customer_email}},
                                                    {{ $addressList->street_address.','. $addressList->city.',
                                                    '.$addressList->state }},
                                                    {{ $addressList->country_name.'-'. $addressList->zipcode }},
                                                    {{ $addressList->phone}}
                                                </label>
                                            </td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                                            
                        @else

                        <div class="row pt-5">
                            <div class="col-lg-6 col-md-6">
                                <div class="billing-info mb-20px">
                                    <label>{{translation('CONTACT_NAME')}} <span class="text-danger">*</span></label>
                                    <input type="text" name="customer_name" class="form-control"
                                        value="{{old('customer_name')}}">
                                    @if ($errors->has('customer_name'))
                                    <span class="text-danger">{{ $errors->first('customer_name') }}</span>
                                    @endif
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="billing-info mb-20px">
                                    <label>{{translation('EMAIL')}}<span class="text-danger">*</span></label>
                                    <input type="email" name="customer_email" value="{{old('customer_email')}}"
                                        class="form-control">
                                    @if ($errors->has('customer_email'))
                                    <span class="text-danger">{{ $errors->first('customer_email') }}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-6 ">
                                <div class="billing-info mb-20px">
                                    <label>{{translation('PHONE')}}<span
                                            class="text-danger">*</span></label>
                                    <input type="text" name="customer_phone" value="{{old('customer_phone')}}" class="form-control">
                                    @if ($errors->has('customer_phone'))
                                    <span class="text-danger">{{ $errors->first('customer_phone') }}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="billing-info mb-20px">
                                    <label>{{translation('STREET_ADDRESS')}}<span class="text-danger">*</span></label>
                                    <input class="billing-address form-control" value="{{old('customer_address')}}"
                                        type="text" name="customer_address">
                                    @if ($errors->has('customer_address'))
                                    <span class="text-danger">{{ $errors->first('customer_address') }}</span>
                                    @endif
                                </div>

                            </div>

                            <div class="col-lg-6">
                                <div class="billing-info mb-20px">
                                    <label>{{translation('CITY')}}<span class="text-danger">*</span></label>
                                    <input type="text" name="customer_city" value="{{old('customer_city')}}"
                                        class="form-control">
                                    @if ($errors->has('customer_city'))
                                    <span class="text-danger">{{ $errors->first('customer_city') }}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-6 ">
                                <div class="billing-info mb-20px">
                                    <label>{{translation('STATE')}}<span class="text-danger">*</span></label>
                                    <input type="text" name="customer_state" value="{{old('customer_state')}}" />
                                    @if ($errors->has('customer_state'))
                                    <span class="text-danger">{{ $errors->first('customer_address') }}</span>
                                    @endif
                                </div>
                            </div>

                            @if(!empty($countries))
                            <div class="col-lg-6 ">
                                <div class="billing-info mb-20px">
                                    <label>{{translation('COUNTRY')}}<span class="text-danger">*</span></label>
                                    <select name="countries_id" class="nice-select ps-2">
                                        <option selected value="" disabled>
                                            {{translation('COUNTRY_PLACEHOLDER')}}
                                        </option>
                                        @foreach($countries as $key=>$country)
                                        <option value="{{$country->countries_id ?? ''}}" @if($Ipcountry->
                                            countries_id==$country->countries_id) selected
                                            @endif>{{$country->countries_name ?? ''}}</option>
                                        @endforeach
                                    </select>
                                    @if ($errors->has('countries_id'))
                                    <span class="text-danger">{{ $errors->first('countries_id') }}</span>
                                    @endif
                                </div>
                            </div>
                            @endif

                            <div class="col-lg-6 ">
                                <div class="billing-info mb-20px">
                                    <label>{{translation('ZIPCODE')}}<span class="text-danger">*</span></label>
                                    <input type="text" name="customer_postcode" value="{{old('customer_postcode')}}"
                                        class="form-control">
                                    @if ($errors->has('customer_postcode'))
                                    <span class="text-danger">{{ $errors->first('customer_postcode') }}</span>
                                    @endif
                                </div>
                            </div>
                        </div>

                        @endif

                        <div class="checkout-account mt-3">
                            <input class="checkout-toggle is_shipping_diff_box" type="checkbox" name="is_shipping_diff">
                            <label>{{translation('CHECKOUT_SHIP_DIFFRENT_ADDRESS')}}</label>
                        </div>

                        <div class="different-address open-toggle mt-30">
                            <div class="row">
                                <div class="col-lg-6 col-md-6">
                                    <div class="billing-info mb-20px">
                                        <label>{{translation('CONTACT_NAME')}}<span class="text-danger">*</span></label>
                                        <input type="text" name="shipping_customer_name"
                                            value="{{old('shipping_customer_name')}}" class="form-control">
                                        @if ($errors->has('shipping_customer_name'))
                                        <span class="text-danger">{{ $errors->first('shipping_customer_name') }}</span>
                                        @endif
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="billing-info mb-20px">
                                        <label>{{translation('EMAIL')}}<span
                                                class="text-danger">*</span></label>
                                        <input type="email" name="shipping_customer_email"
                                            value="{{old('shipping_customer_email')}}" class="form-control">
                                        @if ($errors->has('shipping_customer_email'))
                                        <span class="text-danger">{{ $errors->first('shipping_customer_email') }}</span>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-lg-6 ">
                                    <div class="billing-info mb-20px">
                                        <label>{{translation('PHONE')}}<span class="text-danger">*</span></label>
                                        <input type="text" name="shipping_customer_phone" class="form-control"
                                            value="{{old('shipping_customer_phone')}}" />
                                        @if ($errors->has('shipping_customer_phone'))
                                        <span class="text-danger">{{ $errors->first('shipping_customer_phone') }}</span>
                                        @endif
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="billing-info mb-20px">
                                        <label>{{translation('STREET_ADDRESS')}}<span
                                                class="text-danger">*</span></label>
                                        <input class="billing-address" value="{{old('shipping_customer_address')}}"
                                            type="text" name="shipping_customer_address" />
                                        @if ($errors->has('shipping_customer_address'))
                                        <span class="text-danger">{{ $errors->first('shipping_customer_address')}}</span>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="billing-info mb-20px">
                                        <label>{{translation('CITY')}}<span class="text-danger">*</span></label>
                                        <input type="text" name="shipping_customer_city"
                                            value="{{old('shipping_customer_city')}}" />
                                        @if ($errors->has('shipping_customer_city'))
                                        <span class="text-danger">{{ $errors->first('shipping_customer_city') }}</span>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-lg-6 ">
                                    <div class="billing-info mb-20px">
                                        <label>{{translation('STATE')}}<span class="text-danger">*</span></label>
                                        <input type="text" name="shipping_customer_state"
                                            value="{{old('shipping_customer_state')}}" />
                                        @if ($errors->has('shipping_customer_state'))
                                        <span class="text-danger">{{ $errors->first('shipping_customer_state') }}</span>
                                        @endif
                                    </div>
                                </div>
                                @if(!empty($countries))
                                <div class="col-lg-6 ">
                                    <div class="billing-info mb-20px">
                                        <label>{{translation('COUNTRY')}} <span class="text-danger">*</span></label>
                                        <select name="shipping_countries_id" class="nice-select ps-2" required>
                                            <option selected value="" disabled>
                                                {{translation('COUNTRY_PLACEHOLDER')}}
                                            </option>
                                            @foreach($countries as $key=>$country)
                                            <option value="{{$country->countries_id ?? ''}}" @if($Ipcountry->
                                                countries_id==$country->countries_id) selected @endif>
                                                {{$country->countries_name ?? ''}}</option>
                                            @endforeach
                                        </select>
                                    @if ($errors->has('shipping_customer_country'))
                                    <span class="text-danger">{{ $errors->first('shipping_customer_country') }}</span>
                                    @endif
                                    </div>
                                </div>
                                @endif
                                <div class="col-lg-6 ">
                                    <div class="billing-info mb-20px">
                                        <label>{{translation('ZIPCODE')}}<span class="text-danger">*</span></label>
                                        <input type="text" name="shipping_customer_postcode"
                                            value="{{old('shipping_customer_postcode')}}" />
                                        @if ($errors->has('shipping_customer_postcode'))
                                        <span class="text-danger">{{ $errors->first('shipping_customer_postcode')}}</span>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="additional-info-wrap">
                            <h4>{{translation('ADDITIONAL_INFORMATIONS')}}</h4>
                            <div class="additional-info">
                                <label>{{translation('CHECKOUT_ORDER_NOTE')}}</label>
                                <textarea placeholder="{{translation('ORDER_NOTE_PLACEHOLDER')}}" class="form-control"
                                    name="note"></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4  ">
                    <div class="your-order-area rounded pt-md-5 ">
                        <div class="your-order-wrap bg-transparent ">
                            <h3>{{translation('CHECKOUT_ORDER_TITLE')}}</h3>
                            <div class="your-order-product-info">
                                <div class="your-order-top">

                                    @if (!empty($list['cart_list']))
                                    @foreach ($list['cart_list'] as $cart )
                                    <div class="your-order-middle">
                                        <ul>
                                            <li>
                                                <div class="product_img">
                                                    <img src="{{getFullImageUrl($cart->product->product_image ?? '')}}"
                                                        onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                                                        class="img-fluid" alt="product_img">
                                                </div>

                                            </li>
                                            <li>
                                                <span class="order-middle-left">
                                                    {{ $cart->product->products_name ?? ''}}
                                                </span>
                                                <p>
                                                    <span class="order-price">
                                                        {{currencyFormat($cart->final_price??'')}}
                                                        <span class="order-quantity">
                                                            X {{ $cart->qty ??''}}
                                                        </span>
                                                    </span>
                                                </p>
                                            </li>
                                        </ul>
                                    </div>
                                    @endforeach
                                    @endif

                                    @if (!empty($shippingMethodList) && sizeof($shippingMethodList) > 0 )
                                    <div class="payment-method">
                                        <div class="payment-accordion element-mrg">
                                            <div class="panel-group" id="accordion">
                                                <div class="panel payment-accordion">
                                                    <div class="panel-heading" id="method-one">
                                                        <h4 class="panel-title my-2">
                                                            <a data-bs-toggle="collapse"
                                                                data-parent="#accordion">{{translation('SHIPPING_METHODS')}}
                                                            </a>
                                                        </h4>
                                                    </div>
                                                    @if(!empty($shippingMethodList))
                                                    <div id="method1" class="panel-collapse collapse show">
                                                        <div class="panel-body payment_section">
                                                            <div class="row">
                                                                @foreach ($shippingMethodList as
                                                                $shippingKey=>$shipping)
                                                                <div class="col-md-12 my-1">
                                                                    <div class="form-group d-flex">
                                                                        <input type="radio" name="shipping_method"
                                                                            class="ship-radio-choose"
                                                                            id="{{ $shipping->method_key }}_id"
                                                                            value="{{ $shipping->method_key }}"
                                                                            @if($shippingKey==0)checked @endif required>
                                                                        <label for="{{ $shipping->method_key }}_id"
                                                                            class="text-dark h6">{{$shipping->method_name}}</label>
                                                                        <div class="d-flex">
                                                                            <img src="{{getSuperFullImageUrl($shipping->method_logo)}}" alt="parment_img" class="img-round payment-img " onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" height="20">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                @endforeach
                                                            </div>
                                                        </div>
                                                    </div>
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    @else
                                    <input type="radio" name="shipping_method" value="cod">
                                    @endif

                                    <!-- Check Coupen in enabled or not -->
                                    @if (webFunctionStatus(config('constkey.is_coupon_enabled')))
                                    @if(!session()->has('coupon_id'))
                                    <div class="m-3" id="coupon_area">
                                        <div class="form-group">
                                            <div class="input-group" id="couponform_area">
                                                <input type="text" class="form-control coupon" id="coupon_code"
                                                    name="coupon_code"
                                                    placeholder="{{translation('COUPON_CODE_PLACEHOLDER')}}">
                                                <span class="input-group-append">
                                                    @auth
                                                    <a href="javascript:void(0)" id="applyButton"
                                                        class="btn btn-primary btn-apply coupon">{{translation('COUPON_APPLY_BUTTON')}}</a>
                                                    @endauth
                                                    @guest
                                                    <a href="javascript:void(0)" id="cpnbtn"
                                                        class="btn btn-primary btn-apply coupon">{{translation('COUPON_APPLY_BUTTON')}}</a>
                                                    @endguest
                                                </span>
                                            </div>
                                            <div class="alert alert-danger alert-dismissible fade" id="coupon_alert"
                                                role="alert">
                                                <strong class="coupon_error"></strong>
                                                <button type="button" class="btn-close coupon_alt_btn"
                                                    aria-label="Close"></button>
                                            </div>
                                        </div>
                                    </div>
                                    @endif
                                    @endif
                                    <!-- End of coupon-->

                                    <div class="your-order-total">
                                        <ul>
                                            <li>
                                                <h4>{{translation('CHECKOUT_PRODUCT_SUBTOTAL')}} :
                                                    <span>{{currencyFormat($list['total_product_price'])}}</span></h4>
                                                {{-- @foreach ($shippingMethodList as $shipKey=>$shipVal)
                                                @if($shipKey==0)
                                                <h4>Shipping : <span
                                                        id="shippingPrice">{{currencyFormat(getSetting($shipVal->shipmethodkey[0]->method_key
                                                        ?? ''))}}</span></h4>
                                                @endif
                                                @endforeach

                                                @foreach ($shippingMethodList as $shipKey=>$shipVal)
                                                @if($shipKey==0)
                                                <h4 class="shop-total fw-bold">Total :
                                                    <span>{{currencyFormat($list['grand_total'] +
                                                        getSetting($shipVal->shipmethodkey[0]->method_key ?? '')
                                                        )}}</span>
                                                </h4>
                                                @endif
                                                @endforeach --}}

                                                <div class="coupon_disc_amount">
                                                    @if (!empty($list['coupon_discount']))
                                                    <h4>{{translation('COUPON_DISCOUNT')}} 
                                                        <span>{{currencyFormat($list['coupon_discount'])}}</span></h4>
                                                    @endif
                                                </div>

                                                @if(getSetting('ENABLE_TAX')=='1')
                                                @if(getSetting('tax_type')=='exclusive')
                                                <div class="tax_block">
                                                    @foreach (tax_calculate($list['product_total'])[0] as
                                                    $tax_name=>$tax_prices)
                                                    <h4>{{$tax_name}} : <span>{{currencyFormat($tax_prices)}}</span>
                                                    </h4>
                                                    @endforeach
                                                </div>

                                                <h4>{{translation('CHECKOUT_PRODUCT_TOTAL')}} : <span
                                                        class="subtotal">{{currencyFormat(tax_calculate($list['product_total'])[1])}}</span>
                                                </h4>
                                                @else
                                                <h4>{{translation('CHECKOUT_PRODUCT_TOTAL')}} : <span
                                                        class="subtotal">{{currencyFormat($list['product_total'])}}</span>
                                                </h4>
                                                @endif
                                                @else
                                                <h4>{{translation('CHECKOUT_PRODUCT_TOTAL')}} : <span
                                                        class="subtotal">{{currencyFormat($list['product_total'])}}</span>
                                                </h4>
                                                @endif
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- payment -->
                                <div class="payment-method">
                                    <div class="payment-accordion element-mrg">
                                        <div class="panel-group" id="accordion">
                                            <div class="panel payment-accordion">
                                                <div class="panel-heading" id="method-one">
                                                    <h4 class="panel-title my-2">
                                                        <a data-bs-toggle="collapse" data-parent="#accordion">
                                                            {{translation('PAYMENT_TYPE')}}
                                                        </a>
                                                    </h4>
                                                </div>
                                                @if(!empty($paymentList))
                                                <div id="method1" class="panel-collapse collapse show">
                                                    <div class="panel-body payment_section">
                                                        <div class="row">
                                                            @foreach ($paymentList as $pkey=>$payment)
                                                            <div class="col-md-12 my-1">
                                                                <div class="form-group d-flex">
                                                                    <input type="radio" name="payment_method"
                                                                        class="payment-radio-choose payment-type"
                                                                        id="{{ $payment->method_key }}_id"
                                                                        value="{{ $payment->method_key }}" @if($pkey==0)
                                                                        checked @endif required>

                                                                    <label for="{{ $payment->method_key }}_id">{{
                                                                        $payment->method_name }}</label>
                                                                    <div class="d-flex">
                                                                        <img src="{{getSuperFullImageUrl($payment->method_logo)}}"
                                                                        alt="parment_img"
                                                                        class="img-round payment-img "
                                                                        onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                                                                        height="20">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            @endforeach
                                                        </div>
                                                    </div>
                                                </div>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- payment end -->
                            </div>
                            <div class="Place-order">
                                <button type="submit" value="Submit"
                                    class="btn-hover form-control">{{translation('PLACE_ORDER')}}</button>
                            </div>
                        </div>
                    </div>
                </div>
        </form>
    </div>

    <!-- Modals Start Here-->
    <!-- Login Form Start -->
    <div class="modal fade checkout-form-wrap" id="login-popup" tabindex="-1" aria-hidden="true">
        <input type="hidden" name="login_source" id="login_source" value="checkout">
        <div class="modal-dialog  modal-lg modal-dialog-centered">
            <div class="modal-content rounded shadow border-0">
                <div class="modal-body p-0">

                    <!--Login Start Here-->
                    <div class="container-fluid px-0 sub" id="sublogin">
                        <div class="row align-items-center g-0">

                            <div class="col-lg-12 col-md-12">
                                <div class="alert alert-dismissible fade login_alert d-none" role="alert">
                                    <strong id="alert_message">
                                        <!---here alert message come throw ajax  ---->
                                    </strong>
                                    <button type="button" class="btn-close login_alt_btn" aria-label="Close"></button>
                                </div>
                                
                                <div class="modal-header p-4">
                                    <h5 class="modal-title">{{translation('LOGIN_TITLE')}}</h5>

                                    <button type="button" class="btn-close btn-close prdtbtn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>

                                <form class="login-form px-4 pb-4 needs-validation contact-form-style" novalidate
                                    id="login-modal-form">
                                    <div class="row">
                                        <div class="mb-3">
                                            <label for="login_email"
                                                class="form-label">{{translation('EMAIL')}}<span
                                                    class="text-danger">*</label>
                                            <input type="email" id="login_email" class="form-control"
                                                placeholder="{{translation('EMAIL_PLACEHOLDER')}}*" name="email"
                                                value="{{old('email')}}" required aria-label="email">
                                        </div>
                                        <span class="text-danger" id="email-logerror"></span>

                                        <div class=" mb-3">
                                            <label for="login_Password"
                                                class="form-label">{{translation('PASSWORD')}}<span
                                                    class="text-danger">*</label>
                                            <input type="password" id="login_Password" class="form-control"
                                                placeholder="{{translation('PASSWORD_PLACEHOLDER')}}*"
                                                value="{{old('password')}}" name="password" required
                                                aria-label="password">
                                        </div>
                                        <span class="text-danger" id="email-logerror"></span>
                                        <span class="text-danger" id="invalid-creddential"></span>

                                        <div class="col-lg-12">
                                            <div class="d-flex justify-content-between">
                                                <div class="mb-3">
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="checkbox" id="rememberMe">
                                                        <label class="form-check-label" for="rememberMe">{{translation('REMEMBER_ME')}}</label>
                                                    </div>
                                                </div>
                                                <p class="forgot-pass mb-0">
                                                    <a href="{{url('/forgot-password')}}" id="modalExForgPassBtn"class="text-dark fw-bold">{{translation('FORGOT_PASSWORD')}}?
                                                    </a>
                                                </p>
                                            </div>
                                        </div>

                                        <div class="col-lg-12 mb-0">
                                            <div class="d-grid">
                                                <button type="submit" class="btn btn-primary" id="modalSignInBtn">
                                                    {{translation('SIGN_IN')}}
                                                </button>
                                            </div>
                                        </div>

                                        <div class="col-12 text-center">
                                            <p class="mb-0 mt-3">
                                                <small class="text-dark me-2">{{translation('DONT_HAVE_ACCOUNT')}}</small> 
                                                <a href="javascript:void(0)" class="text-dark fw-bold"
                                                id="modalExchSignUpBtn">{{translation('SIGN_UP')}}</a>
                                            </p>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!--Login End Here-->

                    <!--Register Modal start-->
                    <div class="container-fluid px-0 d-none" id="subregister">

                        <div class="row align-items-center g-0">
                            <div class="col-lg-12 col-md-12">
                                <div class="modal-header">
                                    <h5 class="modal-title">{{translation('REGISTER_TITLE')}}</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <form class="login-form p-4 needs-validation" novalidate id="register-modal-form">
                                    <div class="row">
                                        <div class=" col-lg-12">
                                            <div class="mb-3">
                                                <label for="register_name"
                                                    class="form-label">{{translation('NAME')}}<span
                                                        class="text-danger">*</label>
                                                <input type="text" name="reg_name" class="form-control"
                                                    placeholder="{{translation('NAME_PLACEHOLDER')}}*"
                                                    value="{{old('reg_name')}}" id="register_name" required
                                                    aria-label="Username">
                                            </div>
                                            <span class="text-danger" id="register-name"></span>
                                        </div>

                                        <div class="mb-3">
                                            <label for="register_email"
                                                class="form-label">{{translation('EMAIL')}}<span
                                                    class="text-danger">*</label>
                                            <input type="email" name="email" class="form-control"
                                                placeholder="{{translation('EMAIL_PLACEHOLDER')}}*" id="register_email"
                                                value="{{old('email')}}" required aria-label="Username">
                                        </div>
                                        <span class="text-danger" id="register-email"></span>

                                        <div class="mb-3">
                                            <label for="register_password"
                                                class="form-label">{{translation('PASSWORD')}}<span
                                                    class="text-danger">*</label>
                                            <input type="password" minlength="8" id="register_password" name="password"
                                                class="form-control" placeholder="{{translation('PASSWORD_PLACEHOLDER')}}*"
                                                aria-label="Username" required>
                                        </div>
                                        <div class="invalid-feedback">
                                            {{translation('PLEASE_ENTER_VALID_8_DIGIT_PASSWORD')}}!
                                        </div>
                                        <span class="text-danger" id="register-password"></span>

                                        <div class="mb-3">
                                            <label for="confirm_register_password"
                                                class="form-label">{{translation('CONFIRM_PASSWORDS')}}<span
                                                    class="text-danger">*</label>
                                            <input type="password" minlength="8" id="confirm_register_password"
                                                name="password_confirmation" class="form-control"
                                                placeholder="{{translation('CONFIRM_PASSWORDS_PLACEHOLDER')}}*"
                                                aria-label="Username" required>
                                        </div>
                                        <div class="invalid-feedback">
                                            {{translation('PLEASE_ENTER_VALID_8_DIGIT_PASSWORD')}}!
                                        </div>
                                        <span class="text-danger" id="register-password_confirmation"></span>

                                        <div class="col-lg-12 mb-0">
                                            <div class="d-grid"> <button type="submit" class="btn btn-primary"
                                                    id="modalSignUpBtn">{{translation('REGISTER_BUTTON')}}</button></div>
                                        </div>

                                        <div class="col-12 text-center">
                                            <p class="mb-0 mt-3"><small
                                                    class="text-dark me-2">{{translation('ALREADY_REGISTER')}}?</small>
                                                <a href="javascript:void(0)" class="text-dark fw-bold"
                                                    id="modalExchSignInBtn">{{translation('SIGN_IN')}}</a>
                                            </p>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- End of register modal -->
                </div>
            </div>
        </div>
    </div>
    <!--End of login register-->

    <!-- Add New Address Modal Start Here-->
        <div class="modal fade" id="newAddressModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog">
            <div class="modal-content">
                <button type="button" class="btn-close prdtbtn-close " data-bs-dismiss="modal" aria-label="Close">&times;</button>
                <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">{{translation('ADDRESS_FORM_TITLE')}}</h5>
                </div>
                <div class="modal-body pb-0">
                    <form id="modalAddressform" class="needs-validation" novalidate >
                    <div class="row px-4">

                        <div class="col-lg-6 col-md-6">
                            <div class="billing-info mb-20px">
                                <label>{{translation('CONTACT_NAME')}} <span class="text-danger">*</span></label>
                                <input type="text" name="customer_name" class="form-control"
                                    value="{{old('customer_name')}}" required>
                                <span class="text-danger add_customer_name"></span>
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <div class="billing-info mb-20px">
                                <label>{{translation('EMAIL')}}<span
                                        class="text-danger">*</span></label>
                                <input type="email" name="customer_email" value="{{old('customer_email')}}"
                                    class="form-control" required>
                                <span class="text-danger add_customer_email"></span>
                            </div>
                        </div>

                        <div class="col-lg-6 ">
                            <div class="billing-info mb-20px">
                                <label>{{translation('PHONE')}}<span
                                        class="text-danger">*</span></label>
                                <input type="text" name="phone" value="{{old('phone')}}"
                                    class="form-control" required>
                                <span class="text-danger add_phone"></span>
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <div class="billing-info mb-20px">
                                <label>{{translation('STREET_ADDRESS')}}<span class="text-danger">*</span></label>
                                <input class="billing-address form-control" value="{{old('street_address')}}"
                                    type="text" name="street_address" required>
                                <span class="text-danger add_street_address"></span>
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <div class="billing-info mb-20px">
                                <label>{{translation('CITY')}}<span class="text-danger">*</span></label>
                                <input type="text" name="city" value="{{old('customer_city')}}"
                                    class="form-control" required>
                                <span class="text-danger add_city"></span>
                            </div>
                        </div>

                        <div class="col-lg-6 ">
                            <div class="billing-info mb-20px">
                                <label>{{translation('STATE')}}<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="state" value="{{old('customer_state')}}"  required />
                                <span class="text-danger add_state"></span>
                            </div>
                        </div>

                        @if(!empty($countries))
                        <div class="col-lg-6  mb-2 mb-lg-0">
                            <div class="billing-info mb-20px">
                                <label>{{translation('COUNTRY')}}<span class="text-danger">*</span></label>
                                <select name="countries_id" class="nice-select ps-2" required>
                                    <option selected value="" disabled>
                                        {{translation('COUNTRY_PLACEHOLDER')}}
                                    </option>
                                    @foreach($countries as $key=>$country)
                                    <option value="{{$country->countries_id ?? ''}}" @if($Ipcountry->
                                        countries_id==$country->countries_id) selected
                                        @endif>{{$country->countries_name ?? ''}}</option>
                                    @endforeach
                                </select>
                                <span class="text-danger add_countries_id"></span>
                            </div>
                        </div>
                        @endif
                        
                        <div class="col-lg-6 ">
                            <div class="billing-info mb-20px">
                                <label>{{translation('ZIPCODE')}}<span class="text-danger">*</span></label>
                                <input type="text" name="zipcode" value="{{old('customer_postcode')}}"
                                    class="form-control" required>
                                <span class="text-danger add_zipcode"></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mx-auto col-6">
                        <div class="row">
                            <div class="modal-footer py-0">
                                <button type="button" class="btn btn-primary" id="addressformbutton">{{translation('SUBMIT')}}</button>
                            </div>
                        </div>
                    </div>
                 </form>
                </div>
            </div>
            </div>
        </div>
    <!-- Add New Address Modal End Here -->

    <!-- Modals end Here-->

    @push('scripts')
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
    <script>
        $(document).ready(function () {

            // Add Address function  ajax start

            $(document).on('click', '#addressformbutton', function (e) {
                e.preventDefault();
                $('#modalAddressform').addClass('was-validated');
                if ($('#modalAddressform')[0].checkValidity() === false) {
                    event.stopPropagation();
                } else {
                var newAddress = document.getElementById("modalAddressform");
                var formData = new FormData(newAddress);
                formData.append('page_source','checkout');
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{url('account/add-address')}}",  
                    data: formData,
                    cache: false,
                    contentType: false,
                    processData: false,

                    success: function (response) {
                        if (response.status == 400) {
                            $.each(response.error, function (key, err_val) {
                                $('.add_' + key).text(err_val);
                            });
                        } else {
                            var addressList= `<tr>
                            <td class="d-flex gap-3">
                                <input type="radio" name="default_address" class="default_address" checked
                                    id="add_${response.addressData.address_id}"
                                    value='${response.addressData.address_id}'/>
                                <label for="add_${response.addressData.address_id}">
                                    ${response.addressData.customer_name},${response.addressData.customer_email},
                                    ${response.addressData.street_address},${response.addressData.city},
                                    ${response.addressData.state},
                                    ${response.addressData.country_name}, ${response.addressData.zipcode},
                                    ${response.addressData.phone}
                                </label>
                               </td>
                           </tr>`;

                            $("input[name='address_id']").removeAttr('checked');
                            $(addressList).prependTo("#addressListBox");
                            $('#modalAddressform').removeClass('was-validated');
                            $('#newAddressModal').modal('hide');
                            $('#modalAddressform').trigger("reset");
                            Notify('{{translation('SUCCESSFULLY_SEND')}}!', true);
                        }
                    }
                });
              }
            });
            //  Add Address End 
        
            $('#placeOrderForm').validate({
                rules: {
                    customer_name: {
                        required: true
                    },
                    customer_last_name: {
                        required: true
                    },
                    customer_company: {
                        required: true
                    },
                    countries_id: {
                        required: true
                    },
                    customer_address: {
                        required: true
                    },
                    customer_city: {
                        required: true
                    },
                    customer_state: {
                        required: true
                    },
                    customer_postcode: {
                        required: true
                    },
                    customer_phone: {
                        required: true
                    },
                    customer_email: {
                        required: true
                    },
                    shipping_customer_name: {
                        required: true
                    },
                    shipping_customer_last_name: {
                        required: true
                    },
                    shipping_customer_company: {
                        required: true
                    },
                    shipping_countries_id: {
                        required: true
                    },
                    shipping_customer_address: {
                        required: true
                    },
                    shipping_customer_city: {
                        required: true
                    },
                    shipping_customer_state: {
                        required: true
                    },
                    shipping_customer_postcode: {
                        required: true
                    },
                    shipping_customer_phone: {
                        required: true
                    },
                    shipping_customer_email: {
                        required: true
                    },
                },
                messages: {
                    customer_name: {
                        required: 'Please Enter Contact Name'
                    },
                    customer_last_name: {
                        required: 'Please Enter last name'
                    },
                    customer_company: {
                        required: 'Please Enter company name'
                    },
                    countries_id: {
                        required: 'Please select Country'
                    },
                    customer_address: {
                        required: 'Please Enter Street Address'
                    },
                    customer_city: {
                        required: 'Please Enter City'
                    },
                    customer_state: {
                        required: 'Please Enter State'
                    },
                    customer_postcode: {
                        required: 'Please Enter Zipcode'
                    },
                    customer_phone: {
                        required: 'Please Enter Phone No'
                    },
                    customer_email: {
                        required: 'Please Enter Email'
                    },

                    shipping_customer_name: {
                        required: 'Please Enter Contact Name'
                    },
                    shipping_customer_last_name: {
                        required: 'Please Enter last name'
                    },
                    shipping_customer_company: {
                        required: 'Please Enter company name'
                    },
                    shipping_countries_id: {
                        required: 'Please select Country'
                    },
                    shipping_customer_address: {
                        required: 'Please Enter Street Address'
                    },
                    shipping_customer_city: {
                        required: 'Please Enter City'
                    },
                    shipping_customer_state: {
                        required: 'Please enter State'
                    },
                    shipping_customer_postcode: {
                        required: 'Please Enter Zipcode'
                    },
                    shipping_customer_phone: {
                        required: 'Please Enter Phone No'
                    },
                    shipping_customer_email: {
                        required: 'Please Enter Email'
                    },
                },

                errorElement: 'span',
                errorPlacement: function (error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.billing-info').append(error);
                },
                highlight: function (element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                    $(element).css("border", " 1px solid red")
                },
                unhighlight: function (element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                    $(element).css("border", "1px solid #ebebeb")
                }


            });

            $(document).on('click', '.payment-img', function () {
                $('.payment-img').removeClass('activePayment'); // removew old one
                $(this).addClass('activePayment'); // add new one
            });


            // Change Shipping Ajax

            $(document).on('change', '.ship-radio-choose', function () {
                var methodKey = $(this).attr('value');

                var url = `{{ url('shipping-details/${methodKey}') }}`;
                $.ajax({
                    url: url,
                    type: "GET",
                    success: function (response) {
                        $('#shippingHtml').html("");
                        $('#shippingPrice').html("");
                        $('#shippingHtml').html(response.shippingHtml);
                        $('#shippingPrice').html(response.value);
                    }
                });
            });
        });

        // Coupon Ajax Start Here

        $(document).ready(function () {
            $(document).on('click', '#applyButton', function (e) {
                e.preventDefault();
                if ($('#coupon_code').val() != '') {
                    var data = {
                        'coupon_code': $('#coupon_code').val(),
                    }
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        type: "POST",
                        url: "/apply-coupon",
                        data: data,
                        dataType: "json",

                        beforeSend: function () {
                            $('#applyButton').addClass('disabled');
                            var html = '<i class="fa-solid fa-spinner fa-spin-pulse"></i> {{translation('APPLYING')}}...';
                            $('#sendRequestDemo').html(html);
                        },

                        success: function (response) {

                            if (response.status == 201) {
                                $('.coupon_error').text(response.message);
                                $('#coupon_alert').addClass('show');
                            }
                            if (response.status == 200) {

                                if (response.coupon_response.taxCalculation.length != 0) {
                                    $taxhtml = '';
                                    $.each(response.coupon_response.taxCalculation, function (key, tax_val) {
                                        $taxhtml += `<h4>${key}: <span>${tax_val}</span></h4>`;
                                    });
                                    $('.tax_block').html($taxhtml);
                                }

                                $('.subtotal').text(response.coupon_response.amount);
                                var coupon_html = `<h4>{{translation('COUPON_DISCOUNT')}}: <span>${response.coupon_response.discount_amount}</span></h4>`;
                                $('.coupon_disc_amount').html(coupon_html);

                                Notify('{{translation('APPLIED_SUCCESS_MSG')}}!', true);
                                $('#coupon_code').val('');
                                var coupon_html = `<button type="button" class="btn btn-success">{{translation('COUPON_SUCCESS_MSG')}}!</button>`;
                                $('#coupon_area').html(coupon_html);
                            }
                        },
                        complete: function (response) {
                            $('#couponForm').removeClass('was-validated');
                            $('#applyButton').removeClass('disabled');
                            $('#applyButton').html('{{translation('APPLY')}}');
                        }
                    });
                }
                else {
                    $('.coupon_error').text('{{translation('ERROR_COUPON_MSG')}}');
                    $('#coupon_alert').addClass('show');
                }
            });
        });

        $('.coupon_alt_btn').click(function () {
            $('#coupon_alert').addClass('fade');
            $('#coupon_alert').removeClass('show');
        });

        $('.login_alt_btn').click(function () {
            $('.login_alert').addClass('fade');
            $('.login_alert').removeClass('show');
        });


        $("#cpnbtn").click(function () {
            $("#subregister").addClass('d-none');
            $("#forgot_password").addClass('d-none');
            $("#sublogin").removeClass('d-none');
            $("#login-popup").modal('show');
        });

        // Sign in to SignUp form

        $("#modalExchSignUpBtn").click(function () {
            $("#sublogin").addClass('d-none');
            $("#subregister").removeClass('d-none');
        });

        // Sign up to SignIn form

        $("#modalExchSignInBtn").click(function () {
            $("#sublogin").removeClass('d-none');
            $("#subregister").addClass('d-none');
        });

        // Forgot password button to forgot password form

        $("#modalExForgPassBtn").click(function () {
            $("#sublogin").addClass('d-none');
            $("#forgot_password").removeClass('d-none');
        });


        // Login Ajax Start ModalloginForm

        $(document).on('click', '#modalSignInBtn', function (e) {
            e.preventDefault();
            $('#login-modal-form').addClass('was-validated');
            if ($('#login-modal-form')[0].checkValidity() === false) {
                event.stopPropagation();
            } else {
                var data = {
                    'email': $('#login_email').val(),
                    'password': $('#login_Password').val(),
                    'login_source': $('#login_source').val(),
                    'remember': $('#rememberMe').val(),
                }
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{ url('/customer-login') }}",
                    data: data,
                    dataType: "json",

                    beforeSend: function () {
                        $('#modalSignInBtn').addClass('disabled');
                        $('#modalSignInBtn').html(
                            ' <i class="fa-solid fa-spinner fa-spin-pulse"></i>  {{translation('LOGGING')}}....'
                        );
                    },
                    success: function (response) {
                        console.log(response);
                        if (response.status == "200") {
                            $('#login-modal-form').trigger("reset");
                            $('#login-modal-form').removeClass('was-validated');
                            $("#login-popup").modal('hide');
                            location.reload();
                        }

                        if (response.status == "201") {

                            $(".login_alert").addClass('alert-danger');
                            $(".login_alert").addClass('show');
                            $("#alert_message").html(response.message);
                            $('#modalSignInBtn').html('{{translation('SIGN_IN')}}');
                        }
                    },

                    complete: function (response) {
                        $('#modalSignInBtn').removeClass('disabled');
                        $('#modalSignInBtn').html('{{translation('SIGN_IN')}}');
                    }
                });
            }
        });

        // Register Ajax start here

        $(document).on('click', '#modalSignUpBtn', function (e) {
            e.preventDefault();
            $('#register-modal-form').addClass('was-validated');
            if ($('#register-modal-form')[0].checkValidity() === false) {
                event.stopPropagation();
            } else {
                var data = {
                    'name': $('#register_name').val(),
                    'email': $('#register_email').val(),
                    'password': $('#register_password').val(),
                    'password_confirmation': $('#confirm_register_password').val(),
                }

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{ url('customer-register') }}",
                    data: data,
                    dataType: "json",

                    beforeSend: function () {
                        $('#modalSignUpBtn').addClass('disabled');
                        $('#modalSignUpBtn').html(
                            ' <i class="fa-solid fa-spinner fa-spin-pulse"></i> {{translation('REGISTERING')}}...'
                        );
                    },

                    success: function (response) {
                        if (response.status == 400) {
                            $.each(response.error, function (key, err_val) {
                                $('#' + 'register-' + key).text(err_val);
                            });
                        }
                        if (response.status == 200) {
                            $('#register-modal-form').trigger("reset");
                            $('#register-modal-form').removeClass('was-validated');
                            $("#sublogin").removeClass('d-none');
                            $(".login_alert").removeClass('alert-danger');
                            $(".login_alert").addClass('alert-success');
                            $("#alert_message").html("{{translation('REGISTRAION_SUCCESSFULLY_PLEASE_LOGIN')}}!");
                            $(".login_alert").addClass('show');
                            $("#subregister").addClass('d-none');
                        }
                    },
                    complete: function () {
                        $('#modalSignUpBtn').removeClass('disabled');
                        $('#modalSignUpBtn').html('{{translation('SIGN_UP')}}');
                    }
                });
            }
        });
    </script>
    @endpush