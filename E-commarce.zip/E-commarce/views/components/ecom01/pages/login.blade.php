@php
$main_arr = [
'title'=>'',
'sublist' => [
[
'name'=>translation('HOME'),
'link'=>url("/")
],
[
'name'=>translation('LOGIN'),
'link'=>url()->full()
],
]
];
@endphp
 <!--- Breadcome area start here --->
 <x-Ecom01.SharedComponent.BreadCrumb :data="$main_arr" /> 
 <!--- Breadcome area end here --->

<!-- login area start -->
<div class="my-0">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 col-sm-12 mx-auto login-page login-register-area p-4 my-5">
                <div class="border-0">
                    <div class="card-body">
                        <h4 class="card-title fw-bold text-center">{{ translation('LOGIN') }}</h4>  
                        @if (session('status'))
                            <div class="alert alert-success">
                                {{ session('status') }}
                            </div>
                        @endif
 
                        @error('failed')
                        <strong class="text-danger" style="margin-top:-50px;">{{ $message }}</strong>
                        @enderror                     
                        <form class="login-form mt-4" action="{{ route('login') }}" method="post" id="Login_Form" novalidate="novalidate">
                          @csrf  
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">{{translation('EMAIL')}}<span class="text-danger">*</span></label>
                                        <div class="form-icon position-relative">
                                            <input type="email" class="form-control ps-3" placeholder="{{ translation('EMAIL_PLACEHOLDER') }}" name="email" required="">
                                        </div>
                                        @error('email')
                                        <strong class="text-danger mb-5">{{ $message }}</strong>
                                        @enderror
                                    </div>
                                </div><!--end col-->

                                <div class="col-lg-12">
                                    <div class="mb-4">
                                        <label class="form-label fw-bold">{{translation('PASSWORD')}}<span class="text-danger">*</span></label>
                                        <div class="form-icon position-relative">
                                            <input type="password" name="password" class="form-control ps-3" placeholder="{{ translation('PASSWORD_PLACEHOLDER') }}" required="">
                                        </div>
                                        @error('password')
                                        <strong class="text-danger" style="margin-top:-50px;">{{ $message }}</strong>
                                        @enderror
                                    </div>
                                </div><!--end col-->

                                <div class="col-lg-12">
                                    <div class="d-flex justify-content-between">
                                        <div class="mb-4">
                                            <div class="form-check">
                                                <input class="form-check-input" name="remember" type="checkbox"  id="flexCheckDefault">
                                                <label class="form-check-label" for="flexCheckDefault">{{ translation('REMEMBER_ME') }}</label>
                                            </div>
                                        </div>
                                        <p class="forgot-pass mb-0"><a href="{{url('/forgot-password')}}" class=" fw-bold">{{ translation('FORGOT_PASSWORD') }}</a></p>
                                    </div>
                                </div><!--end col-->

                                <div class="col-lg-5 mb-0 mx-auto">
                                    <div class="d-grid">
                                        <button class="btn btn-primary py-2" type="submit" style="border-radius: 20px;">{{ translation('SIGN_IN') }}</button>
                                    </div>
                                </div><!--end col-->
                                <div class="col-12 text-center">
                                    <p class="mb-0  mt-4"><small class="text-dark me-2">{{translation('DONT_HAVE_ACCOUNT')}}</small> <a href="{{url('/register')}}" class="text-dark fw-bold">{{ translation('SIGN_UP') }}</a></p>
                                </div>
                                <!--end col-->
                            </div><!--end row-->
                        </form>
                    </div>
                </div><!---->                
            </div>
        </div>
    </div>
</div>
<!-- login area end -->

@push('scripts')

<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
<script>
    $(document).ready(function() {
        $('#Login_Form').validate({
            rules: {
                email: {
                    required: true,
                    email: true,
                    maxlength: 150
                },
                password: {
                    minlength: 6,
                    required: true
                },
            },
            messages: {
                email: {
                        required: "Please enter email",
                        email: "Please enter valid email",
                        maxlength: "Email cannot be more than 150 characters.",
                    },
                    password: {
                        required: "Please enter password",
                        minlength: "Password must be at least 6 characters."
                    },
                },
            highlight: function(element) {
                $(element).addClass('is-invalid');
                $(element).css("border", " 1px solid red")
            },
            unhighlight: function(element, errorClass, validClass) {
                $(element).removeClass('is-invalid');
                $(element).css("border", "1px solid #ebebeb")
            }
        });
    });
 
</script>
@endpush