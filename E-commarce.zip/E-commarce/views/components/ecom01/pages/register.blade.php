@php
$main_arr = [
  'title'=>'',
  'sublist' => [
    [
    'name'=>translation('HOME'),
    'link'=>url("/")
    ],
    [
    'name'=>translation('REGISTER'),
    'link'=>url()->full()
    ], 
  ]
];
@endphp
<div class=" my-0">
    <!----- Breadcome area start here --->
    <x-Ecom01.SharedComponent.BreadCrumb :data="$main_arr" /> 
    <!----- Breadcome area start here --->
    <div class="container">
        <div class="row">
            <div class="col-lg-5 col-sm-12 mx-auto login-page  p-4 login-register-area my-5">
                <div>
                    <h4 class="card-title fw-bold text-center">{{translation('REGISTER_TITLE')}}</h4>
                    <form class="login-form mt-4" action="{{route('register')}}" method="post"
                        id="REGISTER_FORM"  novalidate="novalidate">
                        @csrf
                        <div class="row">
                            <div class="col-lg-12 col-md-12">
                                <div class="mb-3">
                                    <label class="form-label fw-bold">{{translation('NAME')}}<span class="text-danger">*</span></label>
                                    <div class="form-icon position-relative">
                                        <input type="text" class="form-control ps-3" placeholder="{{translation('NAME_PLACEHOLDER')}}" value="{{old('name')}}" name="name" required="">
                                        @error('name')
                                        <strong class="text-danger mb-5">{{ $message }}</strong>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                         
                            <div class="col-lg-12  col-md-12">
                                <div class="mb-3">
                                    <label class="form-label fw-bold">{{translation('EMAIL')}}<span class="text-danger">*</span></label>
                                    <div class="">
                                        <input type="email" name="email" class="form-control ps-3" placeholder="{{translation('EMAIL_PLACEHOLDER')}}" value="{{old('email')}}" required="">
                                        @error('email')
                                        <strong class="text-danger mb-5">{{ $message }}</strong>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12  col-md-12">
                                <div class="mb-3">
                                    <label class="form-label fw-bold">{{translation('PASSWORD')}}<span
                                            class="text-danger">*</span></label>
                                    <div class="form-icon position-relative">
                                        <input type="password" name="password" id="password" class="form-control ps-3" placeholder="{{translation('PASSWORD_PLACEHOLDER')}}" required="">
                                        @error('password')
                                        <strong class="text-danger mb-5">{{ $message }}</strong>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12  col-md-12">
                                <div class="mb-3">
                                    <label class="form-label fw-bold">{{translation('CONFIRM_PASSWORDS')}}<span
                                            class="text-danger">*</span></label>
                                    <div class="form-icon position-relative">
                                        <input type="password" name="password_confirmation" class="form-control ps-3" placeholder="{{translation('CONFIRM_PASSWORDS_PLACEHOLDER')}}" required="">
                                        @error('password_confirmation')
                                        <strong class="text-danger mb-5">{{ $message }}</strong>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-5 mb-0 mx-auto">
                                <div class="d-grid">
                                    <button class="btn btn-primary py-2" type="submit"
                                        style="border-radius: 20px;">{{translation('SUBMIT')}}</button>
                                </div>
                            </div>
                            <div class="col-12 text-center">
                                <p class="mb-0  mt-4"><small class="text-dark me-2">{{translation('ALREADY_REGISTER')}}</small> <a href="{{url('login')}}" class="text-dark fw-bold">{{translation('SIGN_IN')}}</a></p>
                            </div>
                        </div>
                        
                    </form>
                </div>

            </div>
        </div>
    </div>
</div>

@push('scripts')

<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
<script>
    $(document).ready(function() {
        $('#REGISTER_FORM').validate({
            rules: {
                name: {
                    required: true
                },
               
                email: {
                    required: true,
                    email: true,
                    maxlength: 150
                },
                password: {
                    minlength: 6,
                    required: true
                },
                password_confirmation: {
                    minlength: 6,
                    required: true,
                    equalTo: "#password",
                },
            },
            messages: {
                name: {
                    required: "Please enter name",
                },
                email: {
                    required: "Please enter email",
                    email: "Please enter valid email address",
                    maxlength: "Email cannot be more than 150 characters",
                },
                password: {
                    required: "Please enter password",
                    minlength: "Password must be at least 6 characters"
                },
                password_confirmation: {
                    required: "Please enter confirm password",
                    minlength: "Confirm Password must be at least 6 characters",
                    equalTo: "Password and confirm password must be same",
                },
            },

            highlight: function(element) {
                $(element).addClass('is-invalid');
                $(element).css("border", " 1px solid red")
            },
            unhighlight: function(element, errorClass, validClass) {
                $(element).removeClass('is-invalid');
                $(element).css("border", "1px solid #ebebeb")
            }

        });
    });
</script>
@endpush