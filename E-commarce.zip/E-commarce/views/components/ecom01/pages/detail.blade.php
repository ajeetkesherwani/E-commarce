@php
$avgrating = AvgRating($products->product_id);
$currentURL = URL::current();
use App\Models\Ecom\Services\EcomService;
@endphp
<!-- Breadcrumb Area start -->
<x-Ecom01.SharedComponent.BreadCrumb :data="$breadCumbArr" />
<!-- Breadcrumb Area End -->

@push('scripts')
<script src="{{LoadAssets('assets/js/test/zoom-image.js')}}"></script>
<script src="{{LoadAssets('assets/js/test/main.js')}}"></script>
@endpush

@push('styles')
<link rel="stylesheet" type="text/css" href="{{LoadAssets('assets/css/test/style.css')}}">
@endpush

<!-- Shop details Area start -->
<section class="product-details-area mt-4 mb-5">
    <div class="container">
        <div class="row"> 
            <!-- Product images Start Here-->
            <div class="col-xl-5 col-lg-5 col-md-12 details-wrapper">
                <div class="show" href="{{ $products->image_url}}">
                    <img src="{{ $products->image_url }}"
                    onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" 
                    id="show-img" class="img-fluid">
                </div>
            
                <!--Product Gallery images  Start Here-->
                @if (!empty($products->products_to_gallery) && sizeof($products->products_to_gallery)>0)
                    <div class="small-img">
                        <img src="{{LoadAssets('assets/images/test/next-icon.png')}}" class="icon-left" alt=""
                            id="prev-img">
                        <div class="small-container">
                            <div id="small-img-roll">
                                @foreach ($products->products_to_gallery as $key => $data)
                                    @if(!empty($data))
                                    <img src="{{$data}}" class="show-small-img"
                                        onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                                        alt="">
                                    @endif
                                @endforeach
                            </div>
                        </div>
                        <img src="{{LoadAssets('assets/images/test/next-icon.png')}}" class="icon-right" alt=""
                            id="next-img">
                    </div>
                @endif
                <!-- Product Gallery End Here -->
            </div>
            <!-- Product images end Here-->

            <div class="col-xl-7 col-lg-7 col-md-12">
                <div class="product-details-content">
                    <h1> {{ $products->products_name ?? '' }} </h1>
                    <!-- Product Brand Start -->
                    @if (in_array($products->product_type_id, ['1', '2', '4']) && $products->products_to_brand != '')
                    @if (!empty($products->products_to_brand))
                    <p class="reference">{{translation('PRODUCT_BRAND')}} : <span class="read-review">
                            <a href="{{ EcomService::url($products->products_to_brand->brand_id ?? '', 'brand') }}">
                                {{ $products->products_to_brand->brand_name ?? '' }}</a></span>
                    </p>
                    @endif
                    @endif
                    <!-- Product Brand End -->

                    <div class="pro-details-rating-wrap">
                        @if (!empty($avgrating))
                            <div class="rating-product">
                                @for ($i = 1; $i < $avgrating; $i++) 
                                <i class="ion-android-star"></i>
                                @endfor
                            </div>
                        @endif
                        @if (in_array(config('constkey.section_review'), $cKey))
                            @if(!empty($review_count))
                                <span class="read-review">
                                    <a class="reviews" href="#read_review">{{translation('PRODUCT_REVIEW')}}
                                        ({{ $review_count ?? '' }})</a>
                                </span>
                            @endif
                        @endif
                    </div>
                    
                    <!--Wishlist Start-->
                    @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))
                    <div class="pro-details-wish-com">
                        <div class="pro-details-wishlist">
                            <a href="javascript:void(0);"
                                onclick="addToWishListFromDetail({{ $products->product_id }})">
                                <i class="ion-android-favorite-outline"></i>
                                {{translation('ADD_TO_WISHLIST')}}
                            </a>
                        </div>
                    </div>
                    @endif
                    <!--Wishlist End-->

                    <!-- Product Features Start-->
                    @if(!empty($products->products_to_features) && sizeof($products->products_to_features)>0)
                    <div class="pro-details-list feature-list">
                        <ul>
                            @foreach($products->products_to_features as $features)
                            <li>{{$features->feature_title ?? ''}} : {{$features->feature_value ?? ''}}</li>
                            @endforeach
                        </ul>
                    </div>
                    @endif
                    <!-- Product Features End-->

                    @if (webFunctionStatus(config('constkey.is_price_show')))

                        <!-- Show WholeSale Price Tabel Start -->
                        <div class="pricing-meta">
                            @if($products->products_prices !=null && $products->source==1)
                            <div class="position-relative">
                                <div style="position:absolute; z-index: 2;">
                                    <div class="qty"><b>{{translation('PRODUCT_QTY')}}</b></div>
                                    <div class="price"><b>{{translation('PRODUCT_PRICE')}}</b></div>
                                </div>
                                <div class="qty-carousel">
                                    @foreach($products->products_prices as $producprice)
                                    <div>
                                        <div class="qty"><b>{{$producprice->product_qty}}</b></div>
                                        <div class="amount">{{currencyFormat($producprice->sale_price)}}</div>
                                    </div>
                                    @endforeach
                                </div>
                            </div>
                            @endif
                        </div>
                        <!-- End of WholeSale price Tabel-->
                    @endif

                    <!-- Start of cart enable-->

                    <form action="{{route('addUpdateToCart')}}" method="post" id="cartform">
                        @csrf
                        <!-- Show product attributes --> 
                        <div class="product-variants js-product-variants">
                            @if (!empty($products->productAttribute)) 
                                @foreach ($products->productAttribute as $attribute)
                                    <div class="clearfix product-variants-item">
                                        <span class="control-label">{{ ucfirst($attribute->option_name ?? '') }} :</span>
                                        @if (isset($attribute->option_value_list) && !empty($attribute->option_value_list))
                                            <ul id="attributes_{{ $attribute->options_id }}">
                                                @foreach ($attribute->option_value_list as $idx => $option_value)
                                                    <li class="input-container float-sm-start">
                                                        <label>
                                                            <input class="input-radio" type="radio"
                                                                attribute="{{ $attribute->options_id }}"
                                                                name="attributes_{{ $attribute->options_id }}" {{ $idx==0 ? 'checked' : '' }}
                                                                value="{{ $attribute->options_id }}_{{ $option_value->options_values_id }}"
                                                                title="{{ $option_value->productOptionsValue->products_options_values_name }}">
                                                                
                                                            <span class="radio-label">{{$option_value->productOptionsValue->products_options_values_name}}</span>
                                                        </label>
                                                    </li>
                                                @endforeach
                                            </ul>
                                        @endif
                                    </div>
                                @endforeach
                            @endif
                        </div>
                        <!-- End of product attributes -->
                        
                        @if (webFunctionStatus(config('constkey.is_price_show')))
                            
                            <div class="pricing-meta mt-3">
                                <!-- Show Only Product is Price wholesale Product-->
                                @if($products->products_prices!=null)
                                <ul>
                                    <span class="price-font">Price:</span>
                                    @foreach($products->products_prices as $holeprice)
                                        @if($holeprice->discount_percent !='0')
                                            <del class="text-danger ms-2 discount_amount">
                                                {{currencyFormat($holeprice->max_sale_price) }}
                                            </del>
                                        @endif
                                        <li class="old-price not-cut">
                                            {{ currencyFormat($holeprice->sale_price ?? '0.00') }}
                                        </li>
                                        <li class="">
                                            / {{$holeprice->product_qty}} Unit
                                        </li>
                                        @if($holeprice->discount_percent != '0')
                                        <span class="discount-price ms-1">
                                            {{ currencyFormat( $holeprice->discount_percent )}}% off
                                        </span>
                                        @endif
                                    @break
                                    @endforeach
                                </ul>
                                @else
                                <ul>
                                    @if($products->discount_type != 'no')
                                    <del class="text-danger ms-2 discount_amount">{{currencyFormat($products->max_sale_price)
                                        }}
                                    </del>
                                    @endif
                                    <li class="old-price not-cut">
                                        {{ currencyFormat($products->sale_price ?? '0.00') }}
                                    </li>
                                    @if($products->discount_type != 'no')
                                        @if($products->discount_type == 'flat')
                                            <span class="text-success ms-1">
                                                {{ currencyFormat($products->discount_amount) }} off
                                            </span>
                                        @else
                                            <span class="text-success ms-1">
                                                {{ currencyFormat( $products->discount_amount )}}% off
                                            </span>
                                        @endif
                                    @endif
                                </ul>
                                @endif
                            </div>
                            <!-- End of product Prices -->

                        @endif


                        @if($products->products_prices !=null)
                        <input type="hidden" hidden class="minordqty"
                            value="{{$products->products_prices->min('product_qty')}}">
                        @endif
                        <div class="pro-details-quality mt-3">
                            <!-- show cart button -->
                            @if (webFunctionStatus(config('constkey.is_cart_enabled')))
                                <div class="cart-plus-minus">
                                    @if($products->products_prices !=null)
                                        @foreach($products->products_prices as $producprice)
                                            <input class="cart-plus-minus-box" onblur="QtyToPrice('page')" type="text" id="qtyItemAdd"
                                                name="qty" value="{{$producprice->product_qty}}" />
                                          @break
                                        @endforeach
                                    @else
                                    <input class="cart-plus-minus-box" onblur="QtyToPrice('page')" type="text" id="qtyItemAdd"
                                        name="qty" value="1" />
                                    @endif
                                </div>
                                <input type="hidden" name="product_slug" value="{{$products->product_slug}}">
                                <input type="hidden" value="page" class="source">
                            

                                <!--if cart is enabled-->

                                @if($products->source==1)
                                    <div class="pro-details-cart btn-hover">
                                        <button type="submit" class="btn btn-primary">{{translation('ADD_TO_CART')}}</button>
                                        </a>
                                    </div>
                                @endif
                            @endif

                            <!--if enquiry is enabled-->
                            @if (webFunctionStatus(config('constkey.is_enquiry_enabled')))
                            <div class="pro-details-cart btn-hover"> <a href="javascript:void(0);"
                                    onclick="showEnquiryForm()"> {{translation('PRODUCT_ENQUIRY_BUTTON')}} </a> </div>
                            @endif

                        </div>
                        <div class="whatsapp-chat">
                            <a href="https://wa.me/+97433459070/?text=https://mediate.workerman.com/product/short-waist-apron-with-pocket"> 
                                <img src="{{ LoadAssets('assets/images/whatsapp-img.png') }}" target="_blank"> 
                            </a>
                        </div>
                    </form>
                    <!--Wholesale Alerts-->
                    <div class="qty_alert"></div>
                    @if(session()->has('warning'))
                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                        {{ session()->get('warning') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    @endif


                    @if (in_array(config('constkey.section_social_share'), $cKey))
                    <div class="pro-details-social-info"> <span>{{translation('PRODUCT_SHARE')}}</span>
                        <div class="social-info">
                            <ul>
                                <li> <a href="https://www.facebook.com/sharer/sharer.php?u={{$currentURL}}"
                                        target="_blank"><i class="ion-social-facebook"></i></a> </li>
                                <li> <a href="https://twitter.com/intent/tweet?text={{ $currentURL }}" target="_blank">
                                        <i class="ion-social-twitter"></i></a> </li>
                                <li> <a href="https://api.whatsapp.com/send?text={{ $currentURL }}" target="_blank"><i
                                            class="ion-social-whatsapp"></i></a> </li>
                            </ul>
                        </div>
                    </div>
                    @endif

                    @if (!empty($returnpolicy))
                    <div class="pro-details-policy">
                        <ul>
                            <li>
                                <img src="{{ LoadAssets('assets/images/icons/policy.png') }}"
                                    onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                                    alt="" />
                                @foreach ($returnpolicy as $policy)
                                  <span> {{ $policy->return_policy_text }}</span>
                                @endforeach
                            </li>
                        </ul>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Shop details Area End -->

<!-- product details description area start -->
<div class="description-review-area mb-60px">
    <div class="container">
        <div class="description-review-wrapper">
            <div class="description-review-topbar nav">
                <a data-bs-toggle="tab" href="#des-details1">{{translation('PRODUCT_DESCRIPTION_TITLE')}}</a>
                <a class="active" data-bs-toggle="tab" href="#des-details2">{{translation('PRODUCT_DETAILS_TITLE')}}</a>
                @if (in_array(config('constkey.section_review'), $cKey))
                <a data-bs-toggle="tab" id="read_review"
                    href="#des-details3">{{translation('PRODUCT_REVIEWS_TITLE')}}</a>
                @endif
            </div>
            <div class="tab-content description-review-bottom">
                <div id="des-details2" class="tab-pane active">
                    <div class="product-anotherinfo-wrapper">
                        
                        @if (!empty($products) && in_array($products->product_type_id, ['1', '2', '4']))
                        <ul>
                            @if (!empty($products->product_sku))
                            <li class="d-md-flex">
                                <span>
                                    {{translation('PRODUCT_SKU')}}
                                </span>
                                <p>{{ $products->product_sku }}</P>
                            </li>
                            @endif
                            @if (!empty($products->product_model))
                            <li class="d-md-flex">
                                <span>
                                    {{translation('PRODUCT_MODEL')}}
                                </span>
                                <p>{{ $products->product_model }}</P>
                            </li>
                            @endif
                            @if (!empty($products->product_condition))
                            <li class="d-md-flex">
                                <span>
                                    {{translation('PRODUCT_CONDITION')}}
                                </span>
                                <p>{{ $products->product_condition == 1 ? 'New' : 'Refurbished' }}</p>
                            </li>
                            @endif
                            @if (!empty($products->products_to_brand))
                            <li class="d-md-flex">
                                <span>
                                    {{translation('PRODUCT_BRAND_NAME')}}
                                </span>
                                <p>{{ !empty($products->products_to_brand) ? $products->products_to_brand->brand_name :
                                    '' }}</p>
                            </li>
                            @endif
                            @if (!empty($products->products_to_features) && sizeof($products->products_to_features) > 0)
                            @foreach ($products->products_to_features as $featKey => $featVal)
                            <li class="d-md-flex">
                                <span>{{ $featVal->feature_title ?? '' }}</span>
                                <p>{{ $featVal->feature_value ?? '' }}</p>
                            </li>
                            @endforeach
                            @endif

                            @if (!empty($products->other_details))
                            @foreach ($products->other_details as $featKey => $featVal)
                            <li class="d-md-flex">
                                <span>{{ucfirst(str_replace('_', ' ', $featKey)) }}</span>
                                <p>{{ $featVal ?? '' }}</p>
                            </li>
                            @endforeach

                            @endif
                        </ul>
                        @endif
                    </div>
                </div>
                <div id="des-details1" class="tab-pane">
                    <div class="product-description-wrapper">
                        <p>{!! $products->products_description ?? '' !!}</p>
                    </div>
                </div>
                <div id="des-details3" class="tab-pane">
                    <div class="row">
                        @if (!$review_data->isEmpty())
                        <div class="col-lg-7">

                            <div class="review-wrapper">
                                @foreach ($review_data as $key => $data)
                                <div class="single-review ty-compact-list">
                                    <div class="review-img">
                                        <img src="{{ asset('Image/default_user.png') }}"
                                            onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                                            alt="" style="height:80px;width:80px;" />
                                    </div>
                                    <div class="review-content">
                                        <div class="review-top-wrap">
                                            <div class="review-left">
                                                <div class="review-name">
                                                    <h4><b>{{ $data->customers_name }}</b></h4>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="review-bottom">
                                            <p> {{ $data->reviews_text }} </p>
                                        </div>
                                        <div class="rating-product">
                                            <span><b>{{translation('PRODUCT_QUALITY_RATING')}}</b></span>
                                            @php
                                            $j = 0;
                                            for ($i = 0; $i < $data->quality_rating; $i++) {
                                                echo '<i class="ion-android-star"></i>';
                                                $j++;
                                                }
                                                for ($k = 5; $k > $j; $k--) {
                                                echo '<i class="ion-android-star-outline"></i>';
                                                }
                                                @endphp
                                        </div>
                                        <div class="rating-product">
                                            <span><b>{{translation('PRODUCT_PRICE_RATING')}}</b></span>
                                            @php
                                            $j = 0;
                                            for ($i = 0; $i < $data->price_rating; $i++) {
                                                echo '<i class="ion-android-star"></i>';
                                                $j++;
                                                }
                                                for ($k = 5; $k > $j; $k--) {
                                                echo '<i class="ion-android-star-outline"></i>';
                                                }
                                                @endphp
                                        </div>
                                    </div>
                                </div>
                                @endforeach
                                <div type="button" class="btn show-more"
                                    style="background-color:red;color:white;border-radius:3px;display:none;">
                                    {{translation('REVIEW_SHOW_MORE')}}</div>
                            </div>
                        </div>
                        @endif
                        <div class="col-lg-5">
                            <div class="ratting-form-wrapper pl-50">
                                <h3><b>{{translation('PRODUCT_ADD_REVIEWS')}}</b></h3>
                                <br />
                                <div class="ratting-form">
                                    <form id="reviewform" class="needs-validation" novalidate>
                                        <div class="star-box mb-0">
                                            <span>{{translation('PRODUCT_QUALITY_RATING')}}</span>
                                            <div class="rate">
                                                <input type="radio" id="star5" name="quality_rating"
                                                    class="quality_rating" value="5" />
                                                <label for="star5" title="text">{{translation('5STARS')}}</label>
                                                <input type="radio" id="star4" name="quality_rating"
                                                    class="quality_rating" value="4" />
                                                <label for="star4" title="text">{{translation('4STARS')}}</label>
                                                <input type="radio" id="star3" name="quality_rating"
                                                    class="quality_rating" value="3" />
                                                <label for="star3" title="text">{{translation('3STARS')}}</label>
                                                <input type="radio" id="star2" name="quality_rating"
                                                    class="quality_rating" value="2" />
                                                <label for="star2" title="text">{{translation('2STARS')}}</label>
                                                <input type="radio" id="star1" name="quality_rating"
                                                    class="quality_rating" value="1" />
                                                <label for="star1" title="text">{{translation('1STARS')}}</label>
                                            </div>
                                        </div>
                                        <span class="text-danger mt-0" id="quality_rating"></span>
                                        <div class="star-box mb-0"> <span>{{translation('PRODUCT_PRICE_RATING')}}</span>
                                            <div class="rate">
                                                <input type="radio" id="stars5" name="price_rating" class="price_rating"
                                                    value="5" />
                                                <label for="stars5" title="text">{{translation('5STARS')}}</label>
                                                <input type="radio" id="stars4" name="price_rating" class="price_rating"
                                                    value="4" />
                                                <label for="stars4" title="text">{{translation('4STARS')}}</label>
                                                <input type="radio" id="stars3" name="price_rating" class="price_rating"
                                                    value="3" />
                                                <label for="stars3" title="text">{{translation('3STARS')}}</label>
                                                <input type="radio" id="stars2" name="price_rating" class="price_rating"
                                                    value="2" />
                                                <label for="stars2" title="text">{{translation('2STARS')}} </label>
                                                <input type="radio" id="stars1" name="price_rating" class="price_rating"
                                                    value="1" />
                                                <label for="stars1" title="text">{{translation('1STARS')}}</label>
                                            </div>
                                        </div>
                                        <span class="text-danger" id="price_rating"></span>

                                        <div class="row">
                                            @guest
                                            <div class="col-md-6">
                                                <div class="rating-form-style mb-10">
                                                    <input
                                                        placeholder="{{translation('PRODUCT_REVIEW_NAME_PLACEHOLDER')}}"
                                                        type="text" name="customers_name" class="form-control customers_name"
                                                        required />
                                                </div>
                                                <span class="text-danger" id="customers_name"></span>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="rating-form-style mb-10">
                                                    <input
                                                        placeholder="{{translation('PRODUCT_REVIEW_EMAIL_PLACEHOLDER')}}"
                                                        type="email" name="customers_email" class="form-control customers_email"
                                                        required />
                                                </div>
                                                <span class="text-danger" id="customers_email"></span>
                                            </div>
                                            @endguest
                                            <div class="col-md-12">
                                                <div class="rating-form-style mb-0">
                                                    <input
                                                        placeholder="{{translation('PRODUCT_REVIEW_TITLE_PLACEHOLDER')}}"
                                                        type="text" name="reviews_title"
                                                        class="form-control reviews_title" required />
                                                </div>
                                            </div>
                                            <input type="hidden" value="{{ $products->product_id }}" class="products_id"
                                                name="products_id">
                                            <input type="hidden" value="0" name="reviews_read">
                                            <div class="col-md-12">
                                                <div class="rating-form-style form-submit">
                                                    <textarea
                                                        placeholder="{{translation('PRODUCT_REVIEW_MESSAGE_PLACEHOLDER')}}"
                                                        name="reviews_text" class="form-control reviews_text"
                                                        required></textarea>
                                                    {{-- <span class="text-danger" id="reviews_text"></span> --}}
                                                    <input type="submit" id="reviewformbutton"
                                                        value="{{translation('PRODUCT_REVIEW_SUBMIT')}}"
                                                        style="color:white;" />
                                                </div>
                                            </div>
                                            <ul id="successlist"></ul>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- product details description area end -->

<!-- Recent Add Product Area Start -->
@if (in_array(config('constkey.section_related'), $cKey))

@if (!$related_data->isEmpty())
<section class="recent-add-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <!-- Section Title -->
                <div class="section-title">
                    <h2>{{translation('PRODUCT_RELETED_TO_YOU')}}</h2>
                    <p>{{translation('PRODUCT_WEEKLY_LINEUP')}}</p>
                </div>
                <!-- Section Title -->
            </div>
        </div>
        <!-- Recent Product slider Start -->
        <div class="recent-product-slider owl-carousel owl-nav-style">
            <!-- Single Item -->

            @foreach ($related_data as $key => $product)
            <x-ecom01.shared-component.product viewtype="grid" :data="$product" />
            @endforeach
            <!-- Single Item -->
        </div>
        <!-- Recent product slider end -->
    </div>
</section>
@endif

@endif
<!-- Recent product area end -->

<!--Starting of Enquiry Form Modal-->
@if (webFunctionStatus(config('constkey.is_enquiry_enabled')))
<div class="modal fade enquiry-form" id="EnquiryModal" tabindex="-1" aria-labelledby="exampleModalLabel"
    aria-modal="true" role="dialog">
    <div class="modal-dialog prdtmodal-dialog py-4">
        <div class="modal-content">
            <div class="col-md-12 ">
                <button type="button" class="btn-close prdtbtn-close" data-bs-dismiss="modal"
                    aria-label="Close">X</button>
            </div>
            <div class="pt-4 px-4 pb-2">
                <div class="pl-3">
                    <h2 class=" enquiry_heading">{{translation('ENQUIRY_TITLE')}}</h2>
                </div>
                <form id="enquiryform" class="enquiryformdata required needs-validation" method="POST"
                    enctype="multipart/form-data" novalidate="">
                    <input type="hidden" id="products_id" name="products_id" value="{{ $products->product_id }}">
                    <div class=" modal-body pt-2">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-12 py-2">
                                <label class="form-label">{{translation('ENQUIRY_NAME')}} <span
                                        class="text-danger">*</span></label>
                                <input type="text" name="customers_name" id="enqcustomers_name"
                                    class="form-control enquiry_form "
                                    placeholder="{{translation('ENQUIRY_NAME_PLACEHOLDER')}}" required="">
                                <div class="invalid-feedback">
                                    {{translation('ERROR_NAME')}}
                                </div>
                                <span class="text-danger customers_name_enq"></span>
                            </div>
                            <div class="col-lg-6 col-md-6 col-12 py-2">
                                <label class="form-label">{{translation('ENQUIRY_EMAIL')}} <span
                                        class="text-danger">*</span></label>
                                <input type="email" class="form-control enquiry_form " name="email_address"
                                    id="email_address" placeholder="{{translation('ENQUIRY_EMAIL_PLACEHOLDER')}}"
                                    aria-label="email" required="">
                                <div class="invalid-feedback">
                                    {{translation('ERROR_EMAIL')}}
                                </div>
                                <span class="text-danger email_address_enq"></span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-12 py-2 ">
                                <label class="form-label">{{translation('ENQUIRY_PHONE_NO')}}</label>

                                <input type="text" class="form-control enquiry_form" name="phone" id="phone"
                                    placeholder="{{translation('ENQUIRY_PHONE_NO_PLACEHOLDER')}}">
                            </div>

                            <div class="col-lg-6 col-md-6 col-12 py-2">
                                <label class="form-label">{{translation('ENQUIRY_QUANTITY')}} <span
                                        class="text-danger">*</span></label>

                                <input type="number" class="form-control enquiry_form " name="products_qty"
                                    onblur="qtyItm()" id="products_qty" maxlength="10"
                                    placeholder="{{translation('ENQUIRY_QUANTITY_PLACEHOLDER')}}" aria-label="qty"
                                    required="">
                                <div class="invalid-feedback">
                                    {{translation('ERROR_QTY')}}
                                </div>
                                <span class="text-danger products_qty_enq"></span>
                            </div>
                        </div>
                        <div class="row">
                            @php $max_option_id =0 @endphp
                            @if (!empty($products->productAttribute))
                            @foreach ($products->productAttribute as $attribute)
                            @if (isset($attribute->option_value_list) && !empty($attribute->option_value_list))
                            @php
                            if ($max_option_id < $attribute->options_id) {
                                $max_option_id = $attribute->options_id;
                                }
                                @endphp
                                <div class="col-lg-6 col-md-6 col-12 py-2">
                                    <label class="form-label">{{ ucfirst($attribute->option_name ?? '')}}</label>
                                    <select aria-label="Default select example"
                                        name="attribute_{{ $attribute->options_id }}" id="{{ $attribute->options_id }}"
                                        class="enquiry_form" required="">
                                        <option selected="" disabled="">Select {{ ucfirst($attribute->option_name ?? '')
                                            }}</option>
                                        @foreach ($attribute->option_value_list as $option_value)
                                        <option value="{{ $option_value->options_values_id }}">
                                            {{ $option_value->productOptionsValue->products_options_values_name }}
                                        </option>
                                        @endforeach
                                    </select>
                                </div>
                                @endif
                                @endforeach
                                @endif
                        </div>
                        <input type="hidden" id="max_option_id" name="max_option_id" value="3">

                        <div class="row">
                            <div class=" col-md-12 col-12 py-2">
                                <label class="form-label">{{translation('ENQUIRY_MESSAGE')}}</label>
                                <textarea type="text" name="message" id="message" class="form-control enquiry_form "
                                    placeholder="{{translation('ENQUIRY_MESSAGE_PLACEHOLDER')}}"
                                    aria-label="Enquiry Message" style="height:65px"></textarea>
                                <span class="text-danger message_enq"></span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-8 col-md-8 col-12 py-2">
                                <input type="checkbox" name="newsletter" checked="" id="myCheck">
                                <label for="myCheck">{{translation('ENQUIRY_NEWSLETTER')}}</label>
                            </div>

                        </div>

                    </div>
                    <div class="col-lg-4 mx-auto">
                        <div class="enquiry_frm_btn">
                            <button type="submit" class="btn enquiry_btn"
                                id="enquirymodalformbutton">{{translation('ENQUIRY_SUBMIT')}}</button>
                            <input type="reset" hidden="">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endif

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
<script>
    $(document).ready(function () {
        // $("#cartform").submit(function (e) {
        //     var min_ord_qty = $('.minordqty').val();
        //     var qtyItemAdd = $('#qtyItemAdd').val();
         
        //     var alertHtml = `<div class="alert alert-danger alert-dismissible fade show" role="alert">
        //                     <strong>Sorry !</strong> Please Add minimum ${min_ord_qty} Qty.
        //                     <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        //                     </div>`;

        //     if (min_ord_qty != 'undefined') {

        //         if (Number(qtyItemAdd) < Number(min_ord_qty)) {
        //             $('#qtyItemAdd').val(min_ord_qty);
        //             $('.qty_alert').html(alertHtml);
        //             e.preventDefault();
        //         }
        //         else {
        //             $('#cartform').submit();
        //         }
        //     } else {
        //         $('#cartform').submit()
        //     }
        // });
    });

    $(document).on('click', '.qtybutton', function (e) {

    })

    // Enquiry Modal 

    $(document).on('click', '#enquirymodalformbutton', function (e) {
        e.preventDefault();
        $('#enquiryform').addClass('was-validated');
        if ($('#enquiryform')[0].checkValidity() === false) {
            event.stopPropagation();
        } else {
            let enquiryform = document.getElementById('enquiryform');
            let formData = new FormData(enquiryform);
            var URL = window.location.href;
            var arr = URL.split('/');
            formData.append('page_source', arr.pop());

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "/storeProductEnquiry",
                data: formData,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                beforeSend: function () {
                    $("#enquirymodalformbutton").addClass('disabled');
                    var html = '<i class="fa-solid fa-spinner fa-spin-pulse"></i> {{translation('SUBMITTING')}}...';
                    $("#enquirymodalformbutton").html(html);
                },
                success: function (response) {
            
                    if (response.status == 400) {
                        $.each(response.error, function (key, err_val) {
                            $('.' + key + '_enq').text(err_val);
                        });
                    } else {
                        $('#enquiryform').trigger("reset");
                        $('#EnquiryModal').modal('hide');
                        Notify('{{translation('SUCCESSFULLY_SEND')}}', true);
                    }
                },
                complete: function (response) {
                    $('#enquirymodalformbutton').removeClass('disabled');
                    $('#enquiryform').removeClass('was-validated');
                    $('#enquirymodalformbutton').html('{{translation('SUBMIT')}}');
                }
            });
        }
    });

    // Ending of Enquiry Form Modal
    var enqdetail_choosen_attributes = [];
    var choosen_attributes_ary = [];

    function enqchooseAttributes(params, opid) {
        choosen_attributes_ary = [];
        enqdetail_choosen_attributes[opid] = params.value;

        // Now it can be used reliably with $.map()
        $.map(enqdetail_choosen_attributes, function (val, i) {
            if (val > 0)
                choosen_attributes_ary.push(val);
        });
    }


    $(document).ready(function () {
        $(document).on('click', '#reviewformbutton', function (e) {
            e.preventDefault();
            $('#reviewform').addClass('was-validated');
            if ($('#reviewform')[0].checkValidity() === false) {
                event.stopPropagation();
            } else {
                var data = {
                    'customers_name': $('.customers_name').val(),
                    'customers_email': $('.customers_email').val(),
                    'quality_rating': $('.quality_rating:checked').val(),
                    'price_rating': $('.price_rating:checked').val(),
                    'reviews_title': $('.reviews_title').val(),
                    'products_id': $('.products_id').val(),
                    'reviews_read': $('.reviews_read').val(),
                    'reviews_text': $('.reviews_text').val(),
                }
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "/storereview",
                    data: data,
                    dataType: "json",

                    beforeSend: function () {
                        $("#reviewformbutton").addClass('disabled');
                        var html = '{{translation('SUBMITTING')}}...';
                        $("#reviewformbutton").html(html);
                    },

                    success: function (response) {
                        if (response.status == 400) {
                            $.each(response.error, function (key, err_val) {
                                $('#' + key).text(err_val);
                            });
                        } else {
                            $('#successlist').html("");
                            Notify('{{translation('REVIEW_SUCCESS_MSG')}}', true);
                            $('#reviewform').trigger("reset");
                        }
                    },
                    complete: function (response) {
                        $('#reviewformbutton').removeClass('disabled');
                        $("#reviewformbutton").html("{{translation('SUBMIT')}}");
                        $('#reviewform').removeClass('was-validated');
                    }

                });
            }
        });
    });

    // Show more jquery

    if ($('.ty-compact-list').length > 3) {
        $('.ty-compact-list:gt(2)').hide();
        $('.show-more').show();
    }
    $('.show-more').on('click', function () {
        $('.ty-compact-list:gt(2)').toggle();
        $(this).text() === 'Show more' ? $(this).text('Show less') : $(this).text('Show more');
    });

    //  Check Min Order VAl

    // function qtyItm() {
    //     var enqQtyItem = $('#products_qty').val();
    //     var qtyItem = $('#qtyItemAdd').val();

    //     if (enqQtyItem < 1) {
    //         $('#products_qty').val('1');
    //     }
    //     if (qtyItem < 1) {
    //         $('#qtyItemAdd').val('1');
    //     }
    // }

</script>
@endpush