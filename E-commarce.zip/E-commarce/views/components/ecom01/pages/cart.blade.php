@php

$main_arr = [
'title' => '',
'sublist' => [
[
'name' => translation('HOME'),
'link' => url('/'),
],
[
'name' =>translation('CART'),
'link' =>url()->full()
],
],
];
@endphp

<!-- Breadcrumb Area Start -->
<x-Ecom01.SharedComponent.BreadCrumb :data="$main_arr" />
<!-- Breadcrumb Area End -->

<!-- cart area start -->
<div class="cart-main-area mtb-60px">
    @if (!empty($list['cart_list']) && sizeof($list['cart_list']) > 0)
    <div class="container" id="cart-table">
        <h3 class="cart-page-title">{{translation('CART_TITLE')}}</h3>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-12" >
                <form action="#">
                    <div class="table-content table-responsive cart-table-content">
                        <table>
                            <thead>
                                <tr>
                                    <th>{{translation('CART_PRODUCT_IMAGE')}}</th>
                                    <th>{{translation('CART_PRODUCT_NAME')}}</th>
                                    <th>{{translation('CART_PRODUCT_UNIT_PRICE')}}</th>
                                    <th>{{translation('CART_PRODUCT_QUANTITY')}}</th>
                                    <th>{{translation('CART_SUBTOTAL')}}</th>
                                    <th>{{translation('CART_ACTION')}}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if (!empty($list['cart_list']))
                                    @foreach ($list['cart_list'] as $cart)
                                    
                                        <tr class="cart-table_{{$cart->cart_id}}">
                                            <td class="product-thumbnail">
                                                <a href="{{ url('product/' . $cart->product->product_slug) }}">
                                                    <img src="{{ getFullImageUrl($cart->product->product_image) }}" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" alt="{{ $cart->product->products_name ?? '' }}" height="50" />
                                                </a>
                                            </td>
                                            <td class="product-name">
                                                <a href="{{ url('product/' . $cart->product->product_slug) }}">
                                                    {{ $cart->product->products_name ?? '' }}
                                                </a>
                                                @if (isset($cart->attributes) && !empty($cart->attributes))
                                                    <div>
                                                        @foreach ($cart->attributes as $attribute)
                                                            @if (isset($attribute->product_options))
                                                                <span>
                                                                    {{ $attribute->product_options->products_options_name }} : {{ $attribute->products_options_values_name }}
                                                                </span><br />
                                                            @endif
                                                        @endforeach
                                                    </div>
                                                @endif
                                            </td>
                                            <td class="product-price-cart"><span class="amount prd_prc__{{$cart->cart_id}}">
                                                    {{ currencyFormat($cart->final_price ?? 0) }}
                                                </span></td>
                                            <td class="product-quantity">
                                                <div class="cart-plus-minus ">
                                                    <input class="cart-plus-minus-box quantity" data-cart="{{ $cart->cart_id }}" id="{{ $cart->cart_id }}_qty" type="number" name="qtybutton" onblur="qtyItm({{$cart->cart_id}})" value="{{ $cart->qty }}" min=1 step=1 >
                                                </div>
                                            </td>
                                            
                                            <td class="product-subtotal total_price_{{$cart->cart_id}}">
                                                @php
                                                $qty = (int) $cart->qty;
                                                $price = $cart->final_price ?? 0;
                                                echo currencyFormat($qty * $price);
                                                @endphp
                                            </td>
                                            <td class="product-remove">
                                                <a href="javascript:void(0)"
                                                    onclick="actionOnCart({{ $cart->cart_id }},'del')"><i
                                                    class="fa fa-times"></i></a>
                                            </td>
                                        </tr>

                                        @if($cart->product->products_prices !=null)
                                            <input type="hidden" hidden class="minordqty"  id="{{ $cart->cart_id }}_min_qty" value="{{$cart->product->products_prices->min('product_qty')}}">
                                            <input type="hidden" hidden class="ordqty" id="{{ $cart->cart_id }}_ord_qty"  value="{{$cart->qty}}">
                                        @endif

                                    @endforeach
                                @endif
                            </tbody>
                        </table>
                    </div>
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="cart-shiping-update-wrapper">
                                <div class="cart-shiping-update">
                                    <a href="{{ url('/') }}">{{translation('CONTINUE_TO_SHOP')}}</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-12">
                        <div class="grand-totall">
                            <div class="title-wrap">
                                <h4 class="cart-bottom-title section-bg-gary-cart"></h4>
                            </div>
                            <h5>{{translation('CART_TOTAL')}}<span class="products_total">{{ currencyFormat($list['product_total'])}}</span></h5>
                            <a href="{{ url('checkout') }}">{{translation('PROCEED_CHECKOUT')}}</a>
                        </div>
                    </div>
                    </div>
                </form>
                </div> 
            </div>
        </div>
    </div>
    @else
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-4 mx-auto">
                <img src="{{ LoadAssets('assets/images/EmptyImages/Cart-Empty.jpg') }}"
                    onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" class="rounded mx-auto d-block"
                    width="286px" height="200px" alt="{{ getSetting('site_title') }} Cart-Empty">
                <p class="h4 text-center text-dark mt-2">{{translation('EMPTY_CART_MSG')}}</p>
                <div class="text-center my-3">
                    <a href="{{ url('/') }}" class="btn btn-primary btn-lg btn-block" role="button" aria-pressed="true">{{translation('CONTINUE_TO_SHOP')}}</a>
                </div>
            </div>
        </div>
    </div>
    @endif
</div>

@push('scripts')
<script>
    $(document).on("click", ".qtybutton", function () {
        let cart_id = $(this).parent().find('input').data('cart');

        var min_ord_qty=$(`#${cart_id}_min_qty`).val();
        var ord_qty=$(`#${cart_id}_ord_qty`).val();
        var qty = $(`#${cart_id}_qty`).val();
    
        if(min_ord_qty !='undefined')
        {   
            if(Number(qty)<Number(min_ord_qty))
            {   
                Notify(`Please add minimum ${min_ord_qty} Qty.`, false);
                $(`#${cart_id}_qty`).val(ord_qty);
            }
            else
            {
              actionOnCart(cart_id, 'add'); 
            }
        }else{
            actionOnCart(cart_id, 'add');
        }
    });

    function actionOnCart(cart_id, type) {
        var qty = $(`#${cart_id}_qty`).val();
        if (type === 'del') {
            $('.cart-table_' + cart_id).hide();
        }
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
            url: '{{ route('incDecDelCart') }}',
            method: 'POST',
            data: {
                cart_id: cart_id,
                qty: qty,
                type: type,
            },
            success: function (response) {
                $('.count-cart-total').html(response.header_html);
                if (response.cart_response.total_count > 0) {
                    $('.products_total').text(response.cart_response.products_total);
                    $('.grandAmount').text(response.cart_response.grand_totals);
                    $(response.cart_response.cart_list).each(function (key, value) {
                        if (cart_id == value.cart_id) {
                            $('.prd_prc__' + value.cart_id).text(value.fin_price);
                            $('.total_price_' + value.cart_id).text(value.total);
                        }
                    });
                } else {
                    var html =`<div class="container">
                                <div class="row">
                                    <div class="col-12 col-lg-4 mx-auto">
                                        <img src="{{ LoadAssets('assets/images/EmptyImages/Cart-Empty.jpg') }}"
                                            onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" class="rounded mx-auto d-block"
                                            width="286px" height="200px" alt="{{ getSetting('site_title') }} Cart-Empty">
                                        <p class="h4 text-center text-dark mt-2">{{translation('EMPTY_CART_MSG')}}</p>
                                        <div class="text-center my-3">
                                            <a href="{{ url('/') }}" class="btn btn-primary btn-lg btn-block" role="button" aria-pressed="true">{{translation('CONTINUE_TO_SHOP')}}</a>
                                        </div>
                                    </div>
                                </div>
                            </div>`;
                    $('#cart-table').html(html);
                }
                var msg = type === 'del' ? '{{translation('CART_ITEM_REMOVED_MSG')}}!' : '{{translation('CART_ITEM_UPDATE_MSG')}}!';
                Notify(msg, true);
                $.fn.qtyButton();
            },
            error: function (error) {
                Notify('{{translation('ERROR_CART_ADD')}}', false);
            }
        });

    }

    function qtyItm(id) {
        var qtyItem = $('#'+id+'_qty').val();
        if (qtyItem < 1) {
        $('#'+id+'_qty').val('1');
        }
        // Validation for minimum qty of wholesale product  
        let cart_id = id;
        var min_ord_qty=$(`#${cart_id}_min_qty`).val();
        var ord_qty=$(`#${cart_id}_ord_qty`).val();
        var qty = $(`#${cart_id}_qty`).val();

        if(min_ord_qty !='undefined')
        {   
        if(qty<min_ord_qty)
        {
        $(`#${cart_id}_qty`).val(ord_qty);
        Notify(`Please add minimum ${min_ord_qty} Qty.`, false);
        }
        else
        {
        actionOnCart(cart_id, 'add'); 
        }
        }else{
        actionOnCart(cart_id, 'add');
        }
    }


</script>
@endpush