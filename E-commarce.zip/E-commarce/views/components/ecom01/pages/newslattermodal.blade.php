<div  id="newsletter-wrapper">
    <button type="button" class="btn-close prdtbtn-close " data-bs-dismiss="modal" aria-label="Close">X</button>
    <div class="white-popup">
        <div class="banner-newsletter">
        <img src="{{getFullImageUrl(getSetting('newsletter_image'))}}" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"   class="w-100 img-fluid" alt="{{getSetting('site_title')}}-New Latter Image" class="img-fluid" >
        </div>
        <div class="popup-newsletter">
        <div class="popup-title">
            <h1>{{getSetting('newsletter_title')?? ''}}</h1>
            <p class="notice">{{getSetting('newsletter_subtitle') ?? ''}}</p>
        </div>
        <form class="form-subscribe mt-3 needs-validation"  id="newsltrModalForm" novalidate>
            <input class="input  newsletter-email ps-3 form-control" id="customeremail" type="email" value="" placeholder="{{translation('NEWSLETTER_EMAIL_PLACEHOLDER')}}" name="EMAIL" required>
            <button class="button" name="subscribe" id="modal_subscribe" type="submit">{{translation('NEWSLETTER_SUBSCRIBE_BUTTON')}}</button>
        </form>
        <span id="email_err" class="text-danger"></span> 
        <div>
            <ul>
            @if(!empty(socialLinks('facebook_url')))
            <li>
                    <a href="{{socialLinks('facebook_url')}}"><i class="fab fa-facebook-f"></i></a> 
            </li>
            @endif
            @if(!empty(socialLinks('twitter_url')))
            <li>
                    <a href="{{socialLinks('twitter_url')}}"><i class="fab fa-twitter"></i></a> 
            </li>
            @endif
            @if(!empty(socialLinks('linkedin_url')))
            <li>
                    <a href="{{socialLinks('linkedin_url')}}"><i class="fab fa-linkedin-in"></i></a> 
            </li>
            @endif

            @if(!empty(socialLinks('pinterest_url')))
            <li>   
                    <a href="{{socialLinks('pinterest_url')}}"><i class="fab fa-pinterest-p"></i></a> 
            </li>
            @endif
            @if(!empty(socialLinks('instagram_url')))
            <li> 
              <a href="{{socialLinks('instagram_url')}}"><i class="fab fa-instagram"></i></a> 
              </a>
            </li>
            @endif
            @if(!empty(socialLinks('youtube_url')))
            <li>
                <a href="{{socialLinks('youtube_url')}}"><i class="fab fa-youtube"></i></a> 
            </li>
            @endif
        </ul>
        </div>
        </div>
    </div>
    </div>
