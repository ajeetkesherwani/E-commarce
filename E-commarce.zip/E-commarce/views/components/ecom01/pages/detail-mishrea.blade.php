@push('styles')
<style>
    .prdtmodal-dialog {
        max-width: 600px !important;
    }

    .prdtmodal-footer {
        border: none;
        justify-content: center;
    }

    .prdtbtn-close {
        position: absolute;
        top: 5px;
        right: 5px;
    }

    .prdttxt-right {
        text-align: right;
    }

    /*.modal-content {
        background: linear-gradient(142deg, rgba(238,84,67,1) 0%, rgba(143,50,120,1) 87%);
    }*/
</style>
@endpush
@php
$avgrating=AvgRating($products->product_id);    
@endphp
<section class="breadcrumb-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="breadcrumb-content">
                    <h1 class="breadcrumb-hrading">Single Product Page</h1>
                    <ul class="breadcrumb-links">
                        <li><a href="index.html">Home</a></li>
                        <li>Single Product Variable</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Breadcrumb Area End -->
<!-- Shop details Area start -->
<section class="product-details-area mtb-60px">
    <div class="container">
        <div class="row">
            <div class="col-xl-6 col-lg-6 col-md-12">
                <div class="product-details-img product-details-tab">
                    <div class="zoompro-wrap zoompro-2">
                        <div class="zoompro-border zoompro-span">
                            <img class="zoompro" src="{{getFullImageUrl($products->product_image)}}"
                                data-zoom-image="{{getFullImageUrl($products->product_image)}}" alt="" />
                        </div>
                    </div>
                    @if(!empty($products->products_to_gallery))

                    <div id="gallery" class="product-dec-slider-2">
                        @foreach($products->products_to_gallery as $key=>$data)
                        <a class="active" data-image="{{getFullImageUrl($data->images_id)}}"
                            data-zoom-image="{{getFullImageUrl($data->images_id)}}">
                            <img src="{{getFullImageUrl($data->images_id)}}" alt="{{$data->images_name}}" />
                        </a>
                        @endforeach
                    </div>
                    @endif
                </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-12">
                <div class="product-details-content">
                    <h2>
                        {{ $products->products_name ?? '' }}
                    </h2>
                    <p class="reference">Reference:<span> demo_17</span></p>
                    <div class="pro-details-rating-wrap">
                        <div class="rating-product">
                            @if(!empty($avgrating))
                            @for($i=1;$i<$avgrating;$i++)
                            <i class="ion-android-star"></i>
                           @endfor
                           @endif
                        </div>
                        <span class="read-review"><a class="reviews" href="#">Read reviews (1)</a></span>
                    </div>
                    <div class="pricing-meta">
                        <ul>
                            <li class="old-price not-cut">
                                {{ currencyFormat($products->product_sale_price ?? '0.00') }}
                            </li>
                        </ul>
                    </div>
                    <p> {{ $products->products_description ?? 'Lorem ipsum dolor sit amet, consectetur adipisic elit
                        eiusm
                        tempor incidid ut labore et dolore
                        magna aliqua. Ut enim ad minim venialo quis nostrud exercitation ullamco' }} </p>
                    <div class="pro-details-list">
                        <ul>
                            <li>- 0.5 mm Dail</li>
                            <li>- Inspired vector icons</li>
                            <li>- Very modern style</li>
                        </ul>
                    </div>

                    @if (webFunctionStatus(config('constkey.is_cart_enabled')) || webFunctionStatus(config('constkey.is_enquiry_enabled')))
                    
                        <div class="pro-details-size-color d-flex">
                            @if(!empty($products->productAttribute))
                            @foreach($products->productAttribute as $attribute)
                            <div class="product-size">
                                <span>{{ ucfirst($attribute->option_name ?? '')}}</span>
                                @if( isset($attribute->option_value_list) && !empty($attribute->option_value_list))
                                <select onchange="chooseAttributes(this)">
                                    @foreach($attribute->option_value_list as $option_value)
                                    <option value="{{ $option_value->options_values_id}}">
                                        {{ $option_value->productOptionsValue->products_options_values_name}} </option>
                                    @endforeach
                                </select>
                                @endif
                            </div>
                            @endforeach
                            @endif

                        </div>    
                        <div class="pro-details-quality">
                            <!-- show cart button -->
                            @if (webFunctionStatus(config('constkey.is_cart_enabled')))    
                                <div class="cart-plus-minus">
                                    <input class="cart-plus-minus-box" type="text" id="qtyItemAdd" name="qtybutton" value="1" />
                                </div>
                                <div class="pro-details-cart btn-hover">
                                    <a href="javascript:void(0);" onclick="addToCartFromDetail({{ $products->product_id }})"> +
                                        Add To Cart
                                    </a>
                                </div>
                            @endif
                            <!-- show enquiry button -->
                            @if (webFunctionStatus(config('constkey.is_enquiry_enabled')))    
                                <div class="pro-details-cart btn-hover">
                                    <a href="javascript:void(0);" onclick="showEnquiryForm()">
                                        Enquiry Now
                                    </a>
                                </div>
                            @endif
                        </div>
                    @endif

                    @if (webFunctionStatus(config('constkey.is_wishlist_enabled'))) 
                    <div class="pro-details-wish-com">
                        <div class="pro-details-wishlist">
                            <a href="javascript:void(0);" onclick="addToWishListFromDetail({{ $products->product_id }})"><i class="ion-android-favorite-outline"></i>Add to wishlist</a>
                        </div>
                    </div>
                    @endif

                    <div class="pro-details-social-info">
                        <span>Share</span>
                        <div class="social-info">
                            <ul>
                                <li>
                                    <a href="{{getSetting('facebook_url')}}" target="_blank" ><i class="ion-social-facebook"></i></a>
                                </li>
                                <li>
                                    <a href="{{getSetting('twitter_url')}}" target="_blank" ><i class="ion-social-twitter"></i></a>
                                </li>
                                <li>
                                    <a href="{{getSetting('google_url')}}" target="_blank" ><i class="ion-social-google"></i></a>
                                </li>
                                <li>
                                    <a href="{{getSetting('instagram_url')}}" target="_blank" ><i class="ion-social-instagram"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="pro-details-policy">
                        <ul>
                            <li>
                                <img src="{{LoadAssets('assets/images/icons/policy.png" alt=""') }} />
                                <span>
                                    Security Policy (Edit With Customer Reassurance Module)
                                </span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Shop details Area End -->
<!-- product details description area start -->
<div class="description-review-area mb-60px">
    <div class="container">
        <div class="description-review-wrapper">
            <div class="description-review-topbar nav">
                <a data-bs-toggle="tab" href="#des-details1">Description</a>
                <a class="active" data-bs-toggle="tab" href="#des-details2">Product Details</a>
                <a data-bs-toggle="tab" href="#des-details3">Reviews</a>
            </div>
            <div class="tab-content description-review-bottom">
                <div id="des-details2" class="tab-pane active">
                    <div class="product-anotherinfo-wrapper">
                        @if(!empty($products))
                        <ul>
                            <li><span>Product Sku</span>{{$products->product_sku}}</li>
                            <li><span>Product Model</span>{{$products->product_model}}</li>
                            <li><span>Product Condition</span>{{$products->product_condition==1?"New":"Refurbished"}}</li>
                            <li><span>Brand Name</span>{{$products->products_to_brand->brand_name}}</li>
                            <li><span>Product Feature</span>{{$products->product_feature==1 ? "Yes" :"No"}}</li>
                            <li><span>Product Shipping</span>{{$products->product_shipping==1 ? "Yes" :"No"}}</li>
                            <li><span>Product Attribute</span>{{$products->product_attribute==1 ? "Yes" :"No"}}</li>
                        </ul>
                        @endif
                    </div>
                </div>
                <div id="des-details1" class="tab-pane">
                    <div class="product-description-wrapper">
                        <p>{{ $products->products_description ?? ' Message is None' }}</p>
                    </div>
                </div>
                <div id="des-details3" class="tab-pane">
                    <div class="row">
                        <div class="col-lg-7">
                            @if(!empty($review_data))

                            <div class="review-wrapper">

                                @foreach($review_data as $key=>$data)
                                <div class="single-review ty-compact-list">
                                    <div class="review-img">
                                        <img src="https://www.pngfind.com/pngs/m/470-4703547_icon-user-icon-hd-png-download.png"
                                            alt="" style="height:80px;width:80px;" />
                                    </div>
                                    <div class="review-content">
                                        <div class="review-top-wrap">
                                            <div class="review-left">
                                                <div class="review-name">
                                                    <h4><b>{{$data->customers_name}}</b></h4>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="review-bottom">
                                            <p>
                                                {{$data->reviews_text}}
                                            </p>
                                        </div>
                                        <div class="rating-product"> <span><b>Quality Rating:</b></span>
                                            @php
                                            $j=0;
                                            for($i=0 ; $i<$data->quality_rating ; $i++)
                                                {
                                                echo'<i class="ion-android-star"></i>';
                                                $j++;
                                                }
                                                for($k=5;$k>$j;$k--)
                                                {
                                                echo'<i class="ion-android-star-outline"></i>';
                                                }
                                                @endphp
                                        </div>
                                        <div class="rating-product"><span><b>Price Rating:</b></span>
                                            @php
                                            $j=0;
                                            for($i=0 ; $i<$data->price_rating ; $i++)
                                                {
                                                echo'<i class="ion-android-star"></i>';
                                                $j++;
                                                }
                                                for($k=5;$k>$j;$k--)
                                                {
                                                echo'<i class="ion-android-star-outline"></i>';
                                                }
                                                @endphp
                                        </div>
                                    </div>
                                </div>
                                @endforeach
                                <div type="button" class="btn show-more"
                                    style="background-color:red;color:white;border-radius:3px;display:none;">Show more
                                </div>
                            </div>
                            @endif
                        </div>
                        <div class="col-lg-5">
                            <div class="ratting-form-wrapper pl-50">
                                <h3>Add a Review</h3>
                                <div class="ratting-form">
                                    <form id="reviewform">

                                        <div class="star-box">
                                            <span>Quality Rating:</span>
                                            <div class="rating-product">
                                                <input type="radio" name="quality_rating" class="quality_rating"
                                                    value="1">
                                                <input type="radio" name="quality_rating" class="quality_rating"
                                                    value="2">
                                                <input type="radio" name="quality_rating" class="quality_rating"
                                                    value="3">
                                                <input type="radio" name="quality_rating" class="quality_rating"
                                                    value="4">
                                                <input type="radio" name="quality_rating" class="quality_rating"
                                                    value="5">
                                            </div>

                                            <span class="text-danger" id="quality_rating"></span>

                                        </div>
                                        <div class="star-box">
                                            <span>Price Rating:</span>
                                            <div class="rating-product">
                                                <input type="radio" name="price_rating" class="price_rating" value="1">
                                                <input type="radio" name="price_rating" class="price_rating" value="2">
                                                <input type="radio" name="price_rating" class="price_rating" value="3">
                                                <input type="radio" name="price_rating" class="price_rating" value="4">
                                                <input type="radio" name="price_rating" class="price_rating" value="5">
                                            </div>

                                            <span class="text-danger" id="price_rating"></span>

                                        </div>
                                        <div class="row">
                                            @guest
                                            <div class="col-md-6">
                                                <div class="rating-form-style mb-10">
                                                    <input placeholder="Enter Your Name Here.." type="text"
                                                        name="customers_name" class="customers_name" />
                                                </div>
                                                <span class="text-danger" id="customers_name"></span>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="rating-form-style mb-10">
                                                    <input placeholder="Enter Your Email Here.." type="email"
                                                        name="customers_email" class="customers_email" />
                                                </div>
                                                <span class="text-danger" id="customers_email"></span>
                                            </div>
                                            @endguest
                                            <div class="col-md-12">
                                                <div class="rating-form-style mb-10">
                                                    <input placeholder="Enter Your Review Title Here.." type="text"
                                                        name="reviews_title" class="reviews_title" required />
                                                </div>
                                                <span class="text-danger" id="reviews_title"></span>
                                            </div>

                                            <input type="hidden" value="{{$products->product_id}}" class="products_id"
                                                name="products_id">
                                            <input type="hidden" value="0" name="reviews_read">
                                            <div class="col-md-12">
                                                <div class="rating-form-style form-submit">
                                                    <textarea placeholder="Enter Your Review" name="reviews_text"
                                                        class="reviews_text" required></textarea>
                                                    <span class="text-danger" id="reviews_text"></span>
                                                    <input type="submit" id="reviewformbutton" value="Submit" />
                                                </div>
                                            </div>
                                            <ul id="successlist"></ul>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    <!-- product details description area end -->
    <!-- Recent Add Product Area Start -->
    <section class="recent-add-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <!-- Section Title -->
                    <div class="section-title">
                        <h2>You Might Also Like</h2>
                        <p>Add Related products to weekly line up</p>
                    </div>
                    <!-- Section Title -->
                </div>
            </div>
            <!-- Recent Product slider Start -->
            <div class="recent-product-slider owl-carousel owl-nav-style">
                <!-- Single Item -->
                @if(!empty($related_data))
                @foreach($related_data as $key=>$product)
                <x-theme1.shared-component.product viewtype="grid" :data="$product" />
                @endforeach
                @endif
                <!-- Single Item -->
            </div>
            <!-- Recent product slider end -->
        </div>
    </section>
    <!-- Recent product area end -->

    <!--Starting of Enquiry Form Modal-->
    @if (webFunctionStatus(config('constkey.is_enquiry_enabled')))    
        <div class="modal fade" id="EnquiryModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog prdtmodal-dialog">
                <div class="modal-content">
                    <div class="row pt-2">
                        <div class="col-md-12 pb-1">
                            <button type="button" class="btn-close prdtbtn-close" data-bs-dismiss="modal"
                                aria-label="Close"></button>
                        </div>
                        <h3 class="text-center text-uppercase">Enquiry Form</h3>
                    </div>
                    <div class="container">
                        <form id="enquiryform" class="enquiryformdata" method="POST" enctype="multipart/form-data">
                            <input type="hidden" id="products_id" value="{{$products->product_id}}">
                            <div class="row modal-body">
                                <div class="row p-2">

                                    <div class="col">
                                        <input type="text" class="form-control" name="products_qty" id="products_qty"
                                            placeholder="Qty Needed" aria-label="qty">
                                            <span class="text-danger products_qty_enq" ></span>
                                    </div>
                                
                                    <div class="col">
                                        <input type="email" class="form-control" name="email_address" id="email_address"
                                            placeholder="Your Email" aria-label="email">
                                            <span class="text-danger email_address_enq" ></span>
                                    </div>
                            
                                </div>
                                <div class="row p-2">
                                    <div class="col">
                                        <input type="text" name="customers_name" id="enqcustomers_name" class="form-control"
                                            placeholder="Your Name">
                                            <span class="text-danger customers_name_enq" ></span>
                                    </div>
                                    
                                    <div class="col">
                                        <input type="text" class="form-control" id="company_name" name="company_name"
                                            placeholder="Company Name">
                                            <span class="text-danger company_name_enq" ></span>
                                    </div>   
                                </div>
                                <div class="row p-2">
                                    <div class="col">
                                        @if(!empty($countriesdata))
                                        <select  aria-label="Default select example" name="countries_id"
                                            id="countries_id" style="width:300px;">
                                            <option selected disabled>Select Country</option>
                                            @foreach($countriesdata as $key=>$data)
                                            <option value="{{$data->countries_id}}">{{$data->countries_name}}</option>
                                            @endforeach
                                        </select>
                                        @endif
                                        <span class="text-danger countries_id_enq" "></span>
                                    </div>
                                
                                    <div class="col">
                                        <input type="file" name="enquiry_file" id="enquiry_file" class="form-control"
                                            placeholder="Last name" aria-label="Last name">
                                    </div> 
                                </div>

                                @if(!empty($products->productAttribute))
                                <div class="row p-2">
                                    @foreach($products->productAttribute as $attribute)
                                    @if( isset($attribute->option_value_list) && !empty($attribute->option_value_list))
                                    <div class="col-6">
                                        <span>{{ ucfirst($attribute->option_name ?? '')}}</span>
                                        <select  onchange="enqchooseAttributes(this)">
                                            @foreach($attribute->option_value_list as $option_value)
                                            <option value="{{ $option_value->options_values_id}}">
                                                {{ $option_value->productOptionsValue->products_options_values_name}}
                                            </option>
                                            @endforeach
                                        </select>
                                    </div>
                                    @endif

                                    @endforeach
                                </div>
                                @endif

                                <div class="row p-2">
                                    <div class="col">
                                        <input type="text" class="form-control" name="phone" id="phone" placeholder="phone">
                                    </div>
                                    <span class="text-danger phone_enq" ></span> 
                                </div>
                                {{-- <div class="row p-2">
                                    <div class="col">
                                        <input type="text" name="subject" id="subject" class="form-control"
                                            placeholder="Enquiry Subject" aria-label="Enquiry Message"></textarea>
                                    </div>
                                </div> --}}
                                <div class="row p-2">
                                    <div class="col">
                                        <textarea type="text" name="message" id="message" class="form-control"
                                            placeholder="Enquiry Message" aria-label="Enquiry Message"></textarea>
                                    </div>
                                    <span class="text-danger message_enq" ></span> 
                                </div>
                                <div class="row p-2">
                                    <div class="col-8">
                                        <input type="checkbox" name="newsletter" id="myCheck">
                                        <label for="myCheck">(Newsletter) Free Marketing Tips</label>
                                    </div>
                                    <div class="col-4">
                                        <div class="txt-right prdttxt-right">
                                            <button type="submit" class="btn btn-primary"
                                                id="enquirymodalformbutton">Submit</button>
                                            <input type="reset" hidden>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer prdtmodal-footer"> </div>
                            </div>


                        </form>
                    </div>
                </div>
            </div>
        </div>
        @push('scripts')
            <script>
                 $(document).on('click', '#enquirymodalformbutton', function (e) {
                    e.preventDefault();
                    let enquiryform = document.getElementById('enquiryform');
                    let formData = new FormData(enquiryform);
                    formData.append('products_attributes_id',enqdetail_choosen_attributes);
                    formData.append('products_id',$('#products_id').val());

                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        type: "POST",
                        url: "/storeProductEnquiry",
                        data:formData,
                        dataType: "json",
                        contentType: false,
                        cache:false,
                        processData: false,
                        success: function (response) {
                            if (response.status == 400) {     
                                $.each(response.error, function (key, err_val) {
                                    $('.' + key+'_enq').text(err_val);
                                });
                            }
                            else {
                                $('#EnquiryModal').modal('hide');
                                $('#enquiryform').trigger("reset");
                                Notify('Send Successfully', true);
                            }
                        }

                    });
                });
            </script>
        @endpush
    @endif
    <!--Ending of Enquiry Form Modal-->


    @push('scripts')
    <script>

        let detail_choosen_attributes = [];

        function addToCartFromDetail(product_id) {
            var qtyItemAdd = $('#qtyItemAdd').val();
            let attributes = detail_choosen_attributes.join(',');
            addToCart(product_id, qtyItemAdd, attributes);
        }

        function chooseAttributes(params) {
            if (!detail_choosen_attributes.includes(params.value)) {
                detail_choosen_attributes.push(params.value);
            }
        }
        

        $(document).ready(function () {
            //alert('hello');
            $(document).on('click', '#reviewformbutton', function (e) {
                e.preventDefault();
                var data = {
                    'customers_name': $('.customers_name').val(),
                    'customers_email': $('.customers_email').val(),
                    'quality_rating': $('.quality_rating').val(),
                    'price_rating': $('.price_rating').val(),
                    'reviews_title': $('.reviews_title').val(),
                    'products_id': $('.products_id').val(),
                    'reviews_read': $('.reviews_read').val(),
                    'reviews_text': $('.reviews_text').val(),

                }
                //console.log(data);
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "/storereview",
                    data: data,
                    dataType: "json",
                    success: function (response) {
                        // console.log(response);
                        if (response.status == 400) {
                            //design

                            $.each(response.error, function (key, err_val) {
                                $('#' + key).text(err_val);
                            });
                        }
                        else {
                            $('#successlist').html("");
                            $('#successlist').addClass("alert alert-success");
                            $('#successlist').append('<li>' + response.message + '</li>');
                            $('#reviewform').trigger("reset");
                        }
                    }

                });
            });
        });

   
        if ($('.ty-compact-list').length > 3) {
            $('.ty-compact-list:gt(2)').hide();
            $('.show-more').show();
        }
        $('.show-more').on('click', function () {
            $('.ty-compact-list:gt(2)').toggle();
            $(this).text() === 'Show more' ? $(this).text('Show less') : $(this).text('Show more');
        });
    
        // <!--End of Enquiry Form Ajax-->

        var enqdetail_choosen_attributes = [];
        function enqchooseAttributes(params) {
            if (!enqdetail_choosen_attributes.includes(params.value)) {
                enqdetail_choosen_attributes.push(params.value);
            }
        }
   
    </script>
    @endpush