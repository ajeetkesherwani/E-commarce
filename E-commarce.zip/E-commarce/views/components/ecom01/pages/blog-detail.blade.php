@php

$main_arr = [
  'title'=>translation('BLOG_POST'),
  'sublist' => [
    [
    'name'=>translation('HOME'),
    'link'=>url("/")
    ],
    [
    'name'=>$blogDetail->post_title ,
    'link'=>url()->full()
    ], 
  ]
];
$currentURL = URL::current();
$url_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$url_segments = explode('/', $url_path);
$url_segment=$url_segments[2]; 
@endphp

<x-Ecom01.SharedComponent.BreadCrumb :data="$main_arr" /> 
<!-- Breadcrumb Area End -->
<!-- Shop Category Area End -->
<div class="shop-category-area single-blog">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 order-lg-first col-md-12 order-md-first">
                <div class="blog-posts">
                    <div class="single-blog-post blog-grid-post">
                        <div class="blog-post-media">
                            <div class="blog-image single-blog">
                                <a href="#"><img class="img-fluid" src="{{getFullImageUrl($blogDetail->img)}}"  onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="{{ $blogDetail->post_title ?? '' }}" /></a>
                            </div>
                        </div>
                        <div class="blog-post-content-inner d-flex justify-content-between py-3">
                            <h4 class="blog-title ">{{ $blogDetail->post_title ?? '' }}</h4>
                            <ul class="blog-page-meta d-flex justify-content-between gap-3">
                                <li>
                                    <i class="ion-person"></i> {{translation('ADMIN')}}
                                </li>
                                <li>
                                   <i class="ion-calendar"></i> {{ date("d M, Y",
                                        strtotime($blogDetail->created_at)) }}
                                </li>
                            </ul>
                        </div>
                        <div class="single-post-content">
                        
                            {!! $blogDetail->post_content ?? '' !!}

                        </div>
                    </div>
                    <!-- single blog post -->
                </div>
                <div class="blog-single-tags-share d-sm-flex justify-content-between">
                    
                    <div class="blog-single-share d-flex">
                        <span class="title">{{translation('BLOG_SHARE')}}:</span>
                        <ul class="social">
                            <li>
                                <a href="https://www.facebook.com/sharer/sharer.php?u={{ $currentURL }}"  target="_blank"><i class="ion-social-facebook"></i></a>
                            </li>
                            <li>
                                <a href="https://twitter.com/intent/tweet?text={{ $currentURL }}"
                                        target="_blank"> <i class="ion-social-twitter"></i></a> 
                            </li>
                            <li>
                                <a href="https://api.whatsapp.com/send?text={{ $currentURL }}"
                                target="_blank"><i class="ion-social-whatsapp"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

             <!-- Sidebar Area Start -->
             <div class="col-lg-3 order-lg-last col-md-12 order-md-last mb-res-md-60px mb-res-sm-60px">
                <div class="left-sidebar">  
                    <!-- Sidebar single item -->
                    <div class="sidebar-widget mt-40">
                        <div class="main-heading">
                            <h2>{{translation('RECENT_POST')}}</h2>
                        </div>
                        <div class="recent-post-widget">

                            @if (!empty($recentPost))
                            @foreach ($recentPost as $blog)

                            <div class="recent-single-post d-flex">
                                <div class="thumb-side">
                                    <a href="{{ url('blog/'.$blog->slug) }}"><img src="{{getFullImageUrl($blog->img)}}" alt="{{ $blog->post_title ?? '' }}" 
                                         onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" /></a>
                                </div>
                                <div class="media-side">
                                    <h5><a href="{{ url('blog/'.$blog->slug) }}">{{ $blog->post_title ?? '' }}</a></h5>
                                    <span class="date">{{ date("F d, Y",
                                        strtotime($blog->created_at)) }}</span>
                                </div>
                            </div>
                            @endforeach
                            @endif
                        </div>
                    </div>
                </div>
            </div>
            <!-- Sidebar Area End -->
            
        </div>
        <br />
        <div class="row">
            <section class="blog-area mb-30px">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <!-- Section title -->
                            <div class="section-title underline-shape">
                                <h2>{{ translation('RELATED_BLOGS') }}</h2>
                            </div>
                            <!-- Section title -->
                        </div>
                    </div>
                    <!-- Blog Slider Start -->
                    <div class="blog-slider-active owl-carousel owl-nav-style-3">
                        <!-- single item -->
                        @if (!empty($relatedPost))
                        @foreach ($relatedPost as $blog)
                        @if($blog->slug!=$url_segment)
                        <x-Ecom01.SharedComponent.PostGrid :data="$blog" />
                        @endif
                        @endforeach
                        @endif
                        <!-- single item -->

                    </div>
                    <!-- Blog Slider Start -->
                </div>
            </section>
        </div>
    </div>
</div>

@push('scripts')
<script>
    $('#search').on('keyup',function(){
    $value=$(this).val();
    $.ajax({
    type : 'get',
    url : '{{URL::to('blogsearch')}}',
    data:{'search':$value},
    success:function(data){
    $('#searchBody').html(data);
    }
    });
    })
    </script>
    <script type="text/javascript">
    $.ajaxSetup({ headers: { 'csrftoken' : '{{ csrf_token() }}' } });
    </script>   
@endpush