<!-- Wishlist area start -->
<div class="col-lg-12 col-md-12 col-sm-12 col-12">
    <form action="#">
        <div class="table-content table-responsive cart-table-content">
        @if (!empty($wishlist_item) && sizeof($wishlist_item)>0)
            <table class="w-100 text-center">
                <thead>
                    <tr>
                        <th>{{translation('WISHLIST_PRODUCT_IMAGE')}}</th>
                        <th>{{translation('WISHLIST_PRODUCT_NAME')}}</th>
                        <th>{{translation('WISHLIST_PRODUCT_SKU')}}</th>
                        <th>{{translation('WISHLIST_UNIT_PRICE')}}</th>
                        <th>{{translation('WISHLIST_ACTION')}}</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($wishlist_item as $key=>$data )
                    <tr>
                        <td class="product-thumbnail">
                            <a href="{{url('product/'.$data->product->product_slug)}}"><img src="{{getFullImageUrl($data->product->product_image)}}"  onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" alt="{{ $data->product->products_name ?? ''}}" /></a>
                        </td>
                        <td class="product-name"><a href="{{url('product/'.$data->product->product_slug)}}">{{ $data->product->products_name ?? ''}}</a></td>
                        <td class="product-name"><a href="#">{{ $data->product->product_sku ?? ''}}</a></td>
                        <td class="product-subtotal"> {{ currencyFormat($data->product->sale_price ?? 0)}} </td>
                        <td class="product-wishlist-cart">
                            <a href="{{url('product/'.$data->product->product_slug)}}"><span class="material-symbols-outlined">{{translation('VISIBILITY')}}</span></a>
                            <a href="javascript:void(0)" onclick="actionOnWishlist({{$data->wishlist_id}})"><i class="fa fa-times"></i></a>
                        </td>
                    </tr>
                    @endforeach
                    
                </tbody>
            </table>              
            @else
            <img src="{{ LoadAssets('assets/images/EmptyImages/Wishlist-Empty.png')}}" 
            onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
            class="rounded mx-auto d-block" height="200px" alt="{{getSetting('site_title')}} Wishlist-Empty">
            <p class="h4 text-center text-dark mt-3">{{translation('EMPTY_WISHLIST_MSG')}}</p>
            <div class="text-center my-3">
            <a href="{{url('/')}}" class="btn btn-primary btn-lg btn-block" role="button" aria-pressed="true">{{translation('CONTINUE_SHOP')}}</a>
            </div>
            @endif
        </div>
    </form>
</div>
<!-- Wishlist area end -->


