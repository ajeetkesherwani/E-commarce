@php
$order_number = $list->order_number;
@endphp
<div class="checkout-area mtb-60px">
    <div class="container mt-4 mb-4">
        <div class="row d-flex cart align-items-center justify-content-center">
            <div class="col-md-4 ">

                <div class="pb-5 text-center text-black">
                     <h1><i class="fa fa-close transaction-fail"></i></h1>
                    <br />  
                    {{-- <p class="text-uppercase"><b>{{translation('PAYMENT_METHOD')}} {{ $list->payment_type }} </b></p>  --}}
                    <h2>{{translation('TRANSACTION_FAILED_MSG')}}!</h2>
                </div>

            </div>
        </div>
    </div>
</div>