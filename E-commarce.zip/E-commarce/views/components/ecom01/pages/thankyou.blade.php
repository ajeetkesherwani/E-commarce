<div class="text-center thankyou_wrapper">
<h1 class="fw-bold">{{ translation('ORDER_THANK_YOU_MSG') }}</h1>
<h5 class=" pt-3">{{ translation('ORDER_SUCCESS_MSG') }}</h5>
<div class="py-3">
    <p class="mb-0">{{ translation('ORDER_NUMBER') }}   <strong class="font-dark">{{$list->order_number}}</strong></p>
<p class=" mb-0">{{ translation('ORDER_SUCCESS_NOTE') }}</p>
<p>
    <a href="mailto:{{getSetting('contact_email')}}">
        {{getSetting('contact_email')}}</a> {{ translation('CALL_US') }} 
        <a href="tel:{{getSetting('contact_phone')}}"">
        {{getSetting('contact_phone')}}</a>
</p>
</div>
<a href="{{url('/order/'.$list->order_number.'/download-invoice')}}" class="btn btn-primary btn-lg btn-block" >{{translation('ORDER_DOWNLOAD_INVOICE')}}</a>                    
</div>