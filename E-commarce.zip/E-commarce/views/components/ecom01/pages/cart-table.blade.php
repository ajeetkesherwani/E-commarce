<div class="col-lg-12 col-md-12 col-sm-12 col-12">
    <form action="#">
        <div class="table-content table-responsive cart-table-content">
            @if (!empty($cart_list) && sizeof($cart_list)>0)
            <table>
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Product Name</th>
                        <th>Until Price</th>
                        <th>Qty</th>
                        <th>Subtotal</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    
                    @foreach ($cart_list as $cart )
                    <tr>
                        <td class="product-thumbnail">
                            <a href="#"><img src="{{getFullImageUrl($cart->product->product_image)}}" 
                                onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                                alt=" {{ $cart->product->products_name ?? ''}}"
                                    height="50" /></a>
                        </td>
                        <td class="product-name"><a href="{{url('product/'.$cart->product->product_slug)}}">
                                {{$cart->product->products_name ?? ''}}</a>
                            
                                @if (isset($cart->attributes) && !empty($cart->attributes))
                                <div>
                                    @foreach ($cart->attributes as $attribute)
                                        @if (isset($attribute->product_options))
                                            <span> {{ $attribute->product_options->products_options_name }} : {{ $attribute->products_options_values_name }} </span><br/>
                                        @endif
                                    @endforeach
                                </div>
                            @endif
                            
                            </td>
                        <td class="product-price-cart"><span class="amount">
                                {{ currencyFormat($cart->final_price ?? 0)}}
                                {{-- {{ currencyFormat($cart->product->product_sale_price ?? 0)}} --}}
                            </span></td>
                        <td class="product-quantity">
                            <div class="cart-plus-minus">
                                <input class="cart-plus-minus-box" data-cart="{{$cart->cart_id}}" onchange="actionOnCart({{$cart->cart_id}},'add')"
                                    id="{{$cart->cart_id}}_qty" type="number" name="qtybutton" value="{{ $cart->qty }}"
                                    min=1 step=1 onkeyup="qtyItm()" />
                            </div>
                        </td>
                        <td class="product-subtotal">
                            @php
                            $qty = (int) $cart->qty;
                            $price = $cart->final_price ?? 0;
                            echo currencyFormat($qty*$price);
                            @endphp
                        </td>
                        <td class="product-remove">
                            <a href="javascript:void(0)" onclick="actionOnCart({{$cart->cart_id}},'del')"><i
                                    class="fa fa-times"></i></a>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="cart-shiping-update-wrapper">
                    <div class="cart-shiping-update">
                        <a href="#">Continue Shopping</a>
                    </div>
                    <div class="cart-clear">
                    </div>
                </div>
            </div>
        </div>
    </form>
    <div class="row">
        <div class="col-lg-4 col-md-6">
        </div>
       
        <div class="col-lg-4 col-md-6">
            @if(webFunctionStatus(config('constkey.is_coupon_enabled')))
            <div class="discount-code-wrapper">
                <div class="title-wrap">
                    <h4 class="cart-bottom-title section-bg-gray">Use Coupon Code</h4>
                </div>
                <div class="discount-code">
                    <p>Enter your coupon code if you have one.</p>
                    <form>
                        <input type="text" required="" name="name" />
                        <button class="cart-btn-2" type="submit">Apply Coupon</button>
                    </form>
                </div>
            </div>
            @endif
        </div>
      
        <div class="col-lg-4 col-md-12">
            <div class="grand-totall">
                <div class="title-wrap">
                    <h4 class="cart-bottom-title section-bg-gary-cart">Cart Total</h4>
                </div>
                <h5>Sub Total <span>{{ currencyFormat($grand_total) }}</span></h5>
                {{-- <div class="total-shipping">
                    <h5>Total shipping</h5>
                    <ul>
                        <li><input type="checkbox" /> Standard <span>$20.00</span></li>
                        <li><input type="checkbox" /> Express <span>$30.00</span></li>
                    </ul>
                </div> --}}
                <h4 class="grand-totall-title">Grand Total <span>{{ currencyFormat($grand_total) }}</span></h4>
                <a href="{{ url('checkout') }}">Proceed to Checkout</a>
            </div>
        </div>
    </div>
    @else
    <img src="{{ LoadAssets('assets/images/EmptyImages/Cart-Empty.jpg')}}" 
    onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
    class="rounded mx-auto d-block" width="286px" height="200px" alt="{{getSetting('site_title')}} Cart-Empty">
    <p class="h4 text-center text-dark mt-2">Your cart is empty !</p>
    <div class="text-center my-3">
    <a href="{{url('/')}}" class="btn btn-primary btn-lg btn-block" role="button" aria-pressed="true">Continue to shop </a>
    </div>
    @endif
    </div>

    
