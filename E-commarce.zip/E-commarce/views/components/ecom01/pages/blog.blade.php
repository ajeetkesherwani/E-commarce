@php

$main_arr = [
  'title'=>translation('BLOGS'),
  'sublist' => [
    [
    'name'=>translation('HOME'),
    'link'=>url("/")
    ],
    [
    'name'=>'Blog' ,
    'link'=>url()->full()
    ], 
  ]
];
@endphp

<x-Ecom01.SharedComponent.BreadCrumb :data="$main_arr" /> 

@if(!empty($allBlog) && sizeof($allBlog)>0)

<div class="shop-category-area blog-grid">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 col-md-12">
                <div class="blog-posts">
                    <div class="row">
                        {{-- content start here --}}
                        @foreach($allBlog as $blogKey=>$blogData)
                        <div class="col-md-6 ">
                            <div class="single-blog-post blog-grid-post mt-30">
                                <div class="blog-post-media">
                                    <div class="blog-image">
                                        <a href="{{url('blog/'.$blogData->slug)}}"><img src="{{getFullImageUrl($blogData->img)}}"
                                            onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                                             alt="{{getSetting('site_title')}} Not-Found" /></a>
                                    </div>
                                </div>
                                <div class="blog-post-content-inner mt-30">
                                    <h4 class="blog-title"><a href="#">{{$blogData->post_title ?? ''}}</a></h4>
                                    <ul class="blog-page-meta">
                                        <li>
                                            <a href="#"><i class="ion-person"></i>{{$blogData->created_by ?? ''}}</a>
                                        </li>
                                        <li>
                                            <a href="#"><i class="ion-calendar"></i>
                                            @php
                                               echo(date('d F,Y', strtotime($blogData->created_at ?? '')));
                                            @endphp
                                            </a>
                                        </li>
                                    </ul>
                                    <p>
                                      {{$blogData->post_excerpt ?? ''}}
                                    </p>
                                    <a class="read-more-btn" href="{{url('blog/'.$blogData->slug)}}"> {{translation('READ_MORE')}}<i class="ion-android-arrow-dropright-circle"></i></a>
                                </div>
                            </div>
                            <!-- single blog post -->
                        </div>
                        @endforeach
                        {{-- endof content --}}
                    </div>
                </div>
                <!--  Pagination Area Start -->
                <div class="pro-pagination-style text-center">
                    <div class="row">
                        <div class="col-md-12 d-flex justify-content-center p-2">
                            {{ $allBlog->links('vendor.pagination.semantic-ui') }}
                        </div>
                    </div>
                </div>
                <!--  Pagination Area End -->
            </div>
            <!-- Sidebar Area Start -->
            <div class="col-lg-3 col-md-12 mb-res-md-60px mb-res-sm-60px">
                <div class="left-sidebar">
                    <!-- Sidebar single item -->
                    <div class="sidebar-widget mt-40">
                        <div class="main-heading">
                            <h2>{{translation('RECENT_POST')}}</h2>
                        </div>
                        <div class="recent-post-widget">
                            @if(!empty($recentPost))
                            @foreach($recentPost as $recpostVal)
                            <div class="recent-single-post d-flex">
                                <div class="thumb-side">
                                    <a href="{{url('blog/'.$recpostVal->slug)}}"><img src="{{getFullImageUrl($recpostVal->img)}}"
                                        onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                                        alt="{{getSetting('site_title')}} Not-Found" /></a>
                                </div>
                                <div class="media-side">
                                    <h5><a href="{{url('blog/'.$recpostVal->slug)}}">{{$blogData->post_title ?? ''}}</a></h5>
                                    <span class="date"> @php
                                        echo(date('F d,Y', strtotime($blogData->created_at ?? '')));
                                     @endphp</span>
                                </div>
                            </div>
                            @endforeach
                            @endif
                        </div>
                    </div>
               
                </div>
            </div>
            <!-- Sidebar Area End -->
        </div>
    </div>
</div>
@endif