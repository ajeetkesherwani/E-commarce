@php

$main_arr = [
  'title'=>translation('DASHBOARD'),
  'sublist' => [
    [
    'name'=>translation('HOME'),
    'link'=>url("/")
    ],
    [
    'name'=>translation('DASHBOARD'),
    'link'=>url()->full()
    ], 
  ]
];
@endphp

<x-Ecom01.SharedComponent.BreadCrumb :data="$main_arr" />   
<!---- Section start Here ------->
<div class="checkout-area mtb-40px">
  <div class="container">
    <div class="row">
      <div class="mx-auto col-lg-3 ">
        <x-Ecom01.SharedComponent.left-side-menu /> <!-- left menu -->
      </div>
      <div class="mx-auto col-lg-9 ">

        <div class="rightside-content">
          <div class="row">
              <div class="col-lg-3 col-md-6 col-xs-12 col-sm-6">
                  <div class="small-boxes ">
                      <div class="inner">
                        <h3 class="purchase_due">{{$totalOrder}}</h3>
                        <p class="desc">{{ translation('TOTAL_ORDER') }}</p>
                      </div>
                  </div>
              </div>
              <div class="col-lg-3 col-md-6 col-xs-12 col-sm-6">
                  <div class=" small-boxes">
                      <div class="inner">
                        <h3 class="purchase_due">{{$deliverdOrder}}</h3>
                        <p class="desc">{{ translation('ORDER_DELIVERED') }}</p>
                      </div>
                      <!-- <div class="icon"> <i class="fa-solid fa-cart-shopping"></i> </div> -->
                  </div>
              </div>
              <div class="col-lg-3 col-md-6 col-xs-12 col-sm-6">
                  <div class="small-boxes">
                      <div class="inner">
                        <h3 class="purchase_due">{{$inprogressOrder}}</h3>
                        <p class="desc">{{ translation('ORDER_PROGRESS') }}</p>
                      </div>
                      <!-- <div class="icon"> <i class="fa-solid fa-cart-shopping"></i> </div> -->
                  </div>
              </div>
              <div class="col-lg-3 col-md-6 col-xs-12 col-sm-6">
                  <div class="small-boxes">
                      <div class="inner">
                        <h3 class="purchase_due">{{$pendingOrder}}</h3>
                        <p class="desc"> {{ translation('ORDER_PENDING') }}</p>
                      </div>
                  </div>
              </div>
          </div>
     
      <h4 class="latest-order">
        {{ translation('LATEST_ORDER') }}
      </h4>

      <div class="table-responsive  rounded order-table">
          <table class="table table-center bg-white mb-0">
              <thead>
                <tr>
                    <th class="text-center" style="min-width:70px;">{{ translation('ORDER_SL_NO')}}</th>
                    <th class="text-center" style="min-width: 120px;">{{ translation('ORDER_NO')}}</th>
                    <th class="text-center " style="min-width: 120px;">{{ translation('ORDER_PAYMENT_TYPE')}}</th>
                    <th class="text-center " style="min-width: 120px;">{{ translation('ORDER_TOTAL_QTY')}}</th>
                    <th class="text-center " style="min-width: 120px;">{{ translation('ORDER_TOTAL_PRICE')}}</th>
                    <th class="text-center " style="min-width: 120px;">{{ translation('ORDER_PAYMENT_STATUS')}}</th>
                    <th class="text-center " style="min-width: 120px;"> {{ translation('ORDER_STATUS')}}</th>

                </tr>
              </thead>
              @if(!empty($latestOrder) && count($latestOrder) >0 )
              <tbody>
                <!-- Start -->
                @foreach ($latestOrder as $key=>$item)
                  <tr>
                    <td class="text-center">{{$key+1}}</td>
                    <td class=" text-start">
                        <span class="ms-2">{{$item->order_number}}</span>
                    </td>
                    <td class="text-center ">{{$item->payment_type}}</td>
                    <td class="text-center">{{$item->total_qty}}</td>
                    <td class="text-center">{{currencyFormat($item->grand_total)}}</td>

                    @switch($item->payment_status) 
                      @case(0)      
                        <td class="text-center">
                          <div class="badge badge-pill badge-success bg-pending" style="background:rgb(255, 128, 0);">{{ translation('PENDING')}}</div>
                        </td>
                      @break
                      @case(1)
                        <td class="text-center">
                          <div class="badge badge-pill badge-success bg-success">
                            {{ translation('ORDER_PAID')}}
                          </div>
                        </td>
                      @break
                      @default
                        <td class="text-center">
                          <div class="badge badge-pill "  style="background:rgb(241, 0, 0);">
                            {{ translation('ORDER_FAILED')}}
                          </div>
                        </td>
                      @break
                      @endswitch
                      
                      @switch($item->order_status)
                        @case(1)      
                          <td class="text-center" ><div class="badge badge-pill badge-success bg-pending" style="background:rgb(255, 128, 0);">{{ translation('PENDING')}}</div></td>
                        @break
                        @case(2)
                          <td class="text-center" ><div class="badge badge-pill " style="background:rgb(249, 228, 0);">{{ translation('IN_PROGRESS')}}</div></td>
                        @break
                        @case(3)
                          <td class="text-center"><div class="badge badge-pill "  style="background:rgb(0, 26, 225);">{{ translation('DISPATCH')}}</div></td>
                        @break
                        @default
                          <td class="text-center"><div class="badge badge-pill badge-success bg-success">{{ translation('DELIVERED')}}</div></td>
                        @break
                      @endswitch
                  </tr>
                @endforeach
                  <!-- End -->
              </tbody>
              @else
                <tr>
                  <td>
                      {{translation('ORDER_EMPTY_MSG')}}
                  </td>
                </tr>
              @endif
          </table>
      </div>
      </div>
      </div>
    </div>
  </div>
</div>
