<!-- Slider Area Start -->

[SLIDERS ID=1 THEME=01]

<!-- Slider Area End -->

<!-- Category Area Start -->
<section class="categorie-area categorie-area-2 ptb-70px">
    <div class="container pb-3">
        <div class="row">
            <div class="col-md-12 text-center">
                <div class="section-title mt-res-sx-30px mt-res-md-30px underline-shape">
                    <h2>[ _t('POPULAR_CATEGORIES_TITLE')]</h2>
                    <p>[ _t('POPULAR_CATEGORIES_SUB_TITLE') ]</p>
                </div>
            </div>
        </div>
        [FEATURECATEGORIES ITEM=4 THEME=01]
    </div>
</section>
<!-- Category Area End  -->



<!-- Featured-Group -->

[FEATUREPRODUCTS ITEM=4 THEME=01 VIEWTYPE=slider]

<!-- End  Of Feature Group -->

<!-- Banner Area Start -->
<div class="banner-3-area mt-0px mb-100px">
    <div class="container pt-3">
        <div class="row">
            <div class="col-lg-6">
            [BANNERS ID=11 THEME=01]
            </div>
            <div class="col-lg-6">
            [BANNERS ID=9 THEME=01]
            </div>
        </div>
    </div>
</div>
<!-- Banner Area End -->

<!-- Blog Start -->
<section class="blog-area mb-30px">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <div class="section-title underline-shape mt-50">
                    <h2>[_t('BLOG_TITLE')]</h2>
                    <p>[_t('BLOG_DESCRIPTION')]</p>
                </div>
            </div>
        </div>
        [BLOGS ITEM=3 THEME=01]
    </div>
</section>
<!-- Blog End -->

<!-- Website Feature  Start-->
<section class="static-area mtb-60px">
    <div class="container">
        <div class="static-area-wrap">
            <div class="row">
                [WEBFEATURES ITEM=4 THEME=01]
            </div>
        </div>
    </div>
</section>
<!-- Website Feature End-->

<!-- Testimonial Start -->
<section class="testimonial-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title">
                    <h2 class="text-black text-center text-uppercase" style="font-size: 24px;">
                        {{translation('CLIENT_TESTIMONIAL_TITLE')}}</h2>
                    <p class=" text-center ">{{translation('CLIENT_TESTIMONIAL_SUB_TITLE')}}</p>
                </div>
            </div>
        </div>
        <!-- Testimonial Slider Start -->
        <div class="row">
            <div class="col-lg-8 mx-auto">
                [TESTIMONIALS ITEM=3 THEME=01]
            </div>
        </div>
        <!-- Testimonial Slider End -->
    </div>
</section>
<!-- Testimonial End -->

<!-- Brand area start -->
<div class="brand-area">
    <div class="container">
        [BRANDS ITEM=10 THEME=01]
    </div>
</div>
<!-- Brand area End -->

<!--Starting of Newslatter Modal-->
<div class="modal fade newsletter-popup" id="onloadModal" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body newsmodal">
                <!-- Here Html Come From ajax -->
            </div>
        </div>
    </div>
</div>
<!--Ending of NewsLatter Modal-->