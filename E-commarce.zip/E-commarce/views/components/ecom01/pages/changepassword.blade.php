@php
$main_arr = [
'title' => '',
'sublist' => [
[
'name' => translation('HOME'),
'link' => url('/'),
],
[
'name' =>translation('FORGOT_PASSWORD'),
'link' =>url()->full()
],
],
];
@endphp
<!-- login area start -->
<div class=" my-0 bg-white">
    <!-- Breadcrumb Area Start -->
<x-Ecom01.SharedComponent.BreadCrumb :data="$main_arr" />
<!-- Breadcrumb Area End -->
    <div class="container">
        <div class="row">
            <div class="col-lg-5 col-sm-12 mx-auto login-page  p-4 login-register-area my-5">
                    <div class=" border-0">
                        <div class="card-body">
                            <h4 class="card-title fw-bold text-center">
                                {{translation('FORGOT_PASSWORD')}}</h4> 
                            @if (session('status'))
                                <div class="alert alert-success">
                                    {{ session('status') }}
                                </div>
                            @endif

                            @error('success')
                                <strong class="text-danger" style="margin-top:-50px;">{{ $message }}</strong>
                            @enderror 
                            <form class="login-form mt-4" action="{{ route('password.email') }}" method="post" id="forgot"  novalidate="novalidate">
                            @csrf
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="mb-3">
                                            <label class="form-label fw-bold">{{translation('EMAIL')}}<span class="text-danger">*</span></label>
                                            <div class="form-icon position-relative">
                                                <input type="email" class="form-control ps-3 @error('email') is-invalid @enderror" placeholder="{{ translation('EMAIL_PLACEHOLDER') }}" name="email" required="">
                                            </div>
                                            @error('email')
                                            <strong class="text-danger mb-5">{{ $message }}</strong>
                                            @enderror
                                        </div>
                                    </div><!--end col-->
                                    
                                    <div class="col-lg-5 mb-0 mx-auto">
                                        <div class="d-grid">
                                            <button type="submit" class="btn btn-primary py-2">{{translation('RESET_BUTTON')}}</button>
                                        </div>
                                    </div><!--end col-->
                                    <div class="text-center mt-3 back-to-login">
                                            <a href="{{url('/login')}}"> <i class="fa-solid fa-arrow-left me-2"></i>{{translation('BACK_TO_LOGIN_BUTON')}}</a>
                                    </div>
            
                                    <!--end col-->
                                </div><!--end row-->
                            </form>
                        </div>
                    </div><!---->
                
            </div>
        </div>
    </div>
</div>

@push('scripts')

<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
<script>
    $(document).ready(function() {
        $('#forgot').validate({
            rules: {
                email: {
                    required: true,
                    email: true,
                },
            },
            messages: {
                email: {
                        required: "Please Enter Email",
                        email: "Please Enter Valid Email",
                    },
                },
            highlight: function(element) {
                $(element).addClass('error');
                $(".error").css("color", "red");
                $(element).css("border", " 1px solid red")
            }
        });
    });
</script>
@endpush