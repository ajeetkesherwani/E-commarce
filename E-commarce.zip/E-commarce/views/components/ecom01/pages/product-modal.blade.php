@php
$currentURL = URL::current();
$currentURL=str_replace("showproduct","product",$currentURL);
$avgrating=AvgRating($response['product_id']);
@endphp

<div class="row ">
    <input type="hidden" id="products_id" name="products_id" class="modal_products_id" value="{{ $response['product_id']}}">
    <div class="col-md-5 col-sm-12 col-xs-12">
        <div class="tab-content quickview-big-img">
            {{-- @foreach ($response->products_to_gallery as $key => $data) --}}
            <div id="pro-1" class="tab-pane active show  ">
                <img src="{{getFullImageUrl($response['product_image'])}}"
                    onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                    alt="{{$response['products_name']}}" />
            </div>
            {{-- @endforeach --}}
        </div>
        <!-- Thumbnail Large Image End -->

        <!-- Product gallery start-->
        {{-- <div class="quickview-wrap mt-15">
            <div class="quickview-slide-active owl-carousel nav owl-nav-style owl-nav-style-2" role="tablist">
                @foreach ($response->products_to_gallery as $key => $data)
                <a class="@if($key==0)active @endif" data-bs-toggle="tab" href="#pro-{{$key}}"><img
                        src="{{ getFullImageUrl($data->images_id) }}"
                        onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                        alt="{{$response['products_name']}}" />
                </a>
                @endforeach
            </div>
        </div> --}}
        <!-- Product gallery end-->
    </div>

    <div class="col-md-7 col-sm-12 col-xs-12">
        <div class="product-details-content quickview-content">
            <h2>{{$response['products_name']}}</h2>
            <p class="reference">{{translation('PRODUCT_BRAND')}}:<span>{{$response->products_to_brand->brand_name ??
                    ''}}</span></p>
            <div class="pro-details-rating-wrap">
                <!-- <div class="rating-product"> -->
                <div class="">
                    @if(!empty($avgrating))
                        @for($i=0;$i<5;$i++) @if($i<$avgrating) <i class="ion-android-star"></i>
                            @else
                            <i class="ion-android-star-outline"></i>
                            @endif
                        @endfor
                    @endif
                </div>
                <span class="read-review"><a class="reviews"
                        href="{{ url('product/'.$response['product_slug']) }}">{{translation('PRODUCT_REVIEW')}}</a></span>
            </div>

            <!-- Show WholeSale Price Tabel-->
            <div class="pricing-meta ">
                @if($response->products_prices !=null)
                <div class="position-relative">
                    <div style="position:absolute; z-index: 2;">
                        <div class="qty"><b>{{translation('PRODUCT_QTY')}}</b></div>
                        <div class="price"><b>{{translation('PRODUCT_PRICE')}}</b></div>
                    </div>
                    <div class="qty-carousel" style="margin-left: 4.68rem;">
                        <div class="your-class">
                        @foreach($response->products_prices as $producprice)
                        <div>
                            <div class="qty"><b>{{$producprice->product_qty}}</b></div>
                            <div class="amount">{{currencyFormat($producprice->sale_price)}}</div>
                        </div>
                        @endforeach
                        </div>
                    </div>
                </div>
                @endif
            </div>
            <!-- End of WholeSale price Tabel-->
            
        
            <div class="product-variants js-product-variants">
               @if (webFunctionStatus(config('constkey.is_cart_enabled')))
                    @if(!empty($response->productAttribute))
                        @foreach($response->productAttribute as $attribute)
                            <div class="clearfix product-variants-item">
                                <span class="control-label">{{ ucfirst($attribute['option_name'] ?? '')}} : </span>
                                @if( isset($attribute['option_value_list']) && !empty($attribute['option_value_list']))
                                <ul id="attributes_{{$attribute['options_id']}}">
                                    @foreach($attribute->option_value_list as $idx => $option_value)
                                    <li class="input-container float-sm-start">
                                        <label>
                                            <input class="modal_input-radio" type="radio"
                                                data-product-attribute="{{ $option_value['options_id']}}"
                                                name="attributes_{{ $option_value['options_id']}}" {{$idx==0?"checked":""}}
                                                value="{{$option_value['options_id']}}_{{ $option_value['options_values_id'] }}"
                                                title="{{ $option_value->productOptionsValue->products_options_values_name }}">
                                            <span class="radio-label">{{
                                                $option_value->productOptionsValue->products_options_values_name}}</span>
                                        </label>
                                    </li>
                                    @endforeach
                                </ul>
                                @endif
                            </div>
                        @endforeach
                    @endif

                <!-- Show Only Product is Price wholesale Product-->
                <div class="pricing-meta mt-3">
                    @if($response->products_prices!=null)
                    <ul>
                        Price:
                        @foreach($response->products_prices as $holeprice)
                        @if($holeprice->discount_percent !='0')
                        <del class="text-danger ms-2 discount_amount">
                            {{currencyFormat($holeprice->max_sale_price) }}
                        </del>
                        @endif
                        <li class="old-price not-cut">
                            {{ currencyFormat($holeprice->sale_price ?? '0.00') }}
                        </li>
                        <li class="">
                            / {{$holeprice->product_qty}} Unit
                        </li>
                        @if($holeprice->discount_percent != '0')
                        <span class="discount-price ms-1">
                            {{ currencyFormat( $holeprice->discount_percent )}}% {{translation('PRODUCT_DISCOUNT')}}
                        </span>
                        @endif
                        @break
                        @endforeach
                    </ul>
                    @else
                    <ul>
                        @if($response->discount_type != 'no')
                        <del class="text-danger ms-2 discount_amount">{{currencyFormat($response->max_sale_price) }}
                        </del>
                        @endif
                        <li class="old-price not-cut">
                            {{ currencyFormat($response->sale_price ?? '0.00') }}
                        </li>
                        @if($response->discount_type != 'no')
                        @if($response->discount_type == 'flat')
                        <span class="text-success ms-1">
                            {{ currencyFormat($response->discount_amount) }} {{translation('PRODUCT_DISCOUNT')}}
                        </span>
                        @else
                        <span class="text-success ms-1">
                            {{ currencyFormat( $response->discount_amount )}}% {{translation('PRODUCT_DISCOUNT')}}
                        </span>
                        @endif
                        @endif
                    </ul>
                    @endif
                </div>
                <!-- End of wholesale product Price -->

                <div class="product-details-content">
                    <div class="pro-details-quality">
                        <div class="cart-plus-minus">
                            <div class="dec qtybutton">-</div>
                            @if($response->products_prices !=null)
                            @foreach($response->products_prices as $producprice)
                            <input class="cart-plus-minus-box modal_qtyItemAdd" onblur="QtyToPrice('quickView')" type="text" id="qtyItemAdd"
                                name="qty" value="{{$producprice->product_qty}}" />
                            @break
                            @endforeach
                            @else
                            <input class="cart-plus-minus-box modal_qtyItemAdd" onblur="QtyToPrice('quickView')" type="text" id="qtyItemAdd"
                                name="qty" value="1" />
                            @endif
                            <div class="inc qtybutton">+</div>
                        </div>

                        <input type="hidden" value="{{$response['product_slug']}}" id="productSlug">
                        <input type="hidden" value="quickView" class="source">
                        <div class="pro-details-cart btn-hover">
                            <a href="javascript:void(0);"
                                onclick="addToCartFromModalDetail({{$response['product_id']}})">
                                {{translation('ADD_TO_CART')}}
                            </a>
                        </div>
                    </div>
                </div>

                @endif
                @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))
                <div class="pro-details-wish-com">
                    <div class="pro-details-wishlist">
                        <a href="javascript:void(0);"
                            onclick="addToWishListFromDetail({{ $response['product_id'] ?? '' }})"><i
                                class="ion-android-favorite-outline"></i>{{translation('ADD_TO_WISHLIST')}}
                        </a>
                    </div>
                </div>
                @endif
                <div class="pro-details-social-info">
                    <span>{{translation('PRODUCT_SHARE')}}</span>
                    <div class="social-info">
                        <ul>
                            <li>
                                <a href="https://www.facebook.com/sharer/sharer.php?u={{ $currentURL }}"
                                    target="_blank"><i class="ion-social-facebook"></i></a>
                            </li>
                            <li>
                                <a href="https://twitter.com/intent/tweet?text={{ $currentURL }}" target="_blank"><i
                                        class="ion-social-twitter"></i></a>
                            </li>
                            <li>
                                <a href="https://api.whatsapp.com/send?text={{ $currentURL }}" target="_blank"><i
                                        class="ion-social-whatsapp"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>