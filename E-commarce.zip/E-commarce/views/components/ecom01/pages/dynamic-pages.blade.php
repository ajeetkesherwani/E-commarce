@php
$main_arr = [
  'title'=>$PageData->pages_title,
  'sublist' => [
    [
    'name'=>'HOME',
    'link'=>url("/")
    ],
    [
    'name'=>$PageData->pages_title,
    'link'=>url("")
    ], 
  ]
];
@endphp

<!-- Breadcrumb Area start -->
<x-Ecom01.SharedComponent.BreadCrumb :data="$main_arr" /> 
<!-- Breadcrumb Area End -->

<!-- About Area Start -->
<section class="page-area">
    <div class="container-fluid px-0">
        
                    {{-- @php
                        dd($PageData->pages_content);   
                    @endphp --}}

                    {!!$PageData->pages_content!!}
 
        
    </div>
</section>
<!-- About Area Start -->