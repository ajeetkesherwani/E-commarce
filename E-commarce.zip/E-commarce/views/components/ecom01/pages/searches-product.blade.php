@php
$main_arr = [
'title'=>$searchQuery ?? 'Shop Products',
'sublist' => [
[
'name'=>translation('HOME'),
'link'=>url("/")
],
[
'name'=>translation( 'SEARCH_RESULT' ) .'   '.  $searchQuery,
'link'=>url()->full()
],
]
];
$per_page=substr(url()->full(),-2);
if($per_page==00)
$per_page=substr(url()->full(),-3);
@endphp

<x-Ecom01.SharedComponent.BreadCrumb :data="$main_arr" />
<!-- Breadcrumb Area End -->

<!-- Shop Category Area End -->
<div class="shop-category-area">
    @if(!empty($product_count) )
    <div class="container">
        <form id="filterForm" action="{{url("/search/".urlencode($searchQuery))}}" method="get">
            <input type="hidden" name="filter">
            <div class="row">
                <div class="col-lg-12 order-lg-last col-md-12 order-md-first">
                    <!-- Shop Top Area Start -->
                    <div class="shop-top-bar">
                        <!-- Left Side start -->
                        <div class="shop-tab nav mb-res-sm-15">
                            <a class="active" href="#shop-1" data-bs-toggle="tab">
                                <i class="fa fa-th show_grid"></i>
                            </a>
                            <a href="#shop-2" data-bs-toggle="tab">
                                <i class="fa fa-list-ul"></i>
                            </a>
                            @if(!empty($product_count))
                            <p>
                                @php
                                    $item =  $product_count ?? 1 ;
                                    $data  = translation('PAGINATION_TOTAL_ITEM');
                                    printf($data, $item);
                                @endphp
                            </p>
                            @endif

                            <div class="select-shoing-wrap">
                                <p>{{translation('ITEM_PER_PAGE')}}:</p>
                                <select name="perPageItem" class="filter_style" id="pagination" onChange="filterItem()">
                                    <option value="20" @if($filtersData['perPageItem']==20) selected @endif>20</option>
                                    <option value="40" @if($filtersData['perPageItem']==40) selected @endif>40</option>
                                    <option value="80" @if($filtersData['perPageItem']==80) selected @endif>80</option>
                                    <option value="200" @if($filtersData['perPageItem']==200) selected @endif>200</option>
                                </select>
                            </div>
                        </div>
                        <!-- Left Side End -->

                        <!-- Right Side Start -->
                        <div class="select-shoing-wrap">
                            <div class="shot-product">
                                <p>{{translation('SORT_BY')}}</p>
                            </div>
                            <div class="shop-select">
                                <select name="sortBy" class="filter_style " id="sortBy" onChange="filterItem()">
                                    <option value="latest" @if($filtersData['sortBy']=='latest') selected @endif>{{translation('SORT_BY_LATEST')}}</option>
                                    <option value="pricemintohigh" @if($filtersData['sortBy']=='pricemintohigh') selected @endif>{{translation('PRICE_MIN_TO_MAX')}}</option>
                                    <option value="pricehightomin" @if($filtersData['sortBy']=='pricehightomin') selected @endif>{{translation('PRICE_MAX_TO_MIN')}}</option>
                                    <option value="atoz" @if($filtersData['sortBy']=='atoz') selected @endif>{{translation('A_TO_Z')}}</option>
                                    <option value="ztoa" @if($filtersData['sortBy']=='ztoa') selected @endif>{{translation('Z_TO_A')}}</option>
                                    <option value="instock" @if($filtersData['sortBy']=='instock') selected @endif>{{translation('IN_STOCK')}}</option>
                                </select>
                            </div>
                        </div>
                        <!-- Right Side End -->
                    </div>
                    <!-- Shop Top Area End -->
                    <input type="hidden" name="searchQuery" value="{{$searchQuery}}" id="searchQuery">
                    <!-- Shop Bottom Area Start -->
                    <div class="shop-bottom-area mt-35" id="filterProductData">
                        <!-- Shop Tab Content Start -->
                        <div class="tab-content jump">
                            <div id="shop-1" class="tab-pane active">
                                <div class="row">
                                    @if(!empty($products) && sizeof($products)>0)
                                    @foreach($products as $product)
                                    <div class="col-xl-3 col-md-6 col-lg-4 col-sm-6 col-xs-12">
                                        <x-Ecom01.shared-component.product viewtype="grid" :data="$product" />
                                    </div>
                                    @endforeach
                                    @endif
                                </div>
                            </div>
                            <!-- Tab One End -->

                            <!-- Tab Two Start -->
                            <div id="shop-2" class="tab-pane">
                                @if(!empty($products) && sizeof($products)>0)
                                @foreach($products as $product)
                                <x-Ecom01.shared-component.product viewtype="list" :data="$product" />
                                @endforeach
                                @else
                                <center>
                                    <h3 class="text-secondary">{{translation('EMPTY_SEARCH_PRODUCT_MSG')}}.</h3>
                                </center>
                                @endif
                            </div>
                            <!-- Tab Two End -->
                        </div>
                        <!-- Shop Tab Content End -->
                        <input style="display:none" type="text" name="page" id="page" value="" />

                        <!-- Pagination  Area Start -->
                        <div class="pro-pagination-style text-center">
                        <input type="hidden" id="nextPage" value="1">
                            <div class="row">
                                <div class="col-md-12 d-flex justify-content-center p-2">
                                {{ $products->links('vendor.pagination.for-ajax') }}
                                </div>
                            </div>
                        </div>
                        <!--  Pagination Area End -->
                    </div>
                    <!-- Shop Bottom Area End -->
                </div>

            </div>
            <button type="submit" hidden id="filterFormButton"></button>
        </form>
    </div>
    @else
<img src="{{ LoadAssets('assets/images/EmptyImages/Cart-Empty.jpg')}}" 
onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
class="rounded mx-auto d-block" width="286px" height="200px" alt="{{getSetting('site_title')}} Search-Empty">
<p class="h4 text-center text-dark mt-2">{{translation('EMPTY_SEARCH_PRODUCT_MSG')}}</p>
<div class="text-center my-3">
<a href="{{url('/')}}" class="btn btn-primary btn-lg btn-block" role="button" aria-pressed="true">{{translation('CONTINUE_TO_SHOP')}}</a>
</div>
@endif
</div>
@push('scripts')
<script>
    function filterItem(){
        $("html").scrollTop(0);
        $('#page').val($('#nextPage').val());
        $("#filterForm").submit();
        }
</script>
@endpush