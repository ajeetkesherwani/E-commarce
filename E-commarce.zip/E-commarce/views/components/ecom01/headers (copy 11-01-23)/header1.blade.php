@php
    if(Request::segment(1)=='search')
    $segment= Request::segment(2);
@endphp
<div class="home-5 home-6 home-cosmatics">
    <header class="main-header home-10 home-14 responsive">
        <!-- Header Top Start -->
        <div class="header-top-nav">
            <div class="container">
                <div class="row align-items-center">
                    <!--Left Start-->
                    <div class="col-lg-4 col-md-12">
                        <div class="text-lg-start text-center">
                            <p class="color-black">{{ getSetting('site_slogan') }}</p>
                        </div>
                    </div>
                    <!--Left End-->
                    <!--Right Start-->
                    <div class="col-8 d-lg-block d-none">
                        <div class="header-right-nav hover-style-furniture">
                            <ul>
                                {{-- Top bar work start here --}}
                                @if (!empty($top_nav_data))
                                    @foreach ($top_nav_data as $key => $value)
                                        <li class="border-color-black">
                                            <a href="{{url($value->menu_link) }}">{{ $value->menu_name }}</a>
                                        </li>
                                    @endforeach
                                @endif
                                {{-- Top bar work end here --}}

                              
                                <!-- check registraion enable by subcsriber admin -->
                                @if (webFunctionStatus(config('constkey.is_user_registeration_enabled')))
                                    @guest
                                        <li class="border-color-black">
                                            <a href="{{ url('login') }}">
                                                {{ translation('ACCOUNT_TITLE') }}
                                            </a>
                                        </li>
                                    @endguest
                                    @auth
                                        <li class="border-color-black">
                                            <a href="route('logout')"  onclick="event.preventDefault();
                                                    document.getElementById('myLogOutForm').submit();">
                                                {{ translation('LOGOUT') }}
                                                <form method="POST" id="myLogOutForm" action="{{ route('logout') }}">
                                                    @csrf
                                                </form>

                                            </a>
                                        </li>
                                    @endauth
                                @endif

                            </ul>
                            <!-- Header Top Language Currency -->
                            <div class="header-top-set-lan-curr d-flex justify-content-end">
                                <!-- check registraion enable by subcsriber admin -->
                                @if (webFunctionStatus(config('constkey.is_user_registeration_enabled')))
                                    @auth
                                        <div class="header-bottom-set dropdown">
                                            <button class="dropdown-toggle header-action-btn hover-style-furniture  border-color-black color-black">
                                                <a href="{{ url('account/dashboard') }}">{{ translation('ACCOUNT_TITLE') }}</a>
                                            </button>
                                        </div>
                                    @endauth
                                @endif
                                <!-- Single Wedge Start -->
                                @if (count($Lang_arr) > 1)
                                    <div class="header-top-curr dropdown">
                                        <button class="dropdown-toggle header-action-btn hover-style-furniture border-color-black color-black"
                                            data-bs-toggle="dropdown">
                                            <img  src="{{ asset(config('constkey.flags_path').'/'.$def_lang->languages_code . '.svg') }}"
                                                alt="N/F" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                                                height="10" width="15">
                                                {{ $def_lang->languages_code }}
                                                <i class="ion-ios-arrow-down"></i>
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-right">
                                            @if (!empty($Lang_arr))
                                                @foreach ($Lang_arr as $key => $data)
                                                    <li>
                                                        <a href="{{ url('/lang/locale/' . $data['name']) }}">
                                                        <img src="{{ asset(config('constkey.flags_path').'/'.$data['name'] . '.svg') }}"
                                                    alt="{{ $data['name'] }}" height="10" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"  width="15">
                                                        {{ $data['name'] }}
                                                        </a>
                                                    </li>
                                                @endforeach
                                            @endif
                                        </ul>
                                    </div>
                                @endif
                                @if (count($Curr_arr) > 1)
                                    <div class="header-top-curr dropdown">
                                        <button class="dropdown-toggle header-action-btn hover-style-furniture border-0  color-black"  data-bs-toggle="dropdown">
                                            {{ $defcurrency_data->currencies_code }}
                                            {{ $defcurrency_data->symbol_left }}
                                            <i class="ion-ios-arrow-down"></i>
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-right">
                                            @if (!empty($Curr_arr))
                                                @foreach ($Curr_arr as $key => $data)
                                                    <li>
                                                        <a href="{{ url('/currency/locale/' . $data['name']) }}">
                                                            {{ $data['name'] }}
                                                            {{ $data['icon'] }} 
                                                        </a>
                                                    </li>
                                                @endforeach
                                            @endif
                                        </ul>
                                    </div>
                                @endif
                            </div><!-- Header Top Language Currency -->
                        </div>
                    </div><!--Right End-->
                </div>
            </div>
        </div>
        <!-- Header Top End -->
        <!-- Header Buttom Start -->
        <div class="header-navigation d-none d-lg-block sticky-nav">
            <div class="container">
                <div class="row align-items-center">
                    <!-- Logo Start -->
                    <div class="col-md-3 col-sm-2">
                        <div class="logo">
                            <a href="{{ url('/') }}">
                                <img src="{{ getImageUrlWithKey('website_logo') }}"
                                onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" alt="{{ getSetting('site_title') }}-logo" />
                            </a>
                        </div>
                    </div>
                    <!-- Logo End -->
                    <div class="col-md-9 col-sm-10">
                        <!--Header Bottom Account Start -->
                        <div class="d-flex justify-content-between">
                            <!--Main Navigation Start -->
                            @if (!empty($main_menu))
                                <div class="main-navigation">
                                    <ul>
                                        @foreach ($main_menu as $key => $value)
                                            @if (in_array($value->menu_type, ['1', '2', '3']))
                                                <li {{ $value->menu_ref_id == '0' ? 'class=menu-dropdown' : '' }}>
                                                    <a href="{{url($value->menu_ref_id == ' 0' ? '#' : $value->menu_link)}}">{{ $value->menu_name }}
                                                        @if (!empty($value->menulist))
                                                            <i class="ion-ios-arrow-down"></i>
                                                        @endif
                                                    </a>
                                                    @if (!empty($value->menulist))
                                                        <ul class="sub-menu">
                                                            @foreach ($value->menulist as $cmenu)
                                                                @if (!empty($cmenu['title']))
                                                                    <li class="menu-dropdown position-static"><a
                                                                            href="{{url($cmenu['link']
                                                                            )}}">{{ $cmenu['title'] }}
                                                                            @if (!empty($cmenu['subcate']))
                                                                                <i class="ion-ios-arrow-down"></i>
                                                                            @endif
                                                                        </a>
                                                                        @if (!empty($cmenu['subcate']))
                                                                            <ul class="sub-menu sub-menu-2">
                                                                                @foreach ($cmenu['subcate'] as $smenu)
                                                                                    <li
                                                                                        class="menu-dropdown position-static">
                                                                                        <a
                                                                                            href="{{url($smenu['link'])}}">{{ $smenu['title'] }}</a>
                                                                                    </li>
                                                                                @endforeach
                                                                            </ul>
                                                                        @endif
                                                                    </li>
                                                                @endif
                                                            @endforeach
                                                        </ul>
                                                    @endif
                                                </li>
                                            @else
                                                <li>
                                                    <a href="{{url($value->menu_link)}}">
                                                    {{ $value->menu_name }}
                                                    </a>
                                                </li>
                                            @endif
                                        @endforeach
                                    </ul>
                                </div>
                            @endif
                            <!--Main Navigation End -->
                            <!--Cart info Start -->
                            @if (webFunctionStatus(config('constkey.is_wishlist_enabled')) ||
                                webFunctionStatus(config('constkey.is_cart_enabled')))
                                <div class="cart-info d-flex align-items-center">
                                    @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))
                                        <div class="mini-cart-warp">
                                            <a href="{{ url('wishlist') }}"
                                                class="count-cart heart color-black count-wishlist-total">
                                                <span class="item-quantity-tag">{{ $wishlist_count }}</span>
                                            </a>
                                        </div>
                                    @endif
                                    @if (webFunctionStatus(config('constkey.is_cart_enabled')))
                                        <div class="mini-cart-warp">
                                            <a href="{{ url('cart') }}"
                                                class="count-cart count-cart-total color-black ">
                                                <span class="item-quantity-tag">{{ $cart['total_count'] ?? '0' }}</span>
                                            </a>
                                        </div>
                                    @endif
                                </div>
                            @endif
                            <!--Cart info End -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--Header Bottom Account End -->
        <!-- Menu Content Start -->
        <div class="header-buttom-nav">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-left d-none d-lg-block">
                        <div class="d-flex align-items-center justify-content-start">
                            <!-- Beauty Category -->
                           
                            <div class="beauty-category vertical-menu home-9 home-10">
                                @if (webFunctionStatus(config('constkey.is_categories_enabled')))
                                <h3 class="vertical-menu-heading vertical-menu-toggle">
                                    {{ translation('HEADER_ALL_CATEGORIES_TITLE') }}</h3>
                                <ul class="vertical-menu-wrap open-menu-toggle">
                                    @if (!empty($CategoryTree))
                                        @foreach ($CategoryTree as $category)
                                            @if (isset($category->two_layer_category) && !empty($category->two_layer_category))
                                                @if (!empty($category->category_name))
                                                    <li class="menu-dropdown">
                                                        <a href="{{ url('category/' . $category->categories_slug) }}">
                                                            {{$category->category_name}}
                                                            @if (!empty($category->two_layer_category) && sizeof($category->two_layer_category) > 0)
                                                                <i class="ion-ios-arrow-down"></i>
                                                            @endif
                                                        </a>

                                                        @if (!empty($category->two_layer_category) && sizeof($category->two_layer_category) > 0)
                                                            <ul class="mega-menu-wrap">
                                                                <!-- two layer check -->
                                                                @foreach ($category->two_layer_category as $two_layer)
                                                                    <li>
                                                                        <ul class="mb-20px">
                                                                            <li class="mega-menu-title">
                                                                                <a
                                                                                    href="{{ url('category/' . $two_layer->categories_slug) }}">
                                                                                    {{ $two_layer->category_name}}
                                                                                </a>
                                                                            </li>
                                                                            <!-- three layer check -->
                                                                            @if (isset($two_layer->three_layer_category) && !empty($two_layer->three_layer_category))
                                                                                @foreach ($two_layer->three_layer_category as $three_layer)
                                                                                    <li>
                                                                                        <a
                                                                                            href="{{ url('category/' . $three_layer->categories_slug) }}">
                                                                                            {{ $three_layer->category_name }}
                                                                                        </a>
                                                                                    </li>
                                                                                @endforeach
                                                                            @endif
                                                                        </ul>
                                                                    </li>
                                                                @endforeach
                                                            </ul>
                                                        @endif
                                                    </li>
                                                @endif
                                            @elseif(!empty($category->category_name))
                                                <li>
                                                <a href="{{ url('category/' . $category->categories_slug) }}">
                                                        {{ $category->category_name }} 
                                                    </a>
                                                </li>
                                            @endif
                                        @endforeach
                                    @endif
                                </ul>
                                @endif
                            </div>
                           
                            <!-- Beauty Category -->
                            <!--Seach Area Start -->
                            @if (webFunctionStatus(config('constkey.is_header_search_box_enabled')))
                                <div class="header_account_list search_list">
                                    <a href="javascript:void(0)"><i class="ion-ios-search-strong"></i></a>
                                    <div class="dropdown_search">
                                        <form class="needs-validation" id="searchform" novalidate>
                                            <input placeholder="{{ translation('HEADER_SEARCH_PLACEHOLDER') }}"
                                                class="searchtext" name="searchtext" type="text" autocomplete="off"
                                                required value="{{ $segment ?? '' }}" />
                                            <button type="submit" class="searchbutton"">
                                                <i class="ion-ios-search-strong"></i>
                                            </button>
                                        </form>
                                    </div>
                                    <div class="searchItem hide ">
                                        <div class="searchItemList"></div>
                                    </div>
                                </div>
                            @endif
                            <!--Seach Area End -->
                            @if (!empty(getSetting('contact_phone')))
                                <!--Contact info Start -->
                                <div class="contact-link-wrap">
                                    <div class="contact-link">
                                        <div class="phone">
                                            <p>{{ translation('HEADER_CALL_US') }}:</p>
                                            <a href="tel:{{ getSetting('contact_phone') }}">
                                                {{ getSetting('contact_phone') }}
                                            </a>
                                        </div>
                                    </div><!--Contact info End -->
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Menu Content End -->

        <!-- Header mobile area start -->
        <div class="header-bottom d-lg-none sticky-nav py-3 mobile-navigation hover-style-furniture">
            <div class="container-fluid">
                <div class="row justify-content-between align-items-center">
                    <div class="col-md-3 col-sm-3">

                        <a href="#offcanvas-mobile-menu" class="offcanvas-toggle mobile-menu">
                            <i class="ion-navicon"></i>
                        </a>
                    </div>
                    <div class="col-md-6 col-sm-4 d-flex justify-content-center">
                        <div class="logo m-0">
                            <a href="{{ url('/') }}">
                                <img src="{{ getImageUrlWithKey('website_logo') }}" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" alt="" />
                            </a>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-5">
                        <!--Cart info Start -->
                        <div class="cart-info d-flex m-0 justify-content-end">
                            @if (webFunctionStatus(config('constkey.is_cart_enabled')))
                                <div class="mini-cart-warp">
                                    <a href="{{ url('cart') }}"
                                        class="count-cart offcanvas-toggle color-black">
                                        <span class="item-quantity-tag count-cart-total">{{ $cart['total_count'] ?? '' }}</span>
                                    </a>
                                </div>
                            @endif
                            {{-- registration enable / disable --}}
                            @if (webFunctionStatus(config('constkey.is_user_registeration_enabled')))
                                <div class="header-bottom-set dropdown hover-style-furniture">
                                    <button class="dropdown-toggle header-action-btn hover-style-furniture"
                                        data-bs-toggle="dropdown"> <i class="ion-person"></i></button>
                                    <ul class="dropdown-menu">
                                        @guest
                                            <li>
                                                <a class="dropdown-item" href="{{ url('login') }}">{{ translation('ACCOUNT_TITLE') }}</a>
                                            </li>
                                        @endguest
                                        @auth
                                        <li>
                                            <li>
                                                <a href="{{ url('account/dashboard') }}">{{ translation('ACCOUNT_TITLE') }}</a>
                                             </li>
                                            <a class="dropdown-item" href="route('logout')"
                                                onclick="event.preventDefault(); document.getElementById('myLogOutForm').submit();">
                                                {{ translation('LOGOUT') }}
                                                <form method="POST" id="myLogOutForm"
                                                    action="{{ route('logout') }}">
                                                    @csrf
                                                </form>
                                            </a>
                                        </li>
                                        @endauth
                                    </ul>
                                </div>
                            @endif
                        </div>
                        <!--Cart info End -->
                    </div>
                </div>
            </div>
        </div>
        <!-- Header mobile area end -->

    </header>
    <!-- Header End -->
    @if (webFunctionStatus(config('constkey.is_header_search_box_enabled')))
        <div class="mobile-search-option pb-3 d-lg-none hover-style-furniture">
            <div class="container-fluid">
                <div class="header-account-list">
                    <div class="dropdown-search">
                        <form class="needs-validation" id="searchform" novalidate>
                            <input placeholder="{{ translation('HEADER_SEARCH_PLACEHOLDER') }}" name="searchtext" class="searchtext" autocomplete="off" type="text" value="{{$segment ?? ''}}" required />
                            <button type="submit" id=""><i class="ion-ios-search-strong searchbutton"></i></button>
                        </form>
                    </div>
                    <div class="searchItem hide ">
                        <div class="searchItemList"></div>
                    </div>
                </div>
            </div>
        </div>
    @endif
    <!-- offcanvas overlay start -->
    <div class="offcanvas-overlay"></div>
    <!-- offcanvas overlay end -->

    <!-- OffCanvas Menu Start -->
    <div id="offcanvas-mobile-menu" class="offcanvas offcanvas-mobile-menu hover-style-furniture">
        <div class="offcanvas-mobile_logo m-0 logo">
            <a href="{{ url('/') }}"><img src="{{ getImageUrlWithKey('website_logo') }}" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" alt="" /></a>
        </div>
        <button class="offcanvas-close"></button>
        <!-- contact Info -->
        <div class="contact-info d-flex align-items-center justify-content-center color-black pb-3 pt-4">
            <img class="me-3" src="{{ LoadAssets('assets/images/icons/mobile-contact.png') }}"
                onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" alt="">
            <p>{{ translation('CALL_US') }}:</p>
            <a class="color-black" href="tel:{{ getSetting('contact_phone') }}">
                {{ getSetting('contact_phone') }}
            </a>
        </div>
        <!-- offcanvas compare & wishlist -->
        @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))
            <div class="user-panel">
                <ul class="d-flex justify-content-between">
                    @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))
                        <li>
                            <a href="{{ url('wishlist') }}" class="count-wishlist-total">
                                <i class="ion-android-favorite-outline"></i>
                                Wishlist ({{ $wishlist_count }})
                            </a>
                        </li>
                    @endif
                </ul>
            </div>
        @endif
        <div class="offcanvas-userpanel">
            <ul>
                <li class="offcanvas-userpanel__role">
                    <a href="#">{{ $defcurrency_data->currencies_code }} {{ $defcurrency_data->symbol_left }}<i class="ion-ios-arrow-down"></i></a>
                    <ul class="user-sub-menu">
                        @if (!empty($Curr_arr))
                            @foreach ($Curr_arr as $key => $data)
                                <li><a class="current" href="#">{{ $data['name'] }} {{ $data['icon'] }}</a>
                                </li>
                            @endforeach
                        @endif
                    </ul>
                </li>
                <li class="offcanvas-userpanel__role">
                    <a href="#"><img src="{{ asset(config('constkey.flags_path').'/'. $def_lang->languages_code . '.svg') }}"
                            onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                            alt="N/F" height="10" width="15">{{ $def_lang->languages_code }}<i
                            class="ion-ios-arrow-down"></i></a>
                    <ul class="user-sub-menu">
                        @if (!empty($Lang_arr))
                            @foreach ($Lang_arr as $key => $data)
                                <li><a class="current" href="{{ url('/lang/locale/' . $data['name']) }}">
                                    <img src="{{asset(config('constkey.flags_path').'/'.$data['name'].'.svg')}}" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"  alt="N/F" height="10" width="15">{{ $data['name'] }}</a>
                                </li>
                            @endforeach
                        @endif
                    </ul>
                </li>
            </ul>
        </div>
        <!-- offcanvas language -->

        <!-- <div class="offcanvas-userpanel">
            <ul>
                <li class="offcanvas-userpanel__role">
                    <a href="#"><img src="{{ asset(config('constkey.flags_path').'/'. $def_lang->languages_code . '.svg') }}"
                            onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                            alt="N/F" height="10" width="15">{{ $def_lang->languages_code }}<i
                            class="ion-ios-arrow-down"></i></a>
                    <ul class="user-sub-menu">
                        @if (!empty($Lang_arr))
                            @foreach ($Lang_arr as $key => $data)
                                <li><a class="current" href="{{ url('/lang/locale/' . $data['name']) }}">
                                    <img src="{{asset(config('constkey.flags_path').'/'.$data['name'].'.svg')}}" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"  alt="N/F" height="10" width="15">{{ $data['name'] }}</a>
                                </li>
                            @endforeach
                        @endif
                    </ul>
                </li>
            </ul>
        </div> -->

        <div class="menu-close">
            menu
        </div>
        <!-- offcanvas menu -->
        <div class="inner customScroll">
            <div class="offcanvas-menu mb-4">
                <ul>
                    <li><a href="#"><span class="menu-text">Shop</span></a>
                        <ul class="sub-menu">
                            @if (!empty($CategoryTree))
                                @foreach ($CategoryTree as $category)
                                    @if (isset($category->two_layer_category) && !empty($category->two_layer_category))
                                        <li>
                                            @if (!empty($category->category_name))
                                                <a href="{{ url('category/' . $category->categories_slug) }}">
                                                    {{$category->category_name}}
                                                </a>
                                            @endif
                                            <ul class="sub-menu">
                                                <!-- two layer check -->
                                                @foreach ($category->two_layer_category as $two_layer)
                                                    <li>
                                                        <a href="{{ url('category/' . $two_layer->categories_slug) }}">
                                                            <span
                                                                class="menu-text">{{$two_layer->category_name}}</span>
                                                            @if (isset($two_layer->three_layer_category) &&
                                                                !empty($two_layer->three_layer_category) &&
                                                                sizeof($two_layer->three_layer_category) > 0)
                                                            @endif
                                                        </a>
                                                        <ul class="sub-menu">
                                                            <!-- three layer check -->
                                                            @if (isset($two_layer->three_layer_category) && !empty($two_layer->three_layer_category))
                                                                @foreach ($two_layer->three_layer_category as $three_layer)
                                                                    <li>
                                                                        <span class="menu-text"> <a
                                                                                href="{{ url('category/' . $three_layer->categories_slug) }}">
                                                                                {{$three_layer->category_name}}</span>
                                                                        </a>
                                                                    </li>
                                                                @endforeach
                                                            @endif
                                                        </ul>
                                                    </li>
                                                @endforeach
                                            </ul>
                                        </li>
                                    @else
                                        <li><a href="{{ url('category/' . $category->categories_slug) }}">
                                            {{ $category->category_name}} </a></li>
                                    @endif
                                @endforeach
                            @endif
                        </ul>
                    </li>

                    {{-- Dyanamics Menubar --}}

                    @if (!empty($main_menu))
                        @foreach ($main_menu as $key => $value)
                            @if (in_array($value->menu_type, ['1', '2', '3']))
                                <li>
                                    <a href="{{url($value->menu_ref_id == ' 0' ? '#' : $value->menu_link)}}">
                                        <span class="menu-text">
                                            {{$value->menu_name}}
                                        </span>
                                    </a>
                                    @if (!empty($value->menulist))
                                        <ul {{ $value->menu_ref_id == '0' ? 'class=sub-menu' : '' }}>
                                            @foreach ($value->menulist as $cmenu)
                                                @if (!empty($cmenu['title']))
                                                    <li>
                                                        <a href="{{url($cmenu['link'])}}"> {{$cmenu['title']}}</a>
                                                        @if (!empty($cmenu['subcate']))
                                                            <ul class="sub-menu">
                                                                @foreach ($cmenu['subcate'] as $smenu)
                                                                    <li>
                                                                        <a href="{{url($smenu['link'])}}">
                                                                            <span class="menu-text">{{$smenu['title']}}</span>
                                                                        </a>
                                                                    </li>
                                                                @endforeach
                                                            </ul>
                                                        @endif
                                                    </li>
                                                @else
                                                    <li>
                                                        <a href="{{url($value->menu_link)}}"
                                                            target="_blank">
                                                            {{$value->menu_name }}
                                                        </a>
                                                    </li>
                                                @endif
                                            @endforeach
                                        </ul>
                                    @endif
                                </li>
                            @else
                                <li><a href="{{url($value->menu_link)}}">{{$value->menu_name}}</a></li>
                            @endif
                        @endforeach
                    @endif
                </ul>
            </div>
            <!-- OffCanvas Menu End -->
            <div class="offcanvas-social mt-5">
                <ul>
                    <li>
                        <a href="{{ getSetting('facebook_url') }}" target="_blank"><i
                                class="ion-social-facebook"></i></a>
                    </li>
                    <li>
                        <a href="{{ getSetting('twitter_url') }}" target="_blank"><i
                                class="ion-social-twitter"></i></a>
                    </li>
                    <li>
                        <a href="{{ getSetting('google_url') }}" target="_blank"><i
                                class="ion-social-google"></i></a>
                    </li>
                    <li>
                        <a href="{{ getSetting('youtube_url') }}" target="_blank"><i
                                class="ion-social-youtube"></i></a>
                    </li>
                    <li>
                        <a href="{{ getSetting('instagram_url') }}" target="_blank"><i
                                class="ion-social-instagram"></i></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <!-- OffCanvas Menu End -->
    <!-- Header End -->
    <!-- Slider Arae Start -->

</div>


@push('scripts')
    <script>
        $(document).ready(function() {
            $(document).on('click', '.searchbutton', function (e) {
                e.preventDefault();
                let formIns = $(this).parents('form:first');
                var data = formIns.find('.searchtext').val();
                // var data = $('.searchtext').val();
                if(data == ''){
                    Notify('{{translation('ERROR_SEARCH_MSG')}}!');exit;
                }else{
                    window.location.href = "/search/" + data;
                }
            });

            $(document).on('keyup', '.searchtext', function(e) {
                e.preventDefault();
                var searchVal = $(this).val();

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                $.ajax({
                    url: '{{ route('SearchSuggestion') }}',
                    method: 'POST',
                    data: {
                        search: searchVal
                    },
                    success: function(response) {
                        if (response.searchHtml != '') {
                            $('.searchItem').removeClass('hide');
                            $('.searchItemList').html(response.searchHtml);
                        } else {
                            $('.searchItem').addClass('hide');
                        }
                    },
                    error: function(error) {
                        Notify(error.message, false);
                    }
                });
            });
            // hide search suggestion box
            $('.searchItemList').on('mouseleave', function(e) {
                $('.searchItem').addClass('hide');
            });



            $(window).scroll(function() {
                $('.searchItem').addClass('hide');
            });
        });
    </script>
@endpush
