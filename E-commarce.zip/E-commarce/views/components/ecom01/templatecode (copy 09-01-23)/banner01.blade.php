<!-- ========================
  Banner Layout 
 =========================== -->
@if(!empty($banner_data))
<div class="banner-3-area mt-0px mb-100px">
    <div class="container pt-3">
        <div class="row">
            <div class="col-lg-12  col-md-12 col-sm-12 col-xs-12 mb-res-xs-30 mb-res-sm-30">
                <div class="banner-wrapper banner-box">
                    <a href="{{$banner_data->banners_url}}"><img src="{{getFullImageUrl($banner_data->banners_image)}}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="{{$banner_data->banners_title}}"/></a>
                </div>
            </div>
        </div>
    </div>
</div>
@endif