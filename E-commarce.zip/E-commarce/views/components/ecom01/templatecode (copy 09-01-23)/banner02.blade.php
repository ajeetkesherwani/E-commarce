   <!-- ========================
     Banner Layout 1
    =========================== -->
    <section class="banner-layout1 bg-secondary py-0">
        <div class="container-fluid px-0">
          <div class="row row-gutter-0">
            <div class="col-sm-12 col-md-12 col-lg-6">
              <div class="inner-padding">
                <div class="heading-light">
                  <h2 class="heading__subtitle color-accent">Providing Quality Cleaning Services.</h2>
                  <h3 class="heading__title">Experience Ultimate Level Of Cleaning Power With Tailored Industry Leading
                    Services.</h3>
                  <p class="heading__desc font-weight-bold mb-30">We’ll take the time to discuss your preferences and
                    priorities
                    with you
                    before your first home cleaning service and combine with our methods to provide the best clean
                    possible, housekeepers also will arrive with plan in hand to ensure that all of needs are taken into
                    account.
                  </p>
                  <p class="heading__desc font-weight-bold mb-40">Now more than ever, detailed disinfecting methods should
                    be in
                    place to protect the guests and employees of your facility.
                  </p>
                </div>
                <div class="d-flex flex-wrap">
                  <a href="#" class="btn btn__accent mr-30">
                    <span>Our Core Values</span> <i class="icon-arrow-right"></i>
                  </a>
                  <a href="pricing.html" class="btn btn__white btn__outlined">
                    Pricing And Plans
                  </a>
                </div>
              </div><!-- /.banner-text -->
            </div><!-- /.col-lg-6 -->
            <div class="col-sm-12 col-md-12 col-lg-6 banner-img d-flex align-items-center justify-content-center">
              <div class="bg-img">
                <img src="assets/images/banners/5.jpg" alt="backgrounds">
              </div>
              <img src="assets/images/certificates/badge.png" alt="badge">
            </div><!-- /.col-lg-6 -->
          </div><!-- /.row -->
        </div><!-- /.container -->
      </section>
      <!-- /.Banner Layout 1 -->