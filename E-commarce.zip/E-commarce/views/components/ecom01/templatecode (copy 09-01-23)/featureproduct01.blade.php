@php
use App\Models\Ecom\Services\EcomService;
use App\Models\WishList;
$wishlistAry = WishList::getProductsAry();
@endphp

@if(!empty($featureGroupList))
    @foreach($featureGroupList as $featureGroup)
        @if(!empty($featureGroup->featured_product) && sizeof($featureGroup->featured_product) > 0 )
        <section class="recent-add-area mt-5">
            <div class="container">
                
                <div class="row">
                    <div class="col-md-12 text-center">
                        <!-- Section Title -->
                        <div class="section-title underline-shape">
                            <h2>{{$featureGroup->group_name}}</h2>
                            <p>{{$featureGroup->group_title}}</p>
                        </div>
                        <!-- Section Title -->
                    </div>
                </div>

                <!-------------------- Grid View Start------------------------>
                @if($viewType == 'grid')
                <div class="row">
                    @foreach ($featureGroup->featured_product as $featured_product )
                        @if(!empty($featured_product->product))

                        @php
                        $avgrating=AvgRating($featured_product->product->product_id);
                        @endphp

                        <div class="col-lg-3">
                            <div class="product-inner-item mb-60px d-flex justify-content-center">
                                <article class="list-product ">
                                    <ul class="product-flag">
                                        @if(!empty($featured_product->product->feature_name))
                                        @foreach($featured_product->product->feature_name as $productFeature)
                                        <li>
                                            {{$productFeature}}
                                            <!-- Category Badge -->
                                        </li>
                                        @endforeach
                                        @endif
                                    </ul>

                                    <div class="img-block text-center">
                                        <a href="{{ EcomService::url($featured_product->product->product_id , 'product')}}"
                                            class="thumbnail">
                                            <img class="first-img img-fluid"
                                                src="{{getFullImageUrl($featured_product->product->product_image)}}"
                                                onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                                                alt="{{$featured_product->product->products_name ?? ''}}" />
                                        </a>
                                        <div class="add-to-link">
                                            <ul>
                                                @if (webFunctionStatus(config('constkey.is_cart_enabled')))
                                                <li>
                                                    <a href="{{ url('product/'.$featured_product->product->product_slug) }}"
                                                        title="View Details"><i class="ion-eye"></i></a>
                                                </li>
                                                @endif
                                                @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))
                                                <li>
                                                    <a href="javascript:void(0);"
                                                        onclick="addToWishListFromDetail({{ $featured_product->product->product_id }})"
                                                        title="wishlist">
                                                        @if(in_array($featured_product->product->product_id, $wishlistAry))
                                                        <i class="ion-android-favorite-outline whishlist-active"></i>
                                                        @else
                                                        <i class="ion-android-favorite-outline"></i>
                                                        @endif
                                                    </a>
                                                </li>
                                                @endif
                                                <li>
                                                    <a class="quick_view"
                                                        onclick="showfunction('{{ $featured_product->product->product_slug }}')"
                                                        title="Quick View">
                                                        <i class="ion-ios-search-strong"></i>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="product-decs text-center">
                                        <a class="inner-link"
                                            href="{{ EcomService::url($featured_product->product->product_id , 'product')}}"><span>{{$featured_product->product->product_model ?? '' }}</span></a>
                                        <h2>
                                            <a href="{{ EcomService::url($featured_product->product->product_id , 'product')}}"
                                                class="product-link"
                                                title="{{ $featured_product->product->products_name ?? '' }}">{{
                                                sortStringName($featured_product->product->products_name ?? '') }}</a>
                                        </h2>
                                        @if(!empty($avgrating))
                                        <div class="rating-product">
                                            @for($i=0;$i<5;$i++) @if($i<$avgrating) <i class="ion-android-star"></i>
                                                @else
                                                <i class="ion-android-star-outline"></i>
                                                @endif
                                            @endfor
                                        </div>
                                        @endif
                                        <div class="pricing-meta">
                                            @if($featured_product->product->products_prices!=null)
                                              @foreach($featured_product->product->products_prices as $holeprice)
                                                  <ul>
                                                      @if($holeprice->discount_percent !='0')
                                                          <del class="text-danger ms-2">
                                                              {{currencyFormat($holeprice->max_sale_price) }}
                                                          </del>
                                                      @endif
                                                      <li class=" not-cut">
                                                          {{ currencyFormat($holeprice->sale_price ?? '0.00') }} 
                                                      </li>
                                                      @if($holeprice->discount_percent != '0')
                                                          <span class="discount-price ms-1">
                                                              {{ currencyFormat( $holeprice->discount_percent )}}% {{translation('PRODUCT_DISCOUNT')}}
                                                          </span>
                                                      @endif
                                                  </ul>
                                                  @break
                                              @endforeach
                                            @else
                                                  <ul>
                                                      @if($featured_product->product->discount_type != 'no')
                                                          <del class="text-danger ms-2">
                                                              {{currencyFormat($featured_product->product->max_sale_price) }}
                                                          </del>
                                                      @endif
                                                      <li class=" not-cut">
                                                          {{ currencyFormat($featured_product->product->sale_price ?? '0.00') }} 
                                                      </li>
                                                      @if($featured_product->product->discount_type != 'no')
                                                        @if($featured_product->product->discount_type == 'flat')
                                                            <span class="discount-price ms-1">
                                                                {{ currencyFormat($featured_product->product->discount_amount) }} {{translation('PRODUCT_DISCOUNT')}}
                                                            </span>
                                                        @else
                                                            <span class="discount-price ms-1">
                                                                {{ currencyFormat( $featured_product->product->discount_amount )}}% {{translation('PRODUCT_DISCOUNT')}}
                                                            </span>
                                                        @endif
                                                      @endif
                                                  </ul>
                                            @endif
                                        </div>
                                    </div>
                                </article>
                            </div>
                        </div>

                        @endif
                    @endforeach
                </div>
                @endif
                <!-------------------- Grid View End------------------------>

                <!----------- List View Start------------------------>

                @if($viewType == 'list')
                @foreach ($featureGroup->featured_product as $featured_product )
                @if(!empty($featured_product->product))
                @php
                $avgrating=AvgRating($featured_product->product->product_id);
                @endphp
                <div class="shop-list-wrap mb-30px scroll-zoom ">
                    <div class="row list-product m-0px">
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                                    <div class="left-img">
                                        <div class="img-block text-center">
                                            <a href="{{ EcomService::url($featured_product->product->product_id , 'product')}}"
                                                class="thumbnail">
                                                <img class="first-img"
                                                    src="{{getFullImageUrl($featured_product->product->product_image)}}"
                                                    onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                                                    alt="{{$featured_product->product->products_name ?? ''}}" />
                                            </a>
                                            <div class="add-to-link">
                                                <ul>
                                                    @if (webFunctionStatus(config('constkey.is_cart_enabled')))
                                                    <li>
                                                        <a href="{{ url('product/'.$featured_product->product->product_slug) }}"
                                                            title="View Details"><i class="ion-eye"></i></a>
                                                    </li>
                                                    @endif
                                                    @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))
                                                    <li>
                                                        <a href="javascript:void(0);"
                                                            onclick="addToWishListFromDetail({{ $featured_product->product->product_id }})"
                                                            title="wishlist">
                                                            @if(in_array($featured_product->product->product_id, $wishlistAry))
                                                            <i class="ion-android-favorite-outline whishlist-active"></i>
                                                            @else
                                                            <i class="ion-android-favorite-outline"></i>
                                                            @endif
                                                        </a>
                                                    </li>
                                                    @endif

                                                    <li>
                                                        <a class="quick_view"
                                                            onclick="showfunction('{{ $featured_product->product->product_slug }}')"
                                                            title="Quick View">
                                                            <i class="ion-ios-search-strong"></i>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <ul class="product-flag">
                                            @if(!empty($featured_product->product->feature_name))
                                                @foreach($featured_product->product->feature_name as $productFeature)
                                                    <li>
                                                        {{$productFeature}}
                                                    </li>
                                                @endforeach
                                            @endif
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                                    <div class="product-desc-wrap">
                                        <div class="product-decs text-start">

                                            <h2>
                                                <a href="{{ EcomService::url($featured_product->product->product_id , 'product')}}"
                                                    class="product-link">
                                                    {{ $featured_product->product->products_name ?? '' }}
                                                </a>
                                            </h2>
                                            <a class="inner-link"
                                                href="{{ EcomService::url($featured_product->product->product_id , 'product')}}"><span>{{
                                                    $featured_product->product->product_model ?? '' }}</span></a>
                                            @if(!empty($avgrating))
                                            <div class="rating-product">
                                                @for($i=0;$i<5;$i++)
                                                    @if($i<$avgrating)
                                                        <i class="ion-android-star"></i>
                                                    @else
                                                        <i class="ion-android-star-outline"></i>
                                                    @endif
                                                @endfor
                                            </div>
                                            @endif
                                            <div class="pricing-meta mb-1">
                                                @if($featured_product->product->products_prices!=null)
                                                  @foreach($featured_product->product->products_prices as $holeprice)
                                                      <ul>
                                                          @if($holeprice->discount_percent !='0')
                                                              <del class="text-danger ms-2">
                                                                  {{currencyFormat($holeprice->max_sale_price) }}
                                                              </del>
                                                          @endif
                                                          <li class=" not-cut">
                                                              {{ currencyFormat($holeprice->sale_price ?? '0.00') }} 
                                                          </li>
                                                          @if($holeprice->discount_percent != '0')
                                                              <span class="discount-price ms-1">
                                                                  {{ currencyFormat( $holeprice->discount_percent )}}% {{translation('PRODUCT_DISCOUNT')}}
                                                              </span>
                                                          @endif
                                                      </ul>
                                                      @break
                                                  @endforeach
                                                @else
                                                    <ul>
                                                        @if($featured_product->product->discount_type != 'no')
                                                            <del class="text-danger ms-2">
                                                                {{currencyFormat($featured_product->product->max_sale_price) }}
                                                            </del>
                                                        @endif
                                                        <li class=" not-cut">
                                                            {{ currencyFormat($featured_product->product->sale_price ?? '0.00') }} 
                                                        </li>
                                                        @if($featured_product->product->discount_type != 'no')
                                                            @if($featured_product->product->discount_type == 'flat')
                                                                <span class="discount-price ms-1">
                                                                    {{ currencyFormat($featured_product->product->discount_amount) }} {{translation('PRODUCT_DISCOUNT')}}
                                                                </span>
                                                            @else
                                                                <span class="discount-price ms-1">
                                                                    {{ currencyFormat( $featured_product->product->discount_amount )}}% {{translation('PRODUCT_DISCOUNT')}}
                                                                </span>
                                                            @endif
                                                        @endif
                                                    </ul>
                                                @endif
                                              </div>
                                            <div class="product-intro-info">
                                                <p>{!! Str::limit( strip_tags($featured_product->product->products_description)
                                                    ?? '',150) !!}</p>

                                            </div>
                                            <div class="product-intro-info">
                                                @foreach($featured_product->product->products_to_features as $featKey=>$featVal)
                                                <p><span>{{$featVal->feature_title ?? ''}}: </span>{{$featVal->feature_value ??
                                                    ''}}</p>
                                                @endforeach
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @endif
                @endforeach
                @endif
                <!----------- List View End------------------------>

                <!----------- Slider View Start ------------------------>

                @if($viewType == 'slider')
                <div class="best-sell-slider owl-carousel owl-nav-style-3">
                    @foreach ($featureGroup->featured_product as $featured_product )
                    @if(!empty($featured_product->product))

                    @php
                    $avgrating=AvgRating($featured_product->product->product_id);
                    @endphp

                    <div class="product-inner-item mb-60px d-flex justify-content-center">
                        <article class="list-product ">
                            <ul class="product-flag">
                                @if(!empty($featured_product->product->feature_name))
                                @foreach($featured_product->product->feature_name as $productFeature)
                                <li>
                                    {{$productFeature}}
                                    <!-- Category Badge -->
                                </li>
                                @endforeach
                                @endif
                            </ul>

                            <div class="img-block text-center">
                                <a href="{{ EcomService::url($featured_product->product->product_id , 'product')}}"
                                    class="thumbnail">
                                    <img class="first-img" src="{{getFullImageUrl($featured_product->product->product_image)}}"
                                        onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                                        alt="{{$featured_product->product->products_name ?? ''}}" />
                                </a>
                                <div class="add-to-link">
                                    <ul>
                                        @if (webFunctionStatus(config('constkey.is_cart_enabled')))
                                        <li>
                                            <a href="{{ url('product/'.$featured_product->product->product_slug) }}"
                                                title="View Details"><i class="ion-eye"></i></a>
                                        </li>
                                        @endif
                                        @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))
                                        <li>
                                            <a href="javascript:void(0);"
                                                onclick="addToWishListFromDetail({{ $featured_product->product->product_id }})"
                                                title="wishlist">
                                                @if(in_array($featured_product->product->product_id, $wishlistAry))
                                                <i class="ion-android-favorite-outline whishlist-active"></i>
                                                @else
                                                <i class="ion-android-favorite-outline"></i>
                                                @endif
                                            </a>
                                        </li>
                                        @endif
                                        <li>
                                            <a class="quick_view"
                                                onclick="showfunction('{{ $featured_product->product->product_slug }}')"
                                                title="Quick View">
                                                <i class="ion-ios-search-strong"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product-decs text-center">
                                <a class="inner-link"
                                    href="{{ EcomService::url($featured_product->product->product_id , 'product')}}"><span>{{
                                        $featured_product->product->product_model ?? '' }}</span></a>
                                <h2>
                                    <a href="{{ EcomService::url($featured_product->product->product_id , 'product')}}"
                                        class="product-link" title="{{ $featured_product->product->products_name ?? '' }}">{{
                                        sortStringName($featured_product->product->products_name ?? '') }}</a>
                                </h2>
                                @if(!empty($avgrating))
                                <div class="rating-product">
                                    @for($i=0;$i<5;$i++)
                                     @if($i<$avgrating) 
                                       <i class="ion-android-star"></i>
                                     @else
                                        <i class="ion-android-star-outline"></i>
                                      @endif
                                    @endfor
                                </div>
                                @endif
                           
                                <div class="pricing-meta">
                                    @if($featured_product->product->products_prices!=null)
                                      @foreach($featured_product->product->products_prices as $holeprice)
                                          <ul>
                                              @if($holeprice->discount_percent !='0')
                                                  <del class="text-danger ms-2">
                                                      {{currencyFormat($holeprice->max_sale_price) }}
                                                  </del>
                                              @endif
                                              <li class=" not-cut">
                                                  {{ currencyFormat($holeprice->sale_price ?? '0.00') }} 
                                              </li>
                                              @if($holeprice->discount_percent != '0')
                                                  <span class="discount-price ms-1">
                                                      {{ currencyFormat( $holeprice->discount_percent )}}% {{translation('PRODUCT_DISCOUNT')}}
                                                  </span>
                                              @endif
                                          </ul>
                                          @break
                                      @endforeach
                                    @else
                                          <ul>
                                              @if($featured_product->product->discount_type != 'no')
                                                  <del class="text-danger ms-2">
                                                      {{currencyFormat($featured_product->product->max_sale_price) }}
                                                  </del>
                                              @endif
                                                <li class=" not-cut">
                                                    {{ currencyFormat($featured_product->product->sale_price ?? '0.00') }} 
                                                </li>
                                              @if($featured_product->product->discount_type != 'no')
                                                @if($featured_product->product->discount_type == 'flat')
                                                  <span class="discount-price ms-1">
                                                      {{ currencyFormat($featured_product->product->discount_amount) }} {{translation('PRODUCT_DISCOUNT')}}
                                                  </span>
                                                @else
                                                <span class="discount-price ms-1">
                                                    {{ currencyFormat( $featured_product->product->discount_amount )}}% {{translation('PRODUCT_DISCOUNT')}}
                                                </span>
                                                @endif
                                              @endif
                                          </ul>
                                    @endif
                                  </div>
                            </div>
                        </article>
                       </div>
                     @endif
                  @endforeach
                </div>
                @endif
                <!----------- Slider View End ------------------------>
            </div>
        </section>
        @endif
    @endforeach
@endif