<!-- Testimonial Area Start -->
@if($testimonial_data->isNotEmpty())
<section class="testimonial-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <!-- Section Title -->
                <div class="section-title">
                    <h2 class="text-black text-center text-uppercase" style="font-size: 24px;">{{translation('CLIENT_TESTIMONIAL_TITLE')}}</h2>
                    <p class=" text-center ">{{translation('CLIENT_TESTIMONIAL_SUB_TITLE')}}</p>
                </div>
                <!-- Section Title -->
            </div>
        </div>
        <!-- Testimonial Slider Start -->
       <div class="row">
        <div class="col-lg-8 mx-auto">
        <div class="testi-slider owl-carousel owl-dot-style">
            <!-- Single item -->
            @foreach($testimonial_data as $key=>$data)
            <div class="testi-slider-wrapper">
                <div class="testi-slider-inner">
                    <div class="testi-content">
                        <div class="testi-content-text">
                            {{$data->testimonial_text}}
                        </div>
                        <div class="author-text">
                            <h4>{{ !empty($data->user_data) ? $data->user_data->first_name : '' }} 
                            {{ !empty($data->user_data) ? $data->user_data->last_name : ''}}<span>
                            {{!empty($data->user_data) ? $data->user_data->email : ''}}</span></h4>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
            <!-- Single item -->
        </div>
        </div>
       </div>
        <!-- Testimonial Slider End -->
    </div>
</section>
@endif
<!-- Testimonial Area end -->
