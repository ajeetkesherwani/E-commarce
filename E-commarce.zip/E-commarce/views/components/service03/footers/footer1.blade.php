    <!-- Footer Start-->
    <footer>
        <div class="container ">
            <div class="row mx-0">
                <div class="col-sm-12 col-md-3 ">
                    <img src="{{getImageUrlWithKey('website_logo') }}" 
                    onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"width="200px" alt="footer-logo">
                    <div class="footer_inner">
                        <p class="color-light">
                            {{getSetting('footer_about_description')}}
                        </p>
                        <ul class="social-icons list-unstyled my-2">
                            
                            @if(!empty(socialLinks('facebook_url')))
                            <li>
                                <a href="{{socialLinks('facebook_url')}}" target="_blank"><i class="fab fa-facebook-f"></i></a>
                            </li>
                            @endif
                            @if(!empty(socialLinks('twitter_url')))
                            <li>
                                <a href="{{socialLinks('twitter_url')}}" target="_blank"><i class="fab fa-instagram"></i></a>
                            </li>
                            @endif
                            @if(!empty(socialLinks('youtube_url')))
                            <li>
                                <a href="{{socialLinks('youtube_url')}}" target="_blank"><i class="fab fa-youtube"></i></a>
                            </li>
                            @endif
                            @if(!empty(socialLinks('google_url')))
                            <li>
                                <a href="{{socialLinks('google_url')}}" target="_blank"><i class="fab fa-google"></i></a>
                            </li>
                            @endif
                            @if(!empty(socialLinks('instagram_url')))
                            <li>
                                <a href="{{socialLinks('instagram_url')}}" target="_blank"><i class="fab fa-instagram"></i></a>
                            </li>
                            @endif
                            @if(!empty(socialLinks('linkedin_url')))
                            <li>
                                <a href="{{socialLinks('linkedin_url')}}" target="_blank"><i class="fab fa-linkedin"></i></a>
                            </li>
                            @endif
                        </ul>
                    </div>
                </div>
                <div class="col-sm-12 col-md-3 ">
                    @if (!empty($footermenulist1))
                    <h4>{{ translation('INFORMATION') }}</h4>
                    <div class="footer_inner">
                        <ul>
                            @foreach ($footermenulist1 as $key => $value)
                            <li><a href="{{ $value['link'] ?? '' }}">{{ $value['name'] ?? '' }}</a></li>
                            @endforeach
                        </ul>
                    </div>
                    @endif
                </div>

                <div class="col-sm-12 col-md-3 ">
                    @if(!empty($footermenulist2))
                    <h4>{{ translation('CUSTOM_LINKS') }}</h4>
                    <div class="footer_inner">
                        <ul>
                            @foreach ($footermenulist2 as $footer2key => $footer2value)
                            <li><a href="{{ $footer2value['link'] }}">{{ $footer2value['name'] }}</a></li>
                            @endforeach
                        </ul>
                    </div>
                    @endif
                </div>
                <div class="col-sm-12 col-md-3 ">

                    <h4>Newsletter</h4>
                    <div class="footer_inner">
                        <p class="color-light">
                            {{ getSetting('footer_newsletter_info') }}
                        </p>
                        <form  id="newslatterform" class="needs-validation" novalidate method="post" method="post">
                            <div class="position-relative">
                               <input type="email" name="customer_email" class="form-control email"
                                placeholder="{{ translation('ENTER_YOUR_EMAIL_HERE') }}" value="" required>
                               <button class="col-sm-12 " id="news_letter_subscribe" name="subscribe" type="submit">{{ translation('Send') }}</button>
                               <input type="reset" hidden id="configreset" value="Reset">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="row d-flex ">
                <div class="col-lg-4 d-flex">
                    <div class="media blue-bg">
                        <div class="icon-wrapper">
                            <i class="fa-solid fa-phone"></i>
                        </div>
                        <div class="media-body">
                            <a href=" tel:{{ getSetting('phone') }}">{{ getSetting('phone') }}</a>
                            <h6 class="mt-0 text-white">Give Us A Call</h6>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 d-flex">
                    <div class="media yellow-bg">
                        <div class="icon-wrapper blue-bg">
                            <i class="fa-regular fa-envelope text-white"></i>
                        </div>
                        <div class="media-body">
                            <h6 class="mt-0 text-white">{{ getSetting('contact_email')}}</h6>
                            <a href="mailto:{{ getSetting('contact_email')}}">Drop Us a Line</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 d-flex">
                    <div class="media blue-bg">
                        <div class="icon-wrapper">
                            <i class="fa-solid fa-location-dot"></i>
                        </div>
                        <div class="media-body">
                            <h6 class="mt-0 text-white">{{getSetting('contact_address')}}</h6> 
                            {{getSetting('contact_city')}},{{getSetting('contact_state')}},{{getSetting('contact_country')}} - {{getSetting('contact_zipcode')}}
                        </div>
                    </div>
                </div>
            </div>
            <hr>
            <div class="col-12">
                <div class="row color-light ">
                    <div class="col-lg-6">
                        {{-- Electrical Service & Installation Template --}}
                    </div>
                    <div class="col-lg-6 copyright">
                        <p class="mb-0 text-end">
                            {{ $copyRightText ?? '' }}
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--Footer End-->

    @push('scripts')
    <script>
        $(document).ready(function() {
            $(document).on('click', '#news_letter_subscribe', function(e) {
                e.preventDefault();
                $('#newslatterform').addClass('was-validated');
                if ($('#newslatterform')[0].checkValidity() === false) {
                    Notify('Please Enter Your Email', false);
                    event.stopPropagation();
                } else {
                    var data = {
                        'customer_email': $('.email').val(),
                    }
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        type: "POST",
                        url: "/newslatterstore",
                        data: data,
                        dataType: "json",
                        success: function(response) {
                            if (response.status == 400) {
                                console.log(response.error.customer_email);
                                Notify(response.error.customer_email, false);
                            } else {
                                $('.email').val(),
                                Notify('Subscribed Successfully', true);
                                $("#newslatterform").trigger("reset")
                            }
                        }

                    });
                }
            });
        });
    </script>
@endpush
    
