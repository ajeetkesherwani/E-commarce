    <!--Script Start-->
    <script src="https://kit.fontawesome.com/be06daa5b1.js" crossorigin="anonymous"></script>
    <script src="{{LoadAssets('assets/js/jquery.min.js')}}"></script>
    <script src="{{LoadAssets('assets/js/bootstrap.min.js')}}"></script>
    <script src="{{LoadAssets('assets/js/main.js')}}"></script>
    <script src="{{LoadAssets('assets/js/owl.carousel.js')}}"></script>
    <!-- toastify -->
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
    <!-- Date Picker Js-->
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js" ></script> 
    <!--Script End-->

    <script>
        function Notify(msg, status) {
        Toastify({
            text: msg,
            className: "info",
            duration: 2000,
            close: true,
            gravity: "bottom", // `top` or `bottom`
            position: "right", // `left`, `center` or `right`
            style: {
                background: status ? "green" : "red",
            }
        }).showToast();

    }

    // Custome Forms

$(".customFrom").on('submit', function(e) {
    e.preventDefault();
    $('.customFrom').addClass('was-validated');
    if ($('.customFrom')[0].checkValidity() === false) {
        event.stopPropagation();
    } else {

        let formData = $(this).serialize();

        /*Ajax Request Header setup*/
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
            url: "{{ route('customFormSubmit') }}",
            method: 'post',
            data: formData,

            beforeSend: function() {
                $(".customFrom :submit").addClass('disabled');
                $(".customFrom :submit").html('Submitting...');
            },

            success: function(response) {
                console.log(response);
                if (response.status == 0) {
                    $.each(response.message, function(i, v) {
                        console.log('#erro_' + i);
                        $('#' + i + '-error').html(v);
                    });
                } else {
                    // $('.result').append(response.message);
                    Notify('Data send successfully', true);
                    $('.customFrom').trigger("reset");
                }
            },

            complete: function() {
                $('.customFrom').removeClass('was-validated');
                $(".customFrom :submit").removeClass('disabled');
                $(".customFrom :submit").html('Submit');
            }
        });
    }
});

// Date Picker

$(document).ready(function() {
$(function() {
    $( ".my_date_picker" ).datepicker();
});
})

 // Add to cart

 function addToCart(lisiting_id,qty = 1, attributes_id = '') {
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

$.ajax({
    url: '{{ route('addUpdateToCart') }}',
    method: 'POST',
    data: {
        qty: qty,
        attributes_id: attributes_id,
        listing_id: lisiting_id,
    },
    success: function(response) {
        $('#cart_items').empty();
        $('.count-cart-total').html(response.total_count);
        Notify('Service Added To Cart !', true);
    },
    error: function(error) {
        Notify("Some Error In Add To Cart", false);
    }
});

}

</script>




@if(getsetting('newsletter_popup')=='yes')
@if(empty(Cache::get("loaditem")))
<script>
window.onload = function showNewsLatter() {
    $.ajax({
        url: "/onloadnewslatter",
        success: function (response) {
            $(".newsmodal").html(response);
            $('#onloadModal').modal('show');
        },
        error: function (error) {
            
        },
    });
}
</script>
@endif
@endif