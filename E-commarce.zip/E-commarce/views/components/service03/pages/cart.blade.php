@php

$main_arr = [
  'title'=>'Cart',
  'sublist' => [
    [
    'name'=>'HOME',
    'link'=>url("/")
    ],
    [
    'name'=>'cart' ,
    'link'=>url("")
    ], 
  ]
];
@endphp

<x-Service03.SharedComponent.BreadCrumb :data="$main_arr" /> 
<!-- Breadcrumb Area End -->

<div class="container mt-4">
    <div class="row" id="cart-table">
        @if (!empty($list['cart_list']) && sizeof($list['cart_list']) > 0)
        <div class="col-lg-8 col-md-8 col-sm-12">
            @foreach ($list['cart_list'] as $cart)
            <div class="card rounded-3 mb-4 cart-table_{{$cart->cart_id}}">
                <div class="card-body p-4">
                    <div class="row d-flex justify-content-between align-items-center">
                        <div class="col-md-2 col-lg-2 col-xl-2">
                            <a href="{{ url('services/' . $cart->listing->listing_slug) }}"><img src="{{getFullImageUrl($cart->listing->listing_image ?? '')}}"
                            onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                                class="img-fluid rounded-3" alt="{{$cart->listing->listing_name ?? ''}}"></a>
                        </div>
                        <div class="col-md-3 col-lg-3 col-xl-3">
                            <p class="lead fw-normal mb-2"><a href="{{ url('services/' . $cart->listing->listing_slug) }}">{{$cart->listing->listing_name ?? ''}}</a></p>
                            @if (isset($cart->attributes) && !empty($cart->attributes))
                            <p>
                                @foreach ($cart->attributes as $attribute)
                                @if (isset($attribute->product_options))
                                <span class="text-muted"> {{ $attribute->product_options->products_options_name }} : </span> {{ $attribute->products_options_values_name }}
                                @endif
                                @endforeach
                            </p>
                            @endif
                        </div>
                        <div class="col-md-3 col-lg-2 col-xl-2 offset-lg-1">
                            <h5 class="mb-0 prd_prc__{{$cart->cart_id}}">{{currencyFormat($cart->final_price ?? '')}}</h5>
                        </div>
                        <div class="col-md-1 col-lg-1 col-xl-1 text-end">
                            <a href="javascript:void(0)" onclick="actionOnCart({{$cart->cart_id}},'del')" class="text-danger"><i class="fas fa-trash fa-lg"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach

            <div class="card mb-4">
                <div class="card-body p-4 d-flex flex-row">
                    <div class="form-outline flex-fill">
                        <input type="text" id="form1" class="form-control form-control-lg" />
                        <label class="form-label" for="form1">Discound code</label>
                    </div>
                    <button type="button" class="btn btn-outline-warning btn-lg ms-3">Apply</button>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-8 col-sm-12">
            <div class="card mb-4">
                <div class="card-header py-3">
                    <h5 class="mb-0">Summary</h5>
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <li
                            class="list-group-item d-flex justify-content-between align-items-center border-0 px-0 pb-0">
                            Services Total
                            <span class="products_total">{{ currencyFormat($list['product_total'])}}</span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                            Shipping
                            <span>{{ currencyFormat($list['shipping'])}}</span>
                        </li>
                        <li
                            class="list-group-item d-flex justify-content-between align-items-center border-0 px-0 mb-3">
                            <div>
                                <strong>Total amount</strong>
                            </div>
                            <span><strong class="grandAmount">{{ currencyFormat($list['grand_total']) }}</strong></span>
                        </li>
                    </ul>
                    <a href="{{ url('checkout') }}" role="button" class="btn btn-primary btn-lg btn-block">
                        Go to checkout
                    </a>
                </div>
            </div>
        </div>
        @else
        <div class="col-lg-6 col-md-12 col-sm-12 mx-auto">
        <img src="{{ LoadAssets('assets/images/empty_cart.gif') }}" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" class="rounded mx-auto d-block" width="286px" height="250px"
        alt="{{ getSetting('site_title') }} Cart-Empty">
        <p class="h4 text-center text-dark mt-2">Your cart is empty !</p>
        <div class="text-center my-3">
        <a href="{{ url('/') }}" class="btn btn-primary btn-lg btn-block" role="button" aria-pressed="true">Continue to shop </a>
        </div>
        </div>
        @endif
    </div>
</div>


@push('scripts')

<script>
      function actionOnCart(cart_id, type) {
        if (type === 'del') {
            $('.cart-table_' + cart_id).hide();
        }
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url: '{{ route('incDecDelCart') }}',
            method: 'POST',
            data: {
                cart_id: cart_id,
                type: type,
            },
            success: function (response) {
                console.log(response.cart_response.cart_list)
                if (response.cart_response.total_count > 0) {
                    $(response.cart_response.cart_list).each(function (key, value) {
                        $('.products_total').text(response.cart_response.products_total);
                        $('.grandAmount').text(response.cart_response.grand_totals);
                        $('.count-cart-total').html(response.total_count);
                        if (cart_id == value.cart_id) {
                            $('.prd_prc__' + value.cart_id).text(value.fin_price);
                        }
                    });
                } else {
                    $('.count-cart-total').html(response.total_count);
                    var html = ` <div class="col-lg-6 col-md-12 col-sm-12 mx-auto">
                                <img src="{{ LoadAssets('assets/images/empty_cart.gif') }}" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" class="rounded mx-auto d-block" width="286px" height="250px"
                                alt="{{ getSetting('site_title') }} Cart-Empty">
                                <p class="h4 text-center text-dark mt-2">Your cart is empty !</p>
                                <div class="text-center my-3">
                                <a href="{{ url('/') }}" class="btn btn-primary btn-lg btn-block" role="button" aria-pressed="true">Continue to shop </a>
                                </div>
                                </div>`;
                    $('#cart-table').html(html);
                }
                var msg = type === 'del' ? 'Item Removed From Cart !' : 'Item Qty Updated To Cart !';
                Notify(msg, true);
            },
            error: function (error) {
                Notify('Not able to add', false);
            }
        });
    }
</script>
@endpush