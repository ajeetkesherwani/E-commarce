@php

$main_arr = [
  'title'=>'Blog Post',
  'sublist' => [
    [
    'name'=>'HOME',
    'link'=>url("/")
    ],
    [
    'name'=>$blogDetail->post_title ,
    'link'=>url("")
    ], 
  ]
];
$currentURL = URL::current();
$url_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$url_segments = explode('/', $url_path);
$url_segment=$url_segments[2]; 
@endphp


<x-Service03.SharedComponent.BreadCrumb :data="$main_arr" /> 

    
 <!-- Blog STart -->
        <section class="section"> 
            <div class="container">
                <div class="row">
                    <!-- BLog Start -->
                    <div class="col-lg-8 col-md-6">
                        <div class="card blog blog-detail border-0 shadow rounded">
                            <img src="{{getFullImageUrl($blogDetail->img)}}" alt="{{ $blogDetail->post_title ?? '' }}" class="img-fluid rounded-top" alt="">
                           
                            <div class="card-body content">
                                <h6><i class="mdi mdi-tag text-primary me-1"></i><a href="javscript:void(0)" class="text-primary">Software</a>, <a href="javscript:void(0)" class="text-primary">Application</a></h6>
                                 <span class="post__meta-date">{{ date("d M, Y",
                                        strtotime($blogDetail->created_at)) }}</span>
                                <p class="text-muted mt-3">  {{ $blogDetail->post_title ?? '' }} </p>
                                <blockquote class="blockquote mt-3 p-3">
                                    <p class="text-muted mb-0 fst-italic">{!! $blogDetail->post_content ?? '' !!}</p>
                                </blockquote>
                                
                                <div class="post-meta mt-3">
                                    <ul class="list-unstyled mb-0">
                                        <li class="list-inline-item me-2 mb-0"><a href="javascript:void(0)" class="text-muted like"><i class="uil uil-heart me-1"></i>33</a></li>
                                        <li class="list-inline-item"><a href="javascript:void(0)" class="text-muted comments"><i class="uil uil-comment me-1"></i>08</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        
                    </div>
                    <!-- BLog End -->

                    <!-- START SIDEBAR -->
                    <div class="col-lg-4 col-md-6 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0">
                        <div class="card border-0 sidebar sticky-bar ms-lg-4">
                            <div class="card-body p-0">                               
    
                                <!-- RECENT POST -->
                                <div class="widget mt-4">
                                    <span class="bg-light d-block py-2 rounded shadow text-center h6 mb-0">
                                        Recent Post
                                    </span>
                                  @if (!empty($recentPost))
                                    @foreach ($recentPost as $blog)
                                    <div class="mt-4">
                                        <div class="d-flex align-items-center">
                                            <img src="{{getFullImageUrl($blog->img)}}" class="avatar avatar-small rounded" style="width: auto;" alt="{{ $blog->post_title ?? '' }}">
                                            <div class="flex-1 ms-3">
                                                <a href="{{ url('blog/'.$blog->slug) }}" class="d-block title text-dark">{{ $blog->post_title ?? '' }}</a>
                                                <span class="text-muted">{{ date("F d, Y", strtotime($blog->created_at)) }}</span>
                                            </div>
                                        </div>                                        
                                    </div>
                                    @endforeach
                                  @endif 
                                </div>
                                <!-- RECENT POST -->
                                                                
                                
                            </div>
                        </div>
                    </div><!--end col-->
                    <!-- END SIDEBAR -->
                </div><!--end row-->
            </div><!--end container-->
        </section><!--end section-->
        <!-- Blog End -->

