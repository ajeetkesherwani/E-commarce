    <!-- Banner Start-->
    <section class="banner ">
        <div class="banner-overlay"></div>
        <div class="container">
            <div class="row">
                <div class="banner-content col-lg-6 bg-white">
                    <h1 class="animate__animated animate__fadeInRight">We Are Dedicated To Excellence In Electrical Work
                    </h1>
                    <p class="animate__animated animate__fadeInLeft">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua Ut enim ad minim
                    </p>
                    <div class="banner-button">
                        <div class="">
                            <a href="contact.html" class="btn">Contact Us</a>
                        </div>
                        <div>
                            <div class="btn btn-primary video-btn" data-bs-toggle="modal"
                                data-src="https://www.youtube.com/embed/Jfrjeg26Cwk" data-bs-target="#myModal">

                                <i class="fa-solid fa-play"></i>
                            </div>
                            <span class="button-text pl-3">Watch Video</span>
                        </div>

                        <!-- Modal -->
                        <div class="modal fade" id="myModal" tabindex="-1" role="dialog"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-body">
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></span>
                                        </button>
                                        <!-- 16:9 aspect ratio -->
                                        <div class="ratio ratio-16x9">
                                            <iframe class="embed-responsive-item" src="" id="video"
                                                allowscriptaccess="always" allow="autoplay"></iframe>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        </div>
    </section>
    <!--Banner End-->

    <!--AboutUs Start-->
    <section class="about py-60">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-6 position-relative ">
                    <div class="about-bg1 ">
                        <img src="assets/images/electrician.jpg" class="img-fluid" alt="about">

                    </div>
                    <div class="image-bg-wrapper">
                        <div class="about-bg">
                            <img src="assets/images/1.jpg" class="img-fluid" alt="about">

                        </div>

                        <div class="counter-box  animate__animated animate__fadeInUp">
                            <div class="d-flex justify-content-center">
                                <div class="counter" data-countto="20" data-duration="20">20</div>
                                <sup class="super">+</sup>
                            </div>
                            <div class="counter-title">
                                <p class="counter-title ">
                                    Years Of Experiences</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-12 col-md-12 col-lg-6">
                    <div class="row">
                        <div class="col-12 ps-5">
                            <div class="heading-layout2 ">
                                <div class="animate__animated animate__fadeInRight">
                                    <span class="heading__subtitle color__yellow  ">
                                        Welcome To Electriza</span>
                                </div>
                                <h3 class="heading__title">Best Electrical Solutions For Your Electrical Problems</h3>
                            </div><!-- /heading -->
                            <div class="about__Text">
                                <p>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                    incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
                                    exercitation ullamco laboris nisi
                                </p>

                                <div class="d-flex">
                                    <div class="col-lg-6 ">
                                        <div class="my-4">
                                            <div class="icon-wrapper">
                                                <i class="fa-regular fa-location-dot"></i>
                                            </div>
                                            <div class="media-body">
                                                <h4 class="pt-3 pb-1 ">Professional Team</h4>
                                                Lorem ipsum dolor sit amet, consecte adipiscing elit, sed do eiusmod
                                                tempor incididunt
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 ">
                                        <div class="my-4">
                                            <div class="icon-wrapper">
                                                <i class="fa-regular fa-location-dot"></i>
                                            </div>
                                            <div class="media-body">
                                                <h4 class="pt-3 pb-1 ">24/7 Availability</h4>
                                                Lorem ipsum dolor sit amet, consecte adipiscing elit, sed do eiusmod
                                                tempor incididunt
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="mt-3">
                                <a href="contact.html" class="btn">More About Us</a>
                            </div>
                        </div>


                    </div><!-- /.row -->
                </div><!-- /.col-xl-6 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </section>
    <!--AboutUs End-->

    <!--Services Section Start-->
    <section class="services my-10">
        <div class="container position-relative">
            <div class="row text-center ">
                <div class="col-lg-6 col-sm-12 mx-auto">
                    <span class="heading__subtitle text-white animate__animated animate__fadeInUp">Our Services</span>
                    <h3 class="heading__title text-white">What Service We Offer</h3>
                    <p class="text-white">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua.
                    </p>
                </div>

            </div>
            <div class="row justify-content-center  client_feature pt-5 animate__animated animate__fadeInRight">
                <div class="col-lg-4 col-md-4 col-12   ">
                    <div class="icon_wrapper  d-flex pt-2 pb-4">
                        <div class="icon text-center rounded-circle text-primary me-3 mt-2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" class="feather feather-monitor fea icon-ex-md">
                                <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                                <line x1="8" y1="21" x2="16" y2="21"></line>
                                <line x1="12" y1="17" x2="12" y2="21"></line>
                            </svg>
                        </div>
                        <div class="flex-1">
                            <h4 class="title text-white">Electrical Security</h4>
                            <p class=" mb-0 text-white">
                                Lorem ipsum dolor sit amet consect adipiscing elit, sed do eiusmod tempor incididunt ut
                                labore</p>
                            <a href="" class="icon-box-link">Read More<i aria-hidden="true"
                                    class="fas fa-arrow-right ms-1"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-12   ">
                    <div class=" icon_wrapper d-flex feature-primary pt-2 pb-4">
                        <div class="icon text-center rounded-circle text-primary me-3 mt-2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" class="feather feather-monitor fea icon-ex-md">
                                <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                                <line x1="8" y1="21" x2="16" y2="21"></line>
                                <line x1="12" y1="17" x2="12" y2="21"></line>
                            </svg>
                        </div>
                        <div class="flex-1">
                            <h4 class="title text-white">Electrical Security</h4>
                            <p class=" mb-0 text-white">
                                Lorem ipsum dolor sit amet consect adipiscing elit, sed do eiusmod tempor incididunt ut
                                labore</p>
                            <a href="" class="icon-box-link">Read More<i aria-hidden="true"
                                    class="fas fa-arrow-right ms-1"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-12   ">
                    <div class=" icon_wrapper d-flex feature-primary pt-2 pb-4">
                        <div class="icon text-center rounded-circle text-primary me-3 mt-2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" class="feather feather-monitor fea icon-ex-md">
                                <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                                <line x1="8" y1="21" x2="16" y2="21"></line>
                                <line x1="12" y1="17" x2="12" y2="21"></line>
                            </svg>
                        </div>
                        <div class="flex-1">
                            <h4 class="title text-white">Electrical Security</h4>
                            <p class=" mb-0 text-white">
                                Lorem ipsum dolor sit amet consect adipiscing elit, sed do eiusmod tempor incididunt ut
                                labore</p>
                            <a href="" class="icon-box-link">Read More<i aria-hidden="true"
                                    class="fas fa-arrow-right ms-1"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row animate__animated animate__fadeInLeft">
                <div class="col-lg-4 col-md-4 col-12   ">
                    <div class=" icon_wrapper  d-flex feature-primary pt-2 pb-4">
                        <div class="icon text-center rounded-circle text-primary me-3 mt-2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" class="feather feather-monitor fea icon-ex-md">
                                <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                                <line x1="8" y1="21" x2="16" y2="21"></line>
                                <line x1="12" y1="17" x2="12" y2="21"></line>
                            </svg>
                        </div>
                        <div class="flex-1">
                            <h4 class="title text-white">Electrical Security</h4>
                            <p class=" mb-0 text-white">
                                Lorem ipsum dolor sit amet consect adipiscing elit, sed do eiusmod tempor incididunt ut
                                labore</p>
                            <a href="" class="icon-box-link">Read More<i aria-hidden="true"
                                    class="fas fa-arrow-right ms-1"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-12   ">
                    <div class=" icon_wrapper  d-flex feature-primary pt-2 pb-4">
                        <div class="icon text-center rounded-circle text-primary me-3 mt-2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" class="feather feather-monitor fea icon-ex-md">
                                <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                                <line x1="8" y1="21" x2="16" y2="21"></line>
                                <line x1="12" y1="17" x2="12" y2="21"></line>
                            </svg>
                        </div>
                        <div class="flex-1">
                            <h4 class="title text-white">Electrical Security</h4>
                            <p class=" mb-0 text-white">
                                Lorem ipsum dolor sit amet consect adipiscing elit, sed do eiusmod tempor incididunt ut
                                labore</p>
                            <a href="" class="icon-box-link">Read More<i aria-hidden="true"
                                    class="fas fa-arrow-right ms-1"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-12   ">
                    <div class=" icon_wrapper d-flex  feature-primary pt-2 pb-4">
                        <div class="icon text-center rounded-circle text-primary me-3 mt-2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" class="feather feather-monitor fea icon-ex-md">
                                <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                                <line x1="8" y1="21" x2="16" y2="21"></line>
                                <line x1="12" y1="17" x2="12" y2="21"></line>
                            </svg>
                        </div>
                        <div class="flex-1">
                            <h4 class="title text-white">Electrical Security</h4>
                            <p class=" mb-0 text-white">
                                Lorem ipsum dolor sit amet consect adipiscing elit, sed do eiusmod tempor incididunt ut
                                labore</p>
                            <a href="" class="icon-box-link">Read More<i aria-hidden="true"
                                    class="fas fa-arrow-right ms-1"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    </section>
    <div class="clearfix"></div>
    <!-- Services Section End-->

    <!--Counter Start-->
    <section class=" counter-section ">
        <div class="container blue-bg py-5">
            <div class="row  text-white">
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class=" counter_wrapper">

                        <div>
                            <div class="d-flex justify-content-center">
                                <div class="counter" data-countto="1100" data-duration="1100">1,100</div>
                                <sup class="super">+</sup>
                            </div>
                            <div class="counter-title">
                                <p class="counter-title color-light">
                                    Happy Customer </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class=" counter_wrapper ">

                        <div>
                            <div class="d-flex justify-content-center">
                                <div class="counter" data-countto="1229" data-duration="1229">1,229</div>
                                <sup class="super">+</sup>
                            </div>
                            <div class="counter-title">
                                <p class="counter-title color-light">
                                    Projects Completed</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class=" counter_wrapper ">

                        <div>
                            <div class="d-flex justify-content-center">
                                <div class="counter" data-countto="1420" data-duration="1420">1,420</div>
                                <sup class="super">+</sup>
                            </div>
                            <div class="counter-title">
                                <p class="counter-title color-light">
                                    Satisfied Customers </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class=" counter_wrapper ">

                        <div>
                            <div class="d-flex justify-content-center">
                                <div class="counter" data-countto="1200" data-duration="1200">1,200</div>
                                <sup class="super">+</sup>
                            </div>
                            <div class="counter-title">
                                <p class="counter-title color-light">
                                    Professional Team</p>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!--counter End-->

    <!-- Plan and Pricing Start-->
    <section class="py-60">
        <div class="container ">
            <div class="row">
                <div class="col-lg-6 col-sm-12 ">
                    <div>
                        <span class="heading__subtitle animate__animated animate__fadeInLeft">
                            Pricing Plans</span>
                        <h3 class="heading__title ">Affordable Pricing Plans</h3>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                            labore et dolore magna aliqua.
                        </p>
                        <div class="mt-3">
                            <a href="contact.html" class="btn">View All Plans</a>
                        </div>
                    </div>

                </div>
                <div class="col-lg-6 col-sm-12">
                    <div class="card my-4 border-0">
                        <div class="card-content">
                            <div class="card-body p-0">
                                <div class="media d-flex">
                                    <div class="icon-box icon-box-body text-center">
                                        <h3 class="title color-accent">$45</h3>
                                        <p class="icon-box-description mb-0">Personal Plan</p>
                                        <div class="icon-box-button ">
                                            <a href="" class="icon-box-link">Get Started<i aria-hidden="true"
                                                    class="fas fa-arrow-right ms-1"></i></a>
                                        </div>
                                    </div>
                                    <div class="media-body">
                                        <ul class="list-items">
                                            <li>Free Diagnostics</li>
                                            <li>Replace & Installation</li>
                                            <li>Maintenance Service</li>
                                            <li>30 Day Warranty </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 col-sm-12">
                    <div class="card my-4 border-0">
                        <div class="card-content">
                            <div class="card-body p-0">
                                <div class="media d-flex">
                                    <div class="icon-box icon-box-body text-center">
                                        <h3 class="title color-accent">$45</h3>
                                        <p class="icon-box-description mb-0">Personal Plan</p>
                                        <div class="icon-box-button ">
                                            <a href="" class="icon-box-link">Get Started<i aria-hidden="true"
                                                    class="fas fa-arrow-right ms-1"></i></a>
                                        </div>
                                    </div>
                                    <div class="media-body">
                                        <ul class="list-items">
                                            <li>Free Diagnostics</li>
                                            <li>Replace & Installation</li>
                                            <li>Maintenance Service</li>
                                            <li>30 Day Warranty </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-sm-12">
                    <div class="card my-4 border-0">
                        <div class="card-content">
                            <div class="card-body p-0">
                                <div class="media d-flex">
                                    <div class="icon-box icon-box-body text-center">
                                        <h3 class="title color-accent">$45</h3>
                                        <p class="icon-box-description mb-0">Personal Plan</p>
                                        <div class="icon-box-button ">
                                            <a href="" class="icon-box-link">Get Started<i aria-hidden="true"
                                                    class="fas fa-arrow-right ms-1"></i></a>
                                        </div>
                                    </div>
                                    <div class="media-body">
                                        <ul class="list-items">
                                            <li>Free Diagnostics</li>
                                            <li>Replace & Installation</li>
                                            <li>Maintenance Service</li>
                                            <li>30 Day Warranty </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <!--Plan and Pricing end-->

    <!-- Specialization section start-->
    <section class="specialize-section  my-50">
        <div class="container position-relative">
            <div class="row">
                <div class="col-lg-12 col-sm-12 ">
                    <div class="row">
                        <div class="col-lg-6">
                            <h3 class="heading__title text-white mt-0 animate__animated animate__fadeInLeft">We
                                Specialize in All Types of Electrical Repairs For Your Home</h3>
                        </div>
                        <div class="col-lg-6">
                            <p class="text-white">
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
                                exercitation ullamco laboris nisi
                            </p>
                        </div>
                    </div>


                </div>
            </div>
            <div class="row">
                <div class="col-lg-6">
                    <div class="row">
                        <div class="col-lg-6 col-sm-12">
                            <div class="icon_wrapper  pt-2 pb-4">
                                <div class="icon text-center rounded-circle text-primary me-3 mt-2">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                        fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                        stroke-linejoin="round" class="feather feather-monitor fea icon-ex-md">
                                        <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                                        <line x1="8" y1="21" x2="16" y2="21"></line>
                                        <line x1="12" y1="17" x2="12" y2="21"></line>
                                    </svg>
                                </div>
                                <div class="">
                                    <h4 class="title text-white my-3">Certified Team</h4>
                                    <p class=" mb-0 text-white">
                                        Lorem ipsum dolor sit amet consect adipiscing elit, sed do eiusmod tempor
                                        incididunt ut labore</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-12">
                            <div class="icon_wrapper  pt-2 pb-4">
                                <div class="icon text-center rounded-circle text-primary me-3 mt-2">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                        fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                        stroke-linejoin="round" class="feather feather-monitor fea icon-ex-md">
                                        <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                                        <line x1="8" y1="21" x2="16" y2="21"></line>
                                        <line x1="12" y1="17" x2="12" y2="21"></line>
                                    </svg>
                                </div>
                                <div class="">
                                    <h4 class="title text-white my-3">Modern Technology
                                    </h4>
                                    <p class=" mb-0 text-white">
                                        Lorem ipsum dolor sit amet consect adipiscing elit, sed do eiusmod tempor
                                        incididunt ut labore</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-12">
                            <div class="icon_wrapper  pt-2 pb-4">
                                <div class="icon text-center rounded-circle text-primary me-3 mt-2">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                        fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                        stroke-linejoin="round" class="feather feather-monitor fea icon-ex-md">
                                        <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                                        <line x1="8" y1="21" x2="16" y2="21"></line>
                                        <line x1="12" y1="17" x2="12" y2="21"></line>
                                    </svg>
                                </div>
                                <div class="">
                                    <h4 class="title text-white my-3">Modern Technology
                                    </h4>
                                    <p class=" mb-0 text-white">
                                        Lorem ipsum dolor sit amet consect adipiscing elit, sed do eiusmod tempor
                                        incididunt ut labore</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-12">
                            <div class="icon_wrapper  pt-2 pb-4">
                                <div class="icon text-center rounded-circle text-primary me-3 mt-2">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                        fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                        stroke-linejoin="round" class="feather feather-monitor fea icon-ex-md">
                                        <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                                        <line x1="8" y1="21" x2="16" y2="21"></line>
                                        <line x1="12" y1="17" x2="12" y2="21"></line>
                                    </svg>
                                </div>
                                <div class="">
                                    <h4 class="title text-white my-3">Modern Technology
                                    </h4>
                                    <p class=" mb-0 text-white">
                                        Lorem ipsum dolor sit amet consect adipiscing elit, sed do eiusmod tempor
                                        incididunt ut labore</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6"></div>
                <div class="col-lg-6 col-sm-12 specialize-wrapper ">

                    <div class="">
                        <div class="btn btn-primary video-btn" data-bs-toggle="modal"
                            data-src="https://www.youtube.com/embed/Jfrjeg26Cwk" data-bs-target="#myModal">

                            <i class="fa-solid fa-play"></i>
                        </div>

                    </div>

                    <!-- Modal -->
                    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">


                                <div class="modal-body">
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close">X</span>
                                    </button>
                                    <!-- 16:9 aspect ratio -->
                                    <div class="ratio ratio-16x9">
                                        <iframe class="embed-responsive-item" src="" id="video"
                                            allowscriptaccess="always" allow="autoplay"></iframe>
                                    </div>


                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>
    <!-- Specialization section End-->

    <!-- Our project Start -->
    <section class="py-60">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-4 col-sm-12 ">
                    <div class="animate__animated animate__fadeInLeft">
                        <span class="heading__subtitle ">
                            Our Projects</span>
                    </div>
                    <h3 class="heading__title ">Project We Have Done</h3>
                </div>
                <div class="col-lg-6">
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua.
                    </p>
                </div>
                <div class="col-lg-2 col-sm-12">
                    <div>
                        <a href="contact.html" class="btn">View All Plans</a>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12 col-md-6 col-lg-6 mt-4">
                    <div class="product-item">
                        <div class="product__img">
                            <img src="assets/images/electrician1.jpg" alt="Project" class="img-fluid">
                        </div><!-- /.col-lg-3 -->


                    </div><!-- /.row -->
                    <div class="service_content_cover">
                        <div class="service_content text-center">
                            <h5 class="service_title "><a href="" class="text-white">Electrical Security</a></h5>
                            <div class="service_content_desc">
                                <p class=" mb-0 text-white">
                                    Lorem ipsum dolor sit amet consect adipiscing elit, sed do eiusmod tempor incididunt
                                    ut labore</p>
                                <a href="" class="icon-box-link">Read More<i aria-hidden="true"
                                        class="fas fa-arrow-right ms-1"></i></a>

                            </div>
                        </div>
                    </div><!-- /.product-item -->
                </div>
                <div class="col-sm-12 col-md-6 col-lg-6 mt-4">
                    <div class="product-item">
                        <div class="product__img">
                            <img src="assets/images/electrician1.jpg" alt="Project" class="img-fluid">
                        </div><!-- /.col-lg-3 -->


                    </div><!-- /.row -->
                    <div class="service_content_cover">
                        <div class="service_content text-center">
                            <h5 class="service_title "><a href="" class="text-white">Electrical Security</a></h5>
                            <div class="service_content_desc">
                                <p class=" mb-0 text-white">
                                    Lorem ipsum dolor sit amet consect adipiscing elit, sed do eiusmod tempor incididunt
                                    ut labore</p>
                                <a href="" class="icon-box-link">Read More<i aria-hidden="true"
                                        class="fas fa-arrow-right ms-1"></i></a>

                            </div>
                        </div>
                    </div><!-- /.product-item -->
                </div>
                <div class="col-sm-12 col-md-4 col-lg-4 mt-4">
                    <div class="product-item">
                        <div class="product__img">
                            <img src="assets/images/electrician1.jpg" alt="Project" class="img-fluid">
                        </div><!-- /.col-lg-3 -->


                    </div>
                    <div class="service_content_cover">
                        <div class="service_content text-center">
                            <h5 class="service_title "><a href="" class="text-white">Electrical Security</a></h5>
                            <div class="service_content_desc">
                                <p class=" mb-0 text-white">
                                    Lorem ipsum dolor sit amet consect adipiscing elit, sed do eiusmod tempor incididunt
                                    ut labore</p>
                                <a href="" class="icon-box-link">Read More<i aria-hidden="true"
                                        class="fas fa-arrow-right ms-1"></i></a>

                            </div>
                        </div>
                    </div><!-- /.product-item -->
                </div>
                <div class="col-sm-12 col-md-4 col-lg-4 mt-4">
                    <div class="product-item">
                        <div class="product__img">
                            <img src="assets/images/electrician1.jpg" alt="Project" class="img-fluid">
                        </div><!-- /.col-lg-3 -->


                    </div><!-- /.row -->
                    <div class="service_content_cover">
                        <div class="service_content text-center">
                            <h5 class="service_title "><a href="" class="text-white">Electrical Security</a></h5>
                            <div class="service_content_desc">
                                <p class=" mb-0 text-white">
                                    Lorem ipsum dolor sit amet consect adipiscing elit, sed do eiusmod tempor incididunt
                                    ut labore</p>
                                <a href="" class="icon-box-link">Read More<i aria-hidden="true"
                                        class="fas fa-arrow-right ms-1"></i></a>

                            </div>
                        </div>
                    </div><!-- /.product-item -->
                </div>
                <div class="col-sm-12 col-md-4 col-lg-4 mt-4">
                    <div class="product-item">
                        <div class="product__img">
                            <img src="assets/images/electrician1.jpg" alt="Project" class="img-fluid">
                        </div><!-- /.col-lg-3 -->


                    </div><!-- /.row -->
                    <div class="service_content_cover">
                        <div class="service_content text-center">
                            <h5 class="service_title "><a href="" class="text-white">Electrical Security</a></h5>
                            <div class="service_content_desc">
                                <p class=" mb-0 text-white">
                                    Lorem ipsum dolor sit amet consect adipiscing elit, sed do eiusmod tempor incididunt
                                    ut labore</p>
                                <a href="" class="icon-box-link">Read More<i aria-hidden="true"
                                        class="fas fa-arrow-right ms-1"></i></a>

                            </div>
                        </div>
                    </div><!-- /.product-item -->
                </div>
            </div>

        </div>
    </section>
    <!-- Our project End -->

    <!--Testimonial Start-->
    <section class="testimonial my-50">
        <div class="container-fluid testimonial-content">
            <div class="container ">
                <div class="row">
                    <div class="col-lg-6 col-sm-12  animate__animated animate__fadeInLeft">
                        <div>
                            <div class="">
                                <span class="heading__subtitle text-white">
                                    Testimonials</span>
                            </div>
                            <h3 class="heading__title text-white">We Are Trusted Over 12+ Countries Worldwide</h3>
                            <p class="text-white">
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusm tempor incididunt
                                ut labore et dolore magna aliqua </p>

                        </div>

                    </div>
                    <div class="col-lg-5 col-sm-12 offset-lg-1">
                        <div class="row mt-4">
                            <div class="contain">
                                <div id="owl-carousel" class="owl-carousel owl-theme">
                                    <div class="item ">
                                        <p>
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                                            tempor incididunt ut labore et dolore
                                            magna aliqua Ut enim ad minim veniam
                                        </p>
                                        <div class="comment-details d-flex justify-content-between">
                                            <div class="d-flex gap-2 mt-3">
                                                <div class="profile-image"><img
                                                        src="https://templatekit.jegtheme.com/electriza/wp-content/uploads/sites/112/2021/06/testimonial-N8572T7.jpg"
                                                        alt="Jardel Rayner" class="img-fluid"></div>
                                                <span class="profile-info">
                                                    <strong class="profile-name">Jardel Rayner</strong>
                                                    <p class="profile-des">Businessman</p>
                                                </span>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="item ">
                                        <p>
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                                            tempor incididunt ut labore et dolore
                                            magna aliqua Ut enim ad minim veniam
                                        </p>
                                        <div class="comment-details d-flex justify-content-between">
                                            <div class="d-flex gap-2 mt-3">
                                                <div class="profile-image"><img
                                                        src="https://templatekit.jegtheme.com/electriza/wp-content/uploads/sites/112/2021/06/testimonial-N8572T7.jpg"
                                                        alt="Jardel Rayner" class="img-fluid"></div>
                                                <span class="profile-info">
                                                    <strong class="profile-name">Jardel Rayner</strong>
                                                    <p class="profile-des">Businessman</p>
                                                </span>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="item ">
                                        <p>
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                                            tempor incididunt ut labore et dolore
                                            magna aliqua Ut enim ad minim veniam
                                        </p>
                                        <div class="comment-details d-flex justify-content-between">
                                            <div class="d-flex gap-2 mt-3">
                                                <div class="profile-image"><img
                                                        src="https://templatekit.jegtheme.com/electriza/wp-content/uploads/sites/112/2021/06/testimonial-N8572T7.jpg"
                                                        alt="Jardel Rayner" class="img-fluid"></div>
                                                <span class="profile-info">
                                                    <strong class="profile-name">Jardel Rayner</strong>
                                                    <p class="profile-des">Businessman</p>
                                                </span>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="item ">
                                        <p>
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                                            tempor incididunt ut labore et dolore
                                            magna aliqua Ut enim ad minim veniam
                                        </p>
                                        <div class="comment-details d-flex justify-content-between">
                                            <div class="d-flex gap-2 mt-3">
                                                <div class="profile-image"><img
                                                        src="https://templatekit.jegtheme.com/electriza/wp-content/uploads/sites/112/2021/06/testimonial-N8572T7.jpg"
                                                        alt="Jardel Rayner" class="img-fluid"></div>
                                                <span class="profile-info">
                                                    <strong class="profile-name">Jardel Rayner</strong>
                                                    <p class="profile-des">Businessman</p>
                                                </span>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Testimonial End-->

    <!--Blog Start-->
    <section class="py-60 blog">
        <div class="container">
            <div class="row text-center ">
                <div class="col-lg-6 col-sm-12 mx-auto">
                    <div class=" animate__animated animate__fadeInUp">
                        <span class="heading__subtitle ">
                            Our Blog</span>
                    </div>

                    <h3 class="heading__title ">Latest Blog & Articles</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua
                    </p>
                </div>

            </div>
            <div class="row animate__animated animate__fadeInUp">
                <div class="col-lg-6 col-sm-12">
                    <div class=" mt-4 border-0">
                        <div class="card-content">
                            <div class="card-body p-0">
                                <div class="media d-flex gap-6">
                                    <div class=" w-100 text-center">
                                        <img src="assets/images/blog1.jpg" class="img-fluid" alt="">
                                    </div>
                                    <div class="media-body">
                                        <div class="">
                                            <h5 class="title">How to Get Electricity to a Kitchen Island</h5>
                                            <span><i class="fa-solid fa-clock"></i> June 25, 2021</span>
                                            <p class=" mb-0 mt-2">
                                                Lorem ipsum dolor sit amet consect adipiscing elit, sed do eiusmod
                                                tempor incididunt ut labore</p>
                                            <a href="" class="icon-box-link">Read More<i aria-hidden="true"
                                                    class="fas fa-arrow-right ms-1"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 col-sm-12">
                    <div class=" mt-4 border-0">
                        <div class="card-content">
                            <div class="card-body p-0">
                                <div class="media d-flex gap-6">
                                    <div class=" w-100 text-center">
                                        <img src="assets/images/blog1.jpg" class="img-fluid" alt="">
                                    </div>
                                    <div class="media-body">
                                        <div class="">
                                            <h5 class="title">How to Get Electricity to a Kitchen Island</h5>
                                            <span><i class="fa-solid fa-clock"></i> June 25, 2021</span>
                                            <p class=" mb-0 mt-2">
                                                Lorem ipsum dolor sit amet consect adipiscing elit, sed do eiusmod
                                                tempor incididunt ut labore</p>
                                            <a href="" class="icon-box-link">Read More<i aria-hidden="true"
                                                    class="fas fa-arrow-right ms-1"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-6 col-sm-12">
                    <div class=" mt-4 border-0">
                        <div class="card-content">
                            <div class="card-body p-0">
                                <div class="media d-flex gap-6">
                                    <div class=" w-100 text-center">
                                        <img src="assets/images/blog1.jpg" class="img-fluid" alt="">
                                    </div>
                                    <div class="media-body">
                                        <div class="">
                                            <h5 class="title">How to Get Electricity to a Kitchen Island</h5>
                                            <span><i class="fa-solid fa-clock"></i> June 25, 2021</span>
                                            <p class=" mb-0 mt-2">
                                                Lorem ipsum dolor sit amet consect adipiscing elit, sed do eiusmod
                                                tempor incididunt ut labore</p>
                                            <a href="" class="icon-box-link">Read More<i aria-hidden="true"
                                                    class="fas fa-arrow-right ms-1"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-sm-12">
                    <div class=" mt-4 border-0">
                        <div class="card-content">
                            <div class="card-body p-0">
                                <div class="media d-flex gap-6">
                                    <div class=" w-100 text-center">
                                        <img src="assets/images/blog1.jpg" class="img-fluid" alt="">
                                    </div>
                                    <div class="media-body">
                                        <div class="">
                                            <h5 class="title">How to Get Electricity to a Kitchen Island</h5>
                                            <span><i class="fa-solid fa-clock"></i> June 25, 2021</span>
                                            <p class=" mb-0 mt-2">
                                                Lorem ipsum dolor sit amet consect adipiscing elit, sed do eiusmod
                                                tempor incididunt ut labore</p>
                                            <a href="" class="icon-box-link">Read More<i aria-hidden="true"
                                                    class="fas fa-arrow-right ms-1"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>


    </section>
    <!--Blog End-->