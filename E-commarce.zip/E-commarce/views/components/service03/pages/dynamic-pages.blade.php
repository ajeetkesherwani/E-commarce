@php
$main_arr = [
  'title'=>$PageData->pages_title,
  'sublist' => [
    [
    'name'=>'HOME',
    'link'=>url("/")
    ],
    [
    'name'=>$PageData->pages_title,
    'link'=> URL::current(),
    ], 
  ]
];

@endphp

@push('styles')
<style>
.error{
  color:red;
  display:block !important;
}
</style>
@endpush


<!-- Breadcrumb Area start -->
<x-Service03.SharedComponent.BreadCrumb :data="$main_arr" />
<!-- Breadcrumb Area End -->

<!-- Content Start Here-->
{!!$PageData->pages_content!!}
<!-- Content End Here-->
