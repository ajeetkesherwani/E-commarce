    <!-- Banner -->
    <section class="services-banner">
        <div class="container position-relative">
          <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12 ">
                <div class="banner_content">
                    <h2 class="banner_title text-white">Service</h2>
                   <div class="">
                    <div aria-label="breadcrumb">
                        <ol class="breadcrumb">
                          <li class="breadcrumb-item"><a href="#">Home</a></li>
                          <li class="breadcrumb-item active" aria-current="page">Services</li>
                        </ol>
                    </div>
                   </div>
                    <p></p>
                  </div>
    
            </div>
          </div><!-- /.row -->
        </div><!-- /.container -->
    </section>
    <section class=" py-60">
        <div class="container">
          <div class="row text-center ">
            <div class="col-lg-6 col-sm-12 mx-auto">
                <span class="heading__subtitle">Our Services</span>
                <h3 class="heading__title ">What Service We Offer</h3>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                </p>
              </div>
            
          </div>
          <div class="row justify-content-center  client_feature pt-5">
            <div class="col-lg-4 col-md-4 col-12   ">
                <div class="icon_wrapper  d-flex pt-2 pb-4">
                    <div class="icon text-center rounded-circle text-primary me-3 mt-2">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-monitor fea icon-ex-md"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg>
                    </div>
                    <div>
                        <h4 class="title">Electrical Security</h4>
                        <p class=" mb-0 ">
                            Lorem ipsum dolor sit amet consect adipiscing elit, sed do eiusmod tempor incididunt ut labore</p>
                            <a href="" class="icon-box-link">Read More<i aria-hidden="true" class="fas fa-arrow-right ml-2"></i></a>
                        </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-12   ">
                <div class=" icon_wrapper d-flex feature-primary pt-2 pb-4">
                    <div class="icon text-center rounded-circle text-primary me-3 mt-2">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-monitor fea icon-ex-md"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg>
                    </div>
                    <div>
                        <h4 class="title">Electrical Security</h4>
                        <p class=" mb-0 ">
                            Lorem ipsum dolor sit amet consect adipiscing elit, sed do eiusmod tempor incididunt ut labore</p>
                            <a href="" class="icon-box-link">Read More<i aria-hidden="true" class="fas fa-arrow-right ml-2"></i></a>
                        </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-12   ">
                <div class=" icon_wrapper d-flex feature-primary pt-2 pb-4">
                    <div class="icon text-center rounded-circle text-primary me-3 mt-2">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-monitor fea icon-ex-md"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg>
                    </div>
                    <div class="flex-1">
                        <h4 class="title ">Electrical Security</h4>
                        <p class=" mb-0 ">
                            Lorem ipsum dolor sit amet consect adipiscing elit, sed do eiusmod tempor incididunt ut labore</p>
                            <a href="" class="icon-box-link">Read More<i aria-hidden="true" class="fas fa-arrow-right ml-2"></i></a>
                        </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-12   ">
                <div class=" icon_wrapper  d-flex feature-primary pt-2 pb-4">
                    <div class="icon text-center rounded-circle text-primary me-3 mt-2">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-monitor fea icon-ex-md"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg>
                    </div>
                    <div class="flex-1">
                        <h4 class="title">Electrical Security</h4>
                        <p class=" mb-0">
                            Lorem ipsum dolor sit amet consect adipiscing elit, sed do eiusmod tempor incididunt ut labore</p>
                            <a href="" class="icon-box-link">Read More<i aria-hidden="true" class="fas fa-arrow-right ml-2"></i></a>
                        </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-12   ">
                <div class=" icon_wrapper  d-flex feature-primary pt-2 pb-4">
                    <div class="icon text-center rounded-circle text-primary me-3 mt-2">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-monitor fea icon-ex-md"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg>
                    </div>
                    <div class="flex-1">
                        <h4 class="title">Electrical Security</h4>
                        <p class=" mb-0">
                            Lorem ipsum dolor sit amet consect adipiscing elit, sed do eiusmod tempor incididunt ut labore</p>
                            <a href="" class="icon-box-link">Read More<i aria-hidden="true" class="fas fa-arrow-right ml-2"></i></a>
                        </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-12   ">
                <div class=" icon_wrapper d-flex  feature-primary pt-2 pb-4">
                    <div class="icon text-center rounded-circle text-primary me-3 mt-2">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-monitor fea icon-ex-md"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg>
                    </div>
                    <div class="flex-1">
                        <h4 class="title">Electrical Security</h4>
                        <p class=" mb-0">
                            Lorem ipsum dolor sit amet consect adipiscing elit, sed do eiusmod tempor incididunt ut labore</p>
                            <a href="" class="icon-box-link">Read More<i aria-hidden="true" class="fas fa-arrow-right ml-2"></i></a>
                        </div>
                </div>
            </div>
    
            
           
            <!--end col-->
    
        </div>
        </div>
      
    
    </section>
    <section class="services appointment-wrapper">
        <div class="container position-relative">
          <div class="row text-center">
            <div class="col-lg-12 col-sm-12">
                <span class="heading__subtitle text-white">
                    Make Appointment</span>
                <h3 class="heading__title text-white">Best Electrical Solutions For Your Electrical Problems</h3>
               <div class="row">
                <div class="col-lg-6 col-sm-12  mx-auto">
                    <p class="text-white">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    </p>
                </div>
               </div>
              </div>
    
            
          </div>
        </div>
    </section>
    <section class="appointment-wrapper-form">
        <div class="container">
         <div class="row  ">
             <div class="col-lg-5 col-sm-12 appointment-section">
                 <div class="address-section pb-4">
                     <h5 class="heading-title text-white ">Our Location </h5>
                     <ul>
                         <li class="icon-list-item">
                             <span class="list-icon">
                                 <i class="fa-regular fa-location-dot"></i> </span>
                             <span class="icon-list-text text-white">Jl. Sunset Road No.815, Kuta - 80361</span>
                         </li>
                         <li class="icon-list-item">
                             <span class="list-icon">
                                 <i class="fa-regular fa-location-dot"></i> </span>
                             <span class="icon-list-text text-white">Jl. Sunset Road No.815, Kuta - 80361</span>
                         </li>
                        
                       </ul>
                 </div>
                 <div class="support-section ">
                     <h5 class="heading-title text-white ">Our Support </h5>
                     <ul>
                         <li class="icon-list-item">
                             <span class="list-icon">
                                 <i class="fa-regular fa-location-dot"></i> </span>
                             <span class="icon-list-text text-white">Jl. Sunset Road No.815, Kuta - 80361</span>
                         </li>
                         <li class="icon-list-item">
                             <span class="list-icon">
                                 <i class="fa-regular fa-location-dot"></i> </span>
                             <span class="icon-list-text text-white">Jl. Sunset Road No.815, Kuta - 80361</span>
                         </li>
                        
                       </ul>
                 </div>
                 <div class="spacer-inner"></div>
                 <div>
                     <h6 class="heading-title text-white">We Will Get Back To You Within 24 Hours Or Call Us Everyday, 09.00 AM - 23.00 PM
         </h6>	
         <div class="phone-appointment mt-4">
             <div class="icon-wrapper">
                 <i class="fa-sharp fa-solid fa-phone-volume" style="line-height: 1;"></i>
             </div>
             <div class="box-body">
                 <p class="text-white mb-0">(+62)81 157 2241</p>
                 <div> Call Us for your electrical problems </div>
             </div>
         </div>
     </div>
             </div>
             <div class="col-lg-7 col-sm-12 bg-white form-wrapper">
                 <form class="contact-panel_form" method="" action="" id="appointmentcontactForm">
                     <div class="row">
                       <div class="col-sm-12 col-md-12 col-lg-6">
                         <div class="form-group">
                           <input type="text" class="form-control" placeholder="Name" id="contact-name" name="contact-name" required="" aria-required="true">
                         </div>
                       </div><!-- /.col-lg-6 -->
                       <div class="col-sm-12 col-md-12 col-lg-6">
                         <div class="form-group">
                           <input type="email" class="form-control" placeholder="Email Address" id="contact-email" name="contact-email" required="" aria-required="true">
                         </div>
                       </div><!-- /.col-lg-6 -->
                       <div class="col-sm-12 col-md-12 col-lg-6">
                         <div class="form-group">
                           <input type="text" class="form-control" placeholder="Your Phone" id="phone" name="phone" required="" aria-required="true">
                         </div>
                       </div><!-- /.col-lg-6 -->
                       <div class="col-sm-12 col-md-12 col-lg-6">
                         <div class="form-group">
                              <div class="input-group date" id="datepicker">
                                <span class="input-group-append">
                                     <input type="" class="form-control" id="date" placeholder="dd-mm-yyyy">
                                  <span class="input-group-text border-0 d-block bg-white" style="
                                        position: absolute;
                                        right: 3px;
                                        top: 2px;
                                        padding: 14px;
                                    ">
                                    <i class="fa fa-calendar" aria-hidden="true"></i>
                                  </span>
                                </span>
                              </div>
                                
                         </div>
                       </div><!-- /.col-lg-6 -->
                       <div class="col-lg-12 col-sm-12 col-md-12 ">
                         <div class="form-group">
                              <select class="form-control">
                                 <option value="">Select your option</option>
                                 <option value="volvo">Volvo</option>
                                 <option value="saab">Saab</option>
                                 <option value="opel">Opel</option>
                                 <option value="audi">Audi</option>
                         </select>
                         </div>
                       </div>
                       <div class="col-lg-12 col-sm-12 col-md-12 ">
                         <div class="form-group">
                           <textarea class="form-control" placeholder="Your Message" id="message" name="message"></textarea>
                         </div>
                       </div>
                       <div class="col-lg-6 col-sm-12">
                         <button type="submit" class="btn">
                           <span>Make Appointment </span>
                         </button>
                         <div class="contact-result"></div>
                       </div><!-- /.col-lg-12 -->
                     </div><!-- /.row -->
                   </form>
             </div>
           </div>
        </div>
     </section>
     <section class="py-60">
        <div class="container">
          <div class="row text-center">
            <div class="col-lg-12 col-sm-12">
                <span class="heading__subtitle ">
                    Our Process</span>
                <h3 class="heading__title ">How We Works</h3>
               <div class="row">
                <div class="col-lg-6 col-sm-12  mx-auto">
                    <p class="">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    </p>
                </div>
               </div>
              </div>
    
            
          </div>
          <div class="row process-section pt-4">
            <div class="col-lg-4 col-sm-12 text-center">
                <div class="">
                    <div class="image">
                        <div class="image-container">
                            <img src="https://templatekit.jegtheme.com/electriza/wp-content/uploads/sites/112/2021/06/writing-down-complaints-e1624860268897.jpg" class="img-fluid" alt="">
                        </div>
                    </div>
                    <div class="icon-box-wrapper text-center">
                        <div class="icon-box">
                            <h2 class="title">01</h2>
                        </div>
                    </div>
                    <div class="text-center">
                        <h4 class="title">Make an Appointment</h4>
                        <p class="">Lorem ipsum dolor sit amet, consec adipiscing elit, sed do
                            eiusmod tempor incididunt ut labore et dolore magna aliqua</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-sm-12 text-center">
                <div class="">
                    <div class="image">
                        <div class="image-container">
                            <img src="https://templatekit.jegtheme.com/electriza/wp-content/uploads/sites/112/2021/06/writing-down-complaints-e1624860268897.jpg" class="img-fluid" alt="">
                        </div>
                    </div>
                    <div class="icon-box-wrapper text-center">
                        <div class="icon-box">
                            <h2 class="title">01</h2>
                        </div>
                    </div>
                    <div class="text-center">
                        <h4 class="title">Electrician At Work</h4>
                        <p class="">Lorem ipsum dolor sit amet, consec adipiscing elit, sed do
                            eiusmod tempor incididunt ut labore et dolore magna aliqua</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-sm-12 text-center">
                <div class="">
                    <div class="image">
                        <div class="image-container">
                            <img src="https://templatekit.jegtheme.com/electriza/wp-content/uploads/sites/112/2021/06/writing-down-complaints-e1624860268897.jpg" class="img-fluid" alt="">
                        </div>
                    </div>
                    <div class="icon-box-wrapper text-center">
                        <div class="icon-box">
                            <h2 class="title">01</h2>
                        </div>
                    </div>
                    <div class="text-center">
                        <h4 class="title">Your Problem Solved</h4>
                        <p class="">Lorem ipsum dolor sit amet, consec adipiscing elit, sed do
                            eiusmod tempor incididunt ut labore et dolore magna aliqua</p>
                    </div>
                </div>
            </div>
          </div>
        </div>
    </section>
    <section class="testimonial my-50">
        <div class="container-fluid testimonial-content">
         <div class="container ">
             <div class="row">
                 <div class="col-lg-6 col-sm-12  animate__animated animate__fadeInLeft">
                     <div>
                         <div class="">
                             <span class="heading__subtitle text-white">
                                 Testimonials</span>
                         </div>
                         <h3 class="heading__title text-white">We Are Trusted Over 12+ Countries Worldwide</h3>
                         <p class="text-white">
                             Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusm tempor incididunt ut labore et dolore magna aliqua                        </p>
                         
                     </div>
                    
                   </div>
                   <div class="col-lg-5 col-sm-12 offset-lg-1">
                     <div class="row mt-4">
                         <div class="contain">
                             <div id="owl-carousel" class="owl-carousel owl-theme">
                             <div class="item ">
                                 <p>
                                     Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
                                     magna aliqua Ut enim ad minim veniam
                                 </p>
                                     <div class="comment-details d-flex justify-content-between">
                                         <div class="d-flex gap-2 mt-3">
                                             <div class="profile-image"><img
                                                 src="https://templatekit.jegtheme.com/electriza/wp-content/uploads/sites/112/2021/06/testimonial-N8572T7.jpg"
                                                 alt="Jardel Rayner" class="img-fluid"></div>
                                         <span class="profile-info">
                                             <strong class="profile-name">Jardel Rayner</strong>
                                             <p class="profile-des">Businessman</p>
                                         </span>
                                         </div>
                                         
                                     </div>
                             </div>
                             <div class="item ">
                                 <p>
                                     Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
                                     magna aliqua Ut enim ad minim veniam
                                 </p>
                                     <div class="comment-details d-flex justify-content-between">
                                         <div class="d-flex gap-2 mt-3">
                                             <div class="profile-image"><img
                                                 src="https://templatekit.jegtheme.com/electriza/wp-content/uploads/sites/112/2021/06/testimonial-N8572T7.jpg"
                                                 alt="Jardel Rayner" class="img-fluid"></div>
                                         <span class="profile-info">
                                             <strong class="profile-name">Jardel Rayner</strong>
                                             <p class="profile-des">Businessman</p>
                                         </span>
                                         </div>
                                         
                                     </div>
                             </div>
                             <div class="item ">
                                 <p>
                                     Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
                                     magna aliqua Ut enim ad minim veniam
                                 </p>
                                     <div class="comment-details d-flex justify-content-between">
                                         <div class="d-flex gap-2 mt-3">
                                             <div class="profile-image"><img
                                                 src="https://templatekit.jegtheme.com/electriza/wp-content/uploads/sites/112/2021/06/testimonial-N8572T7.jpg"
                                                 alt="Jardel Rayner" class="img-fluid"></div>
                                         <span class="profile-info">
                                             <strong class="profile-name">Jardel Rayner</strong>
                                             <p class="profile-des">Businessman</p>
                                         </span>
                                         </div>
                                         
                                     </div>
                             </div>
                             <div class="item ">
                                 <p>
                                     Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
                                     magna aliqua Ut enim ad minim veniam
                                 </p>
                                     <div class="comment-details d-flex justify-content-between">
                                         <div class="d-flex gap-2 mt-3">
                                             <div class="profile-image"><img
                                                 src="https://templatekit.jegtheme.com/electriza/wp-content/uploads/sites/112/2021/06/testimonial-N8572T7.jpg"
                                                 alt="Jardel Rayner" class="img-fluid"></div>
                                         <span class="profile-info">
                                             <strong class="profile-name">Jardel Rayner</strong>
                                             <p class="profile-des">Businessman</p>
                                         </span>
                                         </div>
                                         
                                     </div>
                             </div>
                             </div>
                           </div>
                       </div>
                   </div>
             </div>
     </div>
        </div>
       </section>
      <section class="py-60">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-sm-12 ">
                    <div>
                        <span class="heading__subtitle ">
                            Pricing Plans</span>
                        <h3 class="heading__title ">Affordable Pricing Plans</h3>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                        </p>
                        <div class="mt-3">
                            <a href="contact.html" class="btn">View All Plans</a>
                        </div>
                    </div>
                   
                  </div>
                  <div class="col-lg-6 col-sm-12">
                    <div class="card mt-4 border-0">
                        <div class="card-content">
                          <div class="card-body p-0">
                            <div class="media d-flex">
                                <div class="icon-box icon-box-body text-center">
                                    <h3 class="title color-accent">$45</h3>
                                    <p class="icon-box-description mb-0">Personal Plan</p>
                                    <div class="icon-box-button ">
                                        <a href="" class="icon-box-link">Get Started<i aria-hidden="true" class="fas fa-arrow-right"></i></a>
                                </div>
                                </div>
                              <div class="media-body">
                                <ul class="list-items">
                                    <li>Free Diagnostics</li>
                                    <li>Replace &amp; Installation</li>
                                    <li>Maintenance Service</li>
                                    <li>30 Day Warranty </li>
                                  </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                  </div>
                  
                 
            </div>
            <div class="row">
                <div class="col-lg-6 col-sm-12">
                    <div class="card mt-4 border-0">
                        <div class="card-content">
                          <div class="card-body p-0">
                            <div class="media d-flex">
                                <div class="icon-box icon-box-body text-center">
                                    <h3 class="title color-accent">$45</h3>
                                    <p class="icon-box-description mb-0">Personal Plan</p>
                                    <div class="icon-box-button ">
                                        <a href="" class="icon-box-link">Get Started<i aria-hidden="true" class="fas fa-arrow-right"></i></a>
                                </div>
                                </div>
                              <div class="media-body">
                                <ul class="list-items">
                                    <li>Free Diagnostics</li>
                                    <li>Replace &amp; Installation</li>
                                    <li>Maintenance Service</li>
                                    <li>30 Day Warranty </li>
                                  </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      </div>
                      <div class="col-lg-6 col-sm-12">
                      <div class="card mt-4 border-0">
                        <div class="card-content">
                          <div class="card-body p-0">
                            <div class="media d-flex">
                                <div class="icon-box icon-box-body text-center">
                                    <h3 class="title color-accent">$45</h3>
                                    <p class="icon-box-description mb-0">Personal Plan</p>
                                    <div class="icon-box-button ">
                                        <a href="" class="icon-box-link">Get Started<i aria-hidden="true" class="fas fa-arrow-right"></i></a>
                                </div>
                                </div>
                              <div class="media-body">
                                <ul class="list-items">
                                    <li>Free Diagnostics</li>
                                    <li>Replace &amp; Installation</li>
                                    <li>Maintenance Service</li>
                                    <li>30 Day Warranty </li>
                                  </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                  </div>
            </div>
        </div>
      </section>