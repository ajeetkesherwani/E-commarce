@php
$main_arr = [
    'title' => $listing->listing_name ?? '',
    'sublist' => [
        [
            'name' => 'HOME',
            'link' => url('/'),
        ],
        [
            'name' => $listing->categories_name,
            'link' => route('categorySlug',['slug'=>$listing->categories_slug]),
        ],
        [
            'name' => $listing->listing_name ?? '',
            'link' => URL::current(),
        ],
    ],
];
@endphp
{{-- @dd($listing); --}}
<!-- BreadCumb Start-->
<x-Service03.SharedComponent.BreadCrumb :data="$main_arr" />
<!-- Bread Cumb End -->        
  
@if(!empty($listing))
<section class="section pt-2 pb-0">        
    <div class="container mt-100 mt-60">
        <div class="row mt-4">

            <div class="col-md-8 col-sm-12 col-lg-8 ">
                <div>
                    <img id="main_img" src="{{ getFullImageUrl($listing->listing_image) }}" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" alt="{{ $listing->listing_name ?? '' }}" class="img-fluid">
                </div>
                @if (!empty($listing->listing_to_gallery))
                <div class="my-3">
                    <div class="owl-carousel owl-theme">
                        @foreach ($listing->listing_to_gallery as $key => $data)
                        <div class="item">
                            <img onclick="swapimage(this)" src="{{getFullImageUrl($data->images_id)}}" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" alt="{{ $listing->images_name ?? '' }}" class="img-fluid">
                        </div>
                        @endforeach
                    </div>
                </div>
                @endif
                <div class="m-3">
                    <h2>{{$listing->listing_name ??''}}</h2>
                    {!! $listing->listing_description ?? ''!!}
                </div>

                @if(!empty($listing->listing_to_features) && sizeof($listing->listing_to_features)>0)
                <div class="mt-3">
                    <h2>Service Features</h2>
                    @foreach($listing->listing_to_features as $feaures)
                    <p>{{$feaures->feature_title}} : {{$feaures->feature_value}}</p>
                    @endforeach
                </div>
                @endif
            </div>

            <div class="col-md-4 col-sm-12 col-lg-4">
                <div class="row mb-5">
                    <div class="col-lg-12 ">
                        <div class="card rounded shadow">
                            <ul class="list-group">
                                <li class="list-group-item">Cras justo odio</li>
                                <li class="list-group-item">Dapibus ac facilisis in</li>
                                <li class="list-group-item">Morbi leo risus</li>
                                <li class="list-group-item">Porta ac consectetur ac</li>
                                <li class="list-group-item">Vestibulum at eros</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card rounded shadow">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ulla laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehe in volup velit esse cillum dolore eu fugiat nulla pariatur. 
                            Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum
                        </div>
                    </div>
                </div>

                <div class="product-variants js-product-variants">
                    @if (!empty($listing->productAttribute))
                        @foreach ($listing->productAttribute as $attribute)
                            <div class="clearfix product-variants-item">
                                <span class="control-label">{{ ucfirst($attribute->option_name ?? '') }} :
                                </span>

                                @if (isset($attribute->option_value_list) && !empty($attribute->option_value_list))
                                    <ul id="attributes_{{ $attribute->options_id }}">

                                        @foreach ($attribute->option_value_list as $idx => $option_value)
                                            <li class="input-container float-sm-start">
                                                <label>
                                                
                                                    <input class="input-radio" type="radio"
                                                        attribute="{{ $attribute->options_id }}"
                                                        name="attributes_{{ $attribute->options_id }}"
                                                        {{ $idx == 0 ? 'checked' : '' }}
                                                        value="{{ $attribute->options_id }}_{{ $option_value->options_values_id }}"
                                                        title="{{ $option_value->productOptionsValue->products_options_values_name }}">
                                                    <span
                                                        class="radio-label">{{ $option_value->productOptionsValue->products_options_values_name }}</span>
                                                </label>
                                            </li>
                                        @endforeach

                                    </ul>
                                @endif
                            </div>
                        @endforeach
                    @endif

                </div>

                <div class="row mt-3">                    
                    <button type="button" onclick="addToCartFromDetail({{ $listing->listing_id }})" class="btn btn-primary">
                    Add To Cart
                    </button>
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                    Enquiry Now
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Enquiry Modal Start -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Enquiry For {{$listing->listing_name ??''}}</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            
        <form class="contact-panel_form required needs-validation"  id="appointmentcontactForm"  method="POST"  novalidate="">
            <div class="row">
                <input type="hidden" id="listing_id" name="products_id" value="{{ $listing->listing_id }}" >
                <input type="hidden"  class="form-control" name="products_qty" value="1" id="products_qty" maxlength="10">
                <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="form-group">
                    <input type="text" class="form-control"  name="customers_name" id="enqcustomers_name"  placeholder="Name" required="" aria-required="true">
                </div>
                </div>
                <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="form-group">
                    <input type="email" class="form-control" name="email_address" id="email_address" placeholder="Email Address"  required="" aria-required="true">
                </div>
                </div>

                <div class="col-sm-12 col-md-12 col-lg-12">
                    <div class="form-group">
                        <input type="text" class="form-control" name="email_address" id="email_address" placeholder="Email Address"  required="" aria-required="true">
                    </div>
                </div>

                <div class="row">
                    @php $max_option_id =0 @endphp
                    @if (!empty($listing->productAttribute))
                        @foreach ($listing->productAttribute as $attribute)
                          @if (isset($attribute->option_value_list) && !empty($attribute->option_value_list))
                            @php
                                if ($max_option_id < $attribute->options_id) {
                                    $max_option_id = $attribute->options_id;
                                }
                            @endphp
                      <div class="col-lg-6 col-md-6 col-12">
                        <label class="form-label">{{ ucfirst($attribute->option_name ?? '')}}</label>
                        <select aria-label="Default select example" name="attribute_{{ $attribute->options_id }}"
                            id="{{ $attribute->options_id }}"
                            class="enquiry_form form-control"  required="">
                            <option selected="" disabled="">Select {{ ucfirst($attribute->option_name ?? '') }}</option>
                            @foreach ($attribute->option_value_list as $option_value)
                            <option value="{{ $option_value->options_values_id }}">
                                {{ $option_value->productOptionsValue->products_options_values_name }}
                            </option>
                           @endforeach
                        </select>
                    </div>
                    @endif
                  @endforeach
                @endif
                </div>
                
                <div class="col-lg-12 col-sm-12 col-md-12 ">
                <div class="form-group">
                    <textarea class="form-control"  name="message" id="message" placeholder="Your Message"></textarea>
                </div>
                </div>
                <div class="col-lg-6 col-sm-12">
                <button type="submit" id="enquirymodalformbutton" class="btn">
                    <span>Submit</span>
                </button>
                <div class="contact-result"></div>
                </div><!-- /.col-lg-12 -->
            </div><!-- /.row -->
            <input type="reset" hidden>
        </form>
         
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        </div>
        </div>
    </div>
    </div>
    <!-- Enquiry Modal End -->

</section>
@endif
@push('scripts')
<script>
    $('.owl-carousel').owlCarousel({
    rtl:true,
    loop:true,
    margin:10,
    nav:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:5
        }
    }
})
function swapimage(image)
{
var mimg=document.getElementById("main_img")
mimg.src=image.src
}

$(document).on('click', '#enquirymodalformbutton', function(e) {
    e.preventDefault();
    $('#appointmentcontactForm').addClass('was-validated');
    if ($('#appointmentcontactForm')[0].checkValidity() === false) {
        event.stopPropagation();
    } else {
        let enquiryform = document.getElementById('appointmentcontactForm');
        let formData = new FormData(enquiryform);
        var URL = window.location.href;
        var arr = URL.split('/');
        formData.append('page_source', arr.pop());

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: "POST",
            url: "/storeProductEnquiry",
            data: formData,
            dataType: "json",
            contentType: false,
            cache: false,
            processData: false,
            beforeSend: function() {
                $("#enquirymodalformbutton").addClass('disabled');
                var html = '<i class="fa-solid fa-spinner fa-spin-pulse"></i> Submitting...';
                $("#enquirymodalformbutton").html(html);
            },
            success: function(response) {
                if (response.status == 400) {
                    $.each(response.error, function(key, err_val) {
                        $('.' + key + '_enq').text(err_val);
                    });
                } else {
                    $('#appointmentcontactForm').trigger("reset");
                    $('#exampleModal').modal('hide');
                    Notify('Send Successfully', true);
                }
            },
            complete: function(response) {
                $('#enquirymodalformbutton').removeClass('disabled');
                $('#appointmentcontactForm').removeClass('was-validated');
                $('#enquirymodalformbutton').html('Submit');
            }

        });
    }

});

var cart_detail_choosen_attributes = [];
        
function addToCartFromDetail(listing_id) {

var qtyItemAdd = $('#qtyItemAdd').val();
let attributes = cart_detail_choosen_attributes.join(',');

if (attributes == '') {
    $('input[type="radio"]:checked').each(function() {
        if (!cart_detail_choosen_attributes.includes(this.value)) {
            cart_detail_choosen_attributes.push(this.value);
        }
        console.log(cart_detail_choosen_attributes);
    });
    let attributes = cart_detail_choosen_attributes.join(',');
    addToCart(listing_id, qtyItemAdd, attributes);
} else {
    addToCart(listing_id, qtyItemAdd, attributes);
}
cart_detail_choosen_attributes=[];
}

</script>
@endpush