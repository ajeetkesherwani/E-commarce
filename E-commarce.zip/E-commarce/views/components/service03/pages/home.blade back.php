@php
// Banner-1
$banner_group_size1=12;
$count=count($data['home_page_middle_group_1']);
if($count>0)
{
$banner_group_size1=$banner_group_size1/$count;
}
else {
$banner_group_size1=12;
}

// Banner-2
$banner_group_size2=12;

$count=count($data['home_page_middle_group_2']);
if($count>0)
{
$banner_group_size2=$banner_group_size2/$count;
}
else {
$banner_group_size2=12;
}

@endphp

    <!-- Banner Start-->
    @if(!empty($data['home_page_middle_group_1']) && sizeof($data['home_page_middle_group_1'])>0)
    <section class="banner" style="background-image:({{$data['home_page_middle_group_1'][0]->image}});">
        <div class="banner-overlay"></div>
        <div class="container">
            <div class="row">
                <div class="banner-content col-lg-6 bg-white">
                    <h1 class="animate__animated animate__fadeInRight">We Are Dedicated To Excellence In Electrical Work
                    </h1>
                    <p class="animate__animated animate__fadeInLeft">
                        {{$data['home_page_middle_group_1'][0]->banners_title}}
                    </p>
                    <div class="banner-button">
                        <div class="">
                            <a href="contact.html" class="btn">Contact Us</a>
                        </div>
                        <div>
                            <div class="btn btn-primary video-btn" data-bs-toggle="modal"
                                data-src="https://www.youtube.com/embed/Jfrjeg26Cwk" data-bs-target="#myModal">

                                <i class="fa-solid fa-play"></i>
                            </div>
                            <span class="button-text pl-3">Watch Video</span>
                        </div>

                        <!-- Modal -->
                        <div class="modal fade" id="myModal" tabindex="-1" role="dialog"
                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-body">
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></span>
                                        </button>
                                        <!-- 16:9 aspect ratio -->
                                        <div class="ratio ratio-16x9">
                                            <iframe class="embed-responsive-item" src="" id="video"
                                                allowscriptaccess="always" allow="autoplay"></iframe>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        </div>
    </section>
    @endif
    <!--Banner End-->

    {{-- Some content come here form db Start --}}
    @if(!empty($data['pageDetails']))
     {!!$data['pageDetails']->pages_content!!}
    @endif
    {{-- Some content come here form db  End--}}

        <!-- Plan and Pricing Start-->
        @if(!empty($data['plan_data']) && sizeof($data['plan_data']))
        <section class="py-60">
            <div class="container ">
                <div class="row">
                    <div class="col-lg-6 col-sm-12 ">
                        <div>
                            <span class="heading__subtitle animate__animated animate__fadeInLeft">
                                Pricing Plans</span>
                            <h3 class="heading__title ">Affordable Pricing Plans</h3>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                                labore et dolore magna aliqua.
                            </p>
                            <div class="mt-3">
                                <a href="contact.html" class="btn">View All Plans</a>
                            </div>
                        </div>
                    </div>

                    @foreach($data['plan_data'] as $plan_val)
                    <div class="col-lg-6 col-sm-12">
                        <div class="card my-4 border-0">
                            <div class="card-content">
                                <div class="card-body p-0">
                                    <div class="media d-flex">
                                        <div class="icon-box icon-box-body text-center">
                                            <h3 class="title color-accent">{{currencyFormat($plan_val->plan_amount)}}</h3>
                                            <p class="icon-box-description mb-0">{{$plan_val->plan_name ?? ''}}</p>
                                            <div class="icon-box-button ">
                                                <a href="" class="icon-box-link">Get Started<i aria-hidden="true"
                                                        class="fas fa-arrow-right ms-1"></i></a>
                                            </div>
                                        </div>
                                        <div class="media-body">
                                            <ul class="list-items">
                                                @if(!empty($plan_val->plan_to_feature ) && sizeof($plan_val->plan_to_feature )>0)
                                                @foreach ($plan_val->plan_to_feature->take(5) as $featureval)
                                                <li>{{$featureval->feature_name->feature_title ?? ''}}</li>
                                                @endforeach
                                                @endif
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach

                </div>
            </div>
        </section>
        @endif
        <!--Plan and Pricing end-->

    <!-- Our project Start -->
    @if(!empty($data['popular_category']) && sizeof($data['popular_category'])>0)
    <section class="py-60">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-4 col-sm-12 ">
                    <div class="animate__animated animate__fadeInLeft">
                        <span class="heading__subtitle ">
                            Popular Categories</span>
                    </div>
                    <h3 class="heading__title ">Popular Categories</h3>
                </div>
                <div class="col-lg-6">
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua.
                    </p>
                </div>
                
            </div>
            <div class="row">
                @foreach($data['popular_category'] as $pckey=>$popCatval)
                <div class="col-sm-12 col-md-6 col-lg-6 mt-4">
                    <div class="product-item">
                        <div class="product__img">
                            <img src="{{getFullImageUrl($popCatval->categories_image)}}"
                            onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"  alt="Project" class="img-fluid">
                        </div><!-- /.col-lg-3 -->
                    </div><!-- /.row -->
                    <div class="service_content_cover">
                        <div class="service_content text-center">
                            <h5 class="service_title "><a href="" class="text-white">{{$popCatval->category_name ?? ''}}</a></h5>
                            <div class="service_content_desc">
                                <p class=" mb-0 text-white">
                                    {!! Str::limit($popCatval->category_description ?? '',150) !!}
                                </p>
                                <a href="{{route('categorySlug',['slug'=>$popCatval->categories_slug])}}" class="icon-box-link">Read More<i aria-hidden="true"
                                class="fas fa-arrow-right ms-1"></i></a>
                            </div>
                        </div>
                    </div><!-- /.product-item -->
                </div>
                @endforeach
            </div>
        </div>
    </section>
    @endif
    <!-- Our project End -->

    <!--Testimonial Start-->
    @if(!empty($data['webTestimonialList']) && sizeof($data['webTestimonialList'])>0)
    <section class="testimonial my-50">
        <div class="container-fluid testimonial-content">
            <div class="container ">
                <div class="row">
                    <div class="col-lg-6 col-sm-12  animate__animated animate__fadeInLeft">
                        <div>
                            <div class="">
                                <span class="heading__subtitle text-white">
                                    Testimonials</span>
                            </div>
                            <h3 class="heading__title text-white">We Are Trusted Over 12+ Countries Worldwide</h3>
                            <p class="text-white">
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusm tempor incididunt
                                ut labore et dolore magna aliqua </p>
                        </div>
                    </div>
                    <div class="col-lg-5 col-sm-12 offset-lg-1">
                        <div class="row mt-4">
                            <div class="contain">
                                <div id="owl-carousel" class="owl-carousel owl-theme">
                                    @foreach($data['webTestimonialList'] as $key=>$data)
                                    <div class="item ">
                                        <p>
                                            {{$data->testimonial_text}}
                                        </p>
                                        <div class="comment-details d-flex justify-content-between">
                                            <div class="d-flex gap-2 mt-3">
                                                <div class="profile-image"><img
                                                    src="{{$data->user_data->profile_photo ?? ''}}"
                                                    onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                                                    alt="{{getSetting('site_title')}}-User" class="img-fluid"></div>
                                                <span class="profile-info">
                                                    <strong class="profile-name">
                                                        {{ !empty($data->customer_name) ? $data->customer_name : '' }} 
                                                    </strong>
                                                    <p class="profile-des"> {{ !empty($data->company_name) ? $data->company_name : ''}}</p>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    @endif
    <!--Testimonial End-->

    <!--Blog Start-->
    @if(!empty($data['blog']))
    <section class="py-60 blog">
        <div class="container">
            <div class="row text-center ">
                <div class="col-lg-6 col-sm-12 mx-auto">
                    <div class=" animate__animated animate__fadeInUp">
                        <span class="heading__subtitle ">
                            Our Blog</span>
                    </div>
                    <h3 class="heading__title ">Latest Blog & Articles</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua
                    </p>
                </div>
            </div>
            <div class="row animate__animated animate__fadeInUp">
            @foreach ($data['blog']->take(4) as $blog)
            <x-Service03.SharedComponent.PostGrid :data="$blog" />
            @endforeach
            </div>
            </div>
        </div>
    </section>
    @endif
    <!--Blog End-->