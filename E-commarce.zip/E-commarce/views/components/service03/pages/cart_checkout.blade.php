@php

$main_arr = [
'title'=>'Cart-Checkout',
'sublist' => [
[
'name'=>'HOME',
'link'=>url("/")
],
[
'name'=>'checkout' ,
'link'=>url("")
],
]
];
@endphp

<x-Service03.SharedComponent.BreadCrumb :data="$main_arr" />
<!-- Breadcrumb Area End -->
        <div class="container mt-4">
        <div class="row">
            <div class="col-lg-8 col-sm-12">
                <form class="contact-panel_form" method="" action="" >
                    <div class="row">
                      <div class="col-sm-12 col-md-12 col-lg-12">
                        <div class="form-group">
                          <input type="text" class="form-control" placeholder="Name" id="contact-name" name="contact-name" required="" aria-required="true">
                        </div>
                      </div>
                      <div class="col-sm-12 col-md-12 col-lg-12">
                        <div class="form-group">
                          <input type="email" class="form-control" placeholder="Email Address" id="contact-email" name="contact-email" required="" aria-required="true">
                        </div>
                      </div>
                      <div class="col-sm-12 col-md-12 col-lg-12">
                        <div class="form-group">
                          <input type="text" class="form-control" placeholder=" Your Subject" id="subject" name="subject" required="" aria-required="true">
                        </div>
                      </div>
                      <div class="col-lg-12 col-sm-12 col-md-12 ">
                        <div class="form-group">
                          <textarea class="form-control" placeholder="Your Message" id="message" name="message"></textarea>
                        </div>
                      </div>
                    </div><!-- /.row -->
                  </form>
            </div>
            <div class="col-lg-4 col-sm-12">
                @if (!empty($list['cart_list']))
                <div class="card ">
                    <div class="card-header py-3">
                        <h5 class="mb-0">Service Details</h5>
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            @foreach ($list['cart_list'] as $cart )
                            <li class="list-group-item d-flex gap-3 justify-content-between align-items-center border-0 px-0 pb-0 ">
                                <img src="{{getFullImageUrl($cart->listing->listing_image ?? '')}}"  
                                onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" 
                                height="50px" width="50px"/>
                                <span class="products_total">
                                    {{ $cart->listing->listing_name ?? ''}}
                                </span>
                                <span class="order-price"> {{currencyFormat($cart->final_price??'')}}
                                    <span class="order-quantity"> X {{ $cart->qty ??''}} </span>
                                </span>
                            </li>
                            @endforeach

                            <li class="list-group-item d-flex justify-content-between align-items-center border-0   px-0 pb-0">
                                Services Total
                                <span class="products_total"></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center border-0 px-0">
                                Shipping
                                <span></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center   border-0 px-0 mb-3">
                                <div>
                                    <strong>Total amount</strong>
                                </div>
                                <span><strong class="grandAmount"></strong></span>
                            </li>
                        </ul>
                        
                    </div>
                </div>
                @endif
                <button type="submit" class="btn btn-lg btn-block mt-5 mx-auto">
                    <span>Place Order</span>
                </button>
            </div>
        </div>
        </div>

    {{-- Add New Address modal form start --}}
    <div class="modal fade" id="AddNewUSerAddress" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog  modal-lg modal-dialog-centered">
            <div class="modal-content rounded shadow border-0">
                <div class="modal-body p-4">
                    <div class="container-fluid px-0">
                        <div class="modal-button">
                            <button type="button" class="btn-icon btn-close modal-close" data-bs-dismiss="modal"
                                id="close-modal"><i class="fa fa-times" aria-hidden="true"></i></button>
                        </div>
                        <h3 class="modal-title pb-2" id="EnquryForm-title">Add New Address</h3>
                        <form class="needs-validation" novalidate id="addNewUserAddForm">
                            <div class="row g-3">
                                <div class="col-sm-6">
                                    <input type="text" class="form-control" name="customer_name" placeholder="Name"
                                        required>
                                    <p class="text-danger" id="addUADErr_customer_name"></p>
                                </div>

                                <div class="col-md-6">
                                    <input type="email" class="form-control" name="customer_email" placeholder="Email"
                                        required>
                                    <p class="text-danger" id="addUADErr_customer_email"></p>
                                </div>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="phone" placeholder="Phone No."
                                        required>
                                    <p class="text-danger" id="addUADErr_phone"></p>
                                </div>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="street_address"
                                        placeholder="Street Address" required>
                                    <p class="text-danger" id="enqerr_phone"></p>
                                </div>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="city" placeholder="City" required>
                                    <p class="text-danger" id="addUADErr_city"></p>
                                </div>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="state" placeholder="State" required>
                                    <p class="text-danger" id="addUADErr_state"></p>
                                </div>

                                <div class="col-md-6">
                                    <select class="form-select form-control" name="countries_id" id="country" required>
                                        <option selected disabled value="">Choose...</option>
                                        @if (!empty($CountryData))
                                        @foreach ($CountryData as $key => $countryValue)
                                        <option value="{{ $countryValue->countries_id }}" {{ $Ipcountry->countries_id ==
                                            $countryValue->countries_id ? 'selected' : '' }}>
                                            {{ $countryValue->countries_name }}
                                        </option>
                                        @endforeach
                                        @endif
                                    </select>
                                    <p class="text-danger" id="addUADErr_countries_id"></p>
                                </div>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="zipcode" placeholder="Pincode"
                                        required>
                                    <p class="text-danger" id="addUADErr_zipcode"></p>
                                </div>
                                <input type="reset" hidden></button>
                                <button class="w-100 btn btn-primary " id="AddNewUserAddressBtn"
                                    type="button">Submit</button>
                            </div>

                        </form>

                        <!--end row-->
                    </div>
                    <!--end container-->
                </div>
            </div>
        </div>
    </div>
    {{-- Add New Address modal form end --}}


    @push('scripts')
    <script>
        $(document).ready(function () {

            // for date
            $(function () {
                $("#appointment_date").datepicker({
                    altFormat: "yy-mm-dd"
                });
            });

            $(".type").click(function () {
                $(".type").removeClass('selected');
                $(this).toggleClass('selected');
                $('#payment_method').val($(this).attr('value'))
            });

            $(document).ready(function () {
                $('#checkout_form').validate({
                    rules: {
                        customer_name: {
                            required: true
                        },
                        phone: {
                            required: true,
                            // number: true,
                            // max:12,
                            // min:10,
                        },
                        customer_email: {
                            required: true,
                            email: true,
                            // maxlength: 50
                        },
                        street_address: {
                            required: true,

                            // maxlength: 50
                        },
                        city: {
                            required: true,
                            // maxlength: 50
                        },
                        state: {
                            required: true,
                            // maxlength: 50
                        },
                        countries_id: {
                            required: true,
                            // maxlength: 50
                        },
                        zipcode: {
                            required: true,
                            // maxlength: 50
                        },
                        zipcode: {
                            required: true,
                            // maxlength: 50
                        },
                        appointment_date: {
                            required: true,
                            // maxlength: 50
                        },
                        appointment_time: {
                            required: true,
                            // maxlength: 50
                        },
                    },
                    // messages: {
                    //   customer_name: {
                    //     required: "Please enter y name",
                    //   },
                    //   customer_contact: {
                    //     required: "Please enter phone number",
                    //     // number: "Please enter valid contact number",
                    //     // max:"Please enter valid number",
                    //     // min:"Please enter valid number",

                    //   },
                    //   customer_email: {
                    //     required: "Please enter  your email",
                    //     email: "Please enter valid email address",
                    //   },
                    //   street_address: {
                    //     required: "Please enter  your street address",
                    //   },
                    //   customer_city: {
                    //     required: "Please enter your city",
                    //   },
                    //   customer_state: {
                    //     required: "Please enter your state",
                    //   },
                    //   customer_country: {
                    //     required: "Please select your country",
                    //   },
                    //   customer_zipcode: {
                    //     required: "Please enter your zipcode",
                    //   },
                    //   appointment_date: {
                    //     required: "Please enter your appointment date",
                    //   },
                    //   appointment_time: {
                    //     required: "Please enter your appointment time",
                    //   },
                    // },

                    errorElement: 'span',
                    errorPlacement: function (error, element) {
                        // error.addClass('invalid-feedback');
                        // element.closest('.form-group').append(error);
                    },
                    highlight: function (element, errorClass, validClass) {
                        $(element).addClass('is-invalid');
                    },
                    unhighlight: function (element, errorClass, validClass) {
                        $(element).removeClass('is-invalid');
                    }

                });
            });


            // Show Add-Address Modal

            $("#createAddress").click(function () {
                $("#AddNewUSerAddress").modal('show', 'fade');
            });

            $(document).on('click', '.modal-close', function (e) {
                $('#AddNewUSerAddress').modal('hide');
            });

            // Add Adress Ajax

            $(document).on('click', '#AddNewUserAddressBtn', function (e) {
                e.preventDefault();
                $('#addNewUserAddForm').addClass('was-validated');
                if ($('#addNewUserAddForm')[0].checkValidity() === false) {
                    event.stopPropagation();
                } else {
                    let addNewUserAddForm = document.getElementById('addNewUserAddForm');
                    let formData = new FormData(addNewUserAddForm);
                    var html = '';

                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        type: "POST",
                        url: "{{ url('account/add-address') }}",
                        data: formData,
                        dataType: "json",
                        contentType: false,
                        cache: false,
                        processData: false,

                        beforeSend: function () {
                            $('#AddNewUserAddressBtn').addClass('disabled');
                            $('#AddNewUserAddressBtn').html(
                                ' <i class="fa-solid fa-spinner fa-spin-pulse"></i> Submitting...'
                            );
                        },

                        success: function (response) {
                            if (response.status == 400) {
                                $.each(response.error, function (key, err_val) {
                                    $('#addUADErr_' + key).text(err_val);
                                });
                            } else {

                                html = `<div class="col-lg-6 ">
                                                <div
                                                    class="addressboxes_container shadow d-flex justify-content-between px-3">
                                                    <input id="credit" value=${response.createdAddress.address_id} 
                                                        name="address_id" type="radio" class="form-check-input"
                                                        required checked style="float:left;">
                                                        <div class="px-4">
                                                        <h5>${response.createdAddress.customer_name ?? ''}</h5>
                                                        <h6>${response.createdAddress.customer_email ?? ''}</h6>
                                                        ${response.createdAddress.street_address}, ${response.createdAddress.city}<br />
                                                        ${response.createdAddress.state}<br />
                                                        ${response.createdAddress.country_name} ,
                                                        ${response.createdAddress.zipcode}
                                                    </div>
                                                </div>
                                            </div>`;
                                $('#addressboxes').append(html);
                                $('#addNewUserAddForm').trigger("reset");
                                $('#AddNewUSerAddress').modal('hide');
                                swal("Success", "Address Added Successfully.", "success");
                            }
                        },

                        complete: function () {
                            $('#addNewUserAddForm').removeClass('was-validated');
                            $('#AddNewUserAddressBtn').removeClass('disabled');
                            $('#AddNewUserAddressBtn').html('Submit');
                        }
                    });
                }
            });

        });
    </script>
    @endpush

</section>