<!-- Hero Start -->
<section class="bg-auth-home d-table w-100 mt-4">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-7 col-md-6">
                <div class="me-lg-5">
                    <img src="{{ LoadAssets('assets/images/Register.jpg') }}" class="img-fluid d-block mx-auto"
                        alt="">
                </div>
            </div>
            <div class="col-lg-5 col-md-6">
                <div class="card border-0">
                    <div class="card-body">
                        <h4 class="card-title text-center">{{ translation('REGISTRATION') }}</h4>
                        <form class="login-form mt-4 needs-validation" novalidate action="{{ route('register') }}"
                            method="post" id="register_form">
                            @csrf
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">First name <span class="text-danger">*</span></label>
                                        <div class="form-icon position-relative">
                                            <i data-feather="user" class="fea icon-sm icons"></i>
                                            <input type="text" name="first_name" class="form-control "
                                                placeholder="{{ translation('FIRST_NAME') }}" required>
                                            @error('first_name')
                                                <strong class="text-danger mb-5">{{ $message }}</strong>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                                <!--end col-->

                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Last name <span class="text-danger">*</span></label>
                                        <div class="form-icon position-relative">
                                            <i data-feather="user-check" class="fea icon-sm icons"></i>
                                            <input type="text" class="form-control " name="last_name"
                                                placeholder="{{ translation('LAST_NAME') }}" required>
                                            @error('last_name')
                                                <strong class="text-danger mb-5">{{ $message }}</strong>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                                <!--end col-->

                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label class="form-label">Your Email <span class="text-danger">*</span></label>
                                        <div class="form-icon position-relative">
                                            <i data-feather="mail" class="fea icon-sm icons"></i>
                                            <input name="email" type="email"
                                                placeholder="{{ translation('REG_EMAIL') }}" class="form-control "
                                                required>
                                            @error('email')
                                                <strong class="text-danger mb-5">{{ $message }}</strong>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                                <!--end col-->

                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label class="form-label">Password <span class="text-danger">*</span></label>
                                        <div class="form-icon position-relative">
                                            <i data-feather="key" class="fea icon-sm icons"></i>
                                            <input type="password" class="form-control " name="password"
                                                placeholder="{{ translation('REG_PASSWORD') }}" required>
                                            @error('password')
                                                <strong class="text-danger mb-5">{{ $message }}</strong>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                                <!--end col-->

                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value=""
                                                id="flexCheckDefault">
                                            <label class="form-check-label" for="flexCheckDefault">I Accept <a
                                                    href="#" class="text-primary">Terms And Condition</a></label>
                                        </div>
                                    </div>
                                </div>
                                <!--end col-->

                                <div class="col-md-12">
                                    <div class="d-grid">
                                        <button type="submit"
                                            class="btn btn-primary">{{ translation('REGISTER') }}</button>
                                    </div>
                                </div>
                                <!--end col-->


                                <div class="mx-auto">
                                    <p class="mb-0 mt-3"><small class="text-dark me-2">Already have an account ?</small>
                                        <a href="{{ route('login') }}"
                                            class="text-dark fw-bold">{{ translation('LOGIN') }}</a>
                                    </p>
                                </div>
                            </div>
                            <!--end row-->
                        </form>
                    </div>
                </div>
            </div>
            <!--end col-->
        </div>
        <!--end row-->
    </div>
    <!--end container-->
</section>
<!--end section-->

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>

    <script>
        $(document).ready(function() {
            $('#register_form').validate({
                rules: {
                    first_name: {
                        required: true
                    },
                    contact: {
                        required: true,
                    },
                    email: {
                        required: true,
                        email: true,
                    },
                    password: {
                        minlength: 8,
                        required: true
                    },
                },
                messages: {
                    first_name: {
                        required: "Please enter first name",
                    },
                    contact: {
                        required: "Please enter contact number",
                    },
                    email: {
                        required: "Please enter email",
                        email: "Please enter valid email address",
                    },
                    password: {
                        required: "Please enter password",
                        minlength: "Password must be at least 8 characters"
                    },
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.form-group').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                }

            });
        });
    </script>
@endpush
