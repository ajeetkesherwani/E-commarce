@php
$main_arr = [
'title'=>$categoryDesc->categories_name ?? '',
'sublist' => $breadCumbArr
];

@endphp
    <!-- Bread Cumb Start-->
    <x-Service03.SharedComponent.BreadCrumb :data="$main_arr" />  
    <!-- Bread Cumb End -->

    <!-- Our project Start -->
    <section class="py-60">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-4 col-sm-12 ">
                    <div class="animate__animated animate__fadeInLeft">
                        <span class="heading__subtitle ">
                            Our Projects</span>
                    </div>
                    <h3 class="heading__title ">Project We Have Done</h3>
                </div>
                <div class="col-lg-6">
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua.
                    </p>
                </div>
            </div>
            <div class="row">
                @if(!empty($listings) && sizeof($listings)>0)
                @foreach($listings as $listing)

                <x-Service03.shared-component.list-item  :data="$listing" />

                @endforeach
                @endif
            </div>

        </div>
    </section>
    <!-- Our project End -->
  
    

       
