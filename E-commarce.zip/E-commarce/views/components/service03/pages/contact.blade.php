@php
 $main_arr = [
  'title'=>'Contact-Us',
  'sublist' => [
    [
    'name'=>'HOME',
    'link'=>url("/")
    ],
    [
    'name'=>'Contact-Us' ,
    'link'=>url(URL::current())
    ], 
  ]
];   
@endphp

<x-Service03.SharedComponent.BreadCrumb :data="$main_arr" /> 

    <!--Contact us text-->
    <section class="py-60 ">
        <div class="container">
          <div class="row text-center ">
            <div class="col-lg-6 col-sm-12 mx-auto">
                <span class="heading__subtitle ">Contact Us</span>
                <h3 class="heading__title ">Get In Touch With Us</h3>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                </p>
              </div>
            
          </div>
          <div class="row mt-4">
            <div class="col-lg-4 col-sm-12">
                <div class="contact-box">
                    <div class="icon-wrapper mx-auto">
                        <i class="fa-solid fa-phone"></i>
                    </div>
                    <div class="media-body mt-4">
                        <h5 class="icon-box-title">
                            <span> Office Location </span>
                        </h5>
                        <p class="mt-0 ">Jl. Sunset Road No.815, Kuta - 80361</p> 
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-sm-12">
                <div class="contact-box blue-bg">
                    <div class="icon-wrapper mx-auto">
                        <i class="fa-solid fa-location-dot "></i>
                    </div>
                    <div class="media-body mt-4">
                        <h5 class="icon-box-title text-white">
                            <span> Give Us A Call </span>
                        </h5>
                        <p class="mt-0 text-white">Jl. Sunset Road No.815, Kuta - 80361</p> 
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-sm-12">
                <div class="contact-box">
                    <div class="icon-wrapper mx-auto">
                        <i class="fa-regular fa-envelope "></i>
                    </div>
                    <div class="media-body mt-4">
                        <h5 class="icon-box-title">
                            <span> Email Us </span>
                        </h5>
                        <p class="mt-0 ">support@domain.com</p> 
                    </div>
                </div>
            </div>
          </div>
         
        </div>
      
    
    </section>
    <!--Contact us text end-->

    <!--Contact us form start-->
    <section class="map_section py-60">
        <div class="container">
         <div class="row form-wrapper">
             <div class="col-lg-6 col-sm-12 px-0">
                 <div class="mapouter">
                     <div class="gmap_canvas"><iframe class="gmap_iframe" width="100%" height="600" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=600&amp;height=540&amp;hl=en&amp;q=University of Oxford&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe>
                     </div>
                     </div>
             </div>
             <div class="col-lg-6 col-sm-12 bg-white ">
              {!!shortCodeToForm('FORM_CONTACT')!!}
             </div>
         </div>
        </div>
           
    </section>
    <!--contact us form end-->
