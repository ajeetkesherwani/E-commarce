<link href="{{ getImageUrlWithKey('website_favicon') }}" rel="icon">
<link rel="stylesheet" href="{{LoadAssets('assets/css/bootstrap.min.css')}}">
<link rel="stylesheet" href="{{LoadAssets('assets/css/style.css')}}">
<link href="{{LoadAssets('assets/css/owl.carousel.min.css')}}" rel="stylesheet">
{{-- <link href="{{LoadAssets('assets/css/owl.theme.default.css')}}" rel="stylesheet"> --}}
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
<!-- Date Picker CSS -->
<link href='https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/ui-lightness/jquery-ui.css' rel='stylesheet'>
