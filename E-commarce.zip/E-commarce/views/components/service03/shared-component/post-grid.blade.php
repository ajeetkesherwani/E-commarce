<div class="col-lg-6 col-sm-12">
    <div class=" mt-4 border-0">
        <div class="card-content">
            <div class="card-body p-0">
                <div class="media d-flex gap-6">
                    <div class=" w-100 text-center">
                        <img src="{{getFullImageUrl($data->img)}}" 
                        onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" 
                        class="img-fluid" alt="">
                    </div>
                    <div class="media-body">
                        <div class="">
                            <h5 class="title"> {{ $data->post_title ?? ''}}</h5>
                            <span><i class="fa-solid fa-clock"></i>
                               @php
                                echo(date('d F,Y', strtotime($data->created_at ?? '')));
                              @endphp
                            </span>
                            <p class=" mb-0 mt-2">
                                {{ $data->post_excerpt ?? ''}}</p>
                            <a href="{{ url('blog/'.$data->slug) }}" class="icon-box-link">Read More<i aria-hidden="true"
                                    class="fas fa-arrow-right ms-1"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>