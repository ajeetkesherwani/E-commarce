@php
use App\Models\Listing\Services\ListService;
@endphp

<div class="col-sm-12 col-md-6 col-lg-6 mt-4">
    <div class="product-item">
        <div class="product__img">
            <img src="{{getFullImageUrl($listing->listing_image)}}"
            onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
            alt="{{$listing->listing_name ?? ''}}" class="img-fluid">
        </div><!-- /.col-lg-3 -->
    </div><!-- /.row -->
    <div class="service_content_cover">
        <div class="service_content text-center">
            <h5 class="service_title "><a href="" class="text-white">{{$listing->listing_name ?? ''}}</a></h5>
            <div class="service_content_desc">
                <p class=" mb-0 text-white">
                    {!! Str::limit($listing->listing_description ?? '',100) !!}
                </p>
                <a href="{{ListService::url($listing->listing_id , 'listing')}}" class="icon-box-link">View More<i aria-hidden="true"
                        class="fas fa-arrow-right ms-1"></i></a>
            </div>
        </div>
    </div><!-- /.product-item -->
</div>

                         

