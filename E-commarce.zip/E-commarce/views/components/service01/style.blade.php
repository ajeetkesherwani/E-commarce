<link href="{{ getImageUrlWithKey('website_favicon') }}" rel="icon">
<link rel="stylesheet"
  href="https://fonts.googleapis.com/css2?family=Fira+Sans:wght@400;500;600;700&family=Roboto:wght@400;700&family=Covered+By+Your+Grace&display=swap">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css">
<link rel="stylesheet" href="{{ LoadAssets('assets/css/libraries.css') }}">
<link rel="stylesheet" href="{{ LoadAssets('assets/css/style.css') }}">
<link rel="stylesheet" href="{{ LoadAssets('assets/css/extra.css') }}">

<!-- date time picker css -->
<link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
<!-- for time -->
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.css">
<!-- end of datetime picker -->
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
