<!-- ========================
  Banner Layout 1
 =========================== -->
 @if(!empty($banner_data))
 <section class="banner-layout1 bg-secondary py-0">
     <div class="container-fluid px-0">
       <div class="row row-gutter-0">
         <div class="col-sm-12 col-md-12 col-lg-12 banner-img d-flex align-items-center justify-content-center">
            <a href="{{$banner_data->banners_url}}">
           <img src="{{getFullImageUrl($banner_data->banners_image)}}" alt="{{$banner_data->banners_title}}">
        </a>
         </div><!-- /.col-lg-6 -->
       </div><!-- /.row -->
     </div><!-- /.container -->
   </section>
 <!-- /.Banner Layout 1 -->
 @endif