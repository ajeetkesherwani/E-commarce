@if (!empty($popular_category) && sizeof($popular_category) > 0 )
 @foreach($popular_category as $key=>$popCatval)
  <div class="service-item">
    <div class="service__overlay">
      <div class="bg-img">
        <img src="{{LoadAssets('assets/images/services/1.jpg')}}"  alt="service">
      </div>
    </div>
    <div class="service__body">
      <img src="{{getFullImageUrl($popCatval->categories_image)}}"  onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="category-listing">
      <h4 class="service__title">{{$popCatval->category_name ?? ''}}</h4>
      <div class="service__desc">
      <p class="service__desc">
        {!! Str::limit($popCatval->category_description ?? '',150) !!}
      </p>
      </div>
      <a href="{{route('categorySlug',['slug'=>$popCatval->categories_slug])}}" class="btn btn__secondary btn__block d-flex justify-content-between">
        <span>View More</span>
        <i class="icon-arrow-right icon-outlined"></i>
      </a>
    </div>
  </div>
  @endforeach
@endif