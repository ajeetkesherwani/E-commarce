@if(!empty($slider_data))
<section class="slider">
    <div class="slick-carousel carousel-arrows-light carousel-dots-light m-slides-0"
      data-slick='{"slidesToShow": 1, "arrows": true, "dots": true, "speed": 700,"fade": true,"cssEase": "linear"}'>
      @foreach($slider_data as $key=>$data)
      <div class="slide-item bg-overlay align-v-h">
      <div class="bg-img"><img src="{{$data->image}}" alt="slide img"></div>
        <div class="container">
          <div class="row align-items-center">
            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-7">
              <div class="slide__content">
                <h2 class="slide__title">{{$data->banners_title ?? ''}}</h2>
                <div class="d-flex flex-wrap align-items-center">
                  <a href="{{$data->banners_url}}" class="btn btn__accent mr-30">
                    <span>View More</span>
                    <i class="icon-arrow-right"></i>
                  </a>
                </div>
              </div><!-- /.slide-content -->
            </div><!-- /.col-xl-7 -->
          </div><!-- /.row -->
        </div><!-- /.container -->
      </div><!-- /.slide-item -->
      @endforeach
    </div><!-- /.carousel -->
  </section><!-- /.slider -->
@endif