@if (!empty($blog_data) && sizeof($blog_data)>0)
<section class="blog-grid pt-130 pb-60">
   <div class="container">
          <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-6 offset-lg-3">
              <div class="heading text-center mb-40">
                <h2 class="heading__subtitle">Recent Articles</h2>
                <h3 class="heading__title">Tips, News & Updates</h3>
              </div><!-- /.heading -->
            </div><!-- /.col-lg-6 -->
          </div><!-- /.row -->
          <div class="row">
            @foreach ($blog_data as $blog)
            <!-- Post Item-->
            <div class="col-sm-12 col-md-6 col-lg-4">
              <div class="post-item">
                <div class="post__img">
                  <a href="{{ url('blog/'.$blog->slug) }}">
                    <img src="{{getFullImageUrl($blog->img)}}"   onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="{{getSetting('site_title')}} Not-Found" loading="lazy">
                  </a>
                </div><!-- /.post__img -->
                <div class="post__body">
                  <div class="post__meta d-flex">
                    <div class="post__meta-cat">
                      <a href="#">Cleaning</a>
                      <a href="#">Tips</a>
                      <a href="#">Tricks</a>
                    </div><!-- /.blog-meta-cat -->
                    <span class="post__meta-date">{{ date("M d,Y", strtotime($blog->created_at)) }}</span>
                  </div>
                  <h4 class="post__title">
                    <a href="{{ url('blog/'.$blog->slug) }}">
                        {{ $blog->post_title ?? ''}}
                    </a>
                  </h4>
                  {{-- <div class="post__meta-author mb-30">By <a href="#">Admin</a></div> --}}
                  <p class="post__desc">
                    {{ $blog->post_excerpt ?? ''}}
                  </p>
                  <a href="{{ url('blog/'.$blog->slug) }}" class="btn btn__secondary btn__link">
                    <i class="icon-arrow-right"></i>
                    <span>Read More</span>
                  </a>
                </div><!-- /.post__body -->
              </div><!-- /.post-item -->
            </div>
            @endforeach
        
          </div><!-- /.row -->
    </div><!-- /.container -->
</section><!-- /.blog Grid -->
@endif