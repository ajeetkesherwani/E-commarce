@php
if(sizeof($plan_data)>0){
$size=12/count($plan_data);
}else{
  $size=4;
}
@endphp

  <!-- =========================
      Pricing  
      =========================== -->
      <section class="pricing-layout1 pb-80">
        <div class="container">
          <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-6 offset-lg-3">
              <div class="heading text-center mb-40">
                <h2 class="heading__subtitle">Our Pricing And Plans</h2>
                <h3 class="heading__title">Effective & Flexible Pricing
                  That Adapts Your Needs</h3>
              </div><!-- /.heading -->
            </div><!-- /.col-lg-6 -->
          </div><!-- /.row -->
          @if(!empty($plan_data) && sizeof($plan_data)>0)
          <form action="{{ url('/service-checkout') }}" method="post" class="chekoutForm">
            @csrf
          <input type="hidden" name="pricing_id" id="pricing_id" value="">

          <div class="row packages-wrapper">
            @foreach ($plan_data as $plan_val)
            <div class="col-sm-12 col-md-{{$size ?? 4}} col-lg-{{$size ?? 4}}">
              <div class="pricing-package">
                <div class="package__body">
                  <h4 class="package__subtitle">{{$plan_val->plan_name ?? ''}}</h4>
                  <h5 class="package__title">Price:  {{$plan_val->plan_pricing[0]->plan_price ?? ''}}</h5>
                  <p class="package__desc">{!!$plan_val->plan_desc ?? ''!!}</p>
                  <ul class="package__list list-items list-items-layout2 list-unstyled">
                   @if(!empty($plan_val->plan_to_feature ) && sizeof($plan_val->plan_to_feature )>0)
                   @foreach ($plan_val->plan_to_feature as $featureval)
                    <li>{{$featureval->feature_name->feature_title ?? ''}}</li>
                   @endforeach
                   @endif
                  </ul>
                </div><!-- /.package__body -->
                <div class="package__footer">
                                    
                  @guest
                  @if (getSetting('plan_buy_option') == 'checkout')
                  @if (getSetting('plan_guest_checkout')=='yes')
                  <button type="submit" class="btn btn__primary btn__block justify-content-between submitbtn pricing_btn" role="button" value="{{$plan_val->plan_pricing[0]->id ?? ''}}"><span>Purchase Now</span>
                    <i class="icon-arrow-right icon-outlined"></i></button>
                  @else
                  <button type="button" class="btn btn__primary btn__block justify-content-between planLoginbtn pricing_btn" data-source="checkout" role="button" value="{{$plan_val->plan_pricing[0]->id ?? ''}}"><span>Purchase Now</span>
                    <i class="icon-arrow-right icon-outlined"></i></button>
                  @endif
                  @endif
                  @if (getSetting('plan_buy_option') =='enquiry')
                  <button type="button" class="btn btn__primary btn__block justify-content-between pricing_btn " id="enquiryNowBtn" value="{{$plan_val->plan_pricing[0]->id ?? ''}}" role="button">Enquiry Now</button>
                  @endif
                  @endguest
      
                  @auth
                  @if (getSetting('plan_buy_option') == 'checkout')
                  <button type="submit" class="btn btn__primary btn__block justify-content-between submitbtn pricing_btn" role="button" value="{{$plan_val->plan_pricing[0]->id ?? ''}}"> <span>Purchase Now</span>
                    <i class="icon-arrow-right icon-outlined"></i></button>
                  @endif
                  @if (getSetting('plan_buy_option') =='enquiry')
                  <button type="button" class="btn btn__primary btn__block justify-content-between  pricing_btn" id="enquiryNowBtn" value="{{$plan_val->plan_pricing[0]->id ?? ''}}" role="button">Enquiry Now</button>
                  @endif
                  @endauth

                  <div class="package__price">
                    <span class="package__currency">$</span><span>{{$plan_val->plan_pricing[0]->plan_price ?? ''}}</span><span class="package__period">/Mo</span>
                  </div>
                </div><!-- /.package__footer -->
              </div><!-- /.pricing-package -->
            </div><!-- /.col-lg-4 -->
            @endforeach
          </div><!-- /.row -->
        </form>
        @endif
          <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-6 offset-lg-3 text-center">
              <div class="col-12">
                <p class="text__link mb-0">For a cleaning that meets your highest standards, you need a dedicated team of
                  trained specialists. We arrive at each visit with all supplies needed to thoroughly clean your home with
                  our extensive Cleaning Process.
                  <a href="services.html" class="btn btn__secondary btn__link mx-1">
                    <span>Contact Us For More Information</span> <i class="icon-arrow-right icon-outlined"></i>
                  </a>
                </p>
              </div><!-- /.col-12 -->
            </div><!-- /.row -->
          </div><!-- /.container -->
      </section><!-- /.pricing  -->

      <!-- Modal Start -->
<x-Service01.Pages.Modal />

