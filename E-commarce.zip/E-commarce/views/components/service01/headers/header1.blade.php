 <!-- =========================
        Header
    =========================== -->
    <header class="header header-layout1">
      <div class="header-topbar">
        <div class="container-fluid">
          <div class="row align-items-center">
            <div class="col-12 d-flex align-items-center justify-content-between">
              <span class="topbar__text">
                {!! getSetting('site_slogan') !!}
                {{-- <span class="colored__text"><i class="icon-alert"></i>{{getSetting('site_slogan') }}</span> <span>Call for Free Estimate: {{ getSetting('phone')}}</span> --}}
              </span>
             
              @if (!empty($top_nav_data) &&sizeof($top_nav_data)>0)
              <div>
                <ul class="contact__list d-flex flex-wrap align-items-center list-unstyled mb-0">
                  @foreach ($top_nav_data as $key => $value)
                  <li class="border-color-black" ><a href="{{ url($value->menu_link ?? '') }}">{{ $value->menu_name ?? '' }}</a></li>
                  @endforeach
                </ul>
              </div>
              @endif

              <div class="d-flex">
                <ul class="contact__list d-flex flex-wrap align-items-center list-unstyled mb-0">
                  <li>
                    <i class="icon-email"></i>
                    <a href="mailto:{{getSetting('contact_email')}}">
                      <span>Email: </span> <span>{{ getSetting('contact_email')}}</span>
                    </a>
                  </li>
                  <li>
                    <i class="icon-clock"></i>
                    <a href="javascript.void(0);">
                      <span>Working Hours: </span> <span>{{getSetting('opening_days')}}: {{getSetting('opening_times')}}</span>
                    </a>
                  </li>
                
                  {{-- language work start --}}
                  @if (count($Lang_arr) >1)
                  <div class="dropdown lang-dropdown mb-0">
                    <button class="dropdown-toggle lang-dropdown-toggle" id="langDropdown" data-toggle="dropdown">
                      <img src="{{ asset('flags/'.$def_lang->languages_code.'.svg') }}"alt="N/F" 
                      onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                      height="15" width="30"></span>{{$def_lang->languages_code}}</span>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="langDropdown">
                      @if(!empty($Lang_arr))
                      @foreach($Lang_arr as $key=>$data)
                      <a class="dropdown-item" href="{{ url('/lang/locale/'.$data['name']) }}">
                        <img src="{{ asset('flags/'.$data['name'].'.svg') }}"
                        onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                        alt="{{$data['name']}}"  height="10" width="15"> <span>{{$data['name']}}</span>
                      </a>
                      @endforeach
                      @endif
                    </div>
                  </div>
                  @endif
                  {{-- End of language --}}
                 
                  {{-- Currency work start --}}
                  @if (count($Curr_arr) > 1)
                  <div class="dropdown lang-dropdown mb-0">
                    <button class="dropdown-toggle lang-dropdown-toggle" id="langDropdown" data-toggle="dropdown">
                      {{$defcurrency_data->currencies_code}} {{$defcurrency_data->symbol_left}}
                    </button>
                    <div class="dropdown-menu" aria-labelledby="langDropdown">
                      @if(!empty($Curr_arr))
                      @foreach($Curr_arr as $key=>$data)
                      <a class="dropdown-item" href="{{ url('/currency/locale/'.$data['name']) }}">
                        {{$data['name']}}  {{$data['icon']}}
                      </a>
                      @endforeach
                      @endif
                    </div>
                  </div>
                  @endif

                  {{-- End of currency --}}
                  
                </ul><!-- /.contact__list -->
                <ul class="social-icons list-unstyled mb-0 ml-30">

                  {{-- <li><a href="{{getSetting('facebook_url')}}" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                  <li><a href="{{getSetting('instagram_url')}}" target="_blank"><i class="fab fa-instagram"></i></a></li>
                  <li><a href="{{getSetting('twitter_url')}}" target="_blank"><i class="fab fa-twitter"></i></a></li> --}}

                  @if(!empty(socialLinks('facebook_url')))
                  <li>
                      <a href="{{socialLinks('facebook_url')}}" target="_blank"><i class="fab fa-facebook-f"></i></a>
                  </li>
                  @endif
                  @if(!empty(socialLinks('twitter_url')))
                  <li>
                      <a href="{{socialLinks('twitter_url')}}" target="_blank"><i class="fab fa-instagram"></i></a>
                  </li>
                  @endif
                  @if(!empty(socialLinks('youtube_url')))
                  <li>
                      <a href="{{socialLinks('youtube_url')}}" target="_blank"><i class="fab fa-youtube"></i></a>
                  </li>
                  @endif
                  @if(!empty(socialLinks('google_url')))
                  <li>
                      <a href="{{socialLinks('google_url')}}" target="_blank"><i class="fab fa-google"></i></a>
                  </li>
                  @endif
                  @if(!empty(socialLinks('instagram_url')))
                  <li>
                      <a href="{{socialLinks('instagram_url')}}" target="_blank"><i class="fab fa-instagram"></i></a>
                  </li>
                  @endif
                  @if(!empty(socialLinks('linkedin_url')))
                  <li>
                      <a href="{{socialLinks('linkedin_url')}}" target="_blank"><i class="fab fa-linkedin"></i></a>
                  </li>
                  @endif
                  
                </ul><!-- /.social-icons -->
              </div>
            </div><!-- /.col-12 -->
          </div><!-- /.row -->
        </div><!-- /.container -->
      </div><!-- /.header-top -->
      <nav class="navbar navbar-expand-lg sticky-navbar">
        <div class="container-fluid">
          <a class="navbar-brand" href="{{url('/')}}">
            <img src="{{ getImageUrlWithKey('website_logo') }}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
            class="logo-light" alt="logo" style="height: 35px;width:50px" >
            <img src="{{ getImageUrlWithKey('website_logo') }}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
            class="logo-dark" alt="logo" style="height: 35px;width:100px;">
          </a>
          <button class="navbar-toggler" type="button">
            <span class="menu-lines"><span></span></span>
          </button>
          <div class="collapse navbar-collapse" id="mainNavigation">
            <ul class="navbar-nav mr-auto">    
              @if(!empty($main_menu))
              @foreach($main_menu as $key=>$value)
              @if(in_array($value->menu_type, array('1','2','3','4')) && isset($value->menulist) )
              
              <li class="nav__item {{$value->menu_ref_id==0 ? 'has-dropdown': '' }}"  >
                <a href="{{url($value->menu_ref_id==0 ? '#' : $value->menu_link)}}" data-toggle="dropdown" class="{{$value->menu_ref_id==0 ? 'dropdown-toggle': '' }} nav__item-link ">{{$value->menu_name}}</a>
                @if(!empty($value->menulist))
                <ul class="dropdown-menu">
                  @foreach($value->menulist as $cmenu)
                  @if(!empty($cmenu['title']))
                   <li class="nav__item">
                    <a href="{{url($cmenu["link"])}}" class="nav__item-link">{{ $cmenu['title'] }}</a>
                    @if(!empty($cmenu['subcate']))
                    <ul class="sub-menu sub-menu-2">
                    @foreach($cmenu['subcate'] as $smenu)
                    <li class="nav__item"><a href="{{ url($smenu['link']) }}" >{{ $smenu['title'] }}</a>  
                    </li>
                    @endforeach
                    </ul>
                   @endif
                  </li><!-- /.nav-item -->
                  @endif
                  @endforeach
                </ul><!-- /.dropdown-menu -->
                @endif
              </li><!-- /.nav-item -->
              @else
              <li class="nav__item"><a  class=" nav__item-link" href="{{$value->menu_link}}" >{{$value->menu_name}}</a></li>
              @endif
              @endforeach
              @endif
              <li class="nav__item"><a  class=" nav__item-link" href="{{url('/plans')}}" >Subscription Plans</a></li>
              <li class="nav__item"><a  class=" nav__item-link" href="{{url('/plan-pricng')}}" >Plan & Pricing</a></li>
              @guest
              <li class="nav__item"><a  class=" nav__item-link" href="{{url('/login')}}" >My Account</a></li>
              @endguest
              @auth
              <li class="nav__item"><a  class=" nav__item-link" href="{{url('/account/dashboard')}}" >My Account</a></li>

              <li class="nav__item"><a  class=" nav__item-link" href="{{ route('logout') }}" onclick="event.preventDefault(); 
              document.getElementById('frm-logout').submit();" >Log out</a></li>
              <form id="frm-logout" action="{{ route('logout') }}" method="POST" style="display: none;">
                {{ csrf_field() }}
              </form>
              @endauth

              @if(empty($allServiceCategory))
              <li class="nav__item has-dropdown">
                <a href="#" data-toggle="dropdown" class="dropdown-toggle nav__item-link ">Services Categories</a>
                <ul class="dropdown-menu">
                  @foreach($allServiceCategory as $serviveKey=>$Services)
                  <li class="nav__item">
                    <a href="{{route('categorySlug',['slug'=>$Services->categories_slug])}}" class="nav__item-link">{{$Services->category_name}}</a>
                  </li><!-- /.nav-item -->
                  @endforeach
                </ul><!-- /.dropdown-menu -->
              </li><!-- /.nav-item -->
              @endif
            </ul><!-- /.navbar-nav -->
    
            <div class="position-relative">
              <a href="{{ url('cart')}}"  class="action__btn action__btn-cart">
                <span>Cart</span> <i class="icon-cart"></i><span class="cart__counter count-cart-total">{{ $cart['total_count'] ?? '0' }}</span>
              </a>
             {{-- @php
                dd( $cart['cart_list']);
             @endphp --}}
              <div class="cart-minipopup">
                <ul class="list-unstyled" id="cart_items">
                  @if(!empty($cart['cart_list']) && sizeof($cart['cart_list'])>0)
                  @foreach ($cart['cart_list'] as $item)
                  <li class="cart-item">
                    <div class="cart__img"><img src="{{getFullImageUrl($item->listing->listing_image)}}" alt="thumb"></div>
                    <div class="cart__content">
                      <a class="cart__title" href="{{url('services/'.$item->listing->listing_slug ?? '')}}">{{$item->listing->listing_name ?? ''}}</a>
                      <span class="cart__price">{{currencyFormat($item->listing->listing_to_price->base_rate ?? '')}}</span>
                      <button class="cart__delete" onclick="actionOnPopUpCart({{$item->cart_id}},'del')" > &times;</button>
                    </div>
                  </li>
                  @endforeach
                  @else
                  <h5>Your cart is empty</h5>
                  @endif
                </ul>
                <div class="cart-total">
                  <span>Total:</span>
                  <span id="totalAmount">{{ currencyFormat($cart['grand_total'] ?? 0) }}</span>
                </div><!-- /.cart-subtotal -->
                <a href="{{ url('cart')}}" class="btn btn__secondary btn__block">View Cart</a>
              </div><!-- /.cart-minipopup -->
            </div>
            <button class="close-mobile-menu d-block d-lg-none"><i class="fas fa-times"></i></button>
          </div><!-- /.navbar-collapse -->
          <ul class="navbar-actions d-none d-xl-flex align-items-center list-unstyled mb-0">
            <li><button class="action__btn-search"><i class="icon-search"></i></button></li>
            <li><a href="{{url('/request-enquiry')}}" class="btn btn__primary action__btn-request">Request An Enquiry </a>
            </li>
          </ul>
        </div><!-- /.container -->
      </nav><!-- /.navabr -->
    </header><!-- /.Header -->