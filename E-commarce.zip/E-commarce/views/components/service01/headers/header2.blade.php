 <!-- =========================
        Header
    =========================== -->
    <header class="header header-layout2">
      <div class="header-topbar">
        <div class="container-fluid">
          <div class="row align-items-center">
            <div class="col-12 d-flex align-items-center justify-content-between">
              <ul class="contact__list d-flex flex-wrap align-items-center list-unstyled mb-0">
                <!-- <li>
                    <a href="#">
                     <span class="topbar__text">
                      {!! getSetting('site_slogan') !!}
                      {{-- <span class="colored__text"><i class="icon-alert"></i>{{getSetting('site_slogan') }}</span> <span>Call for Free Estimate: {{ getSetting('phone')}}</span> --}}
                    </span>
                   </a>
                 </li> -->
                <li>
                <li>
                  <i class="icon-email"></i>
                  <a href="#">
                    <span>Email: </span> <span>{{ getSetting('email')}}</span>
                  </a>
                </li>
                <li>
                  <i class="icon-clock"></i>
                  <a href="contact-us.html">
                    <span>Working Hours: </span> <span>Mon-Fri: 8am – 7pm</span>
                  </a>
                </li>
              </ul><!-- /.contact__list -->
              <div class="d-flex align-items-center">
                <ul class="topbar__links d-flex list-unstyled mb-0">
                  <li>
                     <span class="topbar__text">
                      {!! getSetting('site_slogan') !!}
                      {{-- <span class="colored__text"><i class="icon-alert"></i>{{getSetting('site_slogan') }}</span> <span>Call for Free Estimate: {{ getSetting('phone')}}</span> --}}
                    </span>
                 </li>
               </ul>
                <ul class="social-icons list-unstyled mb-0 ml-30">
                  <li><a href="{{getSetting('facebook_url')}}" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                  <li><a href="{{getSetting('instagram_url')}}" target="_blank"><i class="fab fa-instagram"></i></a></li>
                  <li><a href="{{getSetting('twitter_url')}}" target="_blank"><i class="fab fa-twitter"></i></a></li>
                </ul> <!-- /.social-icons -->
                 {{-- language work start --}}
                  @if (count($Lang_arr) >1)
                <div class="dropdown lang-dropdown mb-0">
                  <button class="dropdown-toggle lang-dropdown-toggle" id="langDropdown" data-toggle="dropdown">
                   <img src="{{$def_lang->languages_icon}}" alt="N/F"  height="15" width="30"></span>{{$def_lang->languages_code}}</span>
                  </button>
                  <div class="dropdown-menu" aria-labelledby="langDropdown">
                     @if(!empty($Lang_arr))
                      @foreach($Lang_arr as $key=>$data)
                      <a class="dropdown-item" href="{{ url('/lang/locale/'.$data['name']) }}">
                        <img src="{{$data['icon']}}" alt="{{$data['name']}}"  height="10" width="15"> <span>{{$data['name']}}</span>
                      </a>
                      @endforeach
                      @endif
                  </div>
                </div>
                 @endif

               {{-- End of language --}}

                  {{-- Currency work start --}}
                  @if (count($Curr_arr) > 1)
                  <div class="dropdown lang-dropdown mb-0">
                    <button class="dropdown-toggle lang-dropdown-toggle" id="langDropdown" data-toggle="dropdown">
                      {{$defcurrency_data->currencies_code}} {{$defcurrency_data->symbol_left}}
                    </button>
                    <div class="dropdown-menu" aria-labelledby="langDropdown">
                      @if(!empty($Curr_arr))
                      @foreach($Curr_arr as $key=>$data)
                      <a class="dropdown-item" href="{{ url('/currency/locale/'.$data['name']) }}">
                        {{$data['name']}}  {{$data['icon']}}
                      </a>
                      @endforeach
                      @endif
                    </div>
                  </div>
                  @endif

                  {{-- End of currency --}}
              </div>
            </div><!-- /.col-12 -->
          </div><!-- /.row -->
        </div><!-- /.container -->
      </div><!-- /.header-top -->
      <nav class="navbar navbar-expand-lg sticky-navbar">
        <div class="container-fluid">
           <a class="navbar-brand" href="{{url('/')}}">
            <img src="{{ getImageUrlWithKey('website_logo') }}" class="logo-light" alt="logo">
            <img src="{{ getImageUrlWithKey('website_logo') }}" class="logo-dark" alt="logo">
          </a>
          <button class="navbar-toggler" type="button">
            <span class="menu-lines"><span></span></span>
          </button>
          <div class="collapse navbar-collapse" id="mainNavigation">
            <ul class="navbar-nav mr-auto">
               {{-- @php
                 dd($main_menu);
             @endphp --}}
             
              @if(!empty($main_menu))
              @foreach($main_menu as $key=>$value)
              @if(in_array($value->menu_type, array('1','2','4')) && isset($value->menulist) )

             <li class="nav__item {{$value->menu_ref_id==0 ? 'has-dropdown': '' }}"  >
                <a href="{{$value->menu_ref_id==0 ? '#' : $value->menu_link }}" data-toggle="dropdown" class="{{$value->menu_ref_id==0 ? 'dropdown-toggle': '' }} nav__item-link ">{{$value->menu_name}}</a>
                @if(!empty($value->menulist))

                <ul class="dropdown-menu">
                  @foreach($value->menulist as $cmenu)
                  @if(!empty($cmenu['title']))
                    <li class="nav__item">
                    <a href="{{ $cmenu['link']  }}" class="nav__item-link">{{ $cmenu['title'] }}</a>
                    @if(!empty($cmenu['subcate']))
                    <ul class="sub-menu sub-menu-2">
                    @foreach($cmenu['subcate'] as $smenu)
                    <li class="menu-dropdown position-static"><a href="{{ $smenu['link'] }}" >{{ $smenu['title'] }}</a>  
                    </li>
                    @endforeach
                    </ul>
                   @endif
                  </li><!-- /.nav-item -->
                  @endif
                  @endforeach
                </ul><!-- /.dropdown-menu -->
                  @endif
              </li><!-- /.nav-item -->
                @else
                 <li class="nav__item">
                <a  class=" nav__item-link" href="{{$value->menu_link}}" >{{$value->menu_name}}</a></li>
              @endif
              
              @endforeach
              @endif 


                 @if(empty($allServiceCategory))
              <li class="nav__item has-dropdown">
                <a href="#" data-toggle="dropdown" class="dropdown-toggle nav__item-link ">Services Categories</a>
                <ul class="dropdown-menu">
                  @foreach($allServiceCategory as $serviveKey=>$Services)
                  <li class="nav__item">
                    <a href="{{route('categorySlug',['slug'=>$Services->categories_slug])}}" class="nav__item-link">{{$Services->category_name}}</a>
                  </li><!-- /.nav-item -->
                  @endforeach
                </ul><!-- /.dropdown-menu -->
              </li><!-- /.nav-item -->
              @endif
            </ul><!-- /.navbar-nav -->
          </div><!-- /.navbar-collapse -->

          <ul class="navbar-actions d-none d-xl-flex align-items-center list-unstyled mb-0">
            <li><button class="action__btn-search"><i class="icon-search"></i></button></li>
            <li><a href="{{url('/request-estimate')}}" class="btn btn__primary action__btn-request">Request An Estimate </a>
            </li>
          </ul>
        </div><!-- /.container -->
      </nav><!-- /.navabr -->
    </header><!-- /.Header -->

