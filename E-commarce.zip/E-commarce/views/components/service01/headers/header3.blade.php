 <!-- =========================
        Header
    =========================== -->
    <header class="header header-layout1">
        <div class="header-topbar">
          <div class="container-fluid">
            <div class="row align-items-center">
              <div class="col-12 d-flex align-items-center justify-content-between">
                <span class="topbar__text">
                  <span class="colored__text"><i class="icon-alert"></i> Enjoy Our Hot Offers!</span>
                  <span>Call for Free Estimate: +55 654 541 17</span>
                </span>
                <div class="d-flex">
                  <ul class="contact__list d-flex flex-wrap align-items-center list-unstyled mb-0">
                    <li>
                      <i class="icon-email"></i>
                      <a href="#">
                        <span>Email: </span> <span>Clanora@7oroof.com</span>
                      </a>
                    </li>
                    <li>
                      <i class="icon-clock"></i>
                      <a href="contact-us.html">
                        <span>Working Hours: </span> <span>Mon-Fri: 8am – 7pm</span>
                      </a>
                    </li>
                  </ul><!-- /.contact__list -->
                  <ul class="social-icons list-unstyled mb-0 ml-30">
                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                  </ul><!-- /.social-icons -->
                </div>
              </div><!-- /.col-12 -->
            </div><!-- /.row -->
          </div><!-- /.container -->
        </div><!-- /.header-top -->
        <nav class="navbar navbar-expand-lg sticky-navbar">
          <div class="container-fluid">
            <a class="navbar-brand" href="index.html">
              <img src="{{LoadAssets('assets/images/logo/logo-light.png')}}" class="logo-light" alt="logo">
              <img src="{{LoadAssets('assets/images/logo/logo-dark.png')}}" class="logo-dark" alt="logo">
            </a>
            <button class="navbar-toggler" type="button">
              <span class="menu-lines"><span></span></span>
            </button>
            <div class="collapse navbar-collapse" id="mainNavigation">
              <ul class="navbar-nav mr-auto">
                <li class="nav__item has-dropdown">
                  <a href="#" data-toggle="dropdown" class="dropdown-toggle nav__item-link active">Home</a>
                  <ul class="dropdown-menu">
                    <li class="nav__item">
                      <a href="index.html" class="nav__item-link">Home Modern</a>
                    </li><!-- /.nav-item -->
                    <li class="nav__item">
                      <a href="home-classic.html" class="nav__item-link">Home Classic</a>
                    </li><!-- /.nav-item -->
                    <li class="nav__item">
                      <a href="home-shop.html" class="nav__item-link">Home Shop</a>
                    </li><!-- /.nav-item -->
                  </ul><!-- /.dropdown-menu -->
                </li><!-- /.nav-item -->
                <li class="nav__item has-dropdown">
                  <a href="#" data-toggle="dropdown" class="dropdown-toggle nav__item-link">Company</a>
                  <ul class="dropdown-menu">
                    <li class="nav__item">
                      <a href="about-us.html" class="nav__item-link">About Us</a>
                    </li><!-- /.nav-item -->
                    <li class="nav__item">
                      <a href="how-it-works.html" class="nav__item-link">How It Works</a>
                    </li><!-- /.nav-item -->
                    <li class="nav__item">
                      <a href="team.html" class="nav__item-link">Leadership Team</a>
                    </li><!-- /.nav-item -->
                    <li class="nav__item">
                      <a href="awards.html" class="nav__item-link">Awards & Recognition</a>
                    </li><!-- /.nav-item -->
                    <li class="nav__item">
                      <a href="locations.html" class="nav__item-link">Our Locations</a>
                    </li><!-- /.nav-item -->
                    <li class="nav__item">
                      <a href="faqs.html" class="nav__item-link">Help & FAQs</a>
                    </li> <!-- /.nav-item -->
                    <li class="nav__item">
                      <a href="gallery.html" class="nav__item-link">Our Gallery</a>
                    </li><!-- /.nav-item -->
                    <li class="nav__item">
                      <a href="careers.html" class="nav__item-link">Careers</a>
                    </li><!-- /.nav-item -->
                  </ul><!-- /.dropdown-menu -->
                </li><!-- /.nav-item -->
                <li class="nav__item has-dropdown">
                  <a href="#" data-toggle="dropdown" class="dropdown-toggle nav__item-link">Services</a>
                  <ul class="dropdown-menu wide-dropdown-menu">
                    <li class="nav__item">
                      <div class="row mx-0">
                        <div class="col-sm-6 dropdown-menu-col">
                          <a href="services.html" class="nav__item-link dropdown-menu-title">Services</a>
                          <ul class="nav flex-column">
                            <li class="nav__item">
                              <a class="nav__item-link" href="services-single.html">One Time Cleaning</a>
                            </li> <!-- /.nav-item -->
                            <li class="nav__item">
                              <a class="nav__item-link" href="services-single.html">Recurring Cleaning</a>
                            </li> <!-- /.nav-item -->
                            <li class="nav__item">
                              <a class="nav__item-link" href="services-single.html">Move Out-In Cleaning</a>
                            </li> <!-- /.nav-item -->
                            <li class="nav__item">
                              <a class="nav__item-link" href="services-single.html">Apartment Cleaning</a>
                            </li> <!-- /.nav-item -->
                            <li class="nav__item">
                              <a class="nav__item-link" href="services-single.html">Window Cleaning</a>
                            </li> <!-- /.nav-item -->
                            <li class="nav__item">
                              <a class="nav__item-link" href="services-single.html">Carpet Cleaning</a>
                            </li> <!-- /.nav-item -->
                          </ul>
                        </div><!-- /.col-sm-6 -->
                        <div class="col-sm-6 dropdown-menu-col">
                          <a href="industries.html" class="nav__item-link dropdown-menu-title">Industries</a>
                          <ul class="nav flex-column">
                            <li class="nav__item">
                              <a class="nav__item-link" href="industries-single.html">Manufacturing
                                Facilities</a>
                            </li> <!-- /.nav-item -->
                            <li class="nav__item">
                              <a class="nav__item-link" href="industries-single.html">Government buildings</a>
                            </li> <!-- /.nav-item -->
                            <li class="nav__item">
                              <a class="nav__item-link" href="industries-single.html">Educational Facilities</a>
                            </li> <!-- /.nav-item -->
                            <li class="nav__item">
                              <a class="nav__item-link" href="industries-single.html">Financial Institutions</a>
                            </li> <!-- /.nav-item -->
                            <li class="nav__item">
                              <a class="nav__item-link" href="industries-single.html">Medical Facilities</a>
                            </li> <!-- /.nav-item -->
                            <li class="nav__item">
                              <a class="nav__item-link" href="industries-single.html">Office Buildings</a>
                            </li> <!-- /.nav-item -->
                            <!-- /.nav-item -->
                          </ul>
                        </div><!-- /.col-sm-6 -->
                      </div><!-- /.row -->
                    </li><!-- /.nav-item -->
                  </ul>
                </li><!-- /.nav-item -->
                <li class="nav__item has-dropdown">
                  <a href="#" data-toggle="dropdown" class="dropdown-toggle nav__item-link">Pricing</a>
                  <ul class="dropdown-menu">
                    <li class="nav__item">
                      <a href="pricing.html" class="nav__item-link">our Pricing</a>
                    </li><!-- /.nav-item -->
                    <li class="nav__item">
                      <a href="pricing-offers.html" class="nav__item-link">Special Offers</a>
                    </li><!-- /.nav-item -->
                    <li class="nav__item">
                      <a href="request-estimate.html" class="nav__item-link">Request An Estimate</a>
                    </li><!-- /.nav-item -->
                  </ul><!-- /.dropdown-menu -->
                </li><!-- /.nav-item -->
                <li class="nav__item has-dropdown">
                  <a href="#" data-toggle="dropdown" class="dropdown-toggle nav__item-link">News</a>
                  <ul class="dropdown-menu">
                    <li class="nav__item">
                      <a href="blog.html" class="nav__item-link">Blog Grid</a>
                    </li><!-- /.nav-item -->
                    <li class="nav__item">
                      <a href="blog-single-post.html" class="nav__item-link">Single Blog Post</a>
                    </li><!-- /.nav-item -->
                  </ul><!-- /.dropdown-menu -->
                </li><!-- /.nav-item -->
                <li class="nav__item has-dropdown">
                  <a href="#" data-toggle="dropdown" class="dropdown-toggle nav__item-link">Shop</a>
                  <ul class="dropdown-menu">
                    <li class="nav__item">
                      <a href="shop.html" class="nav__item-link">Shop Products</a>
                    </li><!-- /.nav-item -->
                    <li class="nav__item">
                      <a href="shop-single-product.html" class="nav__item-link">Single Product</a>
                    </li><!-- /.nav-item -->
                    <li class="nav__item">
                      <a href="shopping-cart.html" class="nav__item-link">Cart</a>
                    </li><!-- /.nav-item -->
                  </ul><!-- /.dropdown-menu -->
                </li><!-- /.nav-item -->
                <li class="nav__item">
                  <a href="{{url('/contact')}}" class="nav__item-link">Contact Us</a>
                </li><!-- /.nav-item -->
              </ul><!-- /.navbar-nav -->
              <div class="position-relative">
                {{-- <a href="#" class="action__btn action__btn-cart">
                  <span>Cart</span> <i class="icon-cart"></i><span class="cart__counter">3</span>
                </a> --}}
                <div class="cart-minipopup">
                  <ul class="list-unstyled">
                    <li class="cart-item">
                      <div class="cart__img"><img src="assets/images/products/1.jpg" alt="thumb"></div>
                      <div class="cart__content">
                        <a class="cart__title" href="shop-single.html">Broom & Dustpan</a>
                        <span class="cart__price">$ 8.00</span>
                        <button class="cart__delete">&times;</button>
                      </div><!-- /.cart-item-content -->
                    </li><!-- /.cart-item -->
                    <li class="cart-item">
                      <div class="cart__img"><img src="assets/images/products/2.jpg" alt="thumb"></div>
                      <div class="cart__content">
                        <a class="cart__title" href="shop-single.html">Sponge Cleaner </a>
                        <span class="cart__price">$ 6.00</span>
                        <button class="cart__delete">&times;</button>
                      </div><!-- /.cart-item-content -->
                    </li><!-- /.cart-item -->
                  </ul>
                  <div class="cart-total">
                    <span>Total:</span>
                    <span>$14.00</span>
                  </div><!-- /.cart-subtotal -->
                  <a href="shopping-cart.html" class="btn btn__secondary btn__block">View Cart</a>
                </div><!-- /.cart-minipopup -->
              </div>
              <button class="close-mobile-menu d-block d-lg-none"><i class="fas fa-times"></i></button>
            </div><!-- /.navbar-collapse -->
            <ul class="navbar-actions d-none d-xl-flex align-items-center list-unstyled mb-0">
              <li><button class="action__btn-search"><i class="icon-search"></i></button></li>
              <li><a href="request-estimate.html" class="btn btn__primary action__btn-request">Request An Estimate </a>
              </li>
            </ul>
          </div><!-- /.container -->
        </nav><!-- /.navabr -->
      </header><!-- /.Header -->