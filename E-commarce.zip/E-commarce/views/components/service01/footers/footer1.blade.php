    <!-- ========================
      Footer
    ========================== -->
    <footer class="footer">
        <div class="footer-primary">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-3">
                        <div class="footer-widget-contact">
                            <h6 class="footer-widget__title">Quick Contacts</h6>
                            <ul class="contact-list list-unstyled">
                                <li>{{getSetting('footer_about_description')}}</li>
                                <li>
                                    <a href="tel:{{ getSetting('phone') }}" class="phone__number">
                                        <i class="icon-phone"></i> <span>{{ getSetting('phone') }}</span>
                                    </a>
                                </li>
                                <li>{{ getSetting('contact_address') }} , {{ getSetting('contact_city') }} , {{ getSetting('contact_state') }}
                                    <br/>{{ iso_code2_to_name(getSetting('contact_country')) }} , {{ getSetting('contact_zipcode') }}
                                </li>
                            </ul>
                 
                        </div><!-- /.footer-widget__content -->
                    </div><!-- /.col-xl-2 -->

                    <div class="col-sm-6 col-md-6 col-lg-2">
                        @if (!empty($footermenulist1))
                            <div class="footer-widget-nav">
                                <h6 class="footer-widget__title">{{ translation('INFORMATION') }}</h6>
                                <nav>
                                    <ul class="list-unstyled">
                                        @foreach ($footermenulist1 as $key => $value)
                                            <li><a href="{{ $value['link'] ?? '' }}">{{ $value['name'] ?? '' }}</a></li>
                                        @endforeach
                                    </ul>
                                </nav>
                            </div><!-- /.footer-widget__content -->
                        @endif
                    </div><!-- /.col-lg-2 -->
                    {{-- @php
                     dd($footermenu2);
                     @endphp --}}
                    <div class="col-sm-6 col-md-6 col-lg-2">
                        @if (!empty($footermenulist2))
                            <div class="footer-widget-nav">
                                <h6 class="footer-widget__title">{{ translation('CUSTOM_LINKS') }}</h6>
                                <nav>
                                    <ul class="list-unstyled">
                                        @foreach ($footermenulist2 as $footer2key => $footer2value)
                                            <li><a href="{{ $footer2value['link'] }}">{{ $footer2value['name'] }}</a>
                                            </li>
                                        @endforeach
                                    </ul>
                                </nav>
                            </div><!-- /.footer-widget__content -->
                        @endif
                    </div><!-- /.col-lg-2 -->
                    <div class="col-sm-12 col-md-6 col-lg-4 offset-lg-1">
                        <div class="footer-widget-newsletter">
                            <img class="newsletter__stamp" src="{{ LoadAssets('assets/images/icons/stamp.png') }}"
                                alt="stamp">
                            <h6 class="newsletter__title">{{ getSetting('footer_newsletter_info') }}</h6>
                            <form id="newslatterform" class="newsletter__form needs-validation" novalidate name="mc-embedded-subscribe-form" method="post">
                                @csrf
                                <input type="email" name="customer_email" class="form-control email"
                                    placeholder="{{ translation('ENTER_YOUR_EMAIL_HERE') }}" value="" required>
                                <button class="btn btn__secondary " id="mc-embedded-subscribe"
                                    name="subscribe">{{ translation('SIGN_UP') }}</button>
                                <input type="reset" hidden id="configreset" value="Reset">
                            </form>
                            <p class="text-danger mail_error" style="font-size:20px;"></p>
                        </div><!-- /.footer-widget__content -->
                        <!-- <div class="d-flex justify-content-end">
                  <p class="fz-14">Have a question? <a href="{{ url('/contact') }}" class="underlined__link">Click here</a></p>
                </div> -->
                    </div><!-- /.col-lg-2 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.footer-primary -->
        <div class="footer-secondary">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-sm-12 col-md-4 col-lg-4 col-xl-2">
                        <ul class="social-icons list-unstyled my-2">

                            @if(!empty(socialLinks('facebook_url')))
                            <li>
                                <a href="{{socialLinks('facebook_url')}}" target="_blank"><i class="fab fa-facebook-f"></i></a>
                            </li>
                            @endif
                            @if(!empty(socialLinks('twitter_url')))
                            <li>
                                <a href="{{socialLinks('twitter_url')}}" target="_blank"><i class="fab fa-instagram"></i></a>
                            </li>
                            @endif
                            @if(!empty(socialLinks('youtube_url')))
                            <li>
                                <a href="{{socialLinks('youtube_url')}}" target="_blank"><i class="fab fa-youtube"></i></a>
                            </li>
                            @endif
                            @if(!empty(socialLinks('google_url')))
                            <li>
                                <a href="{{socialLinks('google_url')}}" target="_blank"><i class="fab fa-google"></i></a>
                            </li>
                            @endif
                            @if(!empty(socialLinks('instagram_url')))
                            <li>
                                <a href="{{socialLinks('instagram_url')}}" target="_blank"><i class="fab fa-instagram"></i></a>
                            </li>
                            @endif
                            @if(!empty(socialLinks('linkedin_url')))
                            <li>
                                <a href="{{socialLinks('linkedin_url')}}" target="_blank"><i class="fab fa-linkedin"></i></a>
                            </li>
                            @endif

                        </ul><!-- /.social-icons -->
                    </div><!-- /.col-xl-2 -->
                    <div
                        class="col-sm-12 col-md-8 col-lg-8 col-xl-10 d-flex justify-content-between align-items-center">
                        <div>
                            <div class="footer__copyrights">
                                <span class="fz-14">{{ $copyRightText ?? '' }}</span>
                            </div>
                            <nav>
                                {{-- <ul class="list-unstyled footer__copyright-links d-flex flex-wrap mb-0">
                      <li><a href="#">Terms & Conditions</a></li>
                      <li><a href="#">Privacy Policy</a></li>
                      <li><a href="#">Cookies</a></li>
                    </ul> --}}
                            </nav>
                        </div>
                        <button id="scrollTopBtn">
                            <i class="fas fa-long-arrow-alt-up"></i>
                            <span class="scroll__text">Scroll To Top</span>
                        </button>
                    </div><!-- /.col-xl-10 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.footer-secondary -->
    </footer><!-- /.Footer -->

    {{-- search pop up --}}

    <div class="search-popup">
        <button type="button" class="search-popup__close"><i class="fas fa-times"></i></button>
        <form class="search-popup__form" id="searchform">
            <input type="text" class="search-popup__form__input" id="searchtext" name="searchtext"
                placeholder="Search services from here..">
            <button class="search-popup__btn" id="searchbutton"><i class="icon-search"></i></button>
        </form>
    </div><!-- /. search-popup -->


    @push('scripts')
        <script>
            $(document).ready(function() {
                $(document).on('click', '#mc-embedded-subscribe', function(e) {
                    e.preventDefault();
                    $('#newslatterform').addClass('was-validated');
                    if ($('#newslatterform')[0].checkValidity() === false) {
                        event.stopPropagation();
                    } else {
                        var data = {
                            'customer_email': $('.email').val(),
                        }
                        $.ajaxSetup({
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "/newslatterstore",
                            data: data,
                            dataType: "json",
                            success: function(response) {
                                if (response.status == 400) {
                                    $('.mail_error').text(response.error.customer_email);

                                } else {
                                    $('.email').val(),
                                        $('.mail_error').text("");
                                    Notify('Subscribed Successfully', true);
                                    $("#newslatterform").trigger("reset")
                                }
                            }

                        });
                    }
                });
            });
        </script>
    @endpush
