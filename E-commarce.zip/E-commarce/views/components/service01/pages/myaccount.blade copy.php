@push('styles')
<style>
  .list-group-item.active {
    z-index: 2;
    color: #fff;
    background-color: #ef1e1e !important;
    border-color: #ef1e1e !important;
  }
</style>
@endpush

@php

$main_arr = [
  'title'=>'My Profile',
  'sublist' => [
    [
    'name'=>'HOME',
    'link'=>url("/")
    ],
    [
    'name'=>'Profile',
    'link'=>url("")
    ], 
  ]
];
@endphp

<x-Service01.SharedComponent.BreadCrumb :data="$main_arr" /> 

<!-- account area start -->
<div class="checkout-area mtb-60px">
  <div class="container">
    <div class="row">
      <div class="mx-auto col-lg-3 ">
        {{-- Left Side Menubar Component Start --}}
        <x-Service01.SharedComponent.left-side-menu />
        {{--Right Side Menubar Component Start --}}

      </div>
      <div class="mx-auto col-lg-9">
        <div class="checkout-wrapper">
          <div id="faq" class="panel-group">
            <div class="panel panel-default single-my-account">
              <div class="panel-heading my-account-title">
                <h3 class="panel-title">{{translation('MY_ACCOUNT')}}</h3>
              </div>
              <div id="my-account-1" class="">
              <form >
                <div class="panel-body">
                  <div class="myaccount-info-wrapper">
                    <div class="row">
                      <div class="col-lg-6 col-md-6">
                        <div class="billing-info">
                          <label>{{translation('FIRST_NAME')}}</label>
                          <input type="text" id="first_name" value="{{$userData[0]->first_name ??''}}" />
                          <span class="text-danger first_name"></span>
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6">
                        <div class="billing-info">
                          <label>{{translation('LAST_NAME')}}</label>
                          <input type="text" id="last_name"  value="{{$userData[0]->last_name ??''}}"/>
                          <span class="text-danger last_name"></span>
                        </div>
                      </div>
                      <div class="col-lg-12 col-md-12">
                        <div class="billing-info">
                          <label>{{translation('EMAIL_ADDRESS')}}</label>
                          <input type="email" id="email"  value="{{$userData[0]->email ??''}}" readonly />
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col">
                        <div class="billing-info">

                          <input class="checkout-toggle2" id="passwordCheckbox" value="1" style=" width: 4%; height: 15px; text-align: left;"
                            type="checkbox">
                          <label>{{translation('CHANGE_PASSWORD')}}</label>
                        </div>
                      </div>
                    </div>
                    <div class="p-0">
                      <div class="row checkout-account-toggle open-toggle2 mb-30"  id="cpasstoggle">
                        <div class="col-lg-6 col-md-6">
                          <div class="billing-info">
                            <label>{{translation('NEW_PASSWORD')}}</label>
                            <input type="password" name="password" id="password" />
                            <span class="text-danger password"></span>
                            <span class="text-danger password"></span>
                          </div>
                        </div>

                        <div class="col-lg-6 col-md-6"> 
                         <div class="billing-info">
                          <label>{{translation('CONFIRM_PASSWORD')}}</label>
                          <input type="password" name="confirmpassword" id="confirmpassword" />
                          <span class="text-danger password"></span>
                          <span class="text-danger confirmpassword"></span>
                        </div>
                        </div>
                      </div>
                      <div class="billing-back-btn">
                        <div class="billing-btn">
                          <button type="submit" id="updateprofile">{{translation('UPDATE')}}</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

@push('scripts')
<script>
  $(document).ready(function() {
    $(document).on('click', '#updateprofile', function(e) {
      if($("#passwordCheckbox").prop('checked') == true){
        var passwordCheckbox = $('#passwordCheckbox').val();
      } else{
        var passwordCheckbox = 0;
      }
      e.preventDefault();
      var data = {
        'first_name': $('#first_name').val(),
        'last_name': $('#last_name').val(),
        'password': $('#password').val(),
        'confirmpassword': $('#confirmpassword').val(),
        'passwordCheckbox':passwordCheckbox,
      }

      $.ajaxSetup({
        headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
      });
      $.ajax({
        type: "POST",
        url: "{{url('account/update-profile')}}",
        data: data,
        dataType: "json",
        success: function(response) {
          if (response.status == 400) {
            $.each(response.error, function(key, err_val) {
              $('.' + key).text(err_val);
            });
          } else {
            Notify('Profile Updated Successfully', true);
            $('#passwordCheckbox').prop('checked', false); 
            $('#cpasstoggle').hide(2000);
            location.reload();
          }
        }
      });
    });
  });
</script>
@endpush
