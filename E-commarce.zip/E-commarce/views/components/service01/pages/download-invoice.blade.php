<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        @import url(https://fonts.googleapis.com/css?family=Nunito:300,400,500,600,700&display=swap);

        tr {
            border-color: #e9ecef;
        }

        .invoice_wrapper table {
            width: 100%;
            line-height: 24px;
        }

        a {
            text-decoration: none;
            / color: #8492a6 /
            color: #000
        }

        .text-muted,
        svg {
            color: #000
        }

        .invoice_wrapper table tr td {
            padding: 1px;
        }



        h5 {
            font-size: 1.25rem;
            margin-top: 0;
            margin-bottom: .5rem;
            color: #000;
            font-weight: 600;
        }

        h6 {
            margin: 0
        }

        table th {
            font-weight: 400;
            text-align: left;
            color: #000;
            font-weight: 700;
        }

        .invoice_table th {

            padding: .5rem;
        }

        .address_section {
            border-bottom: 1px solid #e9ecef;
        }

        .address_section a {
            letter-spacing: 0.6px;
            width: 88%;
            float: right;
        }

        .address_section span {
            padding-right: 5px;
        }

        .table_border {
            border-bottom: 1px solid #e9ecef;
        }
    </style>
</head>

<body style="background-color: #fff; font-family: Nunito,sans-serif; font-size:16px">
    <div class="wrapper" style="max-width:100%; margin:auto;">
        <div class="invoice_wrapper">
            <table cellspacing="0" cellpadding="0"
                style="background-color:#fff; border-radius:6px;padding: 1.5rem 1rem; border:none;box-shadow:none;">
                <tbody>
                    <tr valign="top">
                        <td style="border-bottom: 1px solid #e9ecef;padding-bottom: 14px; " colspan="4">
                            <table>
                                <tbody>
                                    <tr>
                                        <td>
                                            <img src="{{getSuperFullImageUrl(getSetting('landing_logo'))}}" height="24"
                                                alt="logo_img" style="margin-bottom: .5rem;"><br>

                                        </td>

                                    </tr>
                                    <tr>
                                        <td>
                                            <span align="left">

                                                <span align="left">
                                                    <i class="uil uil-envelope-check d-block rounded h3 mb-0" style="padding-right: 4px;"></i>
                                                </span>


                                                <a href="mailto:{{getSetting('landing_conatct_email')}}"
                                                    class="text-muted">{{getSetting('landing_conatct_email')}}
                                                </a>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>

                                            <span align="left">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                    class="feather feather-phone fea icon-sm"
                                                    style="margin-top: 7px;padding-right: 4px;">
                                                    <path
                                                        d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z">
                                                    </path>
                                                </svg>
                                            </span>
                                            <a href="tel:{{getSetting('landing_conatct_phone')}}" class="text-muted"
                                                style="padding-bottom:1rem">{{getSetting('landing_conatct_phone')}}</a>

                                        </td>
                                    </tr>

                                </tbody>
                            </table>
                        </td>

                        <td valign="top" class="address_section">
                            <table>
                                <tbody>
                                    <tr>
                                        <td>
                                            <span align="left">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                    class="feather feather-map-pin fea icon-sm" style="margin-top:8px">
                                                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                                                    <circle cx="12" cy="10" r="3"></circle>
                                                </svg></span>

                                            <a href=""> {{getSetting('landing_conatct_address')}} <br />
                                                {{getSetting('landing_conatct_city')}}
                                                {{getSetting('landing_conatct_state')}},<br>
                                                {{iso_code2_to_name(getSetting('landing_conatct_country'))}}
                                                {{getSetting('landing_conatct_zip')}}
                                            </a>
                                            </a>

                                        </td>

                                    </tr>


                                </tbody>
                            </table>
                        </td>
                    </tr>

                    <tr>
                        <td colspan="4" style=" padding-top: 1.5rem;">
                            <table style="text-align:left;width:50%">
                                <thead>
                                    <h6 style="font-size:16px"> Billing Info</h6>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            {{-- <p> {{$invoice_data->subscription_history_details->sub_bussiness_info->billing_contact_name ?? ''}}<br>
                                                 {{$invoice_data->subscription_history_details->sub_bussiness_info->billing_company_name ?? ''}}<br>

                                                {{$invoice_data->subscription_history_details->sub_bussiness_info->billing_street_address ?? ""}}<br/>
                                                
                                               {{$invoice_data->subscription_history_details->sub_bussiness_info->billing_city ?? ""}},
                                               {{$invoice_data->subscription_history_details->sub_bussiness_info->billing_state ?? ""}}<br/>
                                               {{get_country($invoice_data->subscription_history_details->sub_bussiness_info->billing_country) ?? ""}},
                                               {{$invoice_data->subscription_history_details->sub_bussiness_info->billing_zipcode ?? ""}}  
                                           
                                               <br/>
                                                <a href="">{{$invoice_data->subscription_history_details->sub_bussiness_info->billing_phone ?? ""}}</a>
                                                <br>
                                                <a href="">{{$invoice_data->subscription_history_details->sub_bussiness_info->billing_email ?? ""}}</a>
                                            </p> --}}
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                        <td>
                            <table>
                                <tbody>
                                    <tr>
                                        <td style="text-align:left;font-weight: 700;"> Invoice No. :</td>
                                        <td class="text-muted"> {{$invoice_data->invoice_no ?? ""}}</td>
                                    </tr>
                                    <tr>
                                        <td style="text-align:left;font-weight: 700;"> Date :</th>
                                        <td class="text-muted">   
                                           @php
                                            echo(date(' M d ,Y' , strtotime($invoice_data->subscription_history_details->created_at ?? '')));
                                           @endphp</td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="5">
                            <table cellspacing="0px" cellpadding="2px" class="invoice_table"
                                style="border-radius:6px ;border:1px solid #e9ecef; margin:1rem 0">
                                <thead>
                                    <tr class="heading  top_row ">
                                        <th class="table_border" style="width:20%; padding-left:16px">
                                            Plan
                                        </th>
                                        <th class="table_border" style="width:20%; text-align:center;">
                                            Duration
                                        </th>
                                        <th class="table_border" style="width:20%;text-align:right;padding-right:16px ">
                                            Price
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="item">
                                        <td class="table_border" style="width:20%; padding:0.4rem 0 0.4rem 1rem">
                                            {{$invoice_data->subscription_history_details->plan_name ?? " "}}
                                        </td>
                                        <td class="table_border" style="width:20%;text-align:center ">
                                            {{$invoice_data->subscription_history_details->plan_duration ?? " "}} Mo

                                        </td>

                                        <td class="table_border" style="width:20%; text-align:right;padding-right:16px">
                                            $ {{round($invoice_data->payment_amount,2) ?? ''}}
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="4">
                            <table cellspacing="0px" cellpadding="2px" style="float: right; width:70%">
                                <tbody>

                                    <tr class="text-muted" style="text-align:right">
                                        <td style="text-align:left"> Subtotal :</th>
                                        <td>{{round($invoice_data->payment_amount,2) ?? ''}}</td>
                                    </tr>
                                    <tr class="text-muted" style="text-align:right">
                                        <td style="text-align:left"> Setup Fee :</th>
                                        <td>0</td>
                                    </tr>
                                    <tr class="text-muted" style="text-align:right">
                                        <td style="text-align:left"> Discount :</th>
                                        <td>
                                             @if($invoice_data->subscription_history_details->plan_pricing->discount_type==0)
                                            {{$invoice_data->subscription_history_details->plan_pricing->plan_discount ?? " "}}
                                            @elseif($invoice_data->subscription_history_details->plan_pricing->discount_type==1)
                                            {{$invoice_data->subscription_history_details->plan_pricing->plan_discount ?? " "}}
                                            @else
                                            {{$invoice_data->subscription_history_details->plan_pricing->plan_discount}} %
                                            @endif
                                        </td>
                                    </tr>
                                    <tr style="text-align:right">
                                        <td style="text-align:left;font-weight: 700;"> Total :</th>
                                        <td>$ {{round($invoice_data->payment_amount,2) ?? ''}}</td>
                                    </tr>

                                </tbody>
                            </table>


                        </td>
                    </tr>

                    <tr class="invoice_footer">
                        <td colspan="5" style="border-top: 1px solid #e9ecef;padding-top:14px">
                            <a href="" style="font-size:16px;font-weight:700; ">Terms &amp; Conditions</a>

                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</body>

</html>