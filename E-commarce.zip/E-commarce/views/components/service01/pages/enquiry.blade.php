@php

$main_arr = [
  'title'=>'Enquiry',
  'sublist' => [
    [
    'name'=>'HOME',
    'link'=>url("/")
    ],
    [
    'name'=>'Enquiry' ,
    'link'=>url("")
    ], 
  ]
];
@endphp

<x-Service01.SharedComponent.BreadCrumb :data="$main_arr" /> 
  
      <section class="pb-80">
        <div class="container">
          <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-4">
              <aside class="sidebar has-marign-right sticky-top mb-30">
                <div class="widget widget-help bg-overlay bg-overlay-primary">
                  <div class="bg-img"><img src="{{LoadAssets('assets/images/banners/5.jpg')}}" alt="background"></div>
                  <div class="widget-content">
                    <h3 class="widget__subtitle">Homeowners Like Us!</h3>
                    <h4 class="widget__title">Healthy Environment For Your Family</h4>
                    <p class="widget__desc font-weight-bold mb-50">The processes and systems we put in place provide high
                      quality service with a
                      focus on safety.
                    </p>
                    <a href="pricing-offers.html" class="btn btn__accent btn__block justify-content-between mb-30">
                      <span>Explore Our Offers</span>
                      <i class="icon-arrow-right"></i>
                    </a>
                    <a href="tel:+201061245741" class="phone__number">
                      <i class="icon-phone"></i> <span>002 01061245741</span>
                    </a>
                  </div><!-- /.widget-content -->
                </div><!-- /.widget-help -->
                <div class="widget widget-download">
                  <div class="widget-content">
                    <h4 class="widget__title">Download Brochure</h4>
                    <a href="#" class="btn btn__secondary btn__block mb-20">
                      <i class="icon-download"></i>
                      <span>Company Report 2022</span>
                    </a>
                    <a href="#" class="btn btn__primary btn__block">
                      <i class="icon-download"></i>
                      <span>Company Brochure</span>
                    </a>
                  </div><!-- /.widget-content -->
                </div><!-- /.widget-download -->
              </aside><!-- /.sidebar -->
            </div><!-- /.col-lg-4 -->
            <div class="col-sm-12 col-md-12 col-lg-8">
              <section class="py-0">
                <div class="contact-panel">
                    <div class="row">
                      <div class="col-12">
                        <h4 class="contact-panel__title">Request An Enquiry</h4>
                        <p class="contact-panel__desc mb-30">For a cleaning that meets your highest standards, you need a
                          dedicated team of trained specialists with all supplies needed to thoroughly clean your home.
                        </p>
                        <div class="request-estimate-form">
                          {!!shortCodeToForm('FORM_ENQUIRY')!!}  
                        </div>
                      </div><!-- /.col-12 -->                  
                    </div><!-- /.row -->
                  </form>
                </div><!-- /.contact-panel -->
              </section><!-- /.contact layout 4 -->
            </div><!-- /.col-lg-8 -->
          </div><!-- /.row -->
        </div><!-- /.container -->
      </section>
      @push('scripts')
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
<script>
    $(document).ready(function () {
         
        // $(document).on('click', '.enquirybtn', function (e) {
        //     e.preventDefault();
        //     $('.customFrom').addClass('was-validated');
        //     if ($('.customFrom')[0].checkValidity() === false) {
        //       event.stopPropagation();
        //     } else {
            
        //     var data = {
        //         'service': $('#service').val(),
        //         'subservice': $('#subservice').val(),
        //         'name': $('#name').val(),
        //         'phone': $('#phone').val(),
        //         'address': $('#address').val(),
        //         'message': $('#message').val(),
        //     }
        
        //     $.ajaxSetup({
        //         headers: {
        //             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        //         }
        //     });
        //     $.ajax({
        //         type: "POST",
        //         url: "{{url('/storeServicesEnquiry')}}",
        //         data: data,
        //         dataType: "json",


        //         beforeSend: function() {
        //                     $('.enquirybtn').addClass('disabled');
        //                     $('.enquirybtn').html(
        //                         ' <i class="fa-solid fa-spinner fa-spin-pulse"></i> Submitting...'
        //                     );
        //                 },

        //         success: function (response) {
        //             if (response.status == 400) {
        //                 $.each(response.error, function (key, err_val) {
        //                     $('#' + key).text(err_val);
        //                 });
        //             }
        //             else {
        //                 Notify('Details Send Successfully', true);
        //                 $('#enquiry-form').trigger("reset");
        //             }
        //         },

        //         complete: function() {
        //                   $('.customFrom').removeClass('was-validated');
        //                   $('.enquirybtn').removeClass('disabled');
        //                   $('.enquirybtn').html('Submit');
        //                 }
        //     });
        //   },
        // });
    });
</script>

   <script type="text/javascript">
            $("document").ready(function () {
                $('select[name="service"]').on('change', function () {
                    var catId = $(this).val();
                   // alert(catId);exit;
                    if (catId) {
                        $.ajax({
                            url: '/subservice/' + catId,
                            type: "GET",
                            dataType: "json",
                            success: function (data) {
                              alert(data);
                                $('select[name="subservice"]').empty();
                                $.each(data, function (key, value) {
                                    $('select[name="subservice"]').append('<option value=" ' + key + '">' + value + '</option>');
                                })
                            }

                        })
                    } else {
                        $('select[name="subservice"]').empty();
                    }
                });


            });
        </script>
@endpush