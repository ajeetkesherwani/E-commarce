@php

$main_arr = [
  'title'=>'My Account',
  'sublist' => [
    [
    'name'=>'HOME',
    'link'=>url("/")
    ],
    [
    'name'=>'Dashboard',
    'link'=>url("/account/dashboard")
    ], 
  ]
];
@endphp

<x-Service01.SharedComponent.BreadCrumb :data="$main_arr" />   

{{-- Section area start --}}



<section>
  <div class="container">
     
    <div class="row">
      <x-Service01.SharedComponent.left-side-menu />
    <div class="col-lg-8 col-sm-12">
      <div class="account_page_detail ">
        <h4 class="account_page__title ">Account Detail</h4>
        <div class="row">
          <div class="col-md-12 col-12 account_page">
              <div class="rounded shadow p-4">
                      <div class="d-flex align-items-center mt-3">

                          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-muted mr-1">
                              <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                              <circle cx="8.5" cy="7" r="4"></circle>
                              <polyline points="17 11 19 13 23 9"></polyline>
                          </svg>
                          <div class="account_page d-flex">
                              <div class="account_page_heading">
                                  <h6 class="mb-0"> User ID:</h6>
                              </div>
                              <div class="account_page_content"><a href="javascript:void(0)" class="text-muted">--------</a> 
                                      <i class="fas fa-solid fa-copy "></i>
                                  </div>
                          </div>
                      </div>

                      <div class="d-flex align-items-center mt-3">

                          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-muted mr-1">
                              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                              <circle cx="12" cy="7" r="4"></circle>
                          </svg>
                          <div class="account_page d-flex">
                              <div class="account_page_heading">
                                  <h6 class="mb-0"> Name:</h6>
                              </div>
                              <div class="account_page_content"><a href="javascript:void(0)" class="text-muted">{{$userData->first_name ?? ''}}
                                       </a>
                              </div>
                          </div>
                      </div>

                      <div class="d-flex align-items-center mt-3 ">
                          <!-- <i class="uil uil-building  align-middle me-2 mb-0"></i> -->
                          <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" width="18" height="18" stroke-width="2" class="mr-1">
                              <path d="M12.5 13h-1a1 1 0 0 0 0 2h1a1 1 0 0 0 0-2ZM12.5 9h-1a1 1 0 0 0 0 2h1a1 1 0 0 0 0-2ZM12.5 5h-1a1 1 0 0 0 0 2h1a1 1 0 0 0 0-2ZM8.5 13h-1a1 1 0 0 0 0 2h1a1 1 0 0 0 0-2ZM8.5 9h-1a1 1 0 0 0 0 2h1a1 1 0 0 0 0-2ZM8.5 5h-1a1 1 0 0 0 0 2h1a1 1 0 0 0 0-2ZM16.5 13h-1a1 1 0 0 0 0 2h1a1 1 0 0 0 0-2ZM16.5 9h-1a1 1 0 0 0 0 2h1a1 1 0 0 0 0-2ZM16.5 5h-1a1 1 0 0 0 0 2h1a1 1 0 0 0 0-2Z" fill="#555555" class="fill-000000 "></path>
                              <path d="M22 21h-1V2a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v19H2a1 1 0 0 0 0 2h20a1 1 0 0 0 0-2Zm-12 0v-2h4v2Zm6 0v-3a1 1 0 0 0-1-1H9a1 1 0 0 0-1 1v3H5V3h14v18Z" fill="#555555" class="fill-000000 "></path>
                          </svg>

                          <div class="account_page  d-flex">
                              <div class="account_page_heading">
                                  <h6 class="mb-0">Company Name:</h6>
                              </div>
                              <div class="account_page_content"><a href="javascript:void(0)" class="text-muted"></a>{{$userData->company_name ?? ''}}</div>
                          </div>
                      </div>
                      <div class="d-flex align-items-center mt-3">
                          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mr-1 text-muted">
                              <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z">
                              </path>
                              <polyline points="22,6 12,13 2,6"></polyline>
                          </svg>
                          <div class="account_page d-flex">
                              <div class="account_page_heading ">
                                  <h6 class="mb-0">Registered Email :</h6>
                              </div>
                              <div class="account_page_content"><a href="javascript:void(0)" class="text-muted">{{$userData->email ?? ''}}</a>
                              </div>
                          </div>
                      </div>

              </div>
              <!--end col-->
     
        </div>
        </div>
        
      </div>
    </div>
  </div>
</div>
 </section>