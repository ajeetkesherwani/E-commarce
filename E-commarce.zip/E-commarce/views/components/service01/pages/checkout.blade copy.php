<div class="container-fluid">
  <div class="row">
    <div class="col-sm-12 col-md-8 col-lg-8 mx-auto p-5">
      <section class="contact-layout4 py-0">
        <div class="contact-panel">
          <form class="contact-panel__form" method="post" action="{{ route('checkout-store') }}" id="checkout_form">
            @csrf

            <input type="hidden" class="form-control" name="plan_id" value="{{$PlanData->plan_id}}">
            <div class="row">
              <div class="col-12">
                <h3 class="contact-panel__title  text-center">{{ translation('BILLING_ADDRESS') }}</h3>
                <div class="mt-50 pb-50 border-top"></div>
              </div><!-- /.col-12 -->
              <div class="col-sm-6">
                <div class="form-group">
                  <label for="name">Name*</label>
                  <input type="text" class="form-control" placeholder="{{ translation('BILLING_NAME') }}" name="billing_name" id="billing_name">
                  @error('billing_name')
                  <p class="text-danger mb-5">{{ $message }}</p>
                  @enderror
                </div>
              </div><!-- /.col-lg-6 -->
              <div class="col-sm-6">
                <div class="form-group">
                  <label for="email">Email *</label>
                  <input type="text" class="form-control" placeholder="{{ translation('BILLING_EMAIL') }}" name="billing_email" id="billing_email">
                  @error('billing_email')
                  <p class="text-danger mb-5">{{ $message }}</p>
                  @enderror
                </div>
              </div><!-- /.col-lg-6 -->

              @if(getSetting('plan_appointment')=='yes')
              @if(getSetting('plan_appointment_date')=='yes')
              <div class="col-md-6">
                <label for="enq_appointment_date" class="form-label">Appointment Date</label>
                <input type="text" class="form-control" value="" name="appointment_date" id="appointment_date" placeholder="">
              </div>
              @endif
              @if(getSetting('plan_appointment_time')=='yes')
              <div class="col-md-6">
                <label for="enq_appointment_time" class="form-label">Appointment Time</label>
                <input type="time" class="form-control" value="" name="appointment_time" id="appointment_time" placeholder="">
              </div>
              @endif
              @endif


              <div class="col-sm-12">
                <div class="form-group">
                  <label for="phone">Phone*</label>
                  <input type="text" class="form-control" placeholder="{{ translation('CONTACT') }}" name="billing_contact" id="billing_contact">
                  @error('contact')
                  <p class="text-danger mb-5">{{ $message}}</p>
                  @enderror
                </div>
              </div><!-- /.col-lg-6 -->

              <div class="col-sm-12">
                <div class="form-group">
                  <label for="phone">Street address*</label>
                  <input type="text" class="form-control" placeholder="{{ translation('STREET_ADDRESS') }}" name="street_address" id="street_address">
                  @error('street_address')
                  <p class="text-danger mb-5">{{ $message}}</p>
                  @enderror
                </div>
              </div><!-- /.col-lg-6 -->

              <div class="col-6">
                <div class="form-group">
                  <label for="street">{{ translation('CITY') }}</label>
                  <input type="text" class="form-control" placeholder="{{ translation('CITY_PLACEHOLDER') }}" id="billing_city" name="billing_city">
                  @error('billing_city')
                  <p class="text-danger mb-5">{{ $message }}</p>
                  @enderror
                </div>

              </div><!-- /.col-12 -->
              <div class="col-6">
                <div class="form-group">
                  <label for="street">{{ translation('STATE') }}</label>
                  <input type="text" class="form-control" placeholder="{{ translation('STATE_PLACEHOLDER') }}" id="billing_state" name="billing_state">
                  @error('billing_state')
                  <p class="text-danger mb-5">{{ $message }}</p>
                  @enderror
                </div>
              </div><!-- /.col-12 -->
              <div class="col-6">
                <div class="form-group">
                  <label for="billing_country">{{ translation('COUNTRY') }}</label>
                  <select class="form-select form-control" name="billing_country" id="billing_country">
                    <option value selected disabled>{{ translation('COUNTRY_PLACEHOLDER') }}</option>
                    @if (!empty($CountryData))
                    @foreach ($CountryData as $key => $countryValue)
                    <option value="{{ $countryValue->countries_id }}">
                      {{ $countryValue->countries_name }}
                    </option>
                    @endforeach
                    @endif
                  </select>
                  @error('billing_country')
                  <p class="text-danger mb-5">{{ $message }}</p>
                  @enderror
                </div>
              </div><!-- /.col-12 -->
              <div class="col-6">
                <div class="form-group">
                  <label for="street">{{ translation('ZIP') }}</label>
                  <input type="text" class="form-control" placeholder="{{ translation('ZIP_PLACEHOLDER') }}" id="billing_zipcode" name="billing_zipcode">
                  @error('billing_zipcode')
                  <p class="text-danger mb-5">{{ $message }}</p>
                  @enderror
                </div>
              </div><!-- /.col-12 -->

              <!--Payment -->
              @if(!empty($PaymentMethods) && sizeof($PaymentMethods)>0)
              <article class="payment_wrapper">
                <div class="container">
                  <div class="payment_body">
                    <div class="payment-type">
                      <div>
                        <h4>Choose a payment method <span>(Click one of the options below)</span>
                        </h4>
                      </div>
                      <div class="types">
                        <div class="col-lg-12">
                          <div class="row">

                            <input type="hidden" id="payment_method" name="payment_method" value="2" />
                            @foreach ($PaymentMethods as $paymethods)
                            @if($paymethods->payment_method_id==2)
                            <div class="col-lg-6 col-md-6 col-sm-12 my-3">
                              <div class="type selected" value="2">
                                <div>
                                  <ul class="list-unstyled ">
                                    <li class="list-inline-item"><a href="javascript:void(0)"><img src="{{ LoadAssets('assets/payment_images/payment.png') }}" class=" " title="American Express" alt=""></a></li>
                                    <li class="list-inline-item"><a href="javascript:void(0)"><img src="{{ LoadAssets('assets/payment_images/visa_1.png') }}" class=" " title="Visa" alt=""></a></li>
                                    <li class="list-inline-item"><a href="javascript:void(0)"><img src="{{ LoadAssets('assets/payment_images/discover.png') }}" class=" " title="Discover" alt=""></a></li>
                                  </ul>
                                  <ul>
                                    <li class="list-inline-item"><a href="javascript:void(0)"><img src="{{ LoadAssets('assets/payment_images/China_Unionpay.png') }}" class=" " title="Paypal" alt=""></a></li>
                                    <li class="list-inline-item"><a href="javascript:void(0)"><img src="{{ LoadAssets('assets/payment_images/master-card.png') }}" class=" " title="Master Card" alt=""></a>
                                    </li>

                                    <li class="list-inline-item"><a href="javascript:void(0)"><img src="{{ LoadAssets('assets/payment_images/JCB_Cards.svg') }}" class=" " title="Visa" alt=""></a></li>
                                  </ul>
                                </div>

                              </div>
                              <div class="text-center">
                                <p>Pay with Cards</p>
                              </div>
                            </div>
                            @endif
                            @if($paymethods->payment_method_id==1)
                            <div class="col-lg-6 col-md-6 col-sm-12 my-3">
                              <div class="type" value="1">
                                <div class="">
                                  <img src="{{ LoadAssets('assets/payment_images/paypal_img.png') }}" alt="Paypal_img" class="img-fluid" style="width:150px; padding: 2rem 1.5rem">
                                </div>

                              </div>
                              <div class="text-center">
                                <p>Pay with PayPal<sup>TM</sup></p>
                              </div>
                            </div>
                            @endif
                            @endforeach
                          </div>
                        </div>

                      </div>
                    </div>
                  </div>
                </div>
              </article>
              @endif
              <!--End of Payment-->

              <div class="col-12">
                <button type="submit" class="btn btn__secondary btn__block btn__xhight d-flex justify-content-between mt-10">
                  <span>{{ translation('CONTINUE_TO_CHECKOUT') }}</span> <i class="icon-arrow-right icon-outlined"></i>
                </button>
                <div class="contact-result"></div>
              </div>
            </div><!-- /.row -->
          </form>
        </div><!-- /.contact-panel -->
      </section><!-- /.contact layout 4 -->
    </div><!-- /.col-lg-8 -->

    <div class="col-sm-12 col-md-4 col-lg-4 mx-auto p-5">
      <div class="pricing-package" id="pricing-package">
        <div class="package__body">
          <h4 class="package__subtitle">For Homes</h4>
          <h5 class="package__title">{{$PlanData->plan_name}}</h5>
          <p class="package__desc">{!! $PlanData->plan_desc !!}</p>
          {{-- <ul class="package__list list-items list-items-layout2 list-unstyled">
            <li>Window sills &amp; ledges</li>
            <li>Hard surface floors</li>
            <li>Remove cobwebs</li>
            <li>Empty trash</li>
          </ul> --}}
        </div><!-- /.package__body -->
        <div class="package__footer">
          <div class="package__price">
            <span class="package__currency">$</span><span>{{$PlanData->plan_amount}}</span><span class="package__period">/Mo</span>
          </div>
        </div><!-- /.package__footer -->
      </div>
    </div><!-- /.col-lg-8 -->
  </div><!-- /.col-lg-8 -->

  @push('scripts')
  <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
  <script>
    // for date
    $(function() {
          $("#appointment_date").datepicker({
            altFormat: "yy-mm-dd"
          });
        });

        $(document).ready(function() {
          $(".type").click(function() {
            $(".type").removeClass('selected');
            $(this).toggleClass('selected');
            $('#payment_method').val($(this).attr('value'))
          });
        });


        $(document).ready(function() {
          $('#checkout_form').validate({
            rules: {
              billing_name: {
                required: true
              },
              billing_contact: {
                required: true,
                // number: true,
                // max:12,
                // min:10,
              },
              billing_email: {
                required: true,
                email: true,
                // maxlength: 50
              },
              street_address: {
                required: true,

                // maxlength: 50
              },
              billing_city: {
                required: true,
                // maxlength: 50
              },
              billing_state: {
                required: true,
                // maxlength: 50
              },
              billing_country: {
                required: true,
                // maxlength: 50
              },
              billing_zipcode: {
                required: true,
                // maxlength: 50
              },
              billing_zipcode: {
                required: true,
                // maxlength: 50
              },
              appointment_date: {
                required: true,
                // maxlength: 50
              },
              appointment_time: {
                required: true,
                // maxlength: 50
              },


            },
            messages: {
              billing_name: {
                required: "Please enter billing name",
              },
              billing_contact: {
                required: "Please enter phone number",
                // number: "Please enter valid contact number",
                // max:"Please enter valid number",
                // min:"Please enter valid number",

              },
              billing_email: {
                required: "Please enter  your email",
                email: "Please enter valid email address",
              },
              street_address: {
                required: "Please enter  your street address",
              },
              billing_city: {
                required: "Please enter your city",
              },
              billing_state: {
                required: "Please enter your state",
              },
              billing_country: {
                required: "Please select your country",
              },
              billing_zipcode: {
                required: "Please enter your zipcode",
              },
              appointment_date: {
                required: "Please enter your appointment date",
              },
              appointment_time: {
                required: "Please enter your appointment time",
              },
            },

            errorElement: 'span',
            errorPlacement: function(error, element) {
              error.addClass('invalid-feedback');
              element.closest('.form-group').append(error);
            },
            highlight: function(element, errorClass, validClass) {
              $(element).addClass('is-invalid');
            },
            unhighlight: function(element, errorClass, validClass) {
              $(element).removeClass('is-invalid');
            }

          });
        });
  </script>
  @endpush