<!-- login area start -->
{{-- <div class="login-register-area mb-60px mt-53px">
    <div class="container">
        <div class="row">
            <div class="col-lg-7 col-md-12 mx-auto">
                <div class="login-register-wrapper">
                    <div class="login-register-tab-list nav">
                        <a class="active" data-bs-toggle="tab" href="#lg1">
                            <h4>{{ translation('REGISTRATION') }}</h4>
                        </a>
                    </div>
                    <div class="tab-content">
                        <div id="lg1" class="tab-pane active">
                            <div class="login-form-container">
                                <div class="login-register-form">
                                    <form action="{{ route('register') }}" method="post" id="register_form">
                                        @csrf
                                        <input type="text" name="first_name" placeholder="{{ translation('FIRST_NAME') }}" />
                                        @error('first_name')
                                        <strong class="text-danger mb-5">{{ $message }}</strong>
                                        @enderror
                                        <input type="text" name="last_name" placeholder="{{ translation('LAST_NAME') }}" />
                                        @error('last_name')
                                        <strong class="text-danger mb-5">{{ $message }}</strong>
                                        @enderror
                                        <input name="email"  type="email"  placeholder="{{ translation('REG_EMAIL') }}"/>
                                        @error('email')
                                        <strong class="text-danger mb-5">{{ $message }}</strong>
                                        @enderror
                                        <input type="password" name="password" placeholder="{{ translation('REG_PASSWORD') }}" />
                                        @error('password')
                                        <strong class="text-danger mb-5">{{ $message }}</strong>
                                        @enderror
                                        <div class="button-box">
                                            <button type="submit"><span>{{ translation('REGISTER') }}</span></button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')

<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
<script>
    $(document).ready(function() {
        $('#register_form').validate({
            rules: {
                first_name: {
                    required: true
                },
                last_name: {
                    required: true
                },
                email: {
                    required: true,
                    email: true,
                    maxlength: 50
                },
                password: {
                    minlength: 8,
                    required: true
                },
            },
            messages: {
                first_name: {
                    required: "Please enter first name",
                },
                last_name: {
                    required: "Please enter last name",
                },
                email: {
                    required: "Please enter email",
                    email: "Please enter valid email address",
                    maxlength: "Email cannot be more than 50 characters",
                },
                password: {
                    required: "Please enter password",
                    minlength: "Password must be at least 8 characters"
                },
            },
        });
    });
</script>
@endpush --}}

<div class="col-sm-12 col-md-12 col-lg-7 mx-auto p-5">
    <section class="contact-layout4 py-0">
      <div class="contact-panel">
        <form class="contact-panel__form" method="post" action="{{ route('register') }}" id="register_form">
            @csrf
          <div class="row">
            <div class="col-12">
                <h3 class="contact-panel__title  text-center">{{ translation('REGISTRATION') }}</h3>
              <div class="mt-4 pt-4 border-top"></div>
            </div><!-- /.col-12 -->
            <div class="col-sm-6">
              <div class="form-group">
                <label for="name">Name  <span class="text-danger">*</span></label>
                <input type="text" class="form-control" placeholder="{{ translation('NAME') }}" name="first_name" id="first_name">
                @error('first_name')
                <strong class="text-danger mb-5">{{ $message }}</strong>
                @enderror
              </div>
            </div><!-- /.col-lg-6 -->
            <div class="col-sm-6">
              <div class="form-group">
                <label for="email">Email <span class="text-danger">*</span></label>
                <input type="text" name="email" class="form-control" placeholder="{{ translation('REG_EMAIL') }}" name="email" id="email">
                @error('email')
                <strong class="text-danger mb-5">{{ $message }}</strong>
                @enderror  
            </div>
            </div><!-- /.col-lg-6 -->
            <div class="col-sm-6">
                <div class="form-group">
                  <label for="phone">Contact No <span class="text-danger">*</span></label>
                  <input type="text" class="form-control" placeholder="{{ translation('CONTACT') }}" name="contact" id="contact">
                  @error('contact')
                  <strong class="text-danger mb-5">{{ $message}}</strong>
                  @enderror
                </div>
              </div><!-- /.col-lg-6 -->
            <div class="col-6">
              <div class="form-group">
                <label for="street">Password  <span class="text-danger">*</span></label>
                <input type="password" class="form-control" placeholder="{{ translation('REG_PASSWORD') }}"  id="password" name="password">
                @error('password')
                <strong class="text-danger mb-5">{{ $message }}</strong>
                @enderror 
            </div>
            </div><!-- /.col-12 -->
            <div class="col-12">
              <button type="submit"
                class="btn btn__secondary btn__block btn__xhight d-flex justify-content-between mt-10">
                <span>{{ translation('REGISTER') }}</span> <i class="icon-arrow-right icon-outlined"></i>
              </button>
              <div class="contact-result"></div>
            </div>
          </div><!-- /.row -->
        </form>
        <p class=" mt-3">Already have an account ? <a href="{{url('/login')}}"><span class="text-warning"><b>{{ translation('LOGIN') }}</b></span></a></p>
      </div><!-- /.contact-panel -->
    </section><!-- /.contact layout 4 -->
  </div><!-- /.col-lg-8 -->

  @push('scripts')

<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
<script>
    $(document).ready(function() {
        $('#register_form').validate({
            rules: {
                first_name: {
                    required: true
                },
                contact: {
                    required: true,
                    // number: true
                },
                email: {
                    required: true,
                    email: true,
                    // maxlength: 50
                },
                password: {
                    minlength: 8,
                    required: true
                },
            },
            messages: {
                first_name: {
                    required: "Please enter first name",
                },
                contact: {
                    required: "Please enter contact number",
                    // number: "Please enter valid contact number",

                },
                email: {
                    required: "Please enter email",
                    email: "Please enter valid email address",
                    // maxlength: "Email cannot be more than 50 characters",
                },
                password: {
                    required: "Please enter password",
                    minlength: "Password must be at least 8 characters"
                },
            },

            errorElement: 'span',
            errorPlacement: function (error, element) {
              error.addClass('invalid-feedback');
              element.closest('.form-group').append(error);
            },
            highlight: function (element, errorClass, validClass) {
              $(element).addClass('is-invalid');
            },
            unhighlight: function (element, errorClass, validClass) {
              $(element).removeClass('is-invalid');
            }

        });
    });
</script>
@endpush 