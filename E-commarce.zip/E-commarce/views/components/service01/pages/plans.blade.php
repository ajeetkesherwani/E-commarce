<!-- ========================
       page title
    =========================== -->
<section class="page-title-layout4 page-title-light bg-overlay bg-parallax text-center">
    <div class="bg-img"><img src="assets/images/page-titles/11.jpg" alt="background"></div>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="pagetitle__heading">Our Pricing</h1>
                <nav>
                    <ol class="breadcrumb justify-content-center mb-0">
                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Pricing</li>
                    </ol>
                </nav>
            </div><!-- /.col-12 -->
        </div><!-- /.row -->
    </div><!-- /.container -->
</section><!-- /.page-title -->

<!-- =========================
        Pricing
        =========================== -->
<section class="pricing-layout1 pb-80">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-6 offset-lg-3">
                <div class="heading text-center mb-40">
                    <h2 class="heading__subtitle">Our Pricing And Plans</h2>
                    <h3 class="heading__title">Effective & Flexible Pricing
                        That Adapts Your Needs</h3>
                </div><!-- /.heading -->
            </div><!-- /.col-lg-6 -->
        </div><!-- /.row -->

        {{-- Plan Tabel start here --}}
        <form action="{{ url('/service-checkout') }}" method="post" class="chekoutForm">
            @csrf
         
            @guest
            @if (getSetting('plan_buy_option') == 'checkout')
            @if (getSetting('plan_guest_checkout')=='yes')
            <button type="submit" class="btn btn-primary  float-right submitbtn" role="button">Buy
                Now</button>
            @else
            <button type="button" class="btn btn-primary planLoginbtn  float-right" data-source="checkout" role="button">Buy
                Now</button>
            @endif
            @endif
            @if (getSetting('plan_buy_option') =='enquiry')
            <button type="button" class="btn btn-primary  float-right" id="enquiryNowBtn" value="{{ $planVal->plan_id }}" role="button">Enquiry Now</button>
            @endif
            @endguest

            @auth
            @if (getSetting('plan_buy_option') == 'checkout')
            <button type="submit" class="btn btn-primary  float-right submitbtn" role="button">Buy
                Now</button>
            @endif
            @if (getSetting('plan_buy_option') =='enquiry')
            <button type="button" class="btn btn-primary  float-right" id="enquiryNowBtn" value="{{ $planVal->plan_id }}" role="button">Enquiry Now</button>
            @endif
            @endauth
            <input type="hidden" name="pricing_id" id="pricing_id" value="">

        <table class="table table-bordered text-center table-responsive" style="display: inline-table">
            <thead>
                <tr>
                    <th scope="row"></th>
                    @foreach ($PlanData as $planKey => $planVal)
                    {{-- @php
                    $price = App\Models\Listing\Services\PlanSevices::planToAmount($planVal->plan_id);
                    @endphp --}}
                    <th scope="col" title="{!! $planVal->plan_desc ?? '' !!}">
                        {{ $planVal->plan_name ?? '' }}<br />
                    </th>
                    @endforeach
                </tr>
            </thead>
            <th></th>
        
            @foreach ($PlanData as $planKey => $planVal)
            <th scope="row">
              @if (!empty($planVal->plan_pricing))
                <select class="form-select w-85 mx-auto" aria-label="Default  example">
                    <option selected value="select">Select Plans</option>
                    @foreach ($planVal->plan_pricing as $planPricing)
                    <option value="{{ $planPricing->id }}">$
                        {{ $planPricing->plan_price }}/{{ $planPricing->plan_duration }}
                        months</option>
                    @endforeach
                </select>
                @endif
            </th>
            @endforeach
            {{-- </tr>

            </tr> --}}
            @foreach ($FeatureData as $featKey => $featVal)
            @if (!empty($featVal->feature_status))
            <tr>
                <td>{{ $featVal->feature_title ?? '' }}</td>
                @foreach ($featVal->feature_status as $avKey => $avVal)
                @if ($avVal->status == 'yes')
                <td><i class="fa fa-check text-success" aria-hidden="true"></i></td>
                @else
                <td><i class="fa fa-times text-danger" aria-hidden="true"></i></td>
                @endif
                @endforeach
            </tr>
            @endif
            @endforeach
           
            <th></th>
        
            @foreach ($PlanData as $planKey => $planVal)
            <th scope="row">
              @if (!empty($planVal->plan_pricing))
                <select class="form-select w-85 mx-auto" aria-label="Default  example">
                    <option selected value="select">Select Plans</option>
                    @foreach ($planVal->plan_pricing as $planPricing)
                    <option value="{{ $planPricing->id }}">$
                        {{ $planPricing->plan_price }}/{{ $planPricing->plan_duration }}
                        months</option>
                    @endforeach
                </select>
                @endif
            </th>
            @endforeach
            

        </table>
        @guest
        @if (getSetting('plan_buy_option') == 'checkout')
        @if (getSetting('plan_guest_checkout')=='yes')
        <button type="submit" class="btn btn-primary  float-right submitbtn" role="button">Buy
            Now</button>
        @else
        <button type="button" class="btn btn-primary planLoginbtn  float-right" data-source="checkout" role="button">Buy
            Now</button>
        @endif
        @endif
        @if (getSetting('plan_buy_option') =='enquiry')
        <button type="button" class="btn btn-primary  float-right" id="enquiryNowBtn" value="{{ $planVal->plan_id }}" role="button">Enquiry Now</button>
        @endif
        @endguest

        @auth
        @if (getSetting('plan_buy_option') == 'checkout')
        <button type="submit" class="btn btn-primary  float-right submitbtn" role="button">Buy
            Now</button>
        @endif
        @if (getSetting('plan_buy_option') =='enquiry')
        <button type="button" class="btn btn-primary  float-right" id="enquiryNowBtn" value="{{ $planVal->plan_id }}" role="button">Enquiry Now</button>
        @endif
        @endauth
    </form>
        {{-- Plan Tabel end here --}}


        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-6 offset-lg-3 text-center">
                <div class="col-12">
                    <p class="text__link mb-0">For a cleaning that meets your highest standards, you need a
                        dedicated team of
                        trained specialists. We arrive at each visit with all supplies needed to thoroughly clean
                        your home with
                        our extensive Cleaning Process.
                        <a href="services.html" class="btn btn__secondary btn__link mx-1">
                            <span>Contact Us For More Information</span> <i class="icon-arrow-right icon-outlined"></i>
                        </a>
                    </p>
                </div><!-- /.col-12 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
</section><!-- /.pricing  -->

<!-- ======================
        Portfolio
      ========================= -->
<section class="portfolio-carousel portfolio-layout1 bg-primary">
    <div class="container">
        <div class="row heading heading-light mb-70">
            <div class="col-12">
                <h2 class="heading__subtitle">Industries We Serve </h2>
            </div>
            <div class="col-sm-12 col-md-12 col-lg-5">
                <h3 class="heading__title">Helping Different Industries And All Types Of Facilities</h3>
            </div><!-- /.col-lg-5 -->
            <div class="col-sm-12 col-md-12 col-lg-6 offset-lg-1">
                <p class="heading__desc font-weight-bold mb-30">For additional safety and protection for everyone,
                    our teams
                    are
                    provided with
                    masks and gloves to use while cleaning your home. And, our professional grade product line up
                    includes
                    cleaners that meet the EPA's criteria for use against the Coronavirus, as well as other germs
                    that may be
                    lurking in your home.</p>
                <div class="d-flex align-items-center">
                    <a href="contact-us.html" class="btn btn__white btn__outlined mr-30">
                        <span>Request An Estimate</span><i class="icon-arrow-right"></i>
                    </a>
                    <a class="video__btn video__btn-white popup-video" href="https://www.youtube.com/watch?v=jwiIzNIK4dg">
                        <div class="video__player">
                            <i class="fa fa-play"></i>
                        </div>
                        <span class="video__title color-white">Our Video !</span>
                    </a>
                </div>
            </div><!-- /.col-lg-6 -->
        </div><!-- /.row -->
        <div class="row">
            <div class="col-12">
                <div class="carousel-container">
                    <div class="slick-carousel carousel-arrows-light carousel-dots-light" data-slick='{"slidesToShow": 3, "slidesToScroll": 3, "autoplay": false, "arrows": true, "dots": true, "responsive": [ {"breakpoint": 992, "settings": {"slidesToShow": 2,"slidesToScroll": 2}}, {"breakpoint": 767, "settings": {"slidesToShow": 1,"slidesToScroll": 1}}, {"breakpoint": 480, "settings": {"slidesToShow": 1,"slidesToScroll": 1}}]}'>
                        <!-- portfolio Item #1 -->
                        <div class="portfolio-item">
                            <div class="portfolio__img">
                                <img src="assets/images/portfolio/1.jpg" alt="portfolio image">
                            </div><!-- /.portfolio__img -->
                            <div class="portfolio__body">
                                <h4 class="portfolio__title">Manufacturing Facilities</h4>
                                <p class="portfolio__desc">We listen to your needs and respond with a customized
                                    plan specific to
                                    you,
                                    scheduled to best fit your business operations...
                                </p>
                                <a href="portfolio-single.html" class="btn btn__primary btn__link">
                                    <i class="icon-arrow-right icon-filled"></i>
                                    <span>Read More</span>
                                </a>
                            </div><!-- /.portfolio__body -->
                        </div><!-- /.portfolio-item -->
                        <!-- portfolio Item #2 -->
                        <div class="portfolio-item">
                            <div class="portfolio__img">
                                <img src="assets/images/portfolio/2.jpg" alt="portfolio image">
                            </div><!-- /.portfolio__img -->
                            <div class="portfolio__body">
                                <h4 class="portfolio__title">Educational Facilities</h4>
                                <p class="portfolio__desc">Our educational facility cleaning experts are backed by
                                    over six decades
                                    of
                                    experience and understand the unique requirements of...
                                </p>
                                <a href="portfolio-single.html" class="btn btn__primary btn__link">
                                    <i class="icon-arrow-right icon-filled"></i>
                                    <span>Read More</span>
                                </a>
                            </div><!-- /.portfolio__body -->
                        </div><!-- /.portfolio-item -->
                        <!-- portfolio Item #3 -->
                        <div class="portfolio-item">
                            <div class="portfolio__img">
                                <img src="assets/images/portfolio/3.jpg" alt="portfolio image">
                            </div><!-- /.portfolio__img -->
                            <div class="portfolio__body">
                                <h4 class="portfolio__title">Medical Facilities</h4>
                                <p class="portfolio__desc">Along with creating a clean, welcoming for each patient,
                                    our
                                    Patient-Centered
                                    Cleaning Program is designed to help you exceed expectations...
                                </p>
                                <a href="portfolio-single.html" class="btn btn__primary btn__link">
                                    <i class="icon-arrow-right icon-filled"></i>
                                    <span>Read More</span>
                                </a>
                            </div><!-- /.portfolio__body -->
                        </div><!-- /.portfolio-item -->
                        <!-- portfolio Item #4 -->
                        <div class="portfolio-item">
                            <div class="portfolio__img">
                                <img src="assets/images/portfolio/4.jpg" alt="portfolio image">
                            </div><!-- /.portfolio__img -->
                            <div class="portfolio__body">
                                <h4 class="portfolio__title">Financial Institutions</h4>
                                <p class="portfolio__desc">As for our cleaning products, we use green cleaners that
                                    are effective
                                    without leaving behind any bothersome odors. We will also make sure that we use
                                    the appropriate
                                    cleaners and methods for sensitive areas of your facility.
                                </p>
                                <a href="portfolio-single.html" class="btn btn__primary btn__link">
                                    <i class="icon-arrow-right icon-filled"></i>
                                    <span>Read More</span>
                                </a>
                            </div><!-- /.portfolio__body -->
                        </div><!-- /.portfolio-item -->
                        <!-- portfolio Item #5 -->
                        <div class="portfolio-item">
                            <div class="portfolio__img">
                                <img src="assets/images/portfolio/5.jpg" alt="portfolio image">
                            </div><!-- /.portfolio__img -->
                            <div class="portfolio__body">
                                <h4 class="portfolio__title">Government Buildings</h4>
                                <p class="portfolio__desc">With our highly skilled, experienced cleaning
                                    technicians, you can be
                                    sure
                                    your place of worship is in the best hands to keep it beautiful and welcoming.
                                </p>
                                <a href="portfolio-single.html" class="btn btn__primary btn__link">
                                    <i class="icon-arrow-right icon-filled"></i>
                                    <span>Read More</span>
                                </a>
                            </div><!-- /.portfolio__body -->
                        </div><!-- /.portfolio-item -->
                        <!-- portfolio Item #6 -->
                        <div class="portfolio-item">
                            <div class="portfolio__img">
                                <img src="assets/images/portfolio/6.jpg" alt="portfolio image">
                            </div><!-- /.portfolio__img -->
                            <div class="portfolio__body">
                                <h4 class="portfolio__title">Religious Building</h4>
                                <p class="portfolio__desc">We’ll work with you to fully understand needs,
                                    accommodate any special
                                    requests and avoid any areas that you indicate.
                                </p>
                                <a href="portfolio-single.html" class="btn btn__primary btn__link">
                                    <i class="icon-arrow-right icon-filled"></i>
                                    <span>Read More</span>
                                </a>
                            </div><!-- /.portfolio__body -->
                        </div><!-- /.portfolio-item -->
                    </div><!-- /.carousel -->
                    <a href="industries.html" class="view-projects">All Industries</a>
                </div><!-- /.carousel-container -->
            </div><!-- /.col-12 -->
        </div><!-- /.row -->
    </div><!-- /.container -->
</section><!-- /.portfolio -->

<!-- ======================
       Work Process
      ========================= -->
<section class="work-process-layout1">
    <div class="bg-img"><img src="assets/images/backgrounds/1.png" alt="background"></div>
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-6 offset-lg-3">
                <div class="heading text-center mb-40">
                    <h2 class="heading__subtitle">See How It Works!</h2>
                    <h3 class="heading__title">Easy Steps For A Clean And <br> Healthy Environment</h3>
                </div><!-- /.heading -->
            </div><!-- /.col-lg-6 -->
        </div><!-- /.row -->
        <div class="row process-row">
            <!-- process item #1 -->
            <div class="col-sm-6 col-md-6 col-lg-3">
                <div class="process-item text-center">
                    <div class="circle__icon"></div>
                    <div class="check__icon">
                        <i class="icon-checkmark"></i>
                    </div>
                    <h4 class="process__title">Provide Us With The Details</h4>
                    <p class="process__desc">Just provide us the timing you want and we will set our schedule
                        according to
                        your need.</p>
                    <div class="process__icon">
                        <i class="icon-mop"></i>
                    </div><!-- /.process__icon -->
                </div><!-- /.process-item -->
            </div><!-- /.col-lg-3 -->
            <!-- process item #2 -->
            <div class="col-sm-6 col-md-6 col-lg-3">
                <div class="process-item text-center">
                    <div class="circle__icon"></div>
                    <div class="check__icon">
                        <i class="icon-checkmark"></i>
                    </div>
                    <h4 class="process__title">Pick The Suitable Plan For You</h4>
                    <p class="process__desc">We come to you to inspect the area to prepare it for disinfection, and
                        to take
                        into concern.</p>
                    <div class="process__icon">
                        <i class="icon-sponge"></i>
                    </div><!-- /.process__icon -->
                </div><!-- /.process-item -->
            </div><!-- /.col-lg-3 -->
            <!-- process item #3 -->
            <div class="col-sm-6 col-md-6 col-lg-3">
                <div class="process-item text-center">
                    <div class="circle__icon"></div>
                    <div class="check__icon">
                        <i class="icon-checkmark"></i>
                    </div>
                    <h4 class="process__title">Online Scheduling In Few Clicks</h4>
                    <p class="process__desc">We carry out the disinfection during couple of hours depending on
                        house size and
                        amount.</p>
                    <div class="process__icon">
                        <i class="icon-tap"></i>
                    </div><!-- /.process__icon -->
                </div><!-- /.process-item -->
            </div><!-- /.col-lg-3 -->
            <!-- process item #4 -->
            <div class="col-sm-6 col-md-6 col-lg-3">
                <div class="process-item text-center">
                    <div class="circle__icon"></div>
                    <div class="check__icon">
                        <i class="icon-checkmark"></i>
                    </div>
                    <h4 class="process__title">Cleaning With Care & leave quickly</h4>
                    <p class="process__desc">We carry out the disinfection during couple of hours depending on
                        house size and
                        amount.</p>
                    <div class="process__icon">
                        <i class="icon-vacuum-cleaner"></i>
                    </div><!-- /.process__icon -->
                </div><!-- /.process-item -->
            </div><!-- /.col-lg-3 -->
        </div><!-- /.row -->
        <div class="row">
            <div class="col-12 text-center">
                <p class="text__link mt-40 mb-0">Dedicated team of trained specialist.
                    <a href="team.html" class="btn btn__secondary btn__link mx-1">
                        <span>Meet Our Experts</span> <i class="icon-arrow-right"></i>
                    </a>
                </p>
            </div><!-- /.col-12 -->
        </div><!-- /.row -->
    </div><!-- /.container -->
</section><!-- /.Work Process -->

<!-- ======================
       Clients
      ========================= -->
<section class="clients pt-50 pb-50">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-sm-12 col-md-4 col-lg-4">
                <p class="font-weight-bold color-secondary my-3">
                    Clanora’s trust ensures every service we offer will get your home cleaner and healthier, to your
                    exact
                    needs.
                </p>
            </div>
            <div class="col-sm-12 col-md-4 col-lg-8">
                <div class="slick-carousel" data-slick='{"slidesToShow": 4, "arrows": false, "dots": false, "autoplay": true,"autoplaySpeed": 2000, "infinite": true, "responsive": [ {"breakpoint": 992, "settings": {"slidesToShow": 3}}, {"breakpoint": 767, "settings": {"slidesToShow": 2}}, {"breakpoint": 480, "settings": {"slidesToShow": 2}}]}'>
                    <div class="client">
                        <img src="assets/images/clients/1.png" alt="client">
                        <img src="assets/images/clients/1.png" alt="client">
                    </div><!-- /.client -->
                    <div class="client">
                        <img src="assets/images/clients/2.png" alt="client">
                        <img src="assets/images/clients/2.png" alt="client">
                    </div><!-- /.client -->
                    <div class="client">
                        <img src="assets/images/clients/3.png" alt="client">
                        <img src="assets/images/clients/3.png" alt="client">
                    </div><!-- /.client -->
                    <div class="client">
                        <img src="assets/images/clients/4.png" alt="client">
                        <img src="assets/images/clients/4.png" alt="client">
                    </div><!-- /.client -->
                    <div class="client">
                        <img src="assets/images/clients/5.png" alt="client">
                        <img src="assets/images/clients/5.png" alt="client">
                    </div><!-- /.client -->
                    <div class="client">
                        <img src="assets/images/clients/6.png" alt="client">
                        <img src="assets/images/clients/6.png" alt="client">
                    </div><!-- /.client -->
                    <div class="client">
                        <img src="assets/images/clients/7.png" alt="client">
                        <img src="assets/images/clients/7.png" alt="client">
                    </div><!-- /.client -->
                </div><!-- /.carousel -->
            </div><!-- /.col-lg-6 -->
        </div><!-- /.row -->
    </div><!-- /.container -->
</section><!-- /.Clients -->

{{-- Attach Modal View --}}

<x-Service01.Pages.Modal />

@push('scripts')
<script>
    $(document).ready(function() {

        // work on plan select dropdown one time only one  plan select

        $('select').change(function () {
                if ($(this).val() == 'select') {
                    $('#pricing_id').val('')
                } else {
                    $('#pricing_id').val($(this).val());
                    // $(".planLoginbtn").prop('disabled', false);
                    // $(".submitbtn").prop('disabled', false);
                    $("select").not(this)[0].selectedIndex = 0;
                    $("select").not(this)[1].selectedIndex = 0;
                    $("select").not(this)[2].selectedIndex = 0;
                    $("select").not(this)[3].selectedIndex = 0;
                    $("select").not(this)[4].selectedIndex = 0;
                }
            });

        $(document).on('click', '.submitbtn', function (e) {
                e.preventDefault()
                if ($('#pricing_id').val() == '') {
                    swal("Please Select A Plan");
                }
                else {
                    $('.chekoutForm').submit();
                }
            });


        $(document).on('click', '#enquiryNowBtn', function(e) {
            var plan_id = $(this).attr('value');
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "/plan_detail",
                data: {
                    'plan_id': plan_id
                },
                dataType: "json",
                success: function(response) {
                    var text = "Enquiry for" + " " + response.data.plan_name;
                    var plan_id = response.data.plan_id;

                    $('#enq_plan_id').val(plan_id);
                    $('#EnquryForm-title').html(text);
                    var text = '';
                    var plan_id = '';
                    $("#planEnquiryModal").modal('show');
                }
            })
        });

        $(document).on('click', '#enquirymodalformbutton', function(e) {
            e.preventDefault();
            let enquiryform = document.getElementById('enquiryform');
            let formData = new FormData(enquiryform);


            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "/storePlanEnquiry",
                data: formData,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function(response) {
                    if (response.status == 400) {
                        $.each(response.error, function(key, err_val) {
                            $('#' + 'enqerr_' + key).text(err_val);
                        });
                    } else {
                        $('#planEnquiryModal').modal('hide');
                        $('#enquiryform').trigger("reset");
                        Notify('Send Successfully', true);
                    }
                }

            });
        });

    });
</script>
@endpush