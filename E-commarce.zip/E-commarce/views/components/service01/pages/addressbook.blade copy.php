@push('styles')
@endpush
@php

$main_arr = [
    'title' => 'Address Book',
    'sublist' => [
        [
            'name' => 'HOME',
            'link' => url('/'),
        ],
        [
            'name' => 'Addresses',
            'link' => url(' '),
        ],
    ],
];
@endphp

<x-Service01.SharedComponent.BreadCrumb :data="$main_arr" />
<!-- section area start -->


<!-- ===================== -->
<section>
    <div class="container">
        <div class="row">
            <x-Service01.SharedComponent.left-side-menu />
            <div class="col-lg-8 col-sm-12">
                <div class="account_page_detail ">
                    <h4 class="account_page__title ">Address</h4>
                    <div class="start-btn">
                        <button  class="ui-button ui-corner-all ui-widget btn btn__primary addNewAdd">Add New
                            Address</button>
                        <!-- <a href="#" class="btn btn__primary "> <i class="fa-solid fa-plus"></i> Add New Address</a> -->
                    </div>

                    <div class="row">
                        <div class="col-lg-6 col-md-6 pb-2">
                            <div class=" p-3 service_detail shadow ">

                                <h6 class="mb-0">Apartment Cleaning</h6>
                                zosijoto@mailinator.com<br>
                                8938384066<br>
                                Dolores enim dolor c, Culpa odit id sed<br>
                                Non qui beatae quide

                            </div>
                            <div class="d-flex justify-content-between mt-3">
                                <a href="" class="">
                                    Edit
                                </a>

                                <div class="button btn btn__secondary">
                                    <a href="">Set Default</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ==== -->
                    <div class="row col-lg-6 col-md-6">
                    </div>
                    <!-- === -->
                </div>
            </div>
        </div>
    </div>
</section>

<x-Service01.Pages.Modal />

@push('scripts')
    <script>
        $(document).ready(function() {

            // Load Address
            function loadaddresss() {
                $.ajax({
                    url: "{{ url('account/load-address') }}",
                    type: "GET",
                    dataType: 'json',
                    success: function(response) {
                        var addressBook = '';
                        console.log(response.data.buss_user_to__info);
                        $.each(response.data.buss_user_to__info, function(key, infoVal) {
                            var is_default = infoVal.billing_default;
                            checked = '';
                            if (is_default == 1) checked = "checked";

                            addressBook += `<div class="col-lg-6 ">
                              <div class="addressboxes_container shadow">
                                    <div class="px-3">
                                        <h6>${infoVal.billing_contact_name}</h6>
                                        ${infoVal.billing_email}<br/>
                                        ${infoVal.billing_phone}<br/>
                                        ${infoVal.billing_street_address}, ${infoVal.billing_city}<br/>
                                        ${infoVal.billing_state} , ${infoVal.billing_country}<br/>
                                        ${infoVal.billing_zipcode}
                                        <div class="d-flex justify-content-between mt-2">
                                          <a href="javascript:void(0)" class="delete_address" id="delete_add_id" value="${infoVal.business_info_id}">
                                            <i class="uil uil-trash-alt h5 align-middle  mb-0"></i>
                                            </a>
                                          <div>
                                            <a href="javascript:void(0)" class="edit_address" value="${infoVal.business_info_id}">
                                              <i class="uil uil-edit-alt h5 align-middle  mb-0"></i>
                                              </a>
                                          </div>
                                          <div class="form-check form-switch">
                                            <input class="form-check-input mySwitch" type="checkbox" role="switch" id="flexSwitchCheckChecked" value="${infoVal.business_info_id}" ${checked}>
                                          Make Default</div>
                                        </div>
                                    </div>
                                </div>
                            </div>`;
                        });
                        $('#addressboxes').html('');
                        $('#addressboxes').append(addressBook);
                    }
                });
            }

            // load all address through ajax
            loadaddresss();

            // add address function  ajax
            $(document).on('click', '#AddNewAddress', function(e) {
                e.preventDefault();
                var data = {
                    'first_name': $('#AC_firstName').val(),
                    'billing_email': $('#AC_email').val(),
                    'billing_phone': $('#AC_phone').val(),
                    'billing_street_address': $('#AC_address').val(),
                    'billing_city': $('#AC_city').val(),
                    'billing_state': $('#AC_state').val(),
                    'billing_country': $('#AC_country').val(),
                    'billing_zipcode': $('#AC_zip').val(),
                    'business_id': $('#AC_bussinessInfoData').val(),
                }
                //console.log(data);
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{ url('account/add-address') }}",
                    data: data,
                    dataType: "json",
                    success: function(response) {
                        if (response.status == 400) {
                            $.each(response.error, function(key, err_val) {
                                $('#add_' + key).text(err_val);
                            });
                        } else {
                            $('#AddNewLoginAddress').modal('hide');
                            $('#NewAcaddress').trigger("reset");
                            loadaddresss();
                            swal("Success", "Address Added Successfully.", "success");
                        }
                    }

                });
            });


            //delete modal
            $(document).on("click", ".delete_address", function(e) {
                e.preventDefault();
                var addId = $(this).attr('value');
                $('#delete_add_id').val(addId);
                $('#DeleteAddressModal').modal('show');
            });

            // final delete
            $(document).on("click", ".delete_add_cnf", function(e) {
                e.preventDefault();
                var business_info_id = $('#delete_add_id').val();
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    url: "{{ url('account/delete-address/') }}",
                    type: "POST",
                    data: {
                        business_info_id: business_info_id
                    },
                    success: function(response) {
                        if (response.status == 200) {
                            $('#DeleteAddressModal').modal('hide');
                            loadaddresss();
                            swal("Success", "Address Deleted Successfully.", "success");
                        }
                    }
                });
            });

            // Edit


            //Edit Address
            $(document).on("click", ".edit_address", function(e) {
                e.preventDefault();
                var addrsId = $(this).attr('value');;
                $('#updateAddressModal').modal('show');
                var url = `{{ url('account/address/${addrsId}/edit') }}`;

                $.ajax({
                    url: url,
                    type: "GET",
                    success: function(response) {
                        //console.log(response);
                        if (response.status == 400) {
                            $('#errorlist').html("");
                            $('#errorlist').addClass("alert alert-danger");
                            $('#errorlist').append('<p>' + response.message + '</p>');
                        } else {
                            $.each(response.addressdata, function(key, adds_val) {
                                $('#' + key).val(adds_val);
                            });
                        }
                    }
                });

            });

            // Update Address

            $(document).on("click", "#updateAddressButton", function(e) {
                e.preventDefault();
                var data = {
                    'billing_contact_name': $('#billing_contact_name').val(),
                    'billing_email': $('#billing_email').val(),
                    'billing_phone': $('#billing_phone').val(),
                    'billing_street_address': $('#billing_street_address').val(),
                    'billing_city': $('#billing_city').val(),
                    'billing_state': $('#billing_state').val(),
                    'billing_country': $('#billing_country').val(),
                    'billing_zipcode': $('#billing_zipcode').val(),
                    'business_id': $('#bussinessInfoData').val(),
                    'business_info_id': $('#business_info_id').val(),
                }

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{ url('account/update-address') }}",
                    data: data,
                    dataType: "json",
                    success: function(response) {
                        console.log(response);
                        if (response.status == 400) {
                            $.each(response.error, function(key, err_val) {
                                $('#up_' + key).text(err_val);
                            });
                        } else {
                            $('#updateAddressModal').modal('hide');
                            loadaddresss();
                            swal("Success", "Address Updated Successfully.", "success");
                        }
                    }
                });
            });

            // Make default address 

            var switchStatus = false;
            $(document).on('click', '.mySwitch', function() {
                if ($(this).is(':checked')) {
                    var data = {
                        'business_info_id': $(this).val(),
                        'business_id': $('#bussinessInfoData').val(),
                    }
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        type: "POST",
                        url: "{{ url('account/makedefault-address') }}",
                        data: data,
                        dataType: "json",
                        success: function(response) {
                            console.log(response);
                            if (response.status == 400) {
                                Notify('Some thing error !', false);
                                loadaddresss();
                            } else {
                                loadaddresss();
                                swal("Success", "Default Address Updated Successfully",
                                    "success");
                            }

                        }
                    });
                }
            });

        });
    </script>
@endpush
