@php

$main_arr = [
  'title'=>'Blog Post',
  'sublist' => [
    [
    'name'=>'HOME',
    'link'=>url("/")
    ],
    [
    'name'=>$blogDetail->post_title ,
    'link'=>url("")
    ], 
  ]
];
$currentURL = URL::current();
$url_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$url_segments = explode('/', $url_path);
$url_segment=$url_segments[2]; 
@endphp


<x-Service01.SharedComponent.BreadCrumb :data="$main_arr" /> 

    
 <!-- ======================
      Blog Single
    ========================= -->
    <section class="blog blog-single pt-20 pb-80">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 col-md-12 col-lg-8">
            <div class="post-item mb-0">
              <div class="post__img">
                <a href="javascript:void(0)">
                  <img src="{{getFullImageUrl($blogDetail->img)}}" alt="{{ $blogDetail->post_title ?? '' }}" loading="lazy">
                </a>
              </div><!-- /.post-img -->
              <div class="post__body pb-0">
                <div class="post__meta d-inline-flex">
                  <div class="post__meta-cat">
                    <a href="#">Cleaning</a>
                    <a href="#">Disinfecting</a>
                  </div><!-- /.blog-meta-cat -->
                  <span class="post__meta-date">{{ date("d M, Y",
                                        strtotime($blogDetail->created_at)) }}</span>
                  <div class="post__meta-author">By <a href="#">Admin</a></div>
                  <div class="post__meta-comments">comments <a href="#">3</a></div>
                </div>
                <h1 class="post__title mb-30">
                {{ $blogDetail->post_title ?? '' }}
                </h1>
                <div class="post__desc">
                  <p>{!! $blogDetail->post_content ?? '' !!}</p>
                </div><!-- /.post-desc -->
           
              </div>
            </div><!-- /.post-item -->
            <div class="d-flex flex-wrap justify-content-between border-bottom pt-30 pb-30 mb-40">
              <!-- <div class="widget-tags">
                <ul class="list-unstyled d-flex flex-wrap mb-0">
                  <li><a href="#">Consulting</a></li>
                  <li><a href="#">Tech</a></li>
                  <li><a href="#">Employee</a></li>
                </ul>
              </div> -->
              <!-- /.blog-tags -->
              <div class="blog-share d-flex flex-wrap align-items-center">
                <strong class="mr-20 color-heading">Share</strong>
                <ul class="list-unstyled social-icons d-flex mb-0">
                  <li><a href="https://www.facebook.com/sharer/sharer.php?u={{ $currentURL }}" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                  <li><a href="https://twitter.com/intent/tweet?text={{ $currentURL }}"
                                        target="_blank"><i class="fab fa-twitter"></i></a></li>
                  <li><a href="https://api.whatsapp.com/send?text={{ $currentURL }}"
                                target="_blank"><i class="fab fa-whatsapp"></i></a></li>
                </ul>
              </div><!-- /.blog-share -->
            </div>
            <!-- <div class="widget-nav d-flex justify-content-between mb-40">
              <a href="#" class="btn btn__secondary btn__outlined">
                <i class="icon-arrow-left"></i>
                <span>Previous Post</span>
              </a>
              <a href="#" class="btn btn__secondary btn__outlined">
                <span>Next Post</span>
                <i class="icon-arrow-right"></i>
              </a>
            </div> -->
          </div><!-- /.col-lg-8 -->
          <div class="col-sm-12 col-md-12 col-lg-4">
            <aside class="sidebar has-marign-left">
              <div class="widget widget-search bg-primary">
                <h5 class="widget__title color-white">Search</h5>
                <div class="widget__content" id="searchBody">
                  <form class="widget__form-search">
                    <input type="text" class="form-control" id="search" placeholder="Search...">
                    <button class="btn" type="submit" id="search"><i class="icon-search"></i></button>
                  </form>
                </div><!-- /.widget-content -->
              </div><!-- /.widget-search -->
              <div class="widget widget-posts">
                <h5 class="widget__title mb-10">Recent Posts</h5>
                <div class="widget__content">
                @if (!empty($recentPost))
                  @foreach ($recentPost as $blog)
                  <!-- post item #1 -->
                  <div class="widget-post-item d-flex align-items-center">
                    <div class="widget-post__img">
                      <a href="{{ url('blog/'.$blog->slug) }}"><img src="{{getFullImageUrl($blog->img)}}" alt="{{ $blog->post_title ?? '' }}"></a>
                    </div><!-- /.widget-post-img -->
                    <div class="widget-post__content">
                      <span class="widget-post__date">{{ date("F d, Y", strtotime($blog->created_at)) }}</span>
                      <h4 class="widget-post__title"><a href="{{ url('blog/'.$blog->slug) }}">{{ $blog->post_title ?? '' }}</a>
                      </h4>
                    </div><!-- /.widget-post-content -->
                  </div><!-- /.widget-post-item -->
                  @endforeach
                @endif 
                </div><!-- /.widget-content -->
              </div><!-- /.widget-posts -->
            </aside><!-- /.sidebar -->
          </div><!-- /.col-lg-4 -->
        </div><!-- /.row -->
      </div><!-- /.container -->
    </section><!-- /.blog Single -->
          

@push('scripts')
<script>
    $('#search').on('keyup',function(){
    $value=$(this).val();
    $.ajax({
    type : 'get',
    url : '{{URL::to('blogsearch')}}',
    data:{'search':$value},
    success:function(data){
    $('#searchBody').html(data);
    }
    });
    })
    </script>
    <script type="text/javascript">
    $.ajaxSetup({ headers: { 'csrftoken' : '{{ csrf_token() }}' } });
    </script>   
@endpush
        