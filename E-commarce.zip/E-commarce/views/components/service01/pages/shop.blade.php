@php
$main_arr = [
'title'=>$sideFilter["cat_details"]->category_name ?? '',
'sublist' => $breadCumbArr
];

@endphp


<x-Theme1.SharedComponent.BreadCrumb :data="$main_arr" />
<!-- Breadcrumb Area End -->
<!-- Shop Category Area End -->
<div class="shop-category-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 order-lg-last col-md-12 order-md-first">
                <!-- Shop Top Area Start -->
                <div class="shop-top-bar">
                    <!-- Left Side start -->
                    <div class="shop-tab nav mb-res-sm-15">
                        <a class="active" href="#shop-1" data-bs-toggle="tab">
                            <i class="fa fa-th show_grid"></i>
                        </a>
                        <a href="#shop-2" data-bs-toggle="tab">
                            <i class="fa fa-list-ul"></i>
                        </a>
                        <p>{{translation('THERE_ARE')}} {{ $products->total() ?? 1 }} {{translation('PAGES')}}.</p>
                         <div class="select-shoing-wrap">
                            <p>{{translation('PER_PAGE')}}:</p>

                            <select name="perPage" class="filter_style" id="pagination">
                                <option value="1">1</option>
                                <option value="2" selected>2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                            </select>
                            <!-- <select name="sortBy" class="filter_style">
                                <option value="20">20</option>
                                <option value="40">40</option>
                                <option value="80">80</option>
                                <option value="200">200</option>
                            </select> -->
                        </div>
                    </div>
                    <!-- Left Side End -->

                    <!-- Right Side Start -->
                    <div class="select-shoing-wrap">
                        <div class="shot-product">
                            <p>{{translation('SORT_BY')}}: </p>
                        </div>
                        <div class="shop-select">
                            <select name="sortBy" class="filter_style" id="sortBy" onChange="filterItem()">
                                <option value="">{{translation('FILTER')}}</option>
                                <option value="latest">{{translation('SHORT_BY_LATEST')}}</option>
                                <option value="pricemintohigh">{{translation('PRICE_MIN_TO_HIGH')}}</option>
                                <option value="pricehightomin">{{translation('PRICE_HIGH_TO_MIN')}}</option>
                                <option value="atoz">{{translation('A_TO_Z')}}</option>
                                <option value="ztoa">{{translation('Z_TO_A')}}</option>
                                <option value="instock">{{translation('IN_STOCK')}}</option>
                            </select>
                        </div>
                    </div>
                    <!-- Right Side End -->
                </div>
                <!-- Shop Top Area End -->

                <!-- Shop Bottom Area Start -->
                <div class="shop-bottom-area mt-35" id="filterProductData">
                    <!-- Shop Tab Content Start -->
                    <div class="tab-content jump">
                        <!-- Tab One Start -->
                        <div id="shop-1" class="tab-pane active">
                            <div class="row">
                                @if(!empty($products) && sizeof($products)>0)
                                @foreach($products as $product)
                                <div class="col-xl-3 col-md-6 col-lg-4 col-sm-6 col-xs-12">
                                    <x-theme1.shared-component.product viewtype="grid" :data="$product" />
                                </div>
                                @endforeach
                                @else
                                <img src="{{ LoadAssets('assets/images/EmptyImages/Wishlist-Empty.png')}}" class="rounded mx-auto d-block" width="286px" height="200px" alt="...">
                                <p class="h4 text-center text-dark mt-3">Opps!! There is no product avaliable for this category</p>
                                <div class="text-center my-3">
                                <a href="{{url('/')}}" class="btn btn-primary btn-lg btn-block" role="button" aria-pressed="true">Continue to shop</a>
                                </div>
                                @endif
                            </div>
                        </div>
                        <!-- Tab One End -->
                        <!-- Tab Two Start -->
                        <div id="shop-2" class="tab-pane">
                            @if(!empty($products) && sizeof($products)>0)
                            @foreach($products as $product)
                            <x-theme1.shared-component.product viewtype="list" :data="$product" />
                            @endforeach
                            @else
                            <img src="{{ LoadAssets('assets/images/EmptyImages/Wishlist-Empty.png')}}" class="rounded mx-auto d-block" width="286px" height="200px" alt="...">
                            <p class="h4 text-center text-dark mt-3">Opps!! There is no product avaliable for this category</p>
                            <div class="text-center my-3">
                            <a href="{{url('/')}}" class="btn btn-primary btn-lg btn-block" role="button" aria-pressed="true">Continue to shop</a>
                            </div>
                            @endif
                        </div>
                        <!-- Tab Two End -->
                    </div>
                    <!-- Shop Tab Content End -->
                    <!--  Pagination Area Start -->
                    <div class="pro-pagination-style text-center">
                        {{-- Pagination --}}
                        <div class="row">
                            <div class="col-md-12 d-flex justify-content-center p-2">
                            {{ $products->links('vendor.pagination.for-ajax') }}
                            </div>
                        </div>
                    </div>
                    <!--  Pagination Area End -->

                    {{-- Category description Start --}}

                    @if(!empty($categoryDesc))
                    <div class="row">
                        <div class="col-lg-12 d- p-2">
                    <div class="card">
                        <div class="card-body">
                            {{$categoryDesc->categories_description ?? ''}}
                        </div>
                    </div>
                    </div>
                   </div>
                    @endif
                   {{-- End of category description --}}

                </div>
                <!-- Shop Bottom Area End -->
            </div>
            <!-- Sidebar Area Start -->
            <div class="col-lg-3 order-lg-first col-md-12 order-md-last mb-res-md-60px mb-res-sm-60px">
                <div class="left-sidebar">
                    <!-- current selected category -->
                    <input style="display:none" type="checkbox" name="choosenCategory[]" value='{{ $sideFilter["cat_details"]->categories_id }}' checked />
                    <!-- end current category -->
                    @if($sideFilter)
                    <div class="sidebar-heading">
                        <div class="main-heading">
                            <h2>{{translation('FILTER_BY')}}</h2>
                        </div>
                        <!-- Sidebar single item -->
                        @if(!$sideFilter['cat_list']->isEmpty())
                        <div class="sidebar-widget">
                            <h4 class="pro-sidebar-title">{{translation('CATEGORIES')}}</h4>
                            <div class="sidebar-widget-list">
                                <ul>
                                    @foreach($sideFilter['cat_list'] as $key=>$cat)
                                    <li>
                                        <div class="sidebar-widget-list-left">
                                            <input type="checkbox" name="choosenCategory[]" onClick="filterItem()"
                                                value='{{  $cat->categories_id }}' />
                                            <a href="#">
                                                {{ $cat->category_name ?? 'No Data' }}
                                            </a>
                                            <span class="checkmark"></span>
                                        </div>
                                    </li>
                                    @endforeach
                                </ul>
                            </div>
                        </div>
                        @else
                        <div></div>
                        @endif
                        <!-- Sidebar single item -->
                    </div>
                    @endif
                    <!-- Sidebar single item -->

                    <!-- Sidebar single brand item -->
                    @if(!($sideFilter['cat_details']->brands)->isEmpty())
                    
                    <div class="sidebar-widget">
                        <h4 class="pro-sidebar-title">{{translation('BRAND')}}</h4>
                        <div class="sidebar-widget-list">
                            <ul>
                                @foreach ($sideFilter['cat_details']->brands as $brands)
                                <li>
                                    <div class="sidebar-widget-list-left">
                                        <input type="checkbox" name="choosenBrands[]" onClick="filterItem()"
                                            value='{{  $brands->brand_id }}' />
                                        <a href="#">
                                            {{ $brands->brand_name ?? 'No Data' }}
                                        </a>
                                        <span class="checkmark"></span>
                                    </div>
                                </li>
                                @endforeach
                            </ul>
                        </div>
                    </div>
                    @else
                    <div></div>
                    @endif


                    @if(!($sideFilter['cat_details']->options)->isEmpty())
                    @foreach ($sideFilter['cat_details']->options as $option)
                    <div class="sidebar-widget mt-30">
                        <h4 class="pro-sidebar-title"> {{ $option->products_options_name ?? '' }}</h4>
                        <div class="sidebar-widget-list">
                            @if (!empty($option->products_options_values))
                            <ul>
                                @foreach ($option->products_options_values as $optionValue)
                                <li>
                                    <div class="sidebar-widget-list-left">
                                        <input type="checkbox" class="optionChoose"
                                            name="option_{{$option->products_options_id}}_[]" onClick="filterItem()"
                                            value="{{  $optionValue->products_options_values_id }}" />
                                        <a href="#">
                                            {{ $optionValue->products_options_values_name ?? '' }}
                                        </a>
                                        <span class="checkmark"></span>
                                    </div>
                                </li>
                                @endforeach
                            </ul>
                            @endif
                        </div>
                    </div>
                    @endforeach
                    @endif
                    <!-- Sidebar single item -->

                    {{-- <div class="sidebar-widget tag mt-30">
                        <div class="main-heading">
                            <h2>{{translation('TAG')}}</h2>
                        </div>
                        <div class="sidebar-widget-tag">
                            <ul>
                                <li><a href="#">Fresh Fruit</a></li>
                                <li><a href="#"> Fresh Vegetables</a></li>
                                <li><a href="#">Fresh Salad</a></li>
                                <li><a href="#"> Butter & Eggs</a></li>
                            </ul>
                        </div>
                    </div> --}}
                    <!-- Sidebar single item -->
                </div>
            </div>
            <!-- Sidebar Area End -->
        </div>
    </div>
</div>

@push('scripts')
<script>

    const optionList = {{ Illuminate\Support\Js:: from($sideFilter['cat_details'] -> options) }};

   // const brandList = {{ Illuminate\Support\Js:: from($sideFilter['cat_details'] -> brands) }};
    // console.log(optionList);

    function filterItem() {
        var ChoosenAttributes = [];

        // attaching category to  filter 
        let category = [];
        let brands = [];
        
        let catHtml = $('input[name="choosenCategory[]"]:checked');
        if (catHtml.length > 0) {
            catHtml.each((label, data) => {
                category.push(data.value);
            });
        }
        let brandHtml = $('input[name="choosenBrands[]"]:checked');
        if (brandHtml.length > 0) {
            brandHtml.each((label, data) => {
                brands.push(data.value);
            });
        }
      
        // ataching option to filter
        /*
           array :  option : [ option_value_id, option_value_id],
        */

        if (optionList.length > 0) {
            for (let index = 0; index < optionList.length; index++) {
                const optionId = optionList[index].products_options_id;

                let options = [];
                let optionHtml = $(`input[name="option_${optionId}_[]"]:checked`);
                if (optionHtml.length > 0) {
                    optionHtml.each((label, data) => {
                        options.push(data.value);
                    });
                }

                ChoosenAttributes[index] = options;

            }

        }

        // console.log('brands', brands);
        // console.log('category', category);
        // console.log('options', ChoosenAttributes);



        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        var page = $('#nextPage').val();
        var sortBy = $('#sortBy').val();

        $.ajax({
            url: '{{ route("filterItem") }}',
            method: 'POST',
            data: {
                category: category,
                options: ChoosenAttributes,
                brands: brands,
                sortBy: sortBy,
                page: page
            },
            beforeSend: function () {
                var html = '<img class="loader-img" src="https://www.wpfaster.org/wp-content/uploads/2013/06/loading-gif.gif" height="100" width="100" style="margin-left: 46%;">';
                $('#filterProductData').html(html);
            },
            success: function (response) {
                console.log(response);
                $('#filterProductData').html(response.table_html);
            },
            error: function (error) {
                Notify(error.responseText, false);
            }
        });

    }

</script>
<script>
    document.getElementById('pagination').onchange = function() { 
        window.location = "{!! $products->url(1) !!}&perPage=" + this.value; 
    }; 
</script>
@endpush