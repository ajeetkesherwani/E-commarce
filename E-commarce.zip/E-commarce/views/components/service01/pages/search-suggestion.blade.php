@if(!empty($categorys) && sizeof($categorys) > 0)
<b>Category</b>
<ul>
	@foreach($categorys as $category)
		<li>
			<a href="{{ url('category/'.$category->categories_slug )  }}">{{ $category->category_name }}</a>
		</li>
	@endforeach
</ul>
<hr />
@endif

@if(!empty($products) && sizeof($products) > 0 )
<b>Products</b>
<ul>
	@foreach($products as $product)
		<li>
			<a href="{{ url('product/'.$product->product_slug )  }}">{{ $product->products_name }}</a>
		</li>
	@endforeach
</ul>
@endif