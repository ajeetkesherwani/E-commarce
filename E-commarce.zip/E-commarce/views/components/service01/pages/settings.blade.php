@push('styles')
@endpush
@php

$main_arr = [
    'title' => 'Setttings',
    'sublist' => [
        [
            'name' => 'HOME',
            'link' => url('/'),
        ],
        [
            'name' => 'settings',
            'link' => url(' '),
        ],
    ],
];
@endphp

<x-Service01.SharedComponent.BreadCrumb :data="$main_arr" />

<section>
    <div class="container">
      <div class="row">
      </div>
      <div class="row">
        <!-- here left side menubar come -->
        <x-Service01.SharedComponent.left-side-menu />
        <div class="col-lg-8 col-sm-12">
          <div class="account_page_detail ">
            <h4 class="account_page__title mb-4 ">Profile Detail</h4>
             
              <div class="row">
                <div class="col-lg-12">
                  <form>
                    <div class="row">
                      <div class="col-xs-12 col-sm-6 col-md-6">
                        <div class="form-group">
                          <label class=" detail_title">Name</label>
                          <input type="text" name="name" id="name" class="form-control input-lg"
                            placeholder=" Name" tabindex="1" required="">
                        </div>
                      </div>
                      <div class="col-xs-12 col-sm-6 col-md-6">
                        <div class="form-group">
                          <label class=" detail_title">Email Address</label>
                          <input type="email" name="email" id="email" class="form-control input-lg"
                            placeholder="Email Address" tabindex="4" required="">
                        </div>
                      </div>
                      
                      <div class="col-xs-12 col-sm-6 col-md-6">
                        <div class="form-group">
                          <label class="detail_title">Phone Number</label>
                          <input type="text" class="form-control" placeholder="Phone" id="phone" name="phone"
                            required="" aria-required="true">
                        </div>
                      </div>
                      <div class="col-xs-12 col-sm-6 col-md-6">
                        <div class="form-group">
                          <label class=" detail_title">Company Name</label>
                          <input type="text" name="company_name" id="company_name" class="form-control input-lg"
                            placeholder="Company Name" tabindex="4" required="">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12 pt-2">
                        <div class="form-check d-flex align-items-center">
                          <input class="form-check-input" type="checkbox" value="" id="showpasswordform">
                          <label class="detail_title mb-0">Change password</label>
                        </div>

                        <form action="" method="post" id="change_password_form" class="needs-validation " 
                          novalidate="novalidate">
                          <input type="hidden" name="" value="">
                          <div class="row mt-4 d-none">
                            <div class="col-lg-6">
                              <div class="mb-3">
                                <label class="form-label">Old password</label>
                                <div>
                                  <input type="password" name="old_password" id="old_password"
                                    class="form-control ps-5" placeholder="Old password" required="">
                                </div>
                              </div>
                            </div>
                            <!--end col-->
                            <div class="col-lg-6">
                              <div class="mb-3">
                                <label class="form-label">New password</label>
                                <div>
                                  <input type="password" name="new_password" id="new_password"
                                    class="form-control ps-5" placeholder="New password" required="">
                                </div>
                              </div>
                            </div>
                            <!--end col-->
                            <div class="col-lg-6">
                              <div class="mb-3">
                                <label class="form-label">Confirm password</label>
                                <div>
                                  <input type="password" name="password_confirmation" id="password_confirmation"
                                    class="form-control ps-5" placeholder="Re-type New password" required="">
                                </div>
                              </div>
                            </div>
                            <!--end col-->
                            <div class="col-lg-12 mt-2 mb-0">
                              <button type="submit" class="btn btn-primary">Save password</button>
                            </div>
                            <!--end col-->
                          </div>
                          <!--end row-->
                        </form>

                      </div>
                      <!--end col-->
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12 p-0 mt-4">
                      <a href="#" class="btn btn__secondary btn__block w-50" id="save_btn">Save Changes</a>
                    </div>
                  </form>
                </div>
              </div>
              <div class="rounded shadow mt-4">
                <div class="p-4 border-bottom">
                  <h4 class="account_page__title  mb-0">Account Notifications </h4>
                </div>
                    <div class=" px-4 py-2 pt-4">
                    <div class="d-flex ">
                        <div class="form-check">
                            <input class="form-check-input" name="setting" type="checkbox" value="1" id="notification">
                            <label class="form-check-label" for="noti1"></label>
                        </div>
                        <p class="text-block__desc">Receive Billing Alerts</p>
                    </div>
                </div>
                    <div class="px-4 py-2">
                    <div class="d-flex ">
                        <div class="form-check">
                            <input class="form-check-input" name="setting" type="checkbox" value="2" id="notification">
                            <label class="form-check-label" for="noti1"></label>
                        </div>
                        <p class="text-block__desc">System Updates</p>
                    </div>
                </div>
                    <div class="px-4 py-2">
                    <div class="d-flex ">
                        <div class="form-check">
                            <input class="form-check-input" name="setting" type="checkbox" value="3" id="notification">
                            <label class="form-check-label" for="noti1"></label>
                        </div>
                        <p class="text-block__desc">Weekly Progress Reports</p>
                    </div>
                </div>
                    <div class="px-4 py-2">
                    <div class="d-flex ">
                        <div class="form-check">
                            <input class="form-check-input" name="setting" type="checkbox" value="4" id="notification">
                            <label class="form-check-label" for="noti1"></label>
                        </div>
                        <p class="text-block__desc"> Blog</p>
                    </div>
                </div>
                    <div class="px-4 py-2">
                    <div class="d-flex ">
                        <div class="form-check">
                            <input class="form-check-input" name="setting" type="checkbox" value="5" id="notification">
                            <label class="form-check-label" for="noti1"></label>
                        </div>
                        <p class="text-block__desc">Unsubscribe From All Email Lists</p>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 p-0 ">
                  <a href="#" class="btn btn__secondary btn__block" id="save_btn">Save Changes</a>
                </div>
            </div>
            </div>
        </div>
      </div>
    </div>

  </section>