@php

$main_arr = [
  'title'=>'Services',
  'sublist' => [
    [
    'name'=>'HOME',
    'link'=>url("/")
    ],
    [
    'name'=>'Services' ,
    'link'=>url("")
    ], 
  ]
];

@endphp

  <!-- ========================
       page title 
    =========================== -->
    <x-Service01.SharedComponent.BreadCrumb :data="$main_arr" />

    <!-- ========================
        Services Layout 1
    =========================== -->
    <section class="services-layout1 pt-130 pb-90">
      <div class="bg-img"><img src="assets/images/backgrounds/3.jpg" alt="background"></div>
      <div class="container">
        <div class="row">
          <div class="col-sm-12 col-md-12 col-lg-6 offset-lg-3">
            <div class="heading text-center mb-60">
              <h2 class="heading__subtitle">Cleaning Plans FOr Your Needs</h2>
              <h3 class="heading__title">Specialist Disinfection Services That Fits Your Premises</h3>
            </div><!-- /.heading -->
          </div><!-- /.col-lg-6 -->
        </div><!-- /.row -->
        <div class="row">
        @foreach($popular_category as $pckey=>$popCatval)
          <!-- service item #1 -->
          <div class="col-sm-12 col-md-6 col-lg-4">
            <div class="service-item">
              <div class="service__overlay">
                <div class="bg-img">
                  <img src="{{getFullImageUrl($popCatval->categories_image)}}" alt="category-listing">
                </div>
              </div><!-- /.service__overlay -->
              <div class="service__body">
                <div class="service__icon">
                  <i class="icon-house"></i>
                </div><!-- /.service__icon -->
                <a href="{{route('categorySlug',['slug'=>$popCatval->categories_slug])}}">
                   <h4 class="service__title">{{$popCatval->category_name ?? ''}}</h4>
                </a>
                <div class="service__desc">
                 <p class="service__desc">{!! Str::limit($popCatval->category_description ?? '',150) !!}</p>
                </div>
                <a href="{{route('categorySlug',['slug'=>$popCatval->categories_slug])}}" class="btn btn__secondary btn__block d-flex justify-content-between">
                  <span>Read More</span>
                  <i class="icon-arrow-right icon-outlined"></i>
                </a>
              </div><!-- /.service__body -->
            </div><!-- /.service-item -->
          </div><!-- /.col-lg-4 -->
          <!-- service item #2 -->
          @endforeach 
        </div><!-- /.row -->
      </div><!-- /.container -->
    </section><!-- /.Services Layout 1 -->

    <!-- =========================
      Pricing  
      =========================== -->
   