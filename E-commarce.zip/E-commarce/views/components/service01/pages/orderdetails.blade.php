@php
// dd($orderdetails);
$main_arr = [
'title'=>'My Oders',
'sublist' => [
[
'name'=>'HOME',
'link'=>url("/")
],
[
'name'=>'Orders',
'link'=>url(" ")
],
]
];
@endphp

<x-Service01.SharedComponent.BreadCrumb :data="$main_arr" />

<!-- Breadcrumb Area End -->
<!-- cart area start -->
<section>
  <div class="container">
    
  
    <div class="row">
      <x-Service01.SharedComponent.left-side-menu />
    <div class="col-lg-8 col-sm-12">
   
      {{-- <form action="#">
        <div class="table-content table-responsive cart-table-content">
          <table style="text-align:center;">
            <thead>
              <tr>
                <th>{{translation('ORDER_NUMBER')}}</th>
                <th>{{translation('TOTAL_QUANTITY')}}</th>
                <th>{{translation('GRAND_TOTAL')}}</th>
                <th>{{translation('PAYMENT_STATUS')}}</th>
                <th>{{translation('ORDER_STATUS')}}</th>
                <th>{{translation('ACTION')}}</th>
              </tr>
            </thead>
            <tbody>
              @if(!empty($orderdetails))
              @foreach($orderdetails as $key=>$data)
              <tr>
                <td class="product-thumbnail"><a href="javascript:void(0);"
                    onclick="showOrderItemModal('{{$data->order_number}}')">{{$data->order_number}}</a></td>
                <td class="product-name">{{$data->total_qty}}</td>
                <td class="product-price-cart">{{ currencyFormat($data->grand_total)}}</td>

                @switch($data->payment_status)
                @case(2)
                <td><span class="badge badge-pill badge-success bg-success">{{translation('PAID')}}</span></td>
                @break
                @case(3)
                <td><span class="badge badge-pill badge-warning bg-warning">{{translation('FAILED')}}</span></td>
                @break
                @default
                <td><span class="badge badge-pill badge-danger bg-danger bg-danger">{{translation('PENDING')}}</span>
                </td>
                @break
                @endswitch

                @switch($data->order_status)
                @case(2)
                <td><span class="badge badge-pill badge-success bg-info">{{translation('IN_PROCESS')}}</span></td>
                @break
                @case(3)
                <td><span class="badge badge-pill badge-warning bg-warning">{{translation('DISPATCH')}}</span></td>
                @break
                @case(4)
                <td><span class="badge badge-pill badge-warning bg-success">{{translation('DELIVERD')}}</span></td>
                @break
                @default
                <td><span class="badge badge-pill badge-danger bg-danger">{{translation('PENDING')}}</span></td>
                @break
                @endswitch

                <td class="product-wishlist-cart action_btn">
                  <a href="javascript:void(0);" onclick="showOrderItemModal('{{$data->order_number}}')"><span
                      class="material-symbols-outlined">View</span></a>
                  <a href="{{url('/account/'.$data->order_number.'/download-invoice')}}">Download</a>
                </td>
              </tr>
              @endforeach
              @else
              <tr>
                <th style="">{{translation('NO_RECORDS_FOUND')}}</th>

              </tr>
              @endif
            </tbody>
          </table>
        </div>
      </form> --}}

@if(!empty($orderdetails) && sizeof($orderdetails)>0)
@foreach($orderdetails as $orderData)
@foreach($orderData->item as $orderItems)
<div class="account_page_detail p-0">
    <div class="order_item">
      <div class="d-flex flex-sm-row flex-column ">
          <div class=" position-relative">          
              <img width="250" height="200"
                src="{{getFullImageUrl($orderItems->product->listing_image)}}"
                class=""
                onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="" srcset="">
            
            <div class="item_price">
              <span>
                {{currencyFormat($orderItems->total_price)}}<sub>/</sub>
              </span>
            </div>
        </div>
        <div class="p-4 clearfix">
          <div class="order_item-title">
            <div>
              <h5 class="title mb-2"><a href="" class="text-dark">
                  {{$orderItems->listing_name ?? ''}}</a></h5>
              <address class="item-address">
                {{$orderData->address[0]->customer_address ?? ''}} ,{{$orderData->address[0]->customer_city ?? ''}}
                {{$orderData->address[0]->customer_state ?? ''}} ,{{$orderData->address[0]->customer_country ?? ''}}
                {{$orderData->address[0]->customer_postcode ?? ''}}
              </address>
            </div>
          </div>
  
          <ul class="item_amenities">
            <li>
             Order Number :  {{$orderData->order_number}}
            </li>
          </ul>

          <span>
             <time>
              Service Data: 
              @php
               echo(date('d F,Y', strtotime($orderItems->created_at ?? '')));
              @endphp
            </time>
          </span>
        </div>
      </div>
    </div>
</div>
@endforeach
@endforeach
@endif

       {{-- Pagination --}}
        <div class="row">
          <div class="col-md-12 d-flex justify-content-center p-2">
            {!! $orderdetails->links('vendor.pagination.simple-default') !!}
            {{-- {{ $orderdetails->links('vendor.pagination.simple-default') }} --}}
          </div>
        </div>
    </div>
  </div>
</div>
 </section>

{{-- Starting of order invoice modal --}}


<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
  aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">

        <button type="button" class="close productmodalbtn" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="orderInvoice">

      </div>
    </div>
  </div>
</div>

{{-- order invoice modal area end --}}

@push('scripts')
<script>

  function showOrderItemModal(orderNumber) {

    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      }
    });
    $.ajax({
      type: "POST",
      url: "{{url('account/show-order-items')}}",
      data: { order_number: orderNumber },
      dataType: "json",
      success: function (response) {
        $('#orderInvoice').html(response.orderDeatil_html);
        $('.bd-example-modal-lg').modal('show');
      },
      error: function (data) {

      }
    });

  };

  // Jquery for hide modal

  $(".productmodalbtn").click(function () {
    $(".bd-example-modal-lg").modal('hide');
  });

</script>
@endpush