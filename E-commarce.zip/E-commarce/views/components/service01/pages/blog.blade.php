@php

$main_arr = [
  'title'=>'Blogs',
  'sublist' => [
    [
    'name'=>'HOME',
    'link'=>url("/")
    ],
    [
    'name'=>'Blog' ,
    'link'=>url("")
    ], 
  ]
];
@endphp

<x-Service01.SharedComponent.BreadCrumb :data="$main_arr" /> 
   <!-- ======================
      Blog Grid
    ========================= -->
    @if(!empty($allBlog) && sizeof($allBlog)>0)
    <section class="blog-grid">
      <div class="container">
        <div class="row">
        {{-- content start here --}}
          @foreach($allBlog as $blogKey=>$blogData)
          <!-- Post Item #1 -->
          <div class="col-sm-12 col-md-6 col-lg-4">
            <div class="post-item">
              <div class="post__img">
                <a href="{{url('blog/'.$blogData->slug)}}">
                  <img src="{{getFullImageUrl($blogData->img)}}" alt="{{getSetting('site_title')}} Not-Found" class="img-fluid" loading="lazy">
                </a>
              </div><!-- /.post__img -->
              <div class="post__body">
                <div class="post__meta d-flex">
                  <div class="post__meta-cat">
                    <a href="#">Cleaning</a>
                    <a href="#">Tips</a>
                    <a href="#">Tricks</a>
                  </div>
                  <!-- /.blog-meta-cat -->
                  <span class="post__meta-date">
                     @php
                      echo(date('d F,Y', strtotime($blogData->created_at ?? '')));
                     @endphp
                  </span>
                </div>
                <h4 class="post__title"><a href="#">{{$blogData->post_title ?? ''}}</a></h4>
                <!-- <div class="post__meta-author mb-30">By <a href="#">John Ezak</a></div> -->
                <p class="post__desc">{{$blogData->post_excerpt ?? ''}}
                </p>
                <a href="{{url('blog/'.$blogData->slug)}}" class="btn btn__secondary btn__link">
                  <i class="icon-arrow-right"></i>
                  <span>Read More</span>
                </a>
              </div><!-- /.post__body -->
            </div><!-- /.post-item -->
          </div><!-- /.col-lg-4 -->
          @endforeach
       {{-- endof content --}}
        </div><!-- /.row -->
        <div class="row">
          <div class="col-12 text-center">
            <nav class="pagination-area">
              <ul class="pagination justify-content-center mb-0">
              {{ $allBlog->links('vendor.pagination.semantic-ui') }}
                <!-- <li><a class="current" href="#">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#"><i class="icon-arrow-right"></i></a></li> -->
              </ul>
            </nav><!-- .pagination-area -->
          </div><!-- /.col-12 -->
        </div><!-- /.row -->
      </div><!-- /.container -->
    </section><!-- /.blog Grid -->
    @endif