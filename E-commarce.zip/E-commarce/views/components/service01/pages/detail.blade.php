@php
$main_arr = [
    'title' => $listing->listing_name ?? '',
    'sublist' => [
        [
            'name' => 'HOME',
            'link' => url('/'),
        ],
        [
            'name' => $listing->categories_name,
            'link' => route('categorySlug',['slug'=>$listing->categories_slug]),
        ],
        [
            'name' => $listing->listing_name ?? '',
            'link' => URL::current(),
        ],
    ],
];

@endphp
  <!-- =========================
        Header
    =========================== -->  
      <!-- ========================
         page title 
      =========================== -->
      {{-- <section class="page-title-layout2 page-title-light bg-overlay bg-parallax">
        <div class="bg-img"><img src="{{LoadAssets('assets/images/page-titles/10.jpg')}}" alt="background"></div>
        <div class="container">
          <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-8">
              <h1 class="pagetitle__heading">{{$listing->listing_name ?? ''}}</h1>
              <p class="pagetitle__desc">{!! Str::limit($listing->listing_description ?? '',100) !!}</p>
              <nav>
                <ol class="breadcrumb mb-0">
                  <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                  <li class="breadcrumb-item"><a href="services.html">Services</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Window Cleaning</li>
                </ol>
              </nav>
            </div><!-- /.col-xl-6 -->
          </div><!-- /.row -->
        </div><!-- /.container -->
      </section><!-- /.page-title --> --}}

      <x-Service01.SharedComponent.BreadCrumb :data="$main_arr" />        
  
      <section class="pb-80">
        <div class="container">
          <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-4">
              <aside class="sidebar has-marign-right">
                <div class="widget widget-services">
                  <h5 class="widget__title">Services We Offer</h5>
                  <div class="widget-content">
                    <ul class="list-unstyled mb-0">
                      @if(!empty($related_services) && sizeof($related_services)>0)
                      @foreach($related_services as $rskey=>$RSval)
                      <li><a href="{{route('listingDetail',['slug'=>$RSval->listing_slug])}}"><span>{{$RSval->listing_name ?? ''}}</span><i class="icon-arrow-right"></i></a></li>
                      @endforeach
                      @endif
                    </ul>
                  </div><!-- /.widget-content -->
                </div><!-- /.widget-services -->
                <div class="widget widget-help bg-overlay bg-overlay-secondary">
                  <div class="bg-img"><img src="assets/images/banners/5.jpg" alt="background"></div>
                  <div class="widget-content">
                    <h3 class="widget__subtitle">Homeowners Like Us!</h3>
                    <h4 class="widget__title">Healthy Environment For Your Family</h4>
                    <p class="widget__desc font-weight-bold mb-50">The processes and systems we put in place provide high
                      quality service with a
                      focus on safety.
                    </p>
                    <a href="pricing-offers.html" class="btn btn__accent btn__block justify-content-between mb-30">
                      <span>Explore Our Offers</span>
                      <i class="icon-arrow-right"></i>
                    </a>
                    <a href="tel:{{getsetting('phone')}}" class="phone__number">
                      <i class="icon-phone"></i> <span>{{getsetting('phone')}}</span>
                    </a>
                  </div><!-- /.widget-content -->
                </div><!-- /.widget-help -->

              </aside><!-- /.sidebar -->
            </div><!-- /.col-lg-4 -->
            <div class="col-sm-12 col-md-12 col-lg-8">
              <div class="text-block mb-50">
                <h5 class="text-block__title">Overview</h5>
                <p class="text-block__desc mb-20">{!!$listing->listing_description!!}</p>
              </div><!-- /.text-block -->
  
            </div><!-- /.col-lg-8 -->
          </div><!-- /.row -->
        </div><!-- /.container -->
      </section>
  
      <!-- ==========================
          contact layout 2
      =========================== -->
      <section class="contact-layout2 bg-overlay bg-overlay-primary-gradient">
        <div class="bg-img"><img src="assets/images/banners/4.jpg" alt="banner"></div>
        <div class="container">
          <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-7">
              <div class="contact-panel">
                <form class="contact-panel__form" method="post" action="assets/php/contact.php" id="">
                  <div class="row">
                    <div class="col-sm-12">
                      <h4 class="contact-panel__title">Request An Estimate</h4>
                      <p class="contact-panel__desc mb-30">For a cleaning that meets your highest standards, you need a
                        dedicated team of trained specialists with all supplies needed to thoroughly clean your home.
                      </p>
                    </div>
                    <div class="col-sm-6 col-md-6 col-lg-6">
                      <div class="form-group">
                        <label for="service">Choose your service</label>
                        <select id="service" class="form-control">
                          <option>Coronavirus Cleaning</option>
                          <option>outdoor Cleaning</option>
                          <option>indoor Cleaning</option>
                        </select>
                      </div>
                    </div><!-- /.col-lg-6 -->
                    <div class="col-sm-6 col-md-6 col-lg-6">
                      <div class="form-group">
                        <label for="type">Indicate type of cleaning</label>
                        <select id="type" class="form-control">
                          <option>Weekly Regular</option>
                          <option>Monthly Regular</option>
                        </select>
                      </div>
                    </div><!-- /.col-lg-6 -->
                    <div class="col-sm-6 col-md-6 col-lg-6">
                      <div class="form-group">
                        <label for="facility">Facility type</label>
                        <select id="facility" class="form-control">
                          <option>Educational</option>
                          <option>Educational</option>
                        </select>
                      </div>
                    </div><!-- /.col-lg-6 -->
                    <div class="col-sm-6 col-md-6 col-lg-6">
                      <div class="form-group">
                        <label for="facilityName">Facility name</label>
                        <input type="text" class="form-control" placeholder="7oroof" id="facilityName">
                      </div>
                    </div><!-- /.col-lg-6 -->
                    <div class="col-sm-4">
                      <div class="form-group">
                        <label for="rooms">Room(s)?</label>
                        <div class="position-relative">
                          <button class="decrease-qty">
                            <i class="fas fa-caret-down"></i>
                          </button>
                          <input type="number" value="5" class="form-control input-number" id="rooms">
                          <button class="increase-qty">
                            <i class="fas fa-caret-up"></i>
                          </button>
                        </div>
                      </div>
                    </div><!-- /.col-lg-4 -->
                    <div class="col-sm-4">
                      <div class="form-group">
                        <label for="hallway">Hallway(s)? </label>
                        <div class="position-relative">
                          <button class="decrease-qty">
                            <i class="fas fa-caret-down"></i>
                          </button>
                          <input type="number" value="2" class="form-control input-number" id="hallway">
                          <button class="increase-qty">
                            <i class="fas fa-caret-up"></i>
                          </button>
                        </div>
                      </div>
                    </div><!-- /.col-lg-4 -->
                    <div class="col-sm-4">
                      <div class="form-group">
                        <label for="staircase">Staircase(s)?</label>
                        <div class="position-relative">
                          <button class="decrease-qty">
                            <i class="fas fa-caret-down"></i>
                          </button>
                          <input type="number" value="5" class="form-control input-number" id="staircase">
                          <button class="increase-qty">
                            <i class="fas fa-caret-up"></i>
                          </button>
                        </div>
                      </div>
                    </div><!-- /.col-lg-4 -->
                    <div class="col-12">
                      <div class="form-group">
                        <label>Do you have all the necessary cleaning supplies?</label>
                        <div>
                          <div class="custom-control custom-radio custom-control-inline">
                            <input type="radio" id="yes" name="radioGroup" class="custom-control-input" value="Yes"
                              checked>
                            <label class="custom-control-label" for="yes">Yes</label>
                          </div>
                          <div class="custom-control custom-radio custom-control-inline">
                            <input type="radio" id="no" name="radioGroup" class="custom-control-input" value="No">
                            <label class="custom-control-label" for="no">No</label>
                          </div>
                        </div>
                      </div>
                      <button type="submit"
                        class="btn btn__secondary btn__block btn__xhight d-flex justify-content-between mt-10">
                        <span>Submit Request</span> <i class="icon-arrow-right icon-outlined"></i>
                      </button>
                      <div class="contact-result"></div>
                    </div><!-- /.col-lg-12 -->
                  </div><!-- /.row -->
                </form>
              </div>
            </div><!-- /.col-lg-7 -->
            <div class="col-sm-12 col-md-12 col-lg-5 d-flex flex-column justify-content-between">
              <div>
                <div class="heading-layout2 heading-light mb-40">
                  <h2 class="heading__subtitle">We’re the Best Cleaning Company</h2>
                  <h3 class="heading__title">Your Clients & Employees Deserve A Clean, Safe And Healthy Environment!!</h3>
                  <p class="heading__desc">Hiring someone to clean your home can feel like a big decision as you want to
                    hire the best house cleaning service you can.</p>
                </div><!-- /.heading -->
                <div class="d-flex flex-wrap mb-70">
                  <a href="#" class="btn btn__white mr-30">
                    <span>Explore More</span>
                    <i class="icon-arrow-right ml-20"></i>
                  </a>
                  <a href="#" class="btn btn__white btn__outlined">Our Products</a>
                </div>
              </div>
              <div class="fancyboxs-layout1 fancybox-light">
                <div class="slick-carousel carousel-dots-light"
                  data-slick='{"slidesToShow": 1, "arrows": false, "dots": true, "autoplay": false,"autoplaySpeed": 2000, "infinite": true}'>
                  <div class="fancybox-item mb-0">
                    <div class="fancybox__icon">
                      <i class="icon-hanger"></i>
                    </div><!-- /.fancybox__icon -->
                    <div class="fancybox__body">
                      <h4 class="fancybox__title">Worry Free Services</h4>
                      <p class="fancybox__desc">We do everything we can to make our services as affordable as possible.
                        Our
                        budget flexibility extends all the way to employing the right amount of help at the right times to
                        make a positive difference in our customers’ lives and confidence in our services.
                      </p>
                    </div><!-- /.feature__body -->
                  </div><!-- /.feature-item -->
                  <div class="fancybox-item mb-0">
                    <div class="fancybox__icon">
                      <i class="icon-spray"></i>
                    </div><!-- /.fancybox__icon -->
                    <div class="fancybox__body">
                      <h4 class="fancybox__title">Trust & Affordability</h4>
                      <p class="fancybox__desc">We do everything we can to make our services as affordable as possible.
                        Our
                        budget flexibility extends all the way to employing the right amount of help at the right times to
                        make a positive difference in our customers’ lives and confidence in our services.
                      </p>
                    </div><!-- /.feature__body -->
                  </div><!-- /.feature-item -->
                </div>
              </div>
            </div><!-- /.col-lg-5 -->
          </div><!-- /.row -->
        </div><!-- /.container -->
      </section><!-- /.contact layout 2 -->
  
      <!-- ======================
       Clients
      ========================= -->
      <section class="clients pt-50 pb-50">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-sm-12 col-md-4 col-lg-4">
              <p class="font-weight-bold color-secondary my-3">
                Clanora’s trust ensures every service we offer will get your home cleaner and healthier, to your exact
                needs.
              </p>
            </div>
            <div class="col-sm-12 col-md-4 col-lg-8">
              <div class="slick-carousel"
                data-slick='{"slidesToShow": 4, "arrows": false, "dots": false, "autoplay": true,"autoplaySpeed": 2000, "infinite": true, "responsive": [ {"breakpoint": 992, "settings": {"slidesToShow": 3}}, {"breakpoint": 767, "settings": {"slidesToShow": 2}}, {"breakpoint": 480, "settings": {"slidesToShow": 2}}]}'>
                <div class="client">
                  <img src="assets/images/clients/1.png" alt="client">
                  <img src="assets/images/clients/1.png" alt="client">
                </div><!-- /.client -->
                <div class="client">
                  <img src="assets/images/clients/2.png" alt="client">
                  <img src="assets/images/clients/2.png" alt="client">
                </div><!-- /.client -->
                <div class="client">
                  <img src="assets/images/clients/3.png" alt="client">
                  <img src="assets/images/clients/3.png" alt="client">
                </div><!-- /.client -->
                <div class="client">
                  <img src="assets/images/clients/4.png" alt="client">
                  <img src="assets/images/clients/4.png" alt="client">
                </div><!-- /.client -->
                <div class="client">
                  <img src="assets/images/clients/5.png" alt="client">
                  <img src="assets/images/clients/5.png" alt="client">
                </div><!-- /.client -->
                <div class="client">
                  <img src="assets/images/clients/6.png" alt="client">
                  <img src="assets/images/clients/6.png" alt="client">
                </div><!-- /.client -->
                <div class="client">
                  <img src="assets/images/clients/7.png" alt="client">
                  <img src="assets/images/clients/7.png" alt="client">
                </div><!-- /.client -->
              </div><!-- /.carousel -->
            </div><!-- /.col-lg-6 -->
          </div><!-- /.row -->
        </div><!-- /.container -->
      </section><!-- /.Clients -->