@push('styles')
@endpush
@php

$main_arr = [
    'title' => 'Address Book',
    'sublist' => [
        [
            'name' => 'HOME',
            'link' => url('/'),
        ],
        [
            'name' => 'Addresses',
            'link' => url(' '),
        ],
    ],
];
@endphp

<x-Service01.SharedComponent.BreadCrumb :data="$main_arr" />
<!-- section area start -->


<!-- ===================== -->
<section>
    <div class="container">
        <div class="row">
            <x-Service01.SharedComponent.left-side-menu />
            <div class="col-lg-8 col-sm-12">
                <div class="account_page_detail ">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 class="account_page__title mb-0 ">Billing Address</h4>
                        <div>
                            <button id="createAddress" class="ui-button ui-corner-all ui-widget btn btn__secondary "><i
                                    class="fas fa-regular fa-plus"></i>Add New Address</button>
                        </div>
                    </div>
                    <div class="row" id="addressboxes">
                        {{-- Ajax Load Show here --}}
                    </div>
                    <!-- ==== -->
                    <div class="row col-lg-6 col-md-6">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

{{-- Delete Confirmation --}}

<div class="modal fade confirmationModal" id="DeleteAddressModal" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Delete Address</h5>
                <button type="button" class="close modal-dismis" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="delete_add_id">
                <h3>Are you sure want to delete ?</h3>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary modal-dismis" data-dismiss="modal">Cancle</button>
                <button type="button" class="btn btn-primary delete_add_cnf ">Yes</button>
            </div>
        </div>
    </div>
</div>

{{-- Delete Confirmation End --}}

<x-Service01.Pages.Modal />

@push('scripts')
    <script>
        $(document).ready(function() {

            // Show Add-Address Modal

            $("#createAddress").click(function() {
                $("#AddNewUSerAddress").modal('show', 'fade');
            });

            // Load Address
            function loadaddresss() {
                $.ajax({
                    url: "{{ url('account/show-address') }}",
                    type: "GET",
                    dataType: 'json',
                    success: function(response) {
                        var addressBook = '';
                        console.log(response.address);
                        $.each(response.address, function(key, infoVal) {
                            var is_default = infoVal.is_default;
                            checked = '';
                            if (is_default == 1) checked = "disabled";

                            addressBook += `<div class="col-lg-6 col-md-6 pb-2">
                            <div class=" p-3 service_detail shadow ">
                                <h6>${infoVal.customer_name}</h6>
                                    ${infoVal.customer_email}<br/>
                                    ${infoVal.phone}<br/>
                                    ${infoVal.street_address}, ${infoVal.city}<br/>
                                    ${infoVal.state} , ${infoVal.country_name}<br/>
                                    ${infoVal.zipcode}
                            </div>
                            <div class="d-flex justify-content-between mt-3">
                                <div><a href="javascript:void(0)" class="edit_address" value="${infoVal.address_id}">Edit</a>/  <a href="javascript:void(0)" class="delete_address" value="${infoVal.address_id}">Remove</a>
                                </div>
                                <button type="button" class="button btn btn__secondary mySwitch" ${checked} value="${infoVal.address_id}">Set Default</button>
                            </div>
                        </div>`;
                        });
                        $('#addressboxes').html('');
                        $('#addressboxes').append(addressBook);
                    }
                });
            }

            // load all address through ajax
            loadaddresss();

            // add address function  ajax
            
            $(document).on('click', '#AddNewUserAddressBtn', function(e) {
                e.preventDefault();
                $('#addNewUserAddForm').addClass('was-validated');
                if ($('#addNewUserAddForm')[0].checkValidity() === false) {
                    event.stopPropagation();
                } else {
                    let addNewUserAddForm = document.getElementById('addNewUserAddForm');
                    let formData = new FormData(addNewUserAddForm);

                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        type: "POST",
                        url: "{{ url('account/add-address') }}",
                        data: formData,
                        dataType: "json",
                        contentType: false,
                        cache: false,
                        processData: false,

                        beforeSend: function() {
                            $('#AddNewUserAddressBtn').addClass('disabled');
                            $('#AddNewUserAddressBtn').html(
                                ' <i class="fa-solid fa-spinner fa-spin-pulse"></i> Submitting...'
                            );
                        },

                        success: function(response) {
                            if (response.status == 400) {
                                $.each(response.error, function(key, err_val) {
                                    $('#addUADErr_' + key).text(err_val);
                                });
                            } else {
                                $('#addNewUserAddForm').trigger("reset");
                                $('#AddNewUSerAddress').modal('hide');
                                loadaddresss();
                                swal("Success", "Address Added Successfully.", "success");
                            }
                        },

                        complete: function() {
                            $('#addNewUserAddForm').removeClass('was-validated');
                            $('#AddNewUserAddressBtn').removeClass('disabled');
                            $('#AddNewUserAddressBtn').html('Submit');
                        }
                    });
                }
            });


            //delete modal
            $(document).on("click", ".delete_address", function(e) {
                e.preventDefault();
                var addId = $(this).attr('value');
                $('#delete_add_id').val(addId);
                $('#DeleteAddressModal').modal('show');
            });

            // final delete
            $(document).on("click", ".delete_add_cnf", function(e) {
                e.preventDefault();
                var address_id = $('#delete_add_id').val();
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    url: "{{ url('account/delete-address/') }}",
                    type: "POST",
                    data: {
                        address_id: address_id
                    },
                    success: function(response) {
                        if (response.status == 200) {
                            $('#DeleteAddressModal').modal('hide');
                            loadaddresss();
                            swal("Success", "Address Deleted Successfully.", "success");
                        }
                    }
                });
            });

            //Edit Address

            $(document).on("click", ".edit_address", function(e) {
                e.preventDefault();
                var addrsId = $(this).attr('value');;
                $('#updateAddressModal').modal('show');
                var url = `{{ url('account/address/${addrsId}/edit') }}`;

                $.ajax({
                    url: url,
                    type: "GET",
                    success: function(response) {
                        if (response.status == 400) {
                            $('#errorlist').html("");
                            $('#errorlist').addClass("alert alert-danger");
                            $('#errorlist').append('<p>' + response.message + '</p>');
                        } else {
                            $.each(response.addressdata, function(key, adds_val) {
                                $('#update_' + key).val(adds_val);
                            });
                        }
                    }
                });

            });

            // Update Address

            $(document).on("click", "#updateAddressButton", function(e) {
                e.preventDefault();
                $('#UpdateUserAddForm').addClass('was-validated');
                if ($('#UpdateUserAddForm')[0].checkValidity() === false) {
                    event.stopPropagation();
                } else {
                    let addNewUserAddForm = document.getElementById('UpdateUserAddForm');
                    let formData = new FormData(addNewUserAddForm);
                    formData.append('address_id', $('.edit_address').attr('value'));
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        type: "POST",
                        url: "{{ url('account/update-address') }}",
                        data: formData,
                        dataType: "json",
                        contentType: false,
                        cache: false,
                        processData: false,

                        beforeSend: function() {
                            $('#updateAddressButton').addClass('disabled');
                            $('#updateAddressButton').html(
                                '<i class="fa-solid fa-spinner fa-spin-pulse"></i> Submitting...'
                            );
                        },

                        success: function(response) {
                            if (response.status == 400) {
                                $.each(response.error, function(key, err_val) {
                                    $('#UPUADErr_' + key).text(err_val);
                                });
                            } else {
                                $('#UpdateUserAddForm').trigger("reset");
                                $('#updateAddressModal').modal('hide');
                                loadaddresss();
                                swal("Success", "Address Updated Successfully.", "success");
                            }
                        },

                        complete: function() {
                            $('#UpdateUserAddForm').removeClass('was-validated');
                            $('#updateAddressButton').removeClass('disabled');
                            $('#updateAddressButton').html('Submit');
                        }

                    });
                }
            });

            // Make default address 

            var switchStatus = false;
            $(document).on('click', '.mySwitch', function() {
                var data = {
                    'address_id': $(this).val(),
                }
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{ url('account/makedefault-address') }}",
                    data: data,
                    dataType: "json",
                    success: function(response) {
                        console.log(response);
                        if (response.status == 400) {
                            swal("Success", "Default Address Updated Successfully",
                                "error");
                            loadaddresss();
                        } else {
                            loadaddresss();
                            swal("Success", "Default Address Updated Successfully",
                                "success");
                        }

                    }
                });
            });
        });
    </script>
@endpush
