  <html>
       <body>
         {{$dynamic_content_from_database}}
       
        </body>
      </html>