@if (!empty($cart_list) && sizeof($cart_list)>0)
<section class="shopping-cart pt-0 pb-100">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="cart-table table-responsive">
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th>Service</th>
                  <th>Price</th>
                  <th>Quantity</th>
                  <th>Total</th>
                </tr>
              </thead>
              <tbody>
      
                @foreach ($cart_list as $cart )
                <tr class="cart-product">
                  <td class="d-flex align-items-center">
                    <button class="cart-product__remove" onclick="actionOnCart({{$cart->cart_id}},'del')"><i class="fas fa-times"></i></button>
                    <div class="cart-product__img">
                      <img src="{{LoadAssets('assets/images/products/5.jpg')}}"
                      onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                       alt="product" />
                    </div>
                    <h5 class="cart-product__title">Broom and Dustpan</h5>
                  </td>
                  <td class="cart-product__price">{{currencyFormat($cart_list[0]['final_price']) ?? 0 }}</td>
                  <td class="cart-product__quantity">
                    <div class="quantity__input-wrap">
                      <i class="fa fa-minus decrease-qty qtybutton"></i>
                      <input type="number" data-cart="{{ $cart->cart_id }}" id="{{ $cart->cart_id }}_qty"
                       value="{{ $cart->qty }}" min=1
                      step=1 class="input-number">
                      <i class="fa fa-plus increase-qty qtybutton"></i>
                    </div>
                  </td>
                  <td class="cart-product__total">  
                    @php
                    $qty = (int) $cart->qty;
                    $price = $cart_list[0]['final_price'] ?? 0;
                    echo currencyFormat($qty*$price);
                    @endphp
                  </td>
                </tr>
                @endforeach
             
                <tr class="cart-product__action">
                  <td colspan="4">
                    <div class="cart-product__action-content d-flex align-items-center justify-content-between">
                      <form class="d-flex flex-wrap">
                        <input type="text" class="form-control mb-10 mr-10" placeholder="Coupon Code">
                        <button type="submit" class="btn btn__secondary mb-10">Apply
                          Coupon</button>
                      </form>
                      <div>
                        <a class="btn btn__secondary mr-10" href="#">update cart</a>
                        <a class="btn btn__secondary" href="{{ url('checkout') }}">Checkout</a>
                      </div>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div><!-- /.cart-table -->
        </div><!-- /.col-lg-12 -->

        <div class="col-sm-12 col-md-6 col-lg-4">
          <div class="cart__total-amount">
            <h6>Cart Totals</h6>
            <ul class="list-unstyled mb-30">
              <li><span>Sub Total :</span><span>$ 16.00</span></li>
              <li><span> Total :</span><span>$ 16.00</span></li>
            </ul>
            <a href="{{ url('checkout') }}" class="btn btn__primary">Proceed To Checkout</a>
          </div><!-- /.cart__total-amount -->
        </div><!-- /.col-lg-6 -->
      </div><!-- /.row -->
    </div><!-- /.container -->
  </section><!-- /.shopping-cart -->
 
@else
<img src="{{ LoadAssets('assets/images/EmptyImages/Cart-Empty.jpg') }}"
    onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
    class="rounded mx-auto d-block" width="286px" height="200px"
    alt="{{ getSetting('site_title') }} Cart-Empty">
<p class="h4 text-center text-dark mt-2">Your cart is empty !</p>
<div class="text-center my-3">
    <a href="{{ url('/') }}" class="btn btn-primary btn-lg btn-block" role="button"
        aria-pressed="true">Home</a>
</div>
@endif