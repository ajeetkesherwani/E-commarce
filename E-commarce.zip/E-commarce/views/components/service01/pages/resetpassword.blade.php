{{-- <div class="login-register-area mb-60px mt-53px">
    <div class="container">
        <div class="row">
            <div class="col-lg-7 col-md-12 mx-auto">
                <div class="login-register-wrapper">
                    <div class="login-register-tab-list nav">
                        <a class="active" data-bs-toggle="tab" href="#lg1">
                            <h4>Reset Password</h4>
                        </a>

                    </div>
                    <div class="tab-content">
                        <div id="lg1" class="tab-pane active">
                            <div class="login-form-container">
                                @if ($errors->any())
                                <div class="alert alert-danger">
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                                @endif

                                <div class="login-register-form">

                                    <form action="{{ route('password.update') }}" method="post" id="forgot">
                                        @csrf

                                        <input type="hidden" name="email" placeholder="New Password"
                                            value="{{ Request::get('email')}}" />
                                        <input type="hidden" name="token" value="{{ Request::route('token')}}" />
                                        <input type="password" name="password" placeholder="New Password" />
                                        <input type="password" name="password_confirmation"
                                            placeholder="Confirm New Password" />

                                        <div class="button-box">
                                            <div class="login-toggle-btn">
                                                <input type="checkbox" />
                                                <a class="flote-none" href="javascript:void(0)">Remember me</a>
                                            </div>
                                            <button type="submit"><span>Change Password</span></button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> --}}

<div class="col-sm-12 col-md-12 col-lg-6 mx-auto p-5">
    <section class="contact-layout4 py-0">
      <div class="contact-panel">
        <form class="contact-panel__form" action="{{ route('password.update') }}" method="post" id="update_password_form">
            @csrf
          <div class="row">
            <div class="col-12">
                <h3 class="contact-panel__title  text-center">{{ translation('RESET_PASSWORD') }}</h3>
              <div class="mt-50 pb-50 border-top"></div>
           
              {{-- @if ($errors->any())
              <div class="alert alert-danger">
                  <ul>
                      @foreach ($errors->all() as $error)
                      <li>{{ $error }}</li>
                      @endforeach
                  </ul>
              </div>
              @endif --}}
            </div><!-- /.col-12 -->
            <input type="hidden" name="token" value="{{ Request::route('token')}}" />
            <input type="hidden" name="email" placeholder="New Password" value="{{ Request::get('email')}}" />
            <div class="col-sm-12">
              <div class="form-group">
                <label for="name">{{ translation('NEW_PASSWORD') }}<span>*</span></label>
                <input type="password" name="password" class="form-control" placeholder="{{ translation('NEW_PASSWORD') }}" id="password">
                @error('password')
                <strong class="text-danger mb-5">{{ $message }}</strong>
                @enderror
              </div>
            </div><!-- /.col-lg-12 -->

            <div class="col-sm-12">
                <div class="form-group">
                  <label for="name">{{ translation('CONFIRM_PASSWORD') }}*</label>
                  <input type="password" name="password_confirmation" class="form-control" placeholder="{{ translation('CONFIRM_PASSWORD') }}" id="password_confirmation">
                  @error('password_confirmation')
                  <strong class="text-danger mb-5">{{ $message }}</strong>
                  @enderror
                </div>
            </div><!-- /.col-lg-12 -->
        
            <div class="col-12">
              <button type="submit"
                class="btn btn__secondary btn__block btn__xhight d-flex justify-content-between mt-10">
                <span>{{ translation('SUBMIT') }}</span> <i class="icon-arrow-right icon-outlined"></i>
              </button>
              <div class="contact-result"></div>
            </div>
          </div><!-- /.row -->
        </form>
 
      </div><!-- /.contact-panel -->
    </section><!-- /.contact layout 4 -->
</div><!-- /.col-lg-8 -->

@push('scripts')

<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
<script>
    $(document).ready(function() {
        $('#update_password_form').validate({
            rules: {
                password: {
                    required: true,
                    minlength: 8,
                },
                password_confirmation: {
                    required: true,
                    minlength: 8,
                    equalTo: "#password",
                },
            },
            messages: {
                password: {
                        required: "Please enter a new password",
                        email: "Please enter valid email",
                        
                    },
                    password_confirmation: {
                        required: "Please enter confirm password",
                        minlength: "Password must be at least 8 characters,Please enter valid password"
                    },
                },
                errorElement: 'span',
            errorPlacement: function (error, element) {
              error.addClass('invalid-feedback');
              element.closest('.form-group').append(error);
            },
            highlight: function (element, errorClass, validClass) {
              $(element).addClass('is-invalid');
            },
            unhighlight: function (element, errorClass, validClass) {
              $(element).removeClass('is-invalid');
            }
        });
    });
</script>
@endpush