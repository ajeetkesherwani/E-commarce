<section>
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-12">
            <div class="text-center">
              <img src="{{LoadAssets('assets/payment_images/payment_failed.png')}}"  alt="payment_failed_img">
              <div class="heading">
                  <h3 class="mb-2">
                      Failure To Pay
                     </h3>
              </div>
              <div class='card_message'>
                <p class='message mb-2'>
                  An error occured while processing your payment
                </p>
              </div>
               <div class="col-lg-2 mx-auto">
                <a href="" class="btn btn-primary btn-lg btn-block">Try Again</a>  
               </div>                                  
            </div>
        </div><!--end col-->
    </div><!--end row-->
    </div>
  </section>