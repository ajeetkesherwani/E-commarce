    <!-- ========================= 
            Google Map
    =========================  -->
    {{-- <section class="google-map py-0">
        <iframe frameborder="0" height="620" width="100%"
          src="https://maps.google.com/maps?q=Suite%20100%20San%20Francisco%2C%20LA%2094107%20United%20States&amp;t=m&amp;z=10&amp;output=embed&amp;iwloc=near"></iframe>
      </section><!-- /.GoogleMap --> --}}
  
      <!-- ==========================
          contact layout 1
      =========================== -->
      <section class="contact-layout1 pt-0 mt-50">
        <div class="container">
          <div class="row">
            <div class="col-12">
              <div class="contact-panel d-flex flex-wrap">
               {{-- <form class="contact-panel__form"  id="contact-form">
                  <div class="row">
                    <div class="col-sm-12">
                      <h4 class="contact-panel__title">Get In Touch</h4>
                      <p class="contact-panel__desc mb-30">We take great pride in everything that we do, control over
                        products allows us to ensure customers receive the best quality service and highest standards, you
                        need a dedicated team of specialists.
                      </p>
                    </div>
                    <div class="col-sm-6 col-md-6 col-lg-6">
                      <div class="form-group">
                        <input type="text"  class="form-control" placeholder="Name" id="contact-name" name="contact-name"
                          required>
                          <span class="text-danger" id="customers_name" ></span>
                          @if ($errors->has('name'))
                          <span class="text-danger">{{ $errors->first('name') }}</span>
                          @endif
                      </div>
                    </div><!-- /.col-lg-6 -->
                    <div class="col-sm-6 col-md-6 col-lg-6">
                      <div class="form-group">
                        <input type="email" class="form-control" placeholder="Email" id="contact-email"
                          name="contact-email" required>
                          <span class="text-danger" id="email_address" ></span>
                          @if ($errors->has('email'))
                          <span class="text-danger">{{ $errors->first('email') }}</span>
                          @endif
                      </div>
                    </div><!-- /.col-lg-6 -->
                    <div class="col-sm-6 col-md-6 col-lg-6">
                      <div class="form-group">
                        <input type="text" class="form-control" placeholder="Phone" id="contact-phone"
                          name="contact-phone" required>
                          <span class="text-danger" id="phone" ></span>
                          @if ($errors->has('phone'))
                          <span class="text-danger">{{ $errors->first('email') }}</span>
                          @endif
                      </div>
                    </div><!-- /.col-lg-6 -->
                    <div class="col-sm-6 col-md-6 col-lg-6">
                      <div class="form-group">
                        <select class="form-control" name="subject" id="subject">
                          <option value="0">Select Your services</option>
                          <option value="service 1">service 1</option>
                          <option value="service 2">service 2</option>
                        </select>
                        <span class="text-danger" id="subject" ></span>
                        @if ($errors->has('subject'))
                        <span class="text-danger">{{ $errors->first('subject') }}</span>
                        @endif
                      </div>
                    </div><!-- /.col-lg-6 -->
                    <div class="col-12">
                      <div class="form-group">
                        <textarea class="form-control" placeholder="Additional Details" id="contact-message"
                          name="contact-message"></textarea>
                          <span class="text-danger" id="message" ></span>
                          @if ($errors->has('message'))
                          <span class="text-danger">{{ $errors->first('message') }}</span>
                          @endif
                      </div>
                      <button type="submit" id="contactusbtn"
                        class="btn btn__secondary btn__block btn__xhight d-flex justify-content-between mt-10">
                        <span>Submit Request</span> <i class="icon-arrow-right icon-outlined"></i>
                      </button>
                      <input type="reset" hidden id="configreset" value="Reset">
                      <div class="contact-result"></div>
                    </div><!-- /.col-lg-12 -->
                  </div><!-- /.row -->
                </form> --}}

                {!!shortCodeToForm('FORM_CONTACT')!!}

                <div
                  class="contact-panel__info d-flex flex-column justify-content-between bg-overlay bg-overlay-primary-gradient">
                  <div class="bg-img"><img src="assets/images/banners/2.jpg" alt="banner"></div>
                  <div>
                    <h3 class="contact-panel__subtitle color-white">Homeowners Like Us!</h3>
                    <h4 class="contact-panel__title color-white">Healthy Environment For Your Family</h4>
                    <p class="contact-panel__desc font-weight-bold color-white mb-30">The processes and systems we put in
                      place provide high quality service with a focus on safety.
                    </p>
                  </div>
                  <div>
                    <ul class="contact__list list-unstyled mb-0">
                      <li>
                        <i class="icon-phone"></i><a href="tel:{{ getSetting('phone')}}">Emergency Line:  {{ getSetting('phone')}}</a>
                      </li>
                      <li>
                        <i class="icon-location"></i><a href="#">Location:  {{getSetting('address')}} {{iso_code2_to_name(getSetting('country'))}}  </a>
                      </li>
                      <li>
                        <i class="icon-clock"></i><a href="contact-us.html">Mon - Fri: 8:00 am - 7:00 pm</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div><!-- /.col-lg-6 -->
          </div><!-- /.row -->
        </div><!-- /.container -->
      </section><!-- /.contact layout 1 -->
  
      <!-- ========================
        feature-layout1
      ========================== -->
      <section class="feature-layout1 pt-0">
        <div class="container">
          <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-6 offset-lg-3">
              <div class="heading text-center">
                <h2 class="heading__subtitle">See Why Homeowners Like Us!</h2>
                <h3 class="heading__title mb-40">The Most Reliable Name in <br> Cleaning Business</h3>
              </div><!-- /heading -->
            </div><!-- /.col-lg-6 -->
          </div><!-- /.row -->
          <div class="row">
            <!-- feature item #1 -->
            <div class="col-sm-6 col-md-6 col-lg-3">
              <div class="feature-item">
                <div class="feature__body">
                  <div class="feature__icon">
                    <i class="icon-hand-dryer"></i>
                  </div><!-- /.feature__icon -->
                  <h4 class="feature__title">Healthy Teams And Social Distance </h4>
                  <p class="feature__desc">Our experts thoroughly trained and use proprietary cleaning and disinfecting
                    systems.</p>
                  <a href="services.html" class="btn btn__secondary btn__link">
                    <i class="icon-arrow-right icon-outlined"></i>
                    <span>Read More</span>
                  </a>
                </div><!-- /.feature__body -->
                <div class="feature__img">
                  <img src="assets/images/features/1.jpg" alt="feature">
                </div><!-- /.feature__img -->
              </div><!-- /.feature-item -->
            </div><!-- /.col-lg-3 -->
            <!-- feature item #2 -->
            <div class="col-sm-6 col-md-6 col-lg-3">
              <div class="feature-item">
                <div class="feature__body">
                  <div class="feature__icon">
                    <i class="icon-bucket"></i>
                  </div><!-- /.feature__icon -->
                  <h4 class="feature__title">Professional Grade Disinfectant </h4>
                  <p class="feature__desc">Reduce cleaning time by about 25% while ensuring a spotless, disinfected
                    environment.</p>
                  <a href="services.html" class="btn btn__secondary btn__link">
                    <i class="icon-arrow-right icon-outlined"></i>
                    <span>Read More</span>
                  </a>
                </div><!-- /.feature__body -->
                <div class="feature__img">
                  <img src="assets/images/features/2.jpg" alt="feature">
                </div><!-- /.feature__img -->
              </div><!-- /.feature-item -->
            </div><!-- /.col-lg-3 -->
            <!-- feature item #3 -->
            <div class="col-sm-6 col-md-6 col-lg-3">
              <div class="feature-item">
                <div class="feature__body">
                  <div class="feature__icon">
                    <i class="icon-wet-floor"></i>
                  </div><!-- /.feature__icon -->
                  <h4 class="feature__title">Sterilized & Disinfected Cleaning Tools</h4>
                  <p class="feature__desc">We'll familiarize ourselves with your facility and then create a customized
                    cleaning.</p>
                  <a href="services.html" class="btn btn__secondary btn__link">
                    <i class="icon-arrow-right icon-outlined"></i>
                    <span>Read More</span>
                  </a>
                </div><!-- /.feature__body -->
                <div class="feature__img">
                  <img src="assets/images/features/3.jpg" alt="feature">
                </div><!-- /.feature__img -->
              </div><!-- /.feature-item -->
            </div><!-- /.col-lg-3 -->
            <!-- feature item #4 -->
            <div class="col-sm-6 col-md-6 col-lg-3">
              <div class="feature-item">
                <div class="feature__body">
                  <div class="feature__icon">
                    <i class="icon-dusting"></i>
                  </div><!-- /.feature__icon -->
                  <h4 class="feature__title">100% Satisfaction Guarantee</h4>
                  <p class="feature__desc">We offers a wide variety of services that can be customized to fit your </p>
                  <a href="services.html" class="btn btn__secondary btn__link">
                    <i class="icon-arrow-right icon-outlined"></i>
                    <span>Read More</span>
                  </a>
                </div><!-- /.feature__body -->
                <div class="feature__img">
                  <img src="assets/images/features/4.jpg" alt="feature">
                </div><!-- /.feature__img -->
              </div><!-- /.feature-item -->
            </div><!-- /.col-lg-3 -->
          </div><!-- /.row -->
          <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-6 offset-lg-3">
              <p class="text__link text-center mb-0">For a cleaning that meets your highest standards, you need a
                dedicated team of
                trained specialists. We arrive at each visit with all supplies needed to thoroughly clean your home with
                our extensive Cleaning Process.
                <a href="services.html" class="btn btn__secondary btn__link mx-1">
                  <span>Contact Us For More Information</span> <i class="icon-arrow-right color-primary"></i>
                </a>
              </p>
            </div><!-- /.col-lg-6 -->
          </div><!-- /.row -->
        </div><!-- /.container -->
      </section><!-- /.feature-layout1 -->

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
<script>
//     $(document).ready(function () {
//         $('#contact-form').validate({
//             rules: {
//               contact-name: {
//                     minlength: 2,
//                     required: true
//                 },
//                 contact-email: {
//                     required: true,
//                 },
//                 contact-phone: {
//                     required: true,
//                 },
//                 subject: {
//                     required: true
//                 },
//                 contact-message: {
//                     required: true
//                 },
//             },
//             highlight: function (element) {
//                 $(element).closest('.cls').removeClass('success').addClass('error');
//                 $(element).css("border", "1px solid red");
//             },
//         });
// });


    $(document).ready(function () {
        $(document).on('click', '#contactusbtn', function (e) {
            e.preventDefault();
            var data = {
                'customers_name': $('#contact-name').val(),
                'email_address': $('#contact-email').val(),
                'subject': $('#subject').val(),
                'phone': $('#contact-phone').val(),
                'message': $('#contact-message').val(),
            }
            
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $.ajax({
                type: "POST",
                url: "{{url('/contactstore')}}",
                data: data,
                dataType: "json",
                success: function (response) {
                    
                    if (response.status == 400) {
                        $.each(response.error, function (key, err_val) {
                            $('#' + key).text(err_val);
                        });
                    }
                    else {
                        Notify('Details Send Successfully', true);
                        $('#contact-form').trigger("reset");
                    }
                }
            });

        });
    });
</script>
@endpush