<section>
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-12">
            <div class="text-center thankyou_wrapper">
                <h2 class="fw-bold mb-1">ThankYou For Your Order</h2>
                <h5 class="mb-1">Order Successfully Placed</h5>
                <div class="py-1" style="
                font-size: 15px; ">
                    <p class="mb-0">Your Order no:<strong class="font-dark">DR7673T613</strong></p>
                <p class=" mb-0">If you have questions about your order, you can email us at</p>
                <p>
                    <a href="mailto:developer@e-nnovation.net">
                        developer@e-nnovation.net</a> or call us <a href="tel:1-877-446-7746">
                            1-877-446-7746</a>
                </p>
                </div>
               <div class="col-lg-2 mx-auto">
                <a href="" class="btn btn-primary btn-lg btn-block">Download Invoice</a>  
               </div>                 
                              
            </div>
        </div><!--end col-->
    </div><!--end row-->
    </div>
  </section