<section class="pricing-layout1 pb-80">
    <div class="container">
      <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-6 offset-lg-3">
          <div class="heading text-center mb-40">
            <h2 class="heading__subtitle">Our Pricing And Plans</h2>
            <h3 class="heading__title">Effective & Flexible Pricing
              That Adapts Your Needs</h3>
          </div><!-- /.heading -->
        </div><!-- /.col-lg-6 -->
      </div><!-- /.row -->
      <div class="row packages-wrapper">
        <!-- pricing item #1-->
        <div class="col-sm-12 col-md-4 col-lg-4">
          <div class="pricing-package">
            <div class="package__body">
              <h4 class="package__subtitle">For Homes</h4>
              <h5 class="package__title">Residential Offers</h5>
              <p class="package__desc">Residential house cleaning services always focus on cleaning for health, our
                extensive industry experience give us a leg up.</p>
              <ul class="package__list list-items list-items-layout2 list-unstyled">
                <li>Window sills & ledges</li>
                <li>Hard surface floors</li>
                <li>Remove cobwebs</li>
                <li>Empty trash</li>
              </ul>
            </div><!-- /.package__body -->
            <div class="package__footer">
              <a href="pricing-offers.html" class="btn btn__primary btn__block justify-content-between">
                <span>Purchase Now</span>
                <i class="icon-arrow-right icon-outlined"></i>
              </a>
              <div class="package__price">
                <span class="package__currency">$</span><span>150</span><span class="package__period">/Mo</span>
              </div>
            </div><!-- /.package__footer -->
          </div><!-- /.pricing-package -->
        </div><!-- /.col-lg-4 -->
        <!-- pricing item #2-->
        <div class="col-sm-12 col-md-4 col-lg-4">
          <div class="pricing-package">
            <div class="package__body">
              <h4 class="package__subtitle">For Business</h4>
              <h5 class="package__title">Commercial Offers</h5>
              <p class="package__desc">Commercial cleaning services will help you protect your customers and
                employees, we care about clean and it shows in our work.</p>
              <ul class="package__list list-items list-items-layout2 list-unstyled">
                <li>Office Buildings</li>
                <li>Manufacturing Facilities</li>
                <li>Educational Facilities</li>
                <li>Medical Facilities</li>
              </ul>
            </div><!-- /.package__body -->
            <div class="package__footer">
              <a href="pricing-offers.html" class="btn btn__secondary btn__block justify-content-between">
                <span>Purchase Now</span>
                <i class="icon-arrow-right icon-outlined"></i>
              </a>
              <div class="package__price">
                <span class="package__currency">$</span><span>250</span><span class="package__period">/Mo</span>
              </div>
            </div><!-- /.package__footer -->
          </div><!-- /.pricing-package -->
        </div><!-- /.col-lg-4 -->
        <!-- pricing item #3-->
        <div class="col-sm-12 col-md-4 col-lg-4">
          <div class="pricing-package">
            <div class="package__body">
              <h4 class="package__subtitle">For Strata</h4>
              <h5 class="package__title">Outdoor Offers</h5>
              <p class="package__desc">Maintaining the cleanliness and appearance of your property is important, need
                a reliable and professional outdoor strata cleaning.</p>
              <ul class="package__list list-items list-items-layout2 list-unstyled">
                <li>High Pressure Cleaning</li>
                <li>Building Exterior Cleaning</li>
                <li>Timber and Sandstone Cleaning</li>
                <li>Roof & Gutter Cleaning</li>
              </ul>
            </div><!-- /.package__body -->
            <div class="package__footer">
              <a href="pricing-offers.html" class="btn btn__accent btn__block justify-content-between">
                <span>Purchase Now</span>
                <i class="icon-arrow-right icon-outlined"></i>
              </a>
              <div class="package__price">
                <span class="package__currency">$</span><span>350</span><span class="package__period">/Mo</span>
              </div>
            </div><!-- /.package__footer -->
          </div><!-- /.pricing-package -->
        </div><!-- /.col-lg-4 -->
      </div><!-- /.row -->
      <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-6 offset-lg-3 text-center">
          <div class="col-12">
            <p class="text__link mb-0">For a cleaning that meets your highest standards, you need a dedicated team of
              trained specialists. We arrive at each visit with all supplies needed to thoroughly clean your home with
              our extensive Cleaning Process.
              <a href="services.html" class="btn btn__secondary btn__link mx-1">
                <span>Contact Us For More Information</span> <i class="icon-arrow-right icon-outlined"></i>
              </a>
            </p>
          </div><!-- /.col-12 -->
        </div><!-- /.row -->
      </div><!-- /.container -->
  </section><!-- /.pricing  -->