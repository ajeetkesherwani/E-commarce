
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Invoice</title>
        <style>
        @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;600&display=swap');
    .clearfix:after {
      content: "";
      display: table;
      clear: both;
    }
    
    a {
      color: #000;
      text-decoration: none;
    }
    p{
      margin:0
    }
    body {
      position: relative;
      width: 21cm;  
      height:24.7cm;
      margin: 0 auto; 
      color: #555555;
      background: #FFFFFF; 
      font-family: 'IBM Plex Sans', sans-serif;
      font-size: 15px;
      padding: 2rem 1rem;
      box-sizing: border-box;
      line-height: 20px;
    
    }
    
    header {
      padding: 10px 0;
      margin-bottom: 20px;
    }
    
    #logo {
      float: left;
    }
    
    #logo img {
      height: 70px;
    }
    
    #company {
      float: right;
    }

    #address {
      width: 50%;
      float: left;
      padding-bottom: 1rem;
    }
    #invoice {
      float: right;
      text-align: right;
      width:50%;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      border-spacing: 0;
      margin-bottom: 20px;
    }
    table th{
      font-size: 14px;
    }
    table th,
    table td {
      padding: 10px 12px;
      text-align: center;
      border-top: 1px solid #f0f0f0;
    }
    
    table .desc {
      text-align: left;
    }
    table tfoot td {
      text-align: left;
      padding: 10px 35px;
      background: #FFFFFF;
      border-bottom: none;
      white-space: nowrap; 
      border:none
    }
    .term {
        font-weight: bold;
    }
    </style>
      </head>
      <body>
        <header class="clearfix">
          <div id="logo">
            <img src="{{ getImageUrlWithKey('invoice_logo') }}" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"  style="margin-bottom: .5rem;" alt="logo_img"><br>
            </div> 
          <div id="company">
            <div>
              <a href="">
                  {{getSetting('invoice_biller_address')}}
              </a>
          </div>
          </div>
        
        </header>
        <main>
          <div id="details" class="clearfix">
            <div id="address">
              <div style="font-weight:bold; margin-bottom:4px">INVOICE TO Order</div>
              <div>
                  {{$orderdetails->address[0]['customer_name'] ?? ''}}<br>
                  {{$orderdetails->address[0]['customer_address'] ?? ''}},   {{$orderdetails->address[0]['customer_city'] ?? ''}} <br>
                  {{$orderdetails->address[1]['customer_state'] ?? ''}},  {{$orderdetails->address[1]['customer_country'] ?? ''}}<br>
                  {{$orderdetails->address[1]['customer_postcode'] ?? ''}}<br>
               <span>Tel:</span> {{$orderdetails->address[0]['customer_phone'] ?? ''}}
                </div>
            </div>
            <div id="invoice">
              <div style="margin-bottom: 4px;"> <span style="font-weight:600;">Invoice No :</span>{{$orderdetails['order_number'] ?? ''}}</div>
              <div> <span style="font-weight:600;">Invoice Date : </span>{{dateFormate($orderdetails['created_at'])}}</div>
              @if(getSetting('invoice_show_tax_number')=='1')
              <div> <span style="font-weight: 600;">Invoice Tax Number: </span>{{getSetting('invoice_tax_number')}}</div>
              @endif
            </div>
          </div>
          @if(!empty($orderdetails->item))
          <table border="0" cellspacing="0" cellpadding="0">
            <thead>
              <tr style="background: #f4f4f4;">
                <th style="text-align:left;"> Service </th>
                <th class="unit"> PRICE</th>
                <th class="qty">QUANTITY</th>
                <th class="total">TOTAL</th>
              </tr>
            </thead>
            <tbody>
              @foreach ($orderdetails->item as $key=>$item)
              <tr style="  background: #ffffff; font-weight: 300;">
                <td class="desc">{{$item->product->description[0]['listing_name'] ?? ''}}
                  @if(!empty($orderdetails['attrOptArray']))
                  @foreach($orderdetails['attrOptArray'][$item->product->product_id] as $attsubarr)
                  @foreach($attsubarr as $attrkey=>$attrVal)
                      <p>{{$attrkey}} : {{$attrVal}}</p>
                  @endforeach
                  @endforeach
                @endif
                </td>
                <td class="unit"> {{currencyFormat($item['base_price']  ?? '')}}</td>
                <td class="qty">{{$orderdetails['total_qty'] ?? ''}}</td>
                <td class="total">{{currencyFormat($item['total_price']) ?? ''}}</td>
              </tr>
              @endforeach
            </tbody>
            <tfoot style="border-top: 1px solid #f0f0f0;">
              <tr>
                <td colspan="2"></td>
                <td>Sub-Total  </td>
                <td style="text-align:right">{{ currencyFormat($orderdetails['sub_total']) ??''}}</td>
              </tr>
              <tr>
                <td colspan="2"></td>
                <td style="border-top: 1px solid #f0f0f0;">Discount </td>
                <td style="text-align:right;border-top: 1px solid #f0f0f0;">{{ currencyFormat($orderdetails['discount_total']) ?? ''}}</td>
              </tr>
              <tr>
                <td colspan="2"></td>
                <td style="border-top: 1px solid #f0f0f0; ">Shipping Charges </td>
                <td style="text-align:right;border-top: 1px solid #f0f0f0;">{{ currencyFormat($orderdetails['shipping_total']) ?? ''}}</td>
              </tr>
              <tr>
                <td colspan="2"></td>
                <td style="border-top: 1px solid #f0f0f0; ">Tax Amount </td>
                <td style="text-align:right;border-top: 1px solid #f0f0f0;">{{ currencyFormat($orderdetails['tax_amount']) ?? ''}}</td>
              </tr>
              
              <tr>
                <td colspan="2"></td>
                <td style="background-color:#f4f4f4;font-weight: 600;">TOTAL </td>
                <td style="text-align:right;background-color:#f4f4f4;">{{ currencyFormat($orderdetails['grand_total']) ?? ''}}</td>
              </tr>
            </tfoot>
          </table>
         @endif
        </main>
        <footer >
          <diV>
            
            <div style="float:left; width:40%">
                <div class="term" >Terms &amp; Conditions</div>
                  <p>{{getSetting('invoice_term_and_condition')}}</p>
                </div>
            </div>
                @if(getSetting('invoice_show_bank_account')=='1')
                <div style="float:right; width:50%; text-align:left">
                  <div class="term" >Bank Details</div>
                  <p>{{getSetting('invoice_bank_account')}}</p>
                </div>
                @endif
              <div style="float:left">
                    <div class="term" >
                      @if(!empty(getSetting('invoice_note')))
                      {{getSetting('invoice_note')}}
                      @endif
                    </div>
              </div>
          </div>
            <div style="display:inline-table; border-top:1px solid #000;padding:1rem 0;margin: 1rem 0; width:100%">
                <span style="float: left;width:33%">
                    <strong>Email : </strong>  {{getSetting('email')}}
                </span>
                <span style="margin-left:60px;">
                    <strong>Call : </strong>  {{getSetting('phone')}}
                </span>
                 <span style="float: right;width:33%">
                    <strong>Website : </strong> {{getSetting('application_domain')}}
                </span>
            </div>
        </footer>
      
    </body>
    </html>
    