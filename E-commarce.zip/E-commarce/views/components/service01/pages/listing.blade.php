@php
$main_arr = [
'title'=>$categoryDesc->categories_name ?? '',
'sublist' => $breadCumbArr
];

@endphp

    <!-- ========================
       page title 
    =========================== -->
    <x-Service01.SharedComponent.BreadCrumb :data="$main_arr" />  
      <!-- ========================
          Services Layout 1
      =========================== -->
        <div class="container">
          <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-6 offset-lg-3">
              <div class="heading text-center mb-60">
                <h2 class="heading__subtitle">{{$categoryDesc->categories_name ?? ''}}Cleaning Plans FOr Your Needs</h2>
                <h3 class="heading__title">Specialist Disinfection Services That Fits Your Premises</h3>
              </div><!-- /.heading -->
            </div><!-- /.col-lg-6 -->
          </div><!-- /.row -->
        </div><!-- /.container -->
   

    <!-- ========================
       shop 
    =========================== -->
    <section class="shop-grid">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 col-md-8 col-lg-9">
            <div class="sorting-options d-flex flex-wrap justify-content-between align-items-center mb-30">
              <strong class="color-secondary">Showing 1:9 of 45 product</strong>
              <select>
                <option selected="" value="0">Sort by latest</option>
                <option value="1">Sort by Popular</option>
                <option value="2">Sort by highest Price </option>
                <option value="3">Sort by lowest Price </option>
              </select>
            </div>
            <div class="row">
           
            @if(!empty($listings) && sizeof($listings)>0)
            @foreach($listings as $listing)
            <x-Service01.shared-component.list-item  :data="$listing" />
            @endforeach
            @endif
              
            </div><!-- /.row -->
            <div class="row">
              <div class="col-sm-12 col-md-12 col-lg-12 text-center">
                {{-- <nav class="pagination-area">
                  <ul class="pagination justify-content-center">
                    <li><a class="current" href="#">1</a></li>
                    <li><a href="#">2</a></li>
                    <li><a href="#"><i class="fa fa-angle-right"></i></a></li>
                  </ul>
                </nav><!-- /.pagination-area --> --}}
                {{ $listings->links() }}
              </div><!-- /.col-lg-12 -->
            </div><!-- /.row -->
          </div><!-- /.col-lg-9 -->
          <div class="col-sm-12 col-md-4 col-lg-3">
            <aside class="sidebar-layout2">
              <div class="widget widget-categories-layout2">
                <h5 class="widget__title">Categories</h5>
                <div class="widget-content">
                  <ul class="list-unstyled mb-0">
                    <li><a href="#">Inventory</a></li>
                    <li><a href="#">Products</a></li>
                    <li><a href="#">Hygiene</a></li>
                    <li><a href="#">Сleanser</a></li>
                    <li><a href="#">Supplies</a></li>
                  </ul>
                </div><!-- /.widget-content -->
              </div><!-- /.widget-categories -->
              <div class="widget widget-search">
                <h5 class="widget__title">Search</h5>
                <div class="widget__content">
                  <form class="widget__form-search">
                    <input type="text" class="form-control" placeholder="Search...">
                    <button class="btn" type="submit"><i class="icon-search"></i></button>
                  </form>
                </div><!-- /.widget-content -->
              </div><!-- /.widget-search -->
              <div class="widget widget-poducts">
                <h5 class="widget__title">Best Sellers</h5>
                <div class="widget__content">
                  <!-- product item #1 -->
                  <div class="widget-product-item d-flex align-items-center">
                    <div class="widget-product__img">
                      <a href="#"><img src="{{LoadAssets('assets/images/products/11.jpg')}}" alt="Product" loading="lazy"></a>
                    </div><!-- /.product-product-img -->
                    <div class="widget-product__content">
                      <h5 class="widget-product__title"><a href="#">Calming Herps</a></h5>
                      <span class="widget-product__price">$ 38.00</span>
                    </div><!-- /.widget-product-content -->
                  </div><!-- /.widget-product-item -->
                  <!-- product item #2 -->
                  <div class="widget-product-item d-flex align-items-center">
                    <div class="widget-product__img">
                      <a href="#"><img src="{{LoadAssets('assets/images/products/10.jpg')}}" alt="Product" loading="lazy"></a>
                    </div><!-- /.product-product-img -->
                    <div class="widget-product__content">
                      <h5 class="widget-product__title"><a href="#">Goji Powder</a></h5>
                      <span class="widget-product__price">$ 33.00</span>
                    </div><!-- /.widget-product-content -->
                  </div><!-- /.widget-product-item -->
                  <!-- product item #3 -->
                  <div class="widget-product-item d-flex align-items-center">
                    <div class="widget-product__img">
                      <a href="#"><img src="{{LoadAssets('assets/images/products/12.jpg')}}" alt="Product" loading="lazy"></a>
                    </div><!-- /.product-product-img -->
                    <div class="widget-product__content">
                      <h5 class="widget-product__title"><a href="#">Biotin Complex</a></h5>
                      <span class="widget-product__price">$ 18.00</span>
                    </div><!-- /.widget-product-content -->
                  </div><!-- /.widget-product-item -->
                </div><!-- /.widget-content -->
              </div><!-- /.widget-poducts -->
              <div class="widget widget-filter">
                <h5 class="widget__title">Pricing Filter</h5>
                <div class="widget__content">
                  <div id="rangeSlider"></div>
                  <div class="d-flex justify-content-between align-items-center">
                    <div class="price-output d-flex align-items-center">
                      <label for="rangeSliderResult">Price: </label>
                      <input type="text" id="rangeSliderResult" readonly>
                    </div>
                    <button class="btn__filter">Filter</button>
                  </div>
                </div><!-- /.widget-content -->
              </div><!-- /.widget-filter -->
              <div class="widget widget-tags">
                <h5 class="widget__title">Tags</h5>
                <div class="widget-content">
                  <ul class="list-unstyled">
                    <li><a href="#">Responsive</a></li>
                    <li><a href="#">Fresh</a></li>
                    <li><a href="#">Modern</a></li>
                    <li><a href="#">Corporate</a></li>
                    <li><a href="#">Business</a></li>
                  </ul>
                </div><!-- /.widget-content -->
              </div><!-- /.widget-Tags -->
            </aside><!-- /.sidebar -->
          </div><!-- /.col-lg-3 -->
        </div><!-- /.row -->
      </div><!-- /.container -->
    </section><!-- /.shop -->

    @push('scripts')
    <script>
    function addToCartFromDetail(lisiting_id) {
      var qtyItemAdd = 1;
      addToCart(lisiting_id,qtyItemAdd);
     }
    </script>
   @endpush   
  
   

