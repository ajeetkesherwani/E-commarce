@if(!empty($orderdetails) && sizeof($orderdetails)>0)
@foreach($orderdetails as $orderData)
@foreach($orderData->item as $orderItems)
<div class="account_page_detail p-0">
    <div class="order_item">
      <div class="d-flex flex-sm-row flex-column ">
          <div class=" position-relative">          
              <img width="250" height="200"
                src="{{getFullImageUrl($orderItems->product->listing_image)}}"
                class=""
                onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="" srcset="">
            
            <div class="item_price">
              <span>
                {{currencyFormat($orderItems->total_price)}}<sub>/</sub>
              </span>
            </div>
        </div>
        <div class="p-4 clearfix">
          <div class="order_item-title">
            <div>
              <h5 class="title mb-2"><a href="" class="text-dark">
                  {{$orderItems->listing_name ?? ''}}</a></h5>
              <address class="item-address">
                {{$orderData->address[0]->customer_address ?? ''}} ,{{$orderData->address[0]->customer_city ?? ''}}
                {{$orderData->address[0]->customer_state ?? ''}} ,{{$orderData->address[0]->customer_country ?? ''}}
                {{$orderData->address[0]->customer_postcode ?? ''}}
              </address>
            </div>
          </div>
  
          <ul class="item_amenities">
            <li>
              <i class="fa fa-shower"></i> <span class="total-baths">2</span> <span class="item-label">Baths</span>
            </li>
  
            <li>
              <i class="fa fa-user"></i> <span class="total-guests">6</span> <span class="item-label">Guests</span>
            </li>
  
            <li class="item-type">House</li>
          </ul>
          <span>
             <time>{{$orderItems->created_at ?? ''}}</time>
          </span>
        </div>
      </div>
    </div>
</div>
@endforeach
@endforeach
@endif