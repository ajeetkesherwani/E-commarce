<!-- Login Form Start -->

<div class="modal fade" id="loginPopup" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog  modal-lg modal-dialog-centered">
        <div class="modal-content rounded shadow border-0">
            <div class="modal-body p-0">
                <div class="modal-button">
                    <button type="button" class=" btn-icon  btn-close login-btn-close" data-bs-dismiss="modal"
                        id="close-modal"><i class="fa fa-times" aria-hidden="true"></i></button>
                </div>

                <div class="alert  m-2 text-white d-none" id="alert_message" role="alert">
                    <!--here alert message come throw ajax-->
                </div>
                <input type="hidden" name="login_source" id="login_source" value="">
                <div class="container-fluid px-0 sub" id="sublogin">
                    <div class="row align-items-center g-0">
                        <!--end col-->
                        <div class="col-lg-12 col-md-12">
                            <h3 class="modal-title text-center mt-2 " id="LoginForm-title">Login</h3>
                            <form class="login-form p-4" id="login-modal-form">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="mb-3">
                                            <label class="form-label">Your Email <span
                                                    class="text-danger">*</span></label>
                                            <div class="form-icon position-relative">
                                                <i class="fa fa-user fea icon-sm icons" aria-hidden="true"></i>
                                                <input type="email" id="login_email" class="form-control ps-5"
                                                    placeholder="Email" name="email" required="">
                                            </div>
                                            <span class="text-danger" id="email-logerror"></span>
                                            @if ($errors->has('email'))
                                                <span class="text-danger">{{ $errors->first('email') }}</span>
                                            @endif

                                        </div>
                                    </div>
                                    <!--end col-->

                                    <div class="col-lg-12">
                                        <div class="mb-3">
                                            <label class="form-label">Password <span
                                                    class="text-danger">*</span></label>
                                            <div class="form-icon position-relative">
                                                <i class="fa fa-key fea icon-sm icons" aria-hidden="true"></i>
                                                <input type="password" name="password" id="login_Password"
                                                    class="form-control ps-5" placeholder="Password" required="">
                                            </div>

                                            <span class="text-danger" id="password-logerror"></span>
                                            @if ($errors->has('password'))
                                                <span class="text-danger">{{ $errors->first('password') }}</span>
                                            @endif

                                        </div>
                                    </div>
                                    <!--end col-->

                                    <div class="col-lg-12">
                                        <h6 class="text-danger text-center" id="invalid-creddential"></h6>
                                    </div>

                                    <div class="col-lg-12">
                                        <div class="d-flex justify-content-between">
                                            <div class="mb-3">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value=""
                                                        id="flexCheckDefault4">
                                                    <label class="form-check-label" for="flexCheckDefault4">Remember
                                                        me</label>
                                                </div>
                                            </div>
                                            <p class="forgot-pass mb-0"><a href="auth-re-password.html"
                                                    class="text-dark fw-bold">Forgot password ?</a></p>
                                        </div>
                                    </div>
                                    <!--end col-->

                                    <div class="col-lg-12 mb-0">
                                        <div class="d-grid">
                                            <button type="submit" class="btn btn-primary" id="modalSignInBtn">Sign
                                                in</button>
                                        </div>
                                    </div>
                                    <!--end col-->

                                    <div class="col-12 text-center">
                                        <p class="mb-0 mt-3"><small class="text-dark me-2">Don't have an account
                                                ?</small> <a href="javascript:void(0)" class="text-dark fw-bold"
                                                id="modalExchSignUpBtn">Sign
                                                Up</a></p>
                                    </div>
                                    <!--end col-->
                                </div>
                                <!--end row-->
                            </form>
                        </div>
                        <!--end col-->
                    </div>
                    <!--end row-->
                </div>
                <!--end container-->


                <!-- Register -->

                <!--Register Modal start-->
                <div class="container-fluid px-0 d-none" id="subregister">
                    <div class="row align-items-center g-0">
                        <!--end col-->
                        <div class="col-lg-12 col-md-12">
                            <h3 class="modal-title mt-2 text-center" id="LoginForm-title">Register</h3>
                            <form class="login-form p-4" id="register-modal-form">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="mb-3">
                                            <label class="form-label">First name<span
                                                    class="text-danger">*</span></label>
                                            <div class="form-icon position-relative">
                                                <i class="fa fa-user fea icon-sm icons" aria-hidden="true"></i>
                                                <input type="text" name="first_name" class="form-control ps-5"
                                                    placeholder="first name" id="register_first_name" required>
                                            </div>
                                            <span class="text-danger" id="register-first_name"></span>
                                            @if ($errors->has('first_name'))
                                                <span class="text-danger">{{ $errors->first('first_name') }}</span>
                                            @endif

                                        </div>
                                    </div>

                                    <div class="col-lg-12">
                                        <div class="mb-3">
                                            <label class="form-label">Email<span class="text-danger">*</span></label>
                                            <div class="form-icon position-relative">
                                                <i class="fa fa-building fea icon-sm icons" aria-hidden="true"></i>
                                                <input type="text" name="register_email" class="form-control ps-5"
                                                    placeholder="Email" id="register_email" required>
                                            </div>

                                            <span class="text-danger" id="register-email"></span>
                                            @if ($errors->has('password'))
                                                <span class="text-danger">{{ $errors->first('password') }}</span>
                                            @endif
                                        </div>
                                    </div>
                                    <!--end col-->

                                    <div class="col-lg-12">
                                        <div class="mb-3">
                                            <label class="form-label">Phone<span class="text-danger">*</span></label>
                                            <div class="form-icon position-relative">
                                                <i class="fa fa-building fea icon-sm icons" aria-hidden="true"></i>
                                                <input type="text" name="register_contact"
                                                    class="form-control ps-5" placeholder="Last name"
                                                    id="register_contact" required>
                                            </div>
                                            <span class="text-danger" id="register-contact"></span>
                                            @if ($errors->has('contact'))
                                                <span class="text-danger">{{ $errors->first('contact') }}</span>
                                            @endif
                                        </div>
                                    </div>

                                    <div class="col-lg-12">
                                        <div class="mb-3">
                                            <label class="form-label">Password <span
                                                    class="text-danger">*</span></label>
                                            <div class="form-icon position-relative">
                                                <i class="fa fa-key fea icon-sm icons" aria-hidden="true"></i>
                                                <input type="password" id="register_password"
                                                    name="register_password" class="form-control ps-5"
                                                    placeholder="Password" required>
                                            </div>
                                            <span class="text-danger" id="register-password"></span>
                                            @if ($errors->has('password'))
                                                <span class="text-danger">{{ $errors->first('password') }}</span>
                                            @endif
                                        </div>
                                    </div>
                                    <!--end col-->

                                    <div class="col-lg-12">
                                        <div class="d-flex justify-content-between">
                                            <div class="mb-3">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value=""
                                                        id="flexCheckDefault4">
                                                    <label class="form-check-label" for="flexCheckDefault4">Remember
                                                        me</label>
                                                </div>
                                            </div>
                                            <p class="forgot-pass mb-0"><a href="auth-re-password.html"
                                                    class="text-dark fw-bold">Forgot password ?</a></p>
                                        </div>
                                    </div>
                                    <!--end col-->

                                    <div class="col-lg-12 mb-0">
                                        <div class="d-grid">
                                            <button type="submit" class="btn btn-primary" id="modalSignUpBtn">Sign
                                                Up</button>
                                        </div>
                                    </div>
                                    <!--end col-->

                                    <div class="col-12 text-center">
                                        <p class="mb-0 mt-3"><small class="text-dark me-2">Already Register
                                                ?</small>
                                            <a href="javascript:void(0)" class="text-dark fw-bold"
                                                id="modalExchSignInBtn">Sign
                                                In</a>
                                        </p>
                                    </div>
                                    <!--end col-->
                                </div>
                                <!--end row-->
                            </form>
                        </div>
                        <!--end col-->
                    </div>
                    <!--end row-->
                </div>

                <!-- End of register modal-->

            </div>
        </div>
    </div>
</div>

{{-- Add New Address Modal Start --}}
<div class="modal fade" id="add-new-address" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog  modal-lg modal-dialog-centered">
        <div class="modal-content rounded shadow border-0">
            <div class="modal-body p-4">
                <div class="container-fluid px-0">
                    <div class="modal-button">
                        <button type="button" class=" btn-icon btn-close" data-bs-dismiss="modal"
                            id="close-modal"><i class="fa fa-times" aria-hidden="true"></i></button>
                    </div>
                    <h3 class="modal-title pb-2" id="LoginForm-title">Add Address</h3>

                    {{-- <form class="login-form ">

                    </form> --}}
                    <form class="needs-validation" novalidate id="Newaddress">
                        @if (!empty($bussinessInfoData))
                            <input type="hidden" id="bussinessInfoData"
                                value="{{ $bussinessInfoData->business_id }}">
                        @endif
                        <div class="row g-3">
                            <div class="col-sm-6">
                                <label for="firstName" class="form-label">Name</label>
                                <input type="text" class="form-control" id="firstName" name="first_name"
                                    value="{{ $user->first_name ?? '' }}" required>
                                <p class="text-danger" id="add_first_name"></p>
                                <div class="invalid-feedback">
                                    Valid Name is required.
                                </div>
                            </div>

                            {{-- <div class="col-sm-6">
                                <label for="lastName" class="form-label">Last name</label>
                                <input type="text" class="form-control" name="last_name" id="lastName"
                                    placeholder="Last Name" value="{{$user->last_name ?? ''}}" required>
                                @error('last_name')
                                <p class="text-danger">{{$message}}</p>
                                @enderror
                                <div class="invalid-feedback">
                                    Valid last name is required.
                                </div>
                            </div> --}}

                            <div class="col-md-6">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" name="billing_email" id="email"
                                    value="{{ $user->email ?? '' }}">

                                <p class="text-danger" id="add_billing_email"></p>

                                <div class="invalid-feedback">
                                    Please enter a valid email address for shipping updates.
                                </div>
                            </div>


                            <div class="col-md-6">
                                <label for="phone" class="form-label">Phone</label>
                                <input type="text" class="form-control" name="billing_phone" id="phone"
                                    placeholder="" required>
                                <p class="text-danger" id="add_billing_phone"></p>
                                <div class="invalid-feedback">
                                    Phone number is required.
                                </div>
                            </div>

                            <div class="col-12">
                                <label for="address">Street Address</label>
                                <input type="text" class="form-control" id="address"
                                    name="billing_street_address">
                                <p class="text-danger" id="add_billing_street_address"></p>
                                <div class="invalid-feedback">
                                    Please enter your billing address.
                                </div>
                            </div>

                            <div class="col-md-6">
                                <label for="city" class="form-label">City</label>
                                <input type="text" class="form-control" name="billing_city" id="city"
                                    required>
                                <p class="text-danger" id="add_billing_city"></p>
                                <div class="invalid-feedback">
                                    Please select a valid City.
                                </div>
                            </div>

                            <div class="col-md-6">
                                <label for="state" class="form-label">State</label>
                                <input type="text" class="form-control" name="billing_state" id="state"
                                    required>
                                <p class="text-danger" id="add_billing_state"></p>
                                <div class="invalid-feedback">
                                    Please provide a valid state.
                                </div>
                            </div>

                            <div class="col-md-6">
                                <label for="country" class="form-label">Country</label>
                                <select class="form-select form-control" name="billing_country" id="country"
                                    required>
                                    <option value="">Choose...</option>
                                    @if (!empty($country_data))
                                        @foreach ($country_data as $key => $countryValue)
                                            <option value="{{ $countryValue->countries_id }}">
                                                {{ $countryValue->countries_name }}
                                            </option>
                                        @endforeach
                                    @endif
                                </select>
                                <p class="text-danger" id="add_billing_country"></p>
                                <div class="invalid-feedback">
                                    Please select a valid country.
                                </div>
                            </div>

                            <div class="col-md-6">
                                <label for="zip" class="form-label">Zip</label>
                                <input type="text" class="form-control" name="billing_zipcode" id="zip"
                                    placeholder="" required>
                                <p class="text-danger" id="add_billing_zipcode"></p>
                                <div class="invalid-feedback">
                                    Zip code required.
                                </div>
                            </div>
                            {{-- <div class="col-md-3">
                                <label for="gst" class="form-label">GST</label>
                                <input type="text" class="form-control" name="billing_gst" id="gst" placeholder=""
                                    required>
                                @error('billing_gst')
                                <p class="text-danger">{{$message}}</p>
                                @enderror
                                <div class="invalid-feedback">
                                    GST is required.
                                </div>
                            </div> --}}
                            <button class="w-100 btn btn-primary " id="Newaddressformbutton"
                                type="button">Submit</button>
                        </div>

                    </form>

                    <!--end row-->
                </div>
                <!--end container-->
            </div>
        </div>
    </div>
</div>
{{-- Add New Modal Form End --}}



{{-- Plan Enquiry modal start --}}

<div class="modal fade" id="planEnquiryModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog  modal-lg modal-dialog-centered">
        <div class="modal-content rounded shadow border-0">
            <div class="modal-body p-4">
                <div class="container-fluid px-0">
                    <div class="modal-button">
                        <button type="button" class=" btn-icon btn-close" data-bs-dismiss="modal"
                            id="close-modal"><i class="fa fa-times" aria-hidden="true"></i></button>
                    </div>
                    <h3 class="modal-title pb-2" id="EnquryForm-title"></h3>
                    <form class="needs-validation" novalidate id="enquiryform">
                        <input type="hidden" name="enquiry_type" id="enq_enquiry_type" value="plan">
                        <input type="hidden" name="page_source" id="enq_page_source" value="planpage">
                        <input type="hidden" name="plan_id" id="enq_plan_id" value="">
                        <div class="row g-3">
                            <div class="col-sm-6">
                                <label for="firstName" class="form-label">Name</label>
                                <input type="text" class="form-control" id="enq_customers_name"
                                    name="customers_name" required>
                                <p class="text-danger" id="enqerr_customers_name"></p>
                                <div class="invalid-feedback">
                                    Please Name is required.
                                </div>
                            </div>

                            <div class="col-md-6">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" name="email_address"
                                    id="enq_email_address">
                                <p class="text-danger" id="enqerr_email_address"></p>
                                <div class="invalid-feedback">
                                    Please enter a valid email address .
                                </div>
                            </div>


                            <div class="col-md-6">
                                <label for="phone" class="form-label">Phone</label>
                                <input type="text" class="form-control" name="phone" id="enq_phone"
                                    placeholder="" required>
                                <p class="text-danger" id="enqerr_phone"></p>
                                <div class="invalid-feedback">
                                    Phone number is required.
                                </div>
                            </div>

                            <div class="col-md-6">
                                <label for="enquiry_file" class="form-label">File</label>
                                <input type="file" class="form-control" name="enquiry_file" id="enq_enquiry_file"
                                    placeholder="" required>
                                <p class="text-danger" id="enqerr_enquiry_file"></p>
                            </div>
                            @if (getSetting('plan_appointment') == 'yes')
                                @if (getSetting('plan_appointment_date') == 'yes')
                                    <div class="col-md-6">
                                        <label for="enq_appointment_date" class="form-label">Appointment Date</label>
                                        <input type="text" class="form-control" value=""
                                            name="appointment_date" id="enq_appointment_date" placeholder="">

                                        <p class="text-danger" id="enqerr_appointment_date"></p>
                                    </div>
                                @endif
                                @if (getSetting('plan_appointment_time') == 'yes')
                                    <div class="col-md-6">
                                        <label for="enq_appointment_time" class="form-label">Appointment Time</label>
                                        <input type="time" class="form-control" value=""
                                            name="appointment_time" id="enq_appointment_time" placeholder="">
                                        <p class="text-danger" id="enqerr_appointment_time"></p>
                                    </div>
                                @endif
                            @endif


                            <div class="col-12">
                                <label for="address">Subject</label>
                                <input type="text" class="form-control" id="enq_subject" name="subject">
                                <p class="text-danger" id="enqerr_subject"></p>
                                <div class="invalid-feedback">
                                    Please enter your subject.
                                </div>
                            </div>

                            <div class="col-12">
                                <div class="form-group">
                                    <label for="address">Message</label>
                                    <textarea class="form-control" placeholder="Additional Details" id="enq_message" name="message"></textarea>
                                    <p class="text-danger" id="enqerr_message"></p>
                                </div>
                            </div>

                            <div class="col-md-8 col-12 py-2">
                                <input type="checkbox" name="newsletter" id="myCheck">
                                <label for="myCheck">(Newsletter) Free Marketing Tips</label>
                            </div>

                            <button class="w-100 btn btn-primary " id="enquirymodalformbutton"
                                type="button">Submit</button>
                        </div>

                    </form>

                    <!--end row-->
                </div>
                <!--end container-->
            </div>
        </div>
    </div>
</div>
{{-- Plan Enquiry modal end --}}


{{-- Add New Address modal form  start --}}

<div class="modal fade" id="AddNewUSerAddress" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog  modal-lg modal-dialog-centered">
        <div class="modal-content rounded shadow border-0">
            <div class="modal-body p-4">
                <div class="container-fluid px-0">
                    <div class="modal-button">
                        <button type="button" class="btn-icon btn-close modal-close" data-bs-dismiss="modal"
                            id="close-modal"><i class="fa fa-times" aria-hidden="true"></i></button>
                    </div>
                    <h3 class="modal-title pb-2" id="EnquryForm-title">Add New Address</h3>
                    <form class="needs-validation" novalidate id="addNewUserAddForm">
                        <div class="row g-3">
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="customer_name" placeholder="Name"
                                    required>
                                <p class="text-danger" id="addUADErr_customer_name"></p>
                            </div>

                            <div class="col-md-6">
                                <input type="email" class="form-control" name="customer_email" placeholder="Email"
                                    required>
                                <p class="text-danger" id="addUADErr_customer_email"></p>
                            </div>

                            <div class="col-md-6">
                                <input type="text" class="form-control" name="phone" placeholder="Phone No."
                                    required>
                                <p class="text-danger" id="addUADErr_phone"></p>
                            </div>

                            <div class="col-md-6">
                                <input type="text" class="form-control" name="street_address"
                                    placeholder="Street Address" required>
                                <p class="text-danger" id="enqerr_phone"></p>
                            </div>

                            <div class="col-md-6">
                                <input type="text" class="form-control" name="city" placeholder="City"
                                    required>
                                <p class="text-danger" id="addUADErr_city"></p>
                            </div>

                            <div class="col-md-6">
                                <input type="text" class="form-control" name="state" placeholder="State"
                                    required>
                                <p class="text-danger" id="addUADErr_state"></p>
                            </div>

                            <div class="col-md-6">
                                <select class="form-select form-control" name="countries_id" id="country" required>
                                    <option selected disabled value="">Choose...</option>
                                    @if (!empty($country_data))
                                        @foreach ($country_data as $key => $countryValue)
                                            <option value="{{ $countryValue->countries_id }}">
                                                {{ $countryValue->countries_name }}
                                            </option>
                                        @endforeach
                                    @endif
                                </select>
                                <p class="text-danger" id="addUADErr_countries_id"></p>
                            </div>

                            <div class="col-md-6">
                                <input type="text" class="form-control" name="zipcode" placeholder="Pincode"
                                    required>
                                <p class="text-danger" id="addUADErr_zipcode"></p>
                            </div>
                            <input type="reset" hidden></button>
                            <button class="w-100 btn btn-primary " id="AddNewUserAddressBtn"
                                type="button">Submit</button>
                        </div>

                    </form>

                    <!--end row-->
                </div>
                <!--end container-->
            </div>
        </div>
    </div>
</div>
{{-- Add New Address modal form end --}}

{{-- update Address modal form  start --}}

<div class="modal fade" id="updateAddressModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog  modal-lg modal-dialog-centered">
        <div class="modal-content rounded shadow border-0">
            <div class="modal-body p-4">
                <div class="container-fluid px-0">
                    <div class="modal-button">
                        <button type="button" class="btn-icon btn-close modal-close" data-bs-dismiss="modal"
                            id="close-modal"><i class="fa fa-times" aria-hidden="true"></i></button>
                    </div>
                    <h3 class="modal-title pb-2" id="EnquryForm-title">Update Address</h3>
                    <form class="needs-validation" novalidate id="UpdateUserAddForm">
                        <div class="row g-3">
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="customer_name"
                                    id="update_customer_name" placeholder="Name" required>
                                <p class="text-danger" id="UPUADErr_customer_name"></p>
                            </div>

                            <div class="col-md-6">
                                <input type="email" id="update_customer_email" class="form-control"
                                    name="customer_email" placeholder="Email" required>
                                <p class="text-danger" id="UPUADErr_customer_email"></p>
                            </div>

                            <div class="col-md-6">
                                <input type="text" id="update_phone" class="form-control" name="phone"
                                    placeholder="Phone No." required>
                                <p class="text-danger" id="addUADErr_phone"></p>
                            </div>

                            <div class="col-md-6">
                                <input type="text" id="update_street_address" class="form-control"
                                    name="street_address" placeholder="Street Address" required>
                                <p class="text-danger" id="enqerr_phone"></p>
                            </div>

                            <div class="col-md-6">
                                <input type="text" id="update_city" class="form-control" name="city"
                                    placeholder="City" required>
                                <p class="text-danger" id="addUADErr_city"></p>
                            </div>

                            <div class="col-md-6">
                                <input type="text" id="update_state" class="form-control" name="state"
                                    placeholder="State" required>
                                <p class="text-danger" id="addUADErr_state"></p>
                            </div>

                            <div class="col-md-6">
                                <select class="form-select form-control" name="countries_id" id="update_countries_id"
                                    required>
                                    <option selected disabled value="">Choose...</option>
                                    @if (!empty($country_data))
                                        @foreach ($country_data as $key => $countryValue)
                                            <option value="{{ $countryValue->countries_id }}">
                                                {{ $countryValue->countries_name }}
                                            </option>
                                        @endforeach
                                    @endif
                                </select>
                                <p class="text-danger" id="addUADErr_countries_id"></p>
                            </div>
                            <div class="col-md-6">
                                <input type="text" id="update_zipcode" class="form-control" name="zipcode"
                                    placeholder="Pincode" required>
                                <p class="text-danger" id="addUADErr_zipcode"></p>
                            </div>
                            <input type="reset" hidden></button>
                            <button class="w-100 btn btn-primary " id="updateAddressButton"
                                type="button">Submit</button>
                        </div>

                    </form>

                    <!--end row-->
                </div>
                <!--end container-->
            </div>
        </div>
    </div>
</div>
{{-- update Address modal form end --}}

