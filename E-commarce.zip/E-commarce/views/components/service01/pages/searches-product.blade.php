@php
$main_arr = [
'title'=>'Shop Products',
'sublist' => [
[
'name'=>'HOME',
'link'=>url("/")
],
[
'name'=>'Search Result',
'link'=>url("")
],
]
];
// dd($products);
@endphp

<x-Theme1.SharedComponent.BreadCrumb :data="$main_arr" />
<!-- Breadcrumb Area End -->
<!-- Shop Category Area End -->
<div class="shop-category-area">
    @if(!empty($products['product_count']) )
    <div class="container">
        <div class="row">
            <div class="col-lg-12 order-lg-last col-md-12 order-md-first">
                <!-- Shop Top Area Start -->
                <div class="shop-top-bar">
                    <!-- Left Side start -->
                    <div class="shop-tab nav mb-res-sm-15">
                        <a class="active" href="#shop-1" data-bs-toggle="tab">
                            <i class="fa fa-th show_grid"></i>
                        </a>
                        <a href="#shop-2" data-bs-toggle="tab">
                            <i class="fa fa-list-ul"></i>
                        </a>
                        @if(!empty($products['product_count']))
                        <p>There Are {{$products['product_count']}} Products.</p>
                        @endif
                    </div>
                    <!-- Left Side End -->
                    <!-- Right Side Start -->
                    <div class="select-shoing-wrap">
                        <div class="shot-product">
                            <p>Sort By:</p>
                        </div>
                        <div class="shop-select">
                            <select name="sortBy" class="filter_style " id="sortBy" onChange="filterItem()">
                                <option value="latest">Short by latest</option>
                                <option value="pricemintohigh">Price min to high</option>
                                <option value="pricehightomin">Price high to min</option>
                                <option value="atoz">A to Z</option>
                                <option value="ztoa">Z to A</option>
                                <option value="instock">In stock</option>
                            </select>
                        </div>
                    </div>
                    <!-- Right Side End -->
                </div>
                <!-- Shop Top Area End -->

                <!-- Shop Bottom Area Start -->
                <div class="shop-bottom-area mt-35" id="filterProductData">
                    <!-- Shop Tab Content Start -->
                    <div class="tab-content jump">
                        <!-- Tab One Start -->
                        <div id="shop-1" class="tab-pane active">
                            <div class="row">
                                @if(!empty($products['product']) && sizeof($products['product'])>0)
                                @foreach($products['product'] as $product)
                                <div class="col-xl-3 col-md-6 col-lg-4 col-sm-6 col-xs-12">
                                    <x-theme1.shared-component.product viewtype="grid" :data="$product" />
                                </div>
                                @endforeach
                                @endif
                            </div>
                        </div>
                        <!-- Tab One End -->
                        <!-- Tab Two Start -->
                        <div id="shop-2" class="tab-pane">
                            @if(!empty($products['product']) && sizeof($products['product'])>0)
                            @foreach($products['product'] as $product)
                            <x-theme1.shared-component.product viewtype="list" :data="$product" />
                            @endforeach
                            @else
                            <center>
                                <h3 class="text-secondary">No product avaliable for this query.</h3>
                            </center>
                            @endif
                        </div>
                        <!-- Tab Two End -->
                    </div>
                    <!-- Shop Tab Content End -->
                    <!--  Pagination Area Start -->
                    {{-- <input type="hidden" id="nextPage" value="1">
                    <div class="pro-pagination-style text-center">
                        <ul>
                            <li>
                                <a class="prev" href="#"><i class="ion-ios-arrow-left"></i></a>
                            </li>
                            <li><a class="active" href="#">1</a></li>
                            <li><a href="#">2</a></li>
                            <li>
                                <a class="next" href="#"><i class="ion-ios-arrow-right"></i></a>
                            </li>
                        </ul>
                    </div> --}}

                    <div class="pro-pagination-style text-center">
                        {{-- Pagination --}}
                        <div class="row">
                            <div class="col-md-12 d-flex justify-content-center p-2">
                            {{ $products['product']->links('vendor.pagination.for-ajax') }}
                            </div>
                        </div>
                    </div>
                    <!--  Pagination Area End -->
                </div>
                <!-- Shop Bottom Area End -->
            </div>

        </div>
    </div>
    @else
<img src="{{ LoadAssets('assets/images/EmptyImages/Cart-Empty.jpg')}}" class="rounded mx-auto d-block" width="286px" height="200px" alt="...">
<p class="h4 text-center text-dark mt-2">Sorry, no results found!</p>
<div class="text-center my-3">
<a href="{{url('/')}}" class="btn btn-primary btn-lg btn-block" role="button" aria-pressed="true">Continue to shop</a>
</div>
@endif
</div>