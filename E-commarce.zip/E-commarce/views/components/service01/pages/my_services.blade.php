@push('styles')
@endpush
@php

$main_arr = [
    'title' => 'My Services',
    'sublist' => [
        [
            'name' => 'HOME',
            'link' => url('/'),
        ],
        [
            'name' => 'Addresses',
            'link' => url(' '),
        ],
    ],
];
@endphp

<x-Service01.SharedComponent.BreadCrumb :data="$main_arr" />

<section>
    <div class="container">

        {{-- breadcumb --}}

        <div class="row">
            <x-Service01.SharedComponent.left-side-menu />
            <div class="col-lg-8 col-sm-12">
                <div class="account_page_detail ">
                    <h4 class="account_page__title ">My Services</h4>
                    <div class="row">
                      @if (!empty($activeSubscription) && sizeof($activeSubscription) > 0)
                      <p class="h5 text-success">Active Subscription</p> <br/>
                      @foreach ($activeSubscription as $key => $active_subs_data)
                      @if (!empty($active_subs_data->plandetails))
                        <div class="col-lg-6 col-md-6 pb-2">
                            <div class=" p-3 service_detail shadow ">
                                <h6 class="mb-0">{{ $active_subs_data->plandetails->plan_name ?? '' }}</h6>
                                zosijoto@mailinator.com<br>
                                8938384066<br>
                                Dolores enim dolor c, Culpa odit id sed<br>
                                Non qui beatae quide

                            </div>
                            <ul class="list-unstyled head mb-0">
                              @if ($active_subs_data->status == 0)
                                  <li class="badge bg-danger rounded-pill">InActive</li>
                              @elseif($active_subs_data->status == 1)
                                  <li class="badge bg-success rounded-pill">Active</li>
                              @elseif($active_subs_data->status == 2)
                                  <li class="badge bg-danger rounded-pill">Canceld</li>
                              @endif
                              </ul>
                            <div class="d-flex justify-content-between mt-3">
                                <a href="" class="">
                                    <i class="fas fa-solid fa-trash align-middle "></i>

                                    Cancel Subscription
                                </a>

                                <div class="button btn btn__secondary ">
                                    <a href="">Renew Subscription</a>
                                </div>
                            </div>
                        </div>
                      @endif
                      @endforeach
                      @endif

                     
                      @if (!empty($inactiveSubscription) && sizeof($inactiveSubscription) > 0)
                      <p class="h5 text-danger">InActive Subscription</p><br/>
                      @foreach ($inactiveSubscription as $key => $inactive_subs_data)
                      @if (!empty($inactive_subs_data->plandetails))
                        <div class="col-lg-6 col-md-6 pb-2">
                            <div class=" p-3 service_detail shadow ">
                                <h6 class="mb-0">{{ $inactive_subs_data->plandetails->plan_name ?? '' }}</h6>
                                Subscription ID :  #{{ $inactive_subs_data->subscription_unique_id ?? '' }}
                                <br/>
                                
                                @if ($inactive_subs_data->status == 1 || $inactive_subs_data->status == 2)
                                @if ($inactive_subs_data->status == 1)
                                Renewal Date
                                @else
                                    Expiray At
                                @endif
                                :</span>
                                {{ $inactive_subs_data->expired_at ?? '' }}
                                <br/>
                                @endif
                                <ul class="list-unstyled head mb-0">
                                    @if ($inactive_subs_data->status == 0)
                                        <li class="badge bg-danger rounded-pill">InActive</li>
                                    @elseif($inactive_subs_data->status == 1)
                                        <li class="badge bg-success rounded-pill">Active</li>
                                    @elseif($inactive_subs_data->status == 2)
                                        <li class="badge bg-danger rounded-pill">Canceld</li>
                                    @endif
                                </ul>
                            </div>
                            <div class="d-flex justify-content-between mt-3">

                                @if ($inactive_subs_data->status == 1)
                                <a href="javascript:void(0)" id="cancel_subs_btn" value="{{ $inactive_subs_data->subscription_unique_id }}">
                                    <i class="fas fa-solid fa-trash align-middle "></i>
                                    Cancel Subscription
                                </a>
                                @endif

                                @if ($inactive_subs_data->status == 0 )
                                <div class="button btn btn__secondary ">
                                    <a href="{{ url('subscription/' . $inactive_subs_data->subscription_unique_id) }}">Renew Subscription</a>
                                </div>
                                @endif

                                <div class="button btn btn__secondary ">
                                    <a href="{{ url('account/transaction-details/' . $inactive_subs_data->subscription_unique_id) }}" class="btn btn-soft-primary">View Detail <i class="uil uil-angle-right-b align-middle"></i></a>
                                </div>
                            </div>
                           
                        </div>
                      @endif
                      @endforeach
                      @endif

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
