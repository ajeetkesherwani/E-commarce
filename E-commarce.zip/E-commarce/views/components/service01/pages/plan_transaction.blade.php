<div class="p-1">
    <div class="d-flex align-items-center justify-content-between">
        <h5 class="m-4">Plan Transaction History</h5>
    </div>

    <div class=" shadow rounded p-4">
        <div class="col-md- col-12 mt-4 pt-2 account_page">
            <div class="tab-content" id="pills-tabContent">
                <div class="col-lg-8 col-12">
                    <div class="pb-4">
                        <div class="row">
                            <div class="col-md-8 ">
                                <h5>Plan Preview </h5>
                                <div class="mt-4">
                                    <div class="d-flex align-items-center mt-3">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                            viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                            stroke-linecap="round" stroke-linejoin="round"
                                            class="feather feather-user-check fea icon-ex-md text-muted me-3">
                                            <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                                            <circle cx="8.5" cy="7" r="4"></circle>
                                            <polyline points="17 11 19 13 23 9"></polyline>
                                        </svg>
                                        <div class="account_page_content">
                                            <div class="account_page_heading">
                                                <h6 class="text-primary mb-0">Subscription Id:</h6>
                                            </div>
                                            <div class="account_page_content"><a href="javascript:void(0)"
                                                    class="text-muted">{{ $subsplanTransData->subscription_unique_id ?? '' }}</a>
                                            </div>
                                        </div>
                                    </div>

                        
                                    <div class="d-flex align-items-center mt-3 ">
                                        <!-- <i class="uil uil-building  align-middle me-2 mb-0"></i> -->
                                        <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" width="22"
                                            height="22" stroke-width="2">
                                            <path
                                                d="M12.5 13h-1a1 1 0 0 0 0 2h1a1 1 0 0 0 0-2ZM12.5 9h-1a1 1 0 0 0 0 2h1a1 1 0 0 0 0-2ZM12.5 5h-1a1 1 0 0 0 0 2h1a1 1 0 0 0 0-2ZM8.5 13h-1a1 1 0 0 0 0 2h1a1 1 0 0 0 0-2ZM8.5 9h-1a1 1 0 0 0 0 2h1a1 1 0 0 0 0-2ZM8.5 5h-1a1 1 0 0 0 0 2h1a1 1 0 0 0 0-2ZM16.5 13h-1a1 1 0 0 0 0 2h1a1 1 0 0 0 0-2ZM16.5 9h-1a1 1 0 0 0 0 2h1a1 1 0 0 0 0-2ZM16.5 5h-1a1 1 0 0 0 0 2h1a1 1 0 0 0 0-2Z"
                                                fill="#555555" class="fill-000000 "></path>
                                            <path
                                                d="M22 21h-1V2a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v19H2a1 1 0 0 0 0 2h20a1 1 0 0 0 0-2Zm-12 0v-2h4v2Zm6 0v-3a1 1 0 0 0-1-1H9a1 1 0 0 0-1 1v3H5V3h14v18Z"
                                                fill="#555555" class="fill-000000 "></path>
                                        </svg>

                                        <div class="account_page_content ms-3">
                                            <div class="account_page_heading">
                                                <h6 class="text-primary mb-0">Plan Name:</h6>
                                            </div>
                                            <div class="account_page_content"><a href="javascript:void(0)"
                                                    class="text-muted">{{ $subsplanTransData->subsHistoryData->plan_name ?? '' }}</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-center mt-3">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                            viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                            stroke-linecap="round" stroke-linejoin="round"
                                            class="feather feather-mail fea icon-ex-md text-muted me-3">
                                            <path
                                                d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z">
                                            </path>
                                            <polyline points="22,6 12,13 2,6"></polyline>
                                        </svg>
                                        <div class="account_page_content">
                                            <div class="account_page_heading">
                                                <h6 class="text-primary mb-0">Duration :</h6>
                                            </div>
                                            <div class="account_page_content"><a href="javascript:void(0)"
                                                    class="text-muted">{{ $subsplanTransData->subsHistoryData->plan_duration . '/Months' ?? '' }}</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-center mt-3">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                            viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                            stroke-linecap="round" stroke-linejoin="round"
                                            class="feather feather-mail fea icon-ex-md text-muted me-3">
                                            <path
                                                d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z">
                                            </path>
                                            <polyline points="22,6 12,13 2,6"></polyline>
                                        </svg>
                                        <div class="account_page_content">
                                            <div class="account_page_heading">
                                                <h6 class="text-primary mb-0">Renewal Date :</h6>
                                            </div>
                                            <div class="account_page_content"><a href="javascript:void(0)"
                                                    class="text-muted">{{ $subsplanTransData->expired_at  ?? '----' }}</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-center mt-3">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                            viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                            stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                            class="feather feather-mail fea icon-ex-md text-muted me-3">
                                            <path
                                                d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z">
                                            </path>
                                            <polyline points="22,6 12,13 2,6"></polyline>
                                        </svg>
                                        <div class="account_page_content">
                                            <div class="account_page_heading">
                                                <h6 class="text-primary mb-0"> Plan Status :</h6>
                                            </div>
                                            <div class="account_page_content"><a href="javascript:void(0)"
                                                    class="text-muted">
                                                    @switch($subsplanTransData->status)
                                                        @case(0)
                                                            <td><span
                                                                    class="badge badge-pill badge-danger  bg-warning">InActive</span>
                                                            </td>
                                                        @break

                                                        @case(1)
                                                            <td><span
                                                                    class="badge badge-pill badge-danger  bg-success">Active</span>
                                                            </td>
                                                        @break

                                                        @default
                                                            <td><span
                                                                    class="badge badge-pill badge-danger  bg-danger">Canceled</span>
                                                            </td>
                                                    @endswitch
                                                </a>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <!--end col-->
                        </div>
                        <!--end row-->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12 mt-4 pt-2">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col" class="border-bottom">#</th>
                        <th scope="col" class="border-bottom">Date</th>
                        <th scope="col" class="border-bottom">Invoice No,</th>
                        <th scope="col" class="border-bottom">Payment Amount</th>
                        <th scope="col" class="border-bottom">Payment Method</th>
                        <th scope="col" class="border-bottom">Invoice Download</th>
                    </tr>
                </thead>
            
                <tbody>
                    @if (!empty($subsplanTransData->SubsTransaction) && sizeof($subsplanTransData->SubsTransaction)>0)
                        @foreach ($subsplanTransData->SubsTransaction as $key => $planTransData)
                            <tr>
                                <th scope="row">1</th>
                                <td>{{ $planTransData->created_at ?? '' }}</td>
                                <td>{{ $planTransData->invoice_no ?? '' }}</td>
                                <td>{{ $planTransData->payment_amount ?? '' }}</td>
                                <td>{{ $planTransData->payment_methods->method_name ?? '' }}</td>
                                @if($planTransData->payment_status=='1')
                                <td><a href="{{url('account/download-invoice/'.$planTransData->subs_txn_id)}}">
                                    Download invoice <i class="uil uil-arrow-right"></i>
                                  </a></td>
                                @endif
                            </tr>
                        @endforeach
                    @else
                        <tr>
                            <td class="h4 colspan=4">No Data Available</td>
                        <tr>
                    @endif
                </tbody>

            </table>
        </div>
        <!--end col-->
    </div>
</div>


{{-- Transaction history details  in pop up start here --}}

<div class="modal fade" id="planTransModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog  modal-lg modal-dialog-centered">
        <div class="modal-content rounded shadow border-0">
            <div class="modal-body p-4">
                <div class="container-fluid px-0">
                    <div class="modal-button">
                        <button type="button" class="btn btn-icon btn-close" data-bs-dismiss="modal"
                            id="close-modal"><i class="uil uil-times fs-4 text-dark"></i></button>
                    </div>
                    <h3 class="modal-title pb-2" id="LoginForm-title">Plan Transaction</h3>

                    <!--end row-->
                </div>
                <!--end container-->
            </div>
        </div>
    </div>
</div>



@push('scripts')
    <script>
        $(document).ready(function() {
            $(document).on('click', '#transData', function(e) {
                e.preventDefault();
                $('#NewAcaddress').addClass('was-validated');
                var data = {
                    'subs_history_id': $('#transData').attr('value'),
                }
                //console.log(data);
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{ url('account/plan-hist-transaction') }}",
                    data: data,
                    dataType: "json",
                    success: function(response) {
                        console.log(response);
                    }
                });
            });
        });
    </script>
@endpush

