@push('styles')
@endpush
@php

$main_arr = [
    'title' => 'Support Ticket',
    'sublist' => [
        [
            'name' => 'HOME',
            'link' => url('/'),
        ],
        [
            'name' => 'Addresses',
            'link' => url(' '),
        ],
    ],
];
@endphp

<x-Service01.SharedComponent.BreadCrumb :data="$main_arr" />

<section>
    <div class="container">
    {{-- Breadcumb --}}

      <div class="row">
        <x-Service01.SharedComponent.left-side-menu />
        <div class="col-lg-8 col-sm-12">
          <div class="account_page_detail ">
            <div class="d-flex justify-content-between align-items-center mb-3">
              <h4 class="account_page__title mb-0 ">Support Tickets</h4>
            <div>
              <button id="create-user" class="ui-button ui-corner-all ui-widget btn btn__secondary px-4"><i class="fas fa-regular fa-plus"></i>Create Ticket</button>
            </div>
            </div>
          
            <div class="row">
              <div class="col-lg-12 col-md-12 pb-2">
                <div class="table-responsive ">
                  <table class=" table m-0 table-center table-nowrap">
                      <thead>
                          <tr class="border">
                              <th scope="col" class=" text-center">#</th>
                              <th scope="col" class=" text-center">Ticked No</th>
                              <th scope="col" class=" text-center">Subject</th>
                              <th scope="col" class=" text-center">Status</th>
                              <th scope="col" class=" text-center">Action</th>
                          </tr>
                      </thead>
                      <tbody>
                        <tr class="h4">
                          <td colspan="5" class=" text-center">
                            <h6 class="mb-0">No Ticket Raised</h6>
                          </td>
                        </tr>
                      </tbody>
                  </table>
              </div>
      
              </div>
             
            </div>
            <!-- ==== -->
           <div class="row col-lg-6 col-md-6">
            </div>

            <div id="popup" style="display: none;">
              <div class="overlay"></div>
              <div class="content col-lg-12">
                <div>
                  <div id="close">✖</div>
                </div>
                <form>
                  <fieldset>
                    <label for="name">Name</label>
                    <input type="text" name="name" id="name" value="Jane Smith" class="text ui-widget-content ui-corner-all">
                    <label for="email">Email</label>
                    <input type="text" name="email" id="email" value="jane@smith.com" class="text ui-widget-content ui-corner-all">
                    <label for="password">Password</label>
                    <input type="password" name="password" id="password" value="xxxxxxx" class="text ui-widget-content ui-corner-all">
                    <input type="submit" tabindex="-1" style="position:absolute; top:-1000px">
                  </fieldset>
                </form>
                <footer>
                  <!-- <button type="button" id="create">Create an account</button> -->
                  <button type="button" id="cancel">Cancel</button>
                </footer>
              </div>
            </div>
         
          
           </div>
           <!-- === -->
          </div>
      </div>
     

    </div>

  </section>