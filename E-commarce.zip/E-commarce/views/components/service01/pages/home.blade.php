@if(!empty($templateComponentKey))
 @foreach ($templateComponentKey as $templateComponentKey)
  @switch($templateComponentKey->component_key)
  {{-- @case($templateComponentKey->component_key == config('constkey.home_slider')) --}}
  @case($templateComponentKey->component_key == config('constkey.home_slider'))
    <!-- ============================
        Slider
    ============================== -->

    @if(!empty($slider_data))
    <section class="slider">
        <div class="slick-carousel carousel-arrows-light carousel-dots-light m-slides-0"
          data-slick='{"slidesToShow": 1, "arrows": true, "dots": true, "speed": 700,"fade": true,"cssEase": "linear"}'>
          @foreach($slider_data as $key=>$data)
          <div class="slide-item bg-overlay align-v-h">
          <div class="bg-img"><img src="{{$data->image}}" alt="slide img"></div>
            <div class="container">
              <div class="row align-items-center">
                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-7">
                  <div class="slide__content">
                    <h2 class="slide__title">{{$data->banners_title ?? ''}}</h2>
                    <div class="d-flex flex-wrap align-items-center">
                      <a href="{{$data->banners_url}}" class="btn btn__accent mr-30">
                        <span>View More</span>
                        <i class="icon-arrow-right"></i>
                      </a>
                    </div>
                  </div><!-- /.slide-content -->
                </div><!-- /.col-xl-7 -->
              </div><!-- /.row -->
            </div><!-- /.container -->
          </div><!-- /.slide-item -->
          @endforeach
        </div><!-- /.carousel -->
      </section><!-- /.slider -->
      @endif
      @break
  
    @case($templateComponentKey->component_key == config('constkey.popular_category'))
    <!-- ========================
        Services Layout 1
    =========================== -->
    @if(!empty($popular_category))
      <section class="services-layout1 services-carousel pt-130 pb-60">
        <div class="bg-img"><img src="{{LoadAssets('assets/images/backgrounds/3.jpg')}}" alt="background"></div>
        <div class="container">
          <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-6 offset-lg-3">
              <div class="heading text-center mb-60">
                <h2 class="heading__subtitle">Cleaning Plans For Your Needs</h2>
                {{-- <h3 class="heading__title">Specialist Disinfection Services That Fits Your Premises (Popular Category)</h3> --}}
                <h3 class="heading__title">{{translation('POPULAR_CATEGORIES')}}</h3>
              </div><!-- /.heading -->
            </div><!-- /.col-lg-6 -->
          </div><!-- /.row -->
          <div class="row">
            <div class="col-12">
              <div class="slick-carousel"
                data-slick='{"slidesToShow": 3, "slidesToScroll": 3, "autoplay": false, "arrows": false, "dots": true, "responsive": [ {"breakpoint": 992, "settings": {"slidesToShow": 2,"slidesToScroll": 2}}, {"breakpoint": 767, "settings": {"slidesToShow": 1,"slidesToScroll": 1}}, {"breakpoint": 480, "settings": {"slidesToShow": 1,"slidesToScroll": 1}}]}'>
                <!-- service item  -->
            
                 @foreach($popular_category as $pckey=>$popCatval)
                <div class="service-item">
                  <div class="service__overlay">
                    <div class="bg-img">
                      <img src="{{LoadAssets('assets/images/services/1.jpg')}}"  alt="service">
                    </div>
                  </div><!-- /.service__overlay -->
                  <div class="service__body">
                    {{-- <div class="service__icon">
                      <i class="icon-house"></i>
                    </div> --}}
                    <!-- /.service__icon -->
                    <img src="{{getFullImageUrl($popCatval->categories_image)}}"  onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="category-listing">
                    <h4 class="service__title">{{$popCatval->category_name ?? ''}}</h4>
                    <div class="service__desc">
                    <p class="service__desc">
                      {!! Str::limit($popCatval->category_description ?? '',150) !!}
                    </p>
                    </div>
                    <a href="{{route('categorySlug',['slug'=>$popCatval->categories_slug])}}" class="btn btn__secondary btn__block d-flex justify-content-between">
                      <span>Read More</span>
                      <i class="icon-arrow-right icon-outlined"></i>
                    </a>
                  </div><!-- /.service__body -->
                </div><!-- /.service-item -->
                @endforeach
              </div><!-- /.carousel -->
            </div><!-- /.col-12 -->
          </div><!-- /.row -->
        </div><!-- /.container -->
      </section><!-- /.Services Layout 1 -->
      @endif
     @break
     @endswitch
    @endforeach
  @endif

<!--Starting of Newslatter Modal-->
<div class="modal newsmodal" id="onloadModal">
  <div class="modal-dialog newslatter_modal_dialog">
      <div class="modal-content">

          <!-- Modal Header -->
          <div class="modal-header">
              <section class="pop-up-from">
                  <div class="content newsmodal">

                  </div>
              </section>
              <button type="button" class="btn-close" id="btnnewslatter" data-bs-dismiss="modal"></button>
          </div>
      </div>
  </div>
</div>
<!--Ending of NewsLatter Modal-->