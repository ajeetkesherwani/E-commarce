<section class="pb-80">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-10 mx-auto">
                <section class="contact-layout4 py-0">
                    <div class="contact-panel">
                        <div class=" p-3" style="box-shadow:0px 3px 10px 0px rgb(157 157 157 / 5%)">
                            <div class="plan_heading">
                                <h4 class="contact-panel__title">Services Details</h4>
                            </div>
                          
                            @if(!empty($list) && sizeof($list['cart_list'])>0)
                            @foreach($list['cart_list'] as $cartVal)
                            <div class="industry_name">
                                <h6 class="mb-0">Service Name: Cleaning Services (Now Static) : Quantity {{$cartVal->qty ?? ''}} : Price {{$cartVal->final_price ?? ''}}</h6>
                            </div>
                            @endforeach
                            <div class="row align-items-center">
                                <div class="col-lg-3 industry_name">
                                    <h6 class="mb-lg-0">Grand Total: {{ $list['grand_total'] ?? '' }}</h6>
                                </div>
                            </div>
                            @endif
                        </div>
                        <form action="{{url('place-order')}}" method="POST" class="needs-validation"
                            id="checkout_form" novalidate>
                            @csrf
                            {{-- <input type="hidden" class="form-control" name="pricing_id" value="{{ $pricing_id }}"> --}}

                            @if (!empty($addressList) && sizeof($addressList) > 0)
                                <div class="col-lg-12 add_section m-3">
                                    <div class="d-flex justify-content-between px-3">
                                        <div class="plan_heading">
                                            <h4>Billing Address</h4>
                                        </div>
                                        <div class="form_address " id="createAddress">
                                            <a href="javascript:void(0)" id="addNewAdd"><i class="fa fa-regular fa-plus"
                                                    style="font-size: 10px; "></i> Add Address</a>
                                        </div>
                                    </div>
                                    <div class="row" id="addressboxes">
                                        @foreach ($addressList as $AddressKey => $AddressVal)
                                            <div class="col-lg-6 ">
                                                <div
                                                    class="addressboxes_container shadow d-flex justify-content-between px-3">
                                                    <input id="credit" value={{ $AddressVal->address_id }}
                                                        name="address_id" type="radio" class="form-check-input"
                                                        required {{ $AddressVal->is_default == 1 ? 'checked' : '' }}
                                                        style="float:left;">
                                                    <div class="px-4">
                                                        <h5>{{ $AddressVal->customer_name ?? '' }}</h5>
                                                        <h6>{{ $AddressVal->customer_email ?? '' }}</h6>
                                                        {{ $AddressVal->street_address, $AddressVal->city }}<br />
                                                        {{ $AddressVal->state }}<br />
                                                        {{ country_name($AddressVal->countries_id) }} ,
                                                        {{ $AddressVal->zipcode }}
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                    </div>
                                </div>
                            @else
                                <div class="container-fluid mt-4">
                                    <h3 class="contact-panel__title pb-2" id="">Billing Address</h3>
                                    <div class="row ">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                {{-- <label for="Name">Name <span class="text-danger">*</span></label> --}}
                                                <input type="text" class="form-control" name="customer_name"
                                                    value="" required placeholder="Name">
                                                @error('customer_name')
                                                    <p class="text-danger mb-5">{{ $message }}</p>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                {{-- <label for="email">Email <span class="text-danger">*</span></label> --}}
                                                <input type="email" class="form-control" name="customer_email"
                                                    value="" placeholder="Email" required="">
                                                @error('customer_name')
                                                    <p class="text-danger mb-5">{{ $message }}</p>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                {{-- <label for="phone"> Phone No. <span class="text-danger">*</span></label> --}}
                                                <input type="text" class="form-control" name="customer_phone" value=""
                                                    placeholder="Phone No." required="">
                                                @error('customer_phone')
                                                    <p class="text-danger mb-5">{{ $message }}</p>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                {{-- <label for="services">Street Address <span class="text-danger">*</span></label> --}}
                                                <input type="text" class="form-control" name="customer_address"
                                                    value="" placeholder="Street Address " required="">
                                                @error('customer_address')
                                                    <p class="text-danger mb-5">{{ $message }}</p>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                {{-- <label for="city"> City <span class="text-danger">*</span></label> --}}
                                                <input type="text" class="form-control" name="customer_city" value=""
                                                    placeholder="City" required="">
                                                @error('customer_city')
                                                    <p class="text-danger mb-5">{{ $message }}</p>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                {{-- <label for="state"> State <span class="text-danger">*</span></label> --}}
                                                <input type="text" class="form-control" name="customer_state"
                                                    value="" placeholder="State" required="">
                                                @error('customer_state')
                                                    <p class="text-danger mb-5">{{ $message }}</p>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                {{-- <label for="state"> Country<span class="text-danger">*</span></label> --}}
                                                <select class="form-select form-control w-100 country-dropdown"
                                                    name="countries_id" required>
                                                    <option value="">Choose a country...</option>
                                                    @if (!empty($countries))
                                                        @foreach ($countries as $key => $countryValue)
                                                            <option value="{{ $countryValue->countries_id }}" {{ $Ipcountry->countries_id== $countryValue->countries_id ? 'selected' : '' }}>
                                                                {{ $countryValue->countries_name }}
                                                            </option>
                                                        @endforeach
                                                    @endif
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                {{-- <label for="pincode">Zipcode<span class="text-danger">*</span></label> --}}
                                                <input type="" class="form-control" name="customer_postcode"
                                                    value="" placeholder="Pincode" required="">
                                                 @error('customer_postcode')
                                                    <p class="text-danger mb-5">{{ $message }}</p>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                @endif
                            <div class="container-fluid mt-4">
                                <div class="row ">
                            @if (getSetting('plan_appointment') == 'yes')
                                @if (getSetting('plan_appointment_date') == 'yes')
                                    <div class="col-md-6">
                                        <div class="form-group">
                                        <label for="pincode">Appointment Date<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" value=""
                                                name="appointment_date" id="appointment_date"
                                                placeholder="Appointment Date">
                                        </div>
                                    </div>
                                @endif
                                @if (getSetting('plan_appointment_time') == 'yes')
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="pincode">Appointment Time<span class="text-danger">*</span></label>
                                            <input type="time" class="form-control" value=""
                                                name="appointment_time" id="appointment_time"
                                                placeholder="Appointment Time">
                                        </div>
                                    </div>
                                @endif
                            @endif
                               </div>
                            </div>
                            <!--Payment -->
                            @if (!empty($paymentList) && sizeof($paymentList) > 0)
                                <div class="payment_wrapper text-center">
                                    <div class="container">
                                        <div class="payment_body">
                                            <div class="payment-type">
                                                <div class="plan_heading">
                                                    <h4 class="contact-panel__title ">Select Payment Option
                                                    </h4>
                                                </div>
                                                <div class="types">
                                                    <div class="col-lg-12">
                                                        <div class="payment_content d-flex">
                                                            <input type="hidden" id="payment_method"
                                                                name="payment_method" value="stripe">
                                                            @foreach ($paymentList as $paymethods)
                                                                @if ($paymethods->method_key == 'paypal')
                                                                    <div class="col-lg-6 col-md-6 col-sm-12 m-2">
                                                                        <div class="type"
                                                                            value="{{ $paymethods->method_key }}">
                                                                            <div>
                                                                                <img src="{{ LoadAssets('assets/payment_images/paypal_img.png') }}"
                                                                                    alt="Paypal_img" class="img-fluid"
                                                                                    style="width:150px; padding: 2rem 1.5rem">
                                                                            </div>
                                                                        </div>
                                                                        <div class="text-center">
                                                                            <p>Pay with PayPal<sup>TM</sup></p>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                                @if ($paymethods->method_key == 'stripe')
                                                                    <div class="col-lg-6 col-md-6 col-sm-12 m-2">
                                                                        <div class="type selected"
                                                                            value="{{ $paymethods->method_key }}">
                                                                            <div class="py-1">
                                                                                <ul class="list-unstyled ">
                                                                                    <li class="list-inline-item"><a
                                                                                            href="javascript:void(0)"><img
                                                                                                src="{{ LoadAssets('assets/payment_images/payment.png') }}"
                                                                                                class=" "
                                                                                                title="American Express"
                                                                                                alt=""></a>
                                                                                    </li>
                                                                                    <li class="list-inline-item"><a
                                                                                            href="javascript:void(0)"><img
                                                                                                src="{{ LoadAssets('assets/payment_images/visa_1.png') }}"
                                                                                                class=" "
                                                                                                title="Visa"
                                                                                                alt=""></a>
                                                                                    </li>
                                                                                    <li class="list-inline-item"><a
                                                                                            href="javascript:void(0)"><img
                                                                                                src="{{ LoadAssets('assets/payment_images/discover.png') }}"
                                                                                                class=" "
                                                                                                title="Discover"
                                                                                                alt=""></a>
                                                                                    </li>
                                                                                </ul>
                                                                                <ul>
                                                                                    <li class="list-inline-item"><a
                                                                                            href="javascript:void(0)"><img
                                                                                                src="{{ LoadAssets('assets/payment_images/China_Unionpay.png') }}"
                                                                                                class=" "
                                                                                                title="Paypal"
                                                                                                alt=""></a>
                                                                                    </li>
                                                                                    <li class="list-inline-item"><a
                                                                                            href="javascript:void(0)"><img
                                                                                                src="{{ LoadAssets('assets/payment_images/master-card.png') }}"
                                                                                                class=" "
                                                                                                title="Master Card"
                                                                                                alt=""></a>
                                                                                    </li>

                                                                                    <li class="list-inline-item"><a
                                                                                            href="javascript:void(0)"><img
                                                                                                src="{{ LoadAssets('assets/payment_images/JCB_Cards.svg') }}"
                                                                                                class=" "
                                                                                                title="Visa"
                                                                                                alt=""></a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>

                                                                        </div>
                                                                        <div class="text-center">
                                                                            <p>Pay with Cards</p>
                                                                        </div>
                                                                    </div>
                                                                @endif
                                                            @endforeach
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <button class="w-50 btn btn-primary mt-3" type="submit">Continue to
                                            checkout</button>
                                    </div>
                                </div>
                            @endif
                            <!--End of Payment-->
                        </form>

                    </div><!-- /.contact-panel -->
                </section><!-- /.contact layout 4 -->
            </div><!-- /.col-lg-8 -->
        </div><!-- /.row -->

    </div><!-- /.container -->

{{-- Add New Address modal form  start --}}

<div class="modal fade" id="AddNewUSerAddress" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog  modal-lg modal-dialog-centered">
        <div class="modal-content rounded shadow border-0">
            <div class="modal-body p-4">
                <div class="container-fluid px-0">
                    <div class="modal-button">
                        <button type="button" class="btn-icon btn-close modal-close" data-bs-dismiss="modal"
                            id="close-modal"><i class="fa fa-times" aria-hidden="true"></i></button>
                    </div>
                    <h3 class="modal-title pb-2" id="EnquryForm-title">Add New Address</h3>
                    <form class="needs-validation" novalidate id="addNewUserAddForm">
                        <div class="row g-3">
                            <div class="col-sm-6">
                                <input type="text" class="form-control" 
                                    name="customer_name" placeholder="Name" required>
                                <p class="text-danger" id="addUADErr_customer_name"></p>
                            </div>

                            <div class="col-md-6">
                                <input type="email" class="form-control" name="customer_email" placeholder="Email" required>
                                <p class="text-danger" id="addUADErr_customer_email"></p>
                            </div>

                            <div class="col-md-6">
                                <input type="text" class="form-control" name="phone" 
                                    placeholder="Phone No." required>
                                <p class="text-danger" id="addUADErr_phone"></p>
                            </div>

                            <div class="col-md-6">
                                <input type="text" class="form-control" name="street_address" 
                                    placeholder="Street Address" required>
                                <p class="text-danger" id="enqerr_phone"></p>
                            </div>

                            <div class="col-md-6">
                                <input type="text" class="form-control" name="city" 
                                    placeholder="City" required>
                                <p class="text-danger" id="addUADErr_city"></p>
                            </div>

                            <div class="col-md-6">
                                <input type="text" class="form-control" name="state" 
                                    placeholder="State" required>
                                <p class="text-danger" id="addUADErr_state"></p>
                            </div>

                            <div class="col-md-6">
                            <select class="form-select form-control" name="countries_id" id="country"
                            required>
                            <option selected disabled value="" >Choose...</option>
                            @if (!empty($CountryData))
                                @foreach ($CountryData as $key => $countryValue)
                                    <option value="{{ $countryValue->countries_id }}" {{ $Ipcountry->countries_id == $countryValue->countries_id ? 'selected' : '' }}>
                                        {{ $countryValue->countries_name }}
                                    </option>
                                @endforeach
                            @endif
                           </select>
                           <p class="text-danger" id="addUADErr_countries_id"></p>
                          </div>

                            <div class="col-md-6">
                                <input type="text" class="form-control" name="zipcode" 
                                    placeholder="Pincode" required>
                                <p class="text-danger" id="addUADErr_zipcode"></p>
                            </div>
                            <input type="reset" hidden></button>
                            <button class="w-100 btn btn-primary " id="AddNewUserAddressBtn"
                                type="button">Submit</button>
                        </div>

                    </form>

                    <!--end row-->
                </div>
                <!--end container-->
            </div>
        </div>
    </div>
</div>
{{-- Add New Address modal form end --}}


    @push('scripts')
        <script>
            $(document).ready(function() {

                // for date
                $(function() {
                    $("#appointment_date").datepicker({
                        altFormat: "yy-mm-dd"
                    });
                });

                $(".type").click(function() {
                    $(".type").removeClass('selected');
                    $(this).toggleClass('selected');
                    $('#payment_method').val($(this).attr('value'))
                });

                $(document).ready(function() {
                    $('#checkout_form').validate({
                        rules: {
                            customer_name: {
                                required: true
                            },
                            phone: {
                                required: true,
                                // number: true,
                                // max:12,
                                // min:10,
                            },
                            customer_email: {
                                required: true,
                                email: true,
                                // maxlength: 50
                            },
                            street_address: {
                                required: true,

                                // maxlength: 50
                            },
                            city: {
                                required: true,
                                // maxlength: 50
                            },
                            state: {
                                required: true,
                                // maxlength: 50
                            },
                            countries_id: {
                                required: true,
                                // maxlength: 50
                            },
                            zipcode: {
                                required: true,
                                // maxlength: 50
                            },
                            zipcode: {
                                required: true,
                                // maxlength: 50
                            },
                            appointment_date: {
                                required: true,
                                // maxlength: 50
                            },
                            appointment_time: {
                                required: true,
                                // maxlength: 50
                            },
                        },
                        // messages: {
                        //   customer_name: {
                        //     required: "Please enter y name",
                        //   },
                        //   customer_contact: {
                        //     required: "Please enter phone number",
                        //     // number: "Please enter valid contact number",
                        //     // max:"Please enter valid number",
                        //     // min:"Please enter valid number",

                        //   },
                        //   customer_email: {
                        //     required: "Please enter  your email",
                        //     email: "Please enter valid email address",
                        //   },
                        //   street_address: {
                        //     required: "Please enter  your street address",
                        //   },
                        //   customer_city: {
                        //     required: "Please enter your city",
                        //   },
                        //   customer_state: {
                        //     required: "Please enter your state",
                        //   },
                        //   customer_country: {
                        //     required: "Please select your country",
                        //   },
                        //   customer_zipcode: {
                        //     required: "Please enter your zipcode",
                        //   },
                        //   appointment_date: {
                        //     required: "Please enter your appointment date",
                        //   },
                        //   appointment_time: {
                        //     required: "Please enter your appointment time",
                        //   },
                        // },

                        errorElement: 'span',
                        errorPlacement: function(error, element) {
                            // error.addClass('invalid-feedback');
                            // element.closest('.form-group').append(error);
                        },
                        highlight: function(element, errorClass, validClass) {
                            $(element).addClass('is-invalid');
                        },
                        unhighlight: function(element, errorClass, validClass) {
                            $(element).removeClass('is-invalid');
                        }

                    });
                });


            // Show Add-Address Modal

            $("#createAddress").click(function() {
                $("#AddNewUSerAddress").modal('show', 'fade');
            });

            $(document).on('click', '.modal-close', function(e) {
                $('#AddNewUSerAddress').modal('hide');
            });

            // Add Adress Ajax

            $(document).on('click', '#AddNewUserAddressBtn', function(e) {
                e.preventDefault();
                $('#addNewUserAddForm').addClass('was-validated');
                if ($('#addNewUserAddForm')[0].checkValidity() === false) {
                    event.stopPropagation();
                } else {
                    let addNewUserAddForm = document.getElementById('addNewUserAddForm');
                    let formData = new FormData(addNewUserAddForm);
                    var html='';

                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        type: "POST",
                        url: "{{ url('account/add-address') }}",
                        data: formData,
                        dataType: "json",
                        contentType: false,
                        cache: false,
                        processData: false,

                        beforeSend: function() {
                            $('#AddNewUserAddressBtn').addClass('disabled');
                            $('#AddNewUserAddressBtn').html(
                                ' <i class="fa-solid fa-spinner fa-spin-pulse"></i> Submitting...'
                            );
                        },

                        success: function(response) {
                            if (response.status == 400) {
                                $.each(response.error, function(key, err_val) {
                                    $('#addUADErr_' + key).text(err_val);
                                });
                            } else {
                                
                                html=`<div class="col-lg-6 ">
                                                <div
                                                    class="addressboxes_container shadow d-flex justify-content-between px-3">
                                                    <input id="credit" value=${response.createdAddress.address_id } 
                                                        name="address_id" type="radio" class="form-check-input"
                                                        required checked style="float:left;">
                                                        <div class="px-4">
                                                        <h5>${response.createdAddress.customer_name ?? '' }</h5>
                                                        <h6>${response.createdAddress.customer_email ?? '' }</h6>
                                                        ${response.createdAddress.street_address}, ${response.createdAddress.city }<br />
                                                        ${response.createdAddress.state }<br />
                                                        ${response.createdAddress.country_name} ,
                                                        ${response.createdAddress.zipcode }
                                                    </div>
                                                </div>
                                            </div>`;
                                $('#addressboxes').append(html);
                                $('#addNewUserAddForm').trigger("reset");
                                $('#AddNewUSerAddress').modal('hide');
                                swal("Success", "Address Added Successfully.", "success");
                            }
                        },

                        complete: function() {
                            $('#addNewUserAddForm').removeClass('was-validated');
                            $('#AddNewUserAddressBtn').removeClass('disabled');
                            $('#AddNewUserAddressBtn').html('Submit');
                        }
                    });
                }
            });

            });
        </script>
    @endpush

</section>
