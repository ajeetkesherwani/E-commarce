    <!-- ========================
       page title 
    =========================== -->
    <section class="page-title-layout4 page-title-light bg-overlay bg-parallax text-center">
        <div class="bg-img"><img src="{{LoadAssets('assets/images/page-titles/13.jpg')}}" alt="background"></div>
        <div class="container">
          <div class="row">
            <div class="col-12">
              <h1 class="pagetitle__heading">Request An Estimate</h1>
              <nav>
                <ol class="breadcrumb justify-content-center mb-0">
                  <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                  <li class="breadcrumb-item"><a href="pricing.html">Pricing</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Request An Estimate</li>
                </ol>
              </nav>
            </div><!-- /.col-12 -->
          </div><!-- /.row -->
        </div><!-- /.container -->
      </section><!-- /.page-title -->
  
      <section class="pb-80">
        <div class="container">
          <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-4">
              <aside class="sidebar has-marign-right sticky-top mb-30">
                <div class="widget widget-help bg-overlay bg-overlay-primary">
                  <div class="bg-img"><img src="{{LoadAssets('assets/images/banners/5.jpg')}}" alt="background"></div>
                  <div class="widget-content">
                    <h3 class="widget__subtitle">Homeowners Like Us!</h3>
                    <h4 class="widget__title">Healthy Environment For Your Family</h4>
                    <p class="widget__desc font-weight-bold mb-50">The processes and systems we put in place provide high
                      quality service with a
                      focus on safety.
                    </p>
                    <a href="pricing-offers.html" class="btn btn__accent btn__block justify-content-between mb-30">
                      <span>Explore Our Offers</span>
                      <i class="icon-arrow-right"></i>
                    </a>
                    <a href="tel:+201061245741" class="phone__number">
                      <i class="icon-phone"></i> <span>002 01061245741</span>
                    </a>
                  </div><!-- /.widget-content -->
                </div><!-- /.widget-help -->
                <div class="widget widget-download">
                  <div class="widget-content">
                    <h4 class="widget__title">Download Brochure</h4>
                    <a href="#" class="btn btn__secondary btn__block mb-20">
                      <i class="icon-download"></i>
                      <span>Company Report 2022</span>
                    </a>
                    <a href="#" class="btn btn__primary btn__block">
                      <i class="icon-download"></i>
                      <span>Company Brochure</span>
                    </a>
                  </div><!-- /.widget-content -->
                </div><!-- /.widget-download -->
              </aside><!-- /.sidebar -->
            </div><!-- /.col-lg-4 -->
            <div class="col-sm-12 col-md-12 col-lg-8">
              <section class="contact-layout4 py-0">
                <div class="contact-panel">
                  <form class="contact-panel__form" method="post" action="{{url('/storeServicesEnquiry')}}">
                     @csrf 
                    <div class="row">
                      <div class="col-12">
                        <h4 class="contact-panel__title">Request An Estimate</h4>
                        <p class="contact-panel__desc mb-30">For a cleaning that meets your highest standards, you need a
                          dedicated team of trained specialists with all supplies needed to thoroughly clean your home.
                        </p>
                      </div><!-- /.col-12 -->
                      <div class="col-sm-6">
                        <div class="form-group">
                          <label for="service">Choose your service</label>
                          <select id="service" name="service" class="form-control">
                             <option>Select Category</option>
                             @foreach($services as $service)
                            <option>{{$service->categories_slug}}</option>
                             @endforeach
                          </select>
                         <!--  <select id="service" name="service" class="form-control">
                            <option>Coronavirus Cleaning</option>
                            <option>outdoor Cleaning</option>
                            <option>indoor Cleaning</option>
                          </select> -->
                          <span class="text-danger" id="service" ></span>
                          @if ($errors->has('service'))
                          <span class="text-danger">{{ $errors->first('service') }}</span>
                          @endif
                        </div>
                      </div><!-- /.col-lg-6 -->
                      <div class="col-sm-6">
                        <div class="form-group">
                          <label for="type">Indicate type of cleaning</label>
                          <select id="subservice" name="subservice" class="form-control">
                            <option value="">select</option>
                          <!--   <option>Weekly Regular</option>
                            <option>Monthly Regular</option> -->
                          </select>
                          <span class="text-danger" id="subservice" ></span>
                          @if ($errors->has('subservice'))
                          <span class="text-danger">{{ $errors->first('subservice') }}</span>
                          @endif
                        </div>
                      </div><!-- /.col-lg-6 -->
                      <div class="col-sm-6">
                        <div class="form-group">
                          <label for="facility">Name *</label>
                          <input type="text" class="form-control" placeholder="Enter Your Name" id="name" name="name">
                          <span class="text-danger" id="name" ></span>
                          @if ($errors->has('name'))
                          <span class="text-danger">{{ $errors->first('name') }}</span>
                          @endif
                        </div>
                      </div><!-- /.col-lg-6 -->
                      <div class="col-sm-6">
                        <div class="form-group">
                          <label for="facilityName">Contact Number *</label>
                          <input type="text" class="form-control" placeholder="Enter Your Contact Number" id="phone" name="phone">
                           <span class="text-danger" id="phone" ></span>
                          @if ($errors->has('phone'))
                          <span class="text-danger">{{ $errors->first('phone') }}</span>
                          @endif
                        </div>
                      </div><!-- /.col-lg-6 -->
                      <div class="col-sm-12">
                        <div class="form-group">
                          <label for="rooms">Address *</label>
                          <input type="text" class="form-control" placeholder="Enter Your Address" id="address" name="address">
                          <span class="text-danger" id="address" ></span>
                          @if ($errors->has('address'))
                          <span class="text-danger">{{ $errors->first('address') }}</span>
                          @endif
                        </div>
                      </div><!-- /.col-lg-4 -->
                      <div class="col-sm-12">
                        <div class="form-group">
                          <label for="hallway">Message *</label>
                          <textarea id="message" class="form-control" placeholder="Text here" name="message" id="message"></textarea>
                          <span class="text-danger" id="message" ></span>
                          @if ($errors->has('message'))
                          <span class="text-danger">{{ $errors->first('message') }}</span>
                          @endif
                        </div>
                      </div><!-- /.col-lg-4 -->
                     
                      <div class="col-12">
                        <button type="submit"
                          class="btn btn__secondary btn__block btn__xhight d-flex justify-content-between mt-10" id="enquirybtn">
                          <span>Submit Request</span> <i class="icon-arrow-right icon-outlined"></i>
                        </button>
                        <div class="contact-result"></div>
                      </div>
                    </div><!-- /.row -->
                  </form>
                </div><!-- /.contact-panel -->
              </section><!-- /.contact layout 4 -->
            </div><!-- /.col-lg-8 -->
          </div><!-- /.row -->
        </div><!-- /.container -->
      </section>
      @push('scripts')
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
<script>
    $(document).ready(function () {
         //alert('hello');
        $(document).on('click', '#enquirybtn', function (e) {
            e.preventDefault();
            var data = {
                'service': $('#service').val(),
                'subservice': $('#subservice').val(),
                'name': $('#name').val(),
                'phone': $('#phone').val(),
                'address': $('#address').val(),
                'message': $('#message').val(),
            }
            console.log(data);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "{{url('/storeServicesEnquiry')}}",
                data: data,
                dataType: "json",
                success: function (response) {
                    console.log(response);
                    if (response.status == 400) {
                        $.each(response.error, function (key, err_val) {
                            $('#' + key).text(err_val);
                        });

                    }
                    else {
                        Notify('Details Send Successfully', true);
                        $('#enquiry-form').trigger("reset");
                    }
                }

            });
        });
    });
</script>

   <script type="text/javascript">
            $("document").ready(function () {
                $('select[name="service"]').on('change', function () {
                    var catId = $(this).val();
                   // alert(catId);exit;
                    if (catId) {
                        $.ajax({
                            url: '/subservice/' + catId,
                            type: "GET",
                            dataType: "json",
                            success: function (data) {
                              alert(data);
                                $('select[name="subservice"]').empty();
                                $.each(data, function (key, value) {
                                    $('select[name="subservice"]').append('<option value=" ' + key + '">' + value + '</option>');
                                })
                            }

                        })
                    } else {
                        $('select[name="subservice"]').empty();
                    }
                });


            });
        </script>
@endpush