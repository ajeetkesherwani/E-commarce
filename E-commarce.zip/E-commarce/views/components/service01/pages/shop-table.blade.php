<!-- Dynamic Product Load To  -->
<!-- Shop Tab Content Start -->
<div class="tab-content jump">
    <!-- Tab One Start -->
    <div id="shop-1" class="tab-pane active">
        <div class="row">
            @if(!empty($products) && sizeof($products)>0)
            @foreach($products as $product)
            <div class="col-xl-3 col-md-6 col-lg-4 col-sm-6 col-xs-12">
                <x-theme1.shared-component.product viewtype="grid" :data="$product" />
            </div>
            @endforeach
            @else
            <center><h3 class="text-secondary">No product avaliable for this query.</h3></center>
            @endif
        </div>
    </div>
    <!-- Tab One End -->

    <!-- Tab Two Start -->
    <div id="shop-2" class="tab-pane">
        @if(!empty($products) && sizeof($products)>0)
        @foreach($products as $product)
        <x-theme1.shared-component.product viewtype="list" :data="$product" />
        @endforeach
        @else
        <center><h3 class="text-secondary">No product avaliable for this query.</h3></center>
        @endif
    </div>
    <!-- Tab Two End -->
</div>
<!-- Shop Tab Content End -->
<!--  Pagination Area Start -->
<input type="hidden" id="nextPage" value="1">
<div class="pro-pagination-style text-center">
    {{-- Pagination --}}
    <div class="row">
        <div class="col-md-12 d-flex justify-content-center p-2">
            {{ $products->links('vendor.pagination.for-ajax') }}
        </div>
    </div>
</div>
<!--  Pagination Area End -->

{{-- Category description Start --}}

@if(!empty($categoryDesc))
<div class="row">
    <div class="col-lg-12 d- p-2">
<div class="card">
    <div class="card-body">
        {{$categoryDesc->categories_description ?? ''}}
    </div>
</div>
</div>
</div>
@endif
{{-- End of category description --}}