{{-- <!-- login area start -->
<div class="login-register-area mb-60px mt-53px">
    <div class="container">
        <div class="row">
            <div class="col-lg-7 col-md-12 mx-auto">
                <div class="login-register-wrapper">
                    <div class="login-register-tab-list nav">
                        <a class="active" data-bs-toggle="tab" href="#lg1">
                            <h4>{{ translation('LOGIN') }}</h4>
                        </a>
                    </div>
                    <div class="tab-content">
                        <div id="lg1" class="tab-pane active">
                            <div class="login-form-container">
                                @if (session('status'))
                                    <div class="alert alert-success">
                                        {{ session('status') }}
                                    </div>
                                @endif
                                @error('failed')
                                <strong class="text-danger" style="margin-top:-50px;">{{ $message }}</strong>
                                @enderror
                                <div class="login-register-form">

                                    <form action="{{ route('login') }}" method="post" id="login_form" onkeyup="myRemoveValidation()">
                                        @csrf
                                        <input type="email" name="email" placeholder="{{ translation('EMAIL_PLACEHOLDER') }}"/>
                                        @error('email')
                                        <strong class="text-danger mb-5">{{ $message }}</strong>
                                        @enderror
                                        <input type="password" name="password" placeholder="{{ translation('PASSWORD_PLACEHOLDER') }}" />
                                        @error('password')
                                        <strong class="text-danger" style="margin-top:-50px;">{{ $message }}</strong>
                                        @enderror
                                        <div class="button-box">
                                            <div class="login-toggle-btn">
                                                <input type="checkbox" />
                                                <a class="flote-none" href="javascript:void(0)">{{ translation('REMEMBER_ME') }}</a>
                                                <a href="{{url('/forgot-password')}}">{{ translation('FORGATE_PASSWORD') }}</a><a href="{{url('/register')}}">{{ translation('SIGN_UP') }}/</a>
                                            </div>
                                            <button type="submit"><span>{{ translation('LOGIN') }}</span></button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')

<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
<script>
    $(document).ready(function() {
        $('#login_form').validate({
            rules: {
                email: {
                    required: true,
                    email: true,
                    maxlength: 50
                },
                password: {
                    minlength: 8,
                    required: true
                },
            },
            messages: {
                email: {
                        required: "Please enter a email",
                        email: "Please enter valid email",
                        maxlength: "Email cannot be more than 50 characters,Please enter valid email",
                    },
                    password: {
                        required: "Please enter password",
                        minlength: "Password must be at least 8 characters,Please enter valid password"
                    },
                },
            // highlight: function(element) {
            //     $(element).addClass('error');
            //     $(element).css("border", " 1px solid red")
            // }
        });
    });
 
</script>
@endpush --}}

<div class="col-sm-12 col-md-12 col-lg-7 mx-auto p-5">
    <section class="contact-layout4 py-0">
      <div class="contact-panel">
        <form class="contact-panel__form" action="{{ route('login') }}" method="post" id="login_form">
            @csrf
          <div class="row">
            <div class="col-12">
                <h3 class="contact-panel__title  text-center">{{ translation('LOGIN') }}</h3>
              <div class="mt-4 pt-4 border-top"></div>
              @if (session('status'))
              <div class="alert alert-success">
                  {{ session('status') }}
              </div>
            @endif
            @error('failed')
                 <strong class="text-danger" style="margin-top:-50px;">{{ $message }}</strong>
             @enderror
            </div><!-- /.col-12 -->
            <div class="col-sm-12">
              <div class="form-group">
                <label for="name">Email <span class="text-danger">*</span></label>
                <input type="email" name="email" class="form-control" placeholder="{{ translation('EMAIL_PLACEHOLDER') }}" id="email">
                @error('email')
                <strong class="text-danger mb-5">{{ $message }}</strong>
                @enderror
              </div>
            </div><!-- /.col-lg-6 -->
            <div class="col-sm-12">
              <div class="form-group">
                <label for="phone">Password  <span class="text-danger">*</span></label>
                <input type="password" name="password" class="form-control" placeholder="{{ translation('PASSWORD_PLACEHOLDER') }}" id="password">
                @error('password')
                <strong class="text-danger" style="margin-top:-50px;">{{ $message }}</strong>
                @enderror
              </div>
            </div><!-- /.col-lg-6 -->
    
            <div class="col-12">
              <button type="submit"
                class="btn btn__secondary btn__block btn__xhight d-flex justify-content-between mt-10">
                <span>{{ translation('LOGIN') }}</span> <i class="icon-arrow-right icon-outlined"></i>
              </button>
              <div class="contact-result"></div>
            </div>
          </div><!-- /.row -->
        </form>
        <p class="mt-3">Do not have an Account? <a href="{{url('/register')}}"><span class="text-dark"><b>{{ translation('SIGN_UP') }}/</b></span></a>
            <a href="{{url('/forgot-password')}}"><span class="text-primary"><b>{{ translation('FORGATE_PASSWORD') }}</b></span></a></p>
      </div><!-- /.contact-panel -->
    </section><!-- /.contact layout 4 -->
</div><!-- /.col-lg-8 -->

  @push('scripts')

<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
<script>
    $(document).ready(function() {
        $('#login_form').validate({
            rules: {
                email: {
                    required: true,
                    email: true,
                    // maxlength: 50
                },
                password: {
                    minlength: 8,
                    required: true
                },
            },
            messages: {
                email: {
                        required: "Please enter a email",
                        email: "Please enter valid email",
                        // maxlength: "Email cannot be more than 50 characters,Please enter valid email",
                    },
                    password: {
                        required: "Please enter password",
                        minlength: "Password must be at least 8 characters."
                    },
                },

            errorElement: 'span',
            errorPlacement: function (error, element) {
              error.addClass('invalid-feedback');
              element.closest('.form-group').append(error);
            },
            highlight: function (element, errorClass, validClass) {
              $(element).addClass('is-invalid');
            },
            unhighlight: function (element, errorClass, validClass) {
              $(element).removeClass('is-invalid');
            }
        });
    });
 
</script>
@endpush