<div class="modal-dialog">
    <div class="modal-content">
        <section id="newsletter">
            <div class="container p-3">
                <div class="row ">
                    <div class="col-md-12 pb-1 d-flex flex-row justify-content-end">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"
                            style="margin-top: -30px;"></button>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="col-md-6 col-sm-12">
                        <img src="{{ getFullImageUrl(getSetting('newsletter_image')) }}"
                            onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                            class="w-100 img-fluid" alt="{{ getSetting('site_title') }}-New Latter Image">
                    </div>
                    <div class="col-md-6 col-sm-12">
                        <h3>{{ getSetting('newsletter_title') ?? '' }}</h3>
                        <p>{{ getSetting('newsletter_subtitle') ?? '' }}</p>
                        <form>
                            <input type="email" name="email" id="customeremail" placeholder="Enter your Email"
                                class="form-control">
                            <input type="submit" id="modal_subscribe" value="Subscribe">
                        </form>
                        <p class="text-light" id="email_err"></p>
                        <div class="social-links">
                            @if (!empty(socialLinks('facebook_url')))
                            <a href="{{ socialLinks('facebook_url') }}"><i class="fab fa-facebook-f"></i></a>
                            @endif
                            @if (!empty(socialLinks('twitter_url')))
                            <a href="{{ socialLinks('twitter_url') }}"><i class="fab fa-twitter"></i></a>
                            @endif
                            @if (!empty(socialLinks('linkedin_url')))
                            <a href="{{ socialLinks('linkedin_url') }}"><i class="fab fa-linkedin-in"></i></a>
                            @endif
                            @if (!empty(socialLinks('pinterest_url')))
                            <a href="{{ socialLinks('pinterest_url') }}"><i class="fab fa-pinterest-p"></i></a>
                            @endif
                            @if (!empty(socialLinks('instagram_url')))
                            <a href="{{ socialLinks('instagram_url') }}"><i class="fab fa-instagram"></i></a>
                            @endif
                            @if (!empty(socialLinks('youtube_url')))
                            <a href="{{ socialLinks('youtube_url') }}"><i class="fab fa-youtube"></i></a>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>