<script src="{{ LoadAssets('assets/js/jquery-3.6.0.min.js') }}"></script>
<script src="{{ LoadAssets('assets/js/plugins.js') }}"></script>
<script src="{{ LoadAssets('assets/js/main.js') }}"></script>
<!-- date time picker -->
<script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
<!-- time -->
<script src="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.js"></script>
<!-- end of date -->

<!-- // toastify -->
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<script>
    function Notify(msg, status) {
        Toastify({
            text: msg,
            className: "info",
            duration: 2000,
            close: true,
            gravity: "bottom", // `top` or `bottom`
            position: "right", // `left`, `center` or `right`
            style: {
                background: status ? "green" : "red",
            }
        }).showToast();

    }

    $(".customFrom").on('submit', function(e) {
        e.preventDefault();
        $('.customFrom').addClass('was-validated');
        if ($('.customFrom')[0].checkValidity() === false) {
            event.stopPropagation();
        } else {

            let formData = $(this).serialize();

            /*Ajax Request Header setup*/
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $.ajax({
                url: "{{ route('customFormSubmit') }}",
                method: 'post',
                data: formData,

                beforeSend: function() {
                    $(".customFrom :submit").addClass('disabled');
                    $(".customFrom :submit").html('Submitting...');
                },

                success: function(response) {
                    console.log(response);
                    if (response.status == 0) {
                        $.each(response.message, function(i, v) {
                            console.log('#erro_' + i);
                            $('#' + i + '-error').html(v);
                        });
                    } else {
                        // $('.result').append(response.message);
                        Notify('Data send successfully', true);
                        $('.customFrom').trigger("reset");
                    }
                },

                complete: function() {
                    $('.customFrom').removeClass('was-validated');
                    $(".customFrom :submit").removeClass('disabled');
                    $(".customFrom :submit").html('Submit');
                }
            });
        }
    });

    // Add to cart

    function addToCart(lisiting_id,qty = 1, attributes_id = '') {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
            url: '{{ route('addUpdateToCart') }}',
            method: 'POST',
            data: {
                qty: qty,
                attributes_id: attributes_id,
                listing_id: lisiting_id,
            },
            success: function(response) {
        
                var html='';
                $.each(response.cartlist, function(key, cart_val) {
                html+=`<li class="cart-item">
                    <div class="cart__img"><img src="${cart_val.listing.image_url}" alt="thumb"></div>
                    <div class="cart__content">
                      <a class="cart__title" href="${cart_val.listing.listing_slug}">${cart_val.listing.listing_name}</a>
                      <span class="cart__price">${cart_val.listing.listing_base_rate}</span>
                      <button class="cart__delete" onclick="actionOnPopUpCart(${cart_val.cart_id},'del')">&times;</button>
                    </div>
                  </li>`;
                });

                $('#cart_items').empty();
                $('#cart_items').html(html);
                $('#totalAmount').text(response.total_amount);
                $('.count-cart-total').html(response.total_count);
                Notify('Service Added To Cart !', true);

            },
            error: function(error) {
                Notify("Some Error In Add To Cart", false);
            }
        });

    }
    // header cart pop up

    function actionOnPopUpCart(cart_id, type){
        var qty = $(`#${cart_id}_qty`).val();

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
            url:'{{ route("incDecDelPopUpCart") }}',
            method:'POST',
            data:{
                cart_id : cart_id,
                qty:qty, 
                type:type,
            },
            success:function(response){
                console.log(response.cartresponse);
                var html='';
                $.each(response.cartresponse.cart_list, function(key, cart_val) {
                html+=`<li class="cart-item">
                    <div class="cart__img"><img src="${cart_val.listing.image_url}" alt="thumb"></div>
                    <div class="cart__content">
                      <a class="cart__title" href="${cart_val.listing.listing_slug}">${cart_val.listing.listing_name}</a>
                      <span class="cart__price">${cart_val.listing.listing_base_rate}</span>
                      <button class="cart__delete" onclick="actionOnPopUpCart(${cart_val.cart_id},'del')">&times;</button>
                    </div>
                  </li>`;
                });

                $('.count-cart-total').html(response.header_html);
                $('#cart_items').empty();
                $('#cart_items').html(html);
                $('#totalAmount').text(response.cartresponse.grand_total);
                $('.count-cart-total').html(response.total_count);
            
                var msg = type=== 'del' ? 'Service Removed From Cart !' : 'Service Qty Updated To Cart !';
                Notify(msg, true);
            },
            error:function(error){
                Notify("Not able to add", false);
            }
        });

        }


</script>

<script type="text/javascript">
    $(document).ready(function() {
        // work on plan select dropdown one time only one  plan select

        $('.pricing_btn').click(function () {
                $('#pricing_id').val($(this).val());
            });

        $(document).on('click', '.submitbtn', function (e) {
                e.preventDefault()
                if ($('#pricing_id').val() == '') {
                    swal("Please Select A Plan");
                }
                else {
                    $('.chekoutForm').submit();
                }
            });


        $(document).on('click', '#enquiryNowBtn', function(e) {
            var plan_id = $(this).attr('value');
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "/plan_detail",
                data: {
                    'plan_id': plan_id
                },
                dataType: "json",
                success: function(response) {
                    var text = "Enquiry for" + " " + response.data.plan_name;
                    var plan_id = response.data.plan_id;

                    $('#enq_plan_id').val(plan_id);
                    $('#EnquryForm-title').html(text);
                    var text = '';
                    var plan_id = '';
                    $("#planEnquiryModal").modal('show');
                }
            })
        });

        $(document).on('click', '#enquirymodalformbutton', function(e) {
            e.preventDefault();
            let enquiryform = document.getElementById('enquiryform');
            let formData = new FormData(enquiryform);


            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "/storePlanEnquiry",
                data: formData,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                success: function(response) {
                    if (response.status == 400) {
                        $.each(response.error, function(key, err_val) {
                            $('#' + 'enqerr_' + key).text(err_val);
                        });
                    } else {
                        $('#planEnquiryModal').modal('hide');
                        $('#enquiryform').trigger("reset");
                        Notify('Send Successfully', true);
                    }
                }

            });
        });

    });
</script>


{{-- Modals Js --}}

<script>
    // for date
    $(function() {
        $("#enq_appointment_date").datepicker({
            altFormat: "yy-mm-dd"
        });
    });

    //     // for time
    //     $( function() {
    //     $('#enq_appointment_time').timepicker({
    //         timeFormat: 'h:mm p',
    //         interval: 60,
    //         minTime: '10',
    //         maxTime: '6:00pm',
    //         defaultTime: '11',
    //         startTime: '10:00',
    //         dynamic: true,
    //         dropdown: true,
    //         scrollbar: true
    //     });
    // } );

    $(document).ready(function() {

        // Add new industry
        $(document).on('click', '#industryServices-dropdown', function(e) {
            if ($(this).val() == "other") {
                $('.extra-industry').removeClass('d-none');
            }
        });

        // add Request for demo  ajax

        $(document).on('click', '#sendRequestDemo', function(e) {
            e.preventDefault();
            var data = {
                'customers_name': $('#demo_customers_name').val(),
                'company_name': $('#demo_company_name').val(),
                'email_address': $('#demo_email_address').val(),
                'phone': $('#demo_phone').val(),
                // 'industry': $('#Indutry-dropdown').val(),
                // 'industry_category_id': $('.industry_category_id').val(),
                // 'industry_name': $('#industry_name').val(),
                'business_type': $('#business_type').val(),
                'website': $('#website').val(),
                'message': $('#demo_message').val(),
                'page_source': $('#page_source').val(),
                'newsletter': ($('#demo_newsletter').is(':checked')) ? '1' : '0',
            }
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "{{ url('request-for-demo-store') }}",
                data: data,
                dataType: "json",
                success: function(response) {
                    if (response.status == 400) {
                        $.each(response.error, function(key, err_val) {
                            $('#enq_' + key).text(err_val);
                        });
                    } else {
                        swal("Thank you for your request",
                            "Our representative will get back to you shortly.",
                            "success");
                        $('#RequestDemoForm').trigger("reset");
                        $('#enquiry-popup').modal('hide');
                    }
                }

            });
        });
    });


    $(document).ready(function() {
        $(".planLoginbtn").click(function() {
            $("#login_source").val($(this).attr('data-source'));
            $("#loginPopup").modal('show');
        });

        // dismiss delete/cancel pop up

        $(".modal-dismiss").click(function() {
            $(".confirmationModal").modal('hide');
        });



        // Sign in to SignUp form

        $("#modalExchSignUpBtn").click(function() {
            $("#sublogin").addClass('d-none');
            $("#subregister").removeClass('d-none');

        });

        // Sign up to SignIn form  

        $("#modalExchSignInBtn").click(function() {
            $("#sublogin").removeClass('d-none');
            $("#subregister").addClass('d-none');
        });



        // Login Ajax start here

        $(document).on('click', '#modalSignInBtn', function(e) {
            e.preventDefault();
            $('#login-modal-form').addClass('was-validated');
            if ($('#login-modal-form')[0].checkValidity() === false) {
                event.stopPropagation();
            } else {
                var data = {
                    'email': $('#login_email').val(),
                    'password': $('#login_Password').val(),
                    'login_source': $('#login_source').val(),
                    'remember': $('#rememberMe').val(),
                }
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{ url('/user-login') }}",
                    data: data,
                    dataType: "json",

                    beforeSend: function() {
                        $('#modalSignInBtn').addClass('disabled');
                        $('#modalSignInBtn').html(
                            ' <i class="icon-spinner icon-spin icon-large"></i> Logging....'
                        );
                    },
                    success: function(response) {
                        console.log(response);
                        if (response.status == "200") {
                            $("input[name='_token']").val(response.token);
                            $('#login-modal-form').trigger("reset");
                            $('#login-modal-form').removeClass('was-validated');
                            $("#loginPopup").modal('hide');

                            if ($('#pricing_id').val() == '') {
                                alert("Please Select A Plan");
                                location.reload();
                            } else {
                                $('.chekoutForm').submit();
                            }
                        }

                        if (response.status == "201") {
                            window.location = "{{ url('/account/profile') }}";
                        }

                        if (response.status == 420) {
                            $("#alert_message").addClass('alert-danger');
                            $("#alert_message").html(response.message);
                            $("#alert_message").removeClass('d-none');
                            $('#modalSignInBtn').html('Sign In');

                        }

                        if (response.status == 320) {
                            $("#alert_message").addClass('alert-danger');
                            $("#alert_message").html(response.message);
                            $("#alert_message").removeClass('d-none');
                            $('#modalSignInBtn').html('Sign In');

                        }

                        if (response.status == 240) {
                            $("#alert_message").html(response.message);
                            $("#alert_message").removeClass('d-none');
                            $('#modalSignInBtn').html('Sign In');

                        }


                    },
                    error: function(response) {
                        var response = JSON.parse(response.responseText);
                        $.each(response, function(key, err_val) {
                            $('#' + key + '-logerror').text(err_val);
                        });
                    },
                    complete: function(response) {
                        $('#modalSignInBtn').removeClass('disabled');
                        $('#modalSignInBtn').html('Sign In');
                    }
                });
            }
        });


        // Register Ajax start here

        $(document).on('click', '#modalSignUpBtn', function(e) {
            e.preventDefault();
            $('#register-modal-form').addClass('was-validated');
            if ($('#register-modal-form')[0].checkValidity() === false) {
                event.stopPropagation();
            } else {
                var data = {
                    'first_name': $('#register_first_name').val(),
                    'email': $('#register_email').val(),
                    'contact': $('#register_contact').val(),
                    'password': $('#register_password').val(),
                }
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{ url('user-register') }}",
                    data: data,
                    dataType: "json",

                    beforeSend: function() {
                        $('#modalSignUpBtn').addClass('disabled');
                        $('#modalSignUpBtn').html(
                            ' <i class="icon-spinner icon-spin icon-large"></i> Registering...'
                        );
                    },

                    success: function(response) {
                        if (response.status == 400) {
                            $.each(response.error, function(key, err_val) {
                                $('#' + 'register-' + key).text(
                                    err_val);
                            });
                        }
                        if (response.status == 200) {

                            $('#register-modal-form').trigger("reset");
                            $('#register-modal-form').removeClass('was-validated');

                            $("#alert_message").removeClass('alert-danger');
                            $("#sublogin").removeClass('d-none');
                            $("#alert_message").addClass('alert-success');
                            $("#alert_message").html(
                                "You have registered successfully, please login!");
                            $("#alert_message").removeClass('d-none');

                            $("#subregister").addClass('d-none');

                        }
                    },
                    complete: function() {
                        $('#modalSignUpBtn').removeClass('disabled');
                        $('#modalSignUpBtn').html('Sign Up');
                    }

                });
            }
        });

        // Add New Address form
        $(".addNewAdd").click(function() {
            $("#add-new-address").modal('show', 'fade');
        });

        //  // Add New Address in account form
        //  $("#addNewAddress").click(function () {
        //     $("#AddNewLoginAddress").modal('show', 'fade');
        // });

        // add address function  ajax
        $(document).on('click', '#Newaddressformbutton', function(e) {
            e.preventDefault();
            var data = {
                'first_name': $('#firstName').val(),
                'billing_email': $('#email').val(),
                'billing_phone': $('#phone').val(),
                'billing_street_address': $('#address').val(),
                'billing_city': $('#city').val(),
                'billing_state': $('#state').val(),
                'billing_country': $('#country').val(),
                'billing_zipcode': $('#zip').val(),
                'business_id': $('#bussinessInfoData').val(),
            }
            //console.log(data);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "{{ url('account/add-address') }}",
                data: data,
                dataType: "json",
                success: function(response) {
                    if (response.status == 400) {
                        $.each(response.error, function(key, err_val) {
                            if (!(err_val.validation.unique)) {
                                $('#add_' + key).text(err_val.validation.unique);
                            } else {
                                $('#add_' + key).text(err_val);
                            }
                        });
                    } else {
                        $html = `<div class="col-lg-12 col-md-6  shadow py-2 mt-2 "><div class="row">
                               <div class="col-lg-1">
                                   <input id="credit" value=${response.data.business_info_id} name="business_info_id" type="radio" class="form-check-input"
                                   checked required>
                               </div>
                               <div class="col-lg-11">
                                   <h6>${response.data.billing_contact_name}</h6>
                                   ${response.data.billing_email}<br/>
                                   ${response.data.billing_phone}<br/>
                                   ${response.data.billing_street_address} , ${response.data.billing_city}<br/>
                                   ${response.data.billing_state} , ${response.data.billing_country}<br/>
                                   ${response.data.billing_zipcode}
                               </div>
                            </div>
                            </div>`;

                        $('#addressboxes').append($html);
                        $('#add-new-address').modal('hide');
                        $('#Newaddress').trigger("reset");
                    }
                }

            });
        });

        // Show Add-Address Modal

        $("#createAddress").click(function() {
            $("#AddNewUSerAddress").modal('show', 'fade');
        });

        $(document).on('click', '.modal-close', function(e) {
            $('#AddNewUSerAddress').modal('hide');
        });

        $(document).on('click', '.modal-close', function(e) {
            $('#updateAddressModal').modal('hide');
        });

        // dismiss login/register popup
        
        $(document).on('click', '.login-btn-close', function(e) {
            $('#loginPopup').modal('hide');
        });

    });

</script>

@if(getsetting('newsletter_popup')=='yes')
@if(empty(Cache::get("loaditem")))
<script>

    window.onload = function showNewsLatter() {
        $.ajax({
            url: "/onloadnewslatter",
            success: function (response) {
                $(".newsmodal").html(response);
                $('#onloadModal').modal('show');
            },
            error: function (error) {
                
            },
        });
    }

</script>
@endif
@endif