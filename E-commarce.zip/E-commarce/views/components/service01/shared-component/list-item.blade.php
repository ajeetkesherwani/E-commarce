<div class="col-sm-6 col-md-6 col-lg-4">
   <div class="product-item">
     <div class="product__img">
       <img src="{{getFullImageUrl($listing->listing_image)}}" alt="Product" loading="lazy" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'">
       <div class="product__action">
         <a href="javascript:void(0);" onclick="addToCartFromDetail({{ $listing->listing_id }})" class="btn btn__primary">
           <i class="icon-cart"></i> <span>Add To Cart</span>
         </a>
       </div><!-- /.product-action -->
     </div><!-- /.product-img -->
     <div class="product__info">
       <h4 class="product__title"><a href="#" >{{$listing->listing_name}}</a></h4>
       <span class="product__price">{{currencyFormat($listing->listing_price->base_rate ?? '')}}</span>
     </div><!-- /.product-content -->
   </div><!-- /.product-item -->
 </div><!-- /.col-lg-4 -->


