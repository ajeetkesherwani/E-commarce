<!-- service item  -->
<div class="col-sm-12 col-md-6 col-lg-4">
    <div class="service-item">
        <div class="service__overlay">
            <div class="bg-img">
                <img src="{{LoadAssets('assets/images/services/1.jpg')}}" alt="service">
            </div>
        </div><!-- /.service__overlay -->
        <div class="service__body">
            {{-- <div class="service__icon">
                <i class="icon-house"></i>
            </div> --}}
            <!-- /.service__icon -->
            <img src="{{getFullImageUrl($listing->listing_image)}}" alt="service-listing">

            <h4 class="service__title">{{$listing->listing_name ?? ''}}</h4>
            <p class="service__desc">
                {!! Str::limit($listing->listing_description ?? '',100) !!}
            </p>
            <a href="{{route('listingDetail',['slug'=>$listing->listing_slug])}}" class="btn btn__secondary btn__block d-flex justify-content-between">
                <span>Read More</span>
                <i class="icon-arrow-right icon-outlined"></i>
            </a>
        </div><!-- /.service__body -->
    </div><!-- /.service-item -->
</div><!-- /.col-lg-4 -->