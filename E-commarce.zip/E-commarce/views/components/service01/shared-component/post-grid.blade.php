<article class="blog-post">
    <div class="blog-post-top">
        <div class="blog-img banner-wrapper">
            <a href="{{ url('blog/'.$data->slug) }}">
                <img src="{{getFullImageUrl($data->img) ?? LoadAssets('assets/images/blog-image/blog-16.jpg') }} " alt="" />
            </a>
        </div>
        <a href="blog-grid-left-sidebar.html" class="blog-meta">Furniture</a>
    </div>
    <div class="blog-post-content">
        <h4 class="blog-post-heading">
            <a href="{{ url('blog/'.$data->slug) }}">
                {{ $data->post_title ?? ''}}
            </a>
        </h4>
        <p class="blog-text">
            {{ $data->post_excerpt ?? ''}}
        </p>
        <a class="read-more-btn" href="{{ url('blog/'.$data->slug) }}">
            Read More
            <i class="ion-android-arrow-dropright-circle"></i>
        </a>
    </div>
</article>