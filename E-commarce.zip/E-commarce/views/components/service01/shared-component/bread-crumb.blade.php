  <section class="page-title-layout2 page-title-light bg-overlay bg-parallax">
    <div class="bg-img"><img src="{{LoadAssets('assets/images/page-titles/9.jpg')}}" alt="background"></div>
    <div class="container">
      <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-8">
          <h1 class="pagetitle__heading">
            {{ $title }}</h1>
          <nav> 
          @if (!empty($sublist))
            <ol class="breadcrumb mb-0">
              @foreach ($sublist as $key=>$list)
              @if( $key <  sizeof($sublist) )
              <li class="breadcrumb-item"><a href="{{ $list['link'] }}">{{ $list['name'] }}</a></li>
              @endif
              @endforeach
            </ol>
          @endif
          </nav>
        </div><!-- /.col-xl-6 -->
      </div><!-- /.row -->
    </div><!-- /.container -->
  </section><!-- /.page-title -->