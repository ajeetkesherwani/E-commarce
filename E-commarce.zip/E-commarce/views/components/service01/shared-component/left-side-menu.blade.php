{{-- @php
$urlSegment = Request::segment(2);
$imgurl = url($user_data->profile_photo ?? 'https://cdn.pixabay.com/photo/2020/07/01/12/58/icon-5359553_960_720.png');
@endphp

<form method="post" enctype="multipart/form-data" id="changeProfileImage" style="
        text-align: center;
        border: 1px solid rgba(0, 0, 0, 0.125);
        margin: 12px 0px;
    ">
  <label for="fileToUpload">
    <div class="profile-picc" style="background-image: url('{{ $imgurl }}')">
      <span class="glyphicon glyphicon-camera"></span>
      <span>{{ translation("CHANGE_IMAGE") }}</span>
    </div>
  </label>
  <input type="File" name="fileToUpload" id="fileToUpload" />
  <h5 class="card-title text-center text-uppercase pt-2">
    {{Auth::user()->first_name}} {{Auth::user()->last_name}}
  </h5>
</form>

<div class="list-group" id="#nav">
  <a href="{{ url('account/dashboard') }}" class="list-group-item list-group-item-action {{
            ($urlSegment == 'dashboard') ? 'active' : ''
        }}">
    {{ translation("DASHBOARD") }}
  </a>
  <a href="{{ url('account/profile') }}" class="list-group-item list-group-item-action {{
            ($urlSegment == 'profile') ? 'active' : ''
        }}">
    {{ translation("MY_PROFILE") }}
  </a>
  <a href="{{ url('account/orders') }}" class="list-group-item list-group-item-action {{
            ($urlSegment == 'orders') ? 'active' : ''
        }} ">
    {{ translation("ORDERS") }}
  </a>
  <a href=" {{ url('account/addreses') }}" class="list-group-item list-group-item-action {{
            ($urlSegment == 'addreses') ? 'active' : ''
        }} ">
    {{ translation("ADDRESSES") }}
  </a>
</div>

@push('scripts')
<script>
  $(document).ready(function () {
    $("#fileToUpload").change(function () {
      $.ajaxSetup({
        headers: {
          "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr(
            "content"
          ),
        },
      });
      var profileimage = document.getElementById("changeProfileImage");
      var formData = new FormData(profileimage);
      $.ajax({
        type: "POST",
        url: "{{ url('account/change-image')}}",
        data: formData,
        cache: false,
        contentType: false,
        processData: false,
        success: function (response) {
          if (response.status == 400) {
          } else {
            Notify("Profile Image Updated Successfully", true);
            location.reload();
          }
        },
        error: function (data) {
          console.log(data);
        },
      });
    });
  });
</script>
@endpush --}}


<div class="col-sm-12 col-md-12 col-lg-4 ">
  <aside class="sidebar has-marign-right account-page">
    <div class="account-page-inner widget widget-services ">
      <div class="widget-content">
        <ul class="list-unstyled mb-0">
          <li><a href="{{url('account/dashboard')}}"><span>My Account</span><i class="icon-arrow-right"></i></a></li>
          <li><a href="{{url('account/my-services')}}"><span>Services Subscriptions </span><i class="icon-arrow-right"></i></a></li>
          <li><a href="{{url('account/orders')}}"><span>My Order </span><i class="icon-arrow-right"></i></a></li>
          <li><a href="{{url('account/addreses')}}"><span>Billing Info</span><i class="icon-arrow-right"></i></a></li>
          <li><a href="{{url('account/support-ticket')}}"><span>Support Ticket</span><i class="icon-arrow-right"></i></a></li>
          <li><a href="{{url('account/profile')}}"><span>Setting</span><i class="icon-arrow-right"></i></a></li>
          <li><a href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('frm-logout').submit();"><span>Logout</span><i class="icon-arrow-right"></i></a></li>
          <form id="frm-logout" action="{{ route('logout') }}" method="POST" style="display: none;">
            {{ csrf_field() }}
          </form>
        </ul>
      </div>
    </div>
  </aside>
</div>