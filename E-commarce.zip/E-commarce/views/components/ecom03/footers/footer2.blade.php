@php
$footermenu1=MenuKey("footer-menu-1");
$footermenu2=MenuKey("footer-menu-2");
@endphp
<footer class="footer-area">
    <div class="footer-top">
        <div class="container">
            <div class="row">
                <!-- footer single wedget -->


                <div class="col-md-6 col-lg-4 mt-res-md-50px mt-res-sx-30px mt-res-md-30px">
                    <div class="single-wedge">
                        <h4 class="footer-herading">{{translation('NEWS_LETTER')}}</h4>
                        <div class="subscrib-text">
                            <p class="text-info">{!! getSetting('footer_about_description') ?? '' !!}</p>
                        </div>

                        <div id="mc_embed_signup" class="subscribe-form">
                            <form id="newslatterform" class="validate needs-validation" novalidate="" 
                                name="mc-embedded-subscribe-form" method="post">
                                @csrf
                                <div id="mc_embed_signup_scroll" class="mc-form">
                                    <input class="email" type="email" required placeholder="{{translation('ENTER_YOUR_EMAIL_HERE')}}"
                                        name="customer_email" value="" />
                                        <p class="text-danger mail_error" style="font-size:20px;"></p>
                                    <div class="clear">
                                        <input id="mc-embedded-subscribe" class="button" type="submit" name="subscribe"
                                            value="{{translation('SIGN_UP')}}" />
                                            <input type="reset" hidden id="configreset" value="Reset">
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="img_app">
                            <div class="col-md-12 col-lg-12 text-center text-md-end order-1 order-md-2">
                                <div class="row">
                                    @if(!empty($activePayList))
                                    @foreach ($activePayList as $payment)
                                    <div class="col-lg-3">
                                     <img class="payment-img img-fluid"
                                        onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                                        src="{{getSuperFullImageUrl($payment->method_logo)}}"  alt="{{getSetting('site_title')}}-payment" /> 
                                    </div>
                                    @endforeach
                                    @endif
                                </div>
                            </div> 
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6 col-lg-4">
                    <!-- footer logo -->
                    <div class="footer-logo">
                        <a href="{{url('/')}}"><img src="{{getImageUrlWithKey('website_logo')}}" 
                            onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                            alt="{{getSetting('site_title')}}-logo" /></a>
                    </div>
                    <!-- footer logo -->
                    <div class="about-footer">
                        <p class="text-info">{{getSetting('footer_newsletter_info') ?? ''}}</p>
                        <div class="need-help">
                            <p class="phone-info">
                                {{translation('NEED_HELP?')}}
                                <span>
                                    <a href="tel:{{ getSetting('contact_phone')}}" class="link-dark">
                                        {{ getSetting('contact_phone')}}
                                    </a> <br/>
                                </span>
                            </p>
                        </div>
                        <div class="social-info">
                            <ul>
                                @if(!empty(socialLinks('facebook_url')))
                                <li>
                                    <a href="{{socialLinks('facebook_url')}}" target="_blank"><i class="ion-social-facebook"></i></a>
                                </li>
                                @endif
                                @if(!empty(socialLinks('twitter_url')))
                                <li>
                                    <a href="{{socialLinks('twitter_url')}}" target="_blank"><i class="ion-social-twitter"></i></a>
                                </li>
                                @endif
                                @if(!empty(socialLinks('youtube_url')))
                                <li>
                                    <a href="{{socialLinks('youtube_url')}}" target="_blank"><i class="ion-social-youtube"></i></a>
                                </li>
                                @endif
                                @if(!empty(socialLinks('google_url')))
                                <li>
                                    <a href="{{socialLinks('google_url')}}" target="_blank"><i class="ion-social-google"></i></a>
                                </li>
                                @endif
                                @if(!empty(socialLinks('instagram_url')))
                                <li>
                                    <a href="{{socialLinks('instagram_url')}}" target="_blank"><i class="ion-social-instagram"></i></a>
                                </li>
                                @endif
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- footer single wedget -->
                <div class="col-md-6 col-lg-2 mt-res-sx-30px mt-res-md-30px">
                    <div class="single-wedge">
                        <h4 class="footer-herading">{{translation('INFORMATION')}}</h4>
                        <div class="footer-links">
                            @if(!empty($footermenulist1))
                            <ul>
                                @foreach($footermenulist1 as $key=>$value)
                                <li><a href="{{$value['link'] ?? ''}}">{{translation($value['name']) ?? ''}}</a></li>
                                @endforeach
                            </ul>
                            @endif
                        </div>
                    </div>
                </div>
                <!-- footer single wedget -->
              
                <div class="col-md-6 col-lg-2 mt-res-md-50px mt-res-sx-30px mt-res-md-30px">
                    <div class="single-wedge">
                        <h4 class="footer-herading">{{translation('CUSTOM_LINKS')}}</h4>
                        <div class="footer-links">
                            @if(!empty($footermenulist2))
                            <ul>
                                @foreach($footermenulist2 as $footer2key=>$footer2value)
                                <li><a href="{{($footer2value['link'])}}">{{translation($footer2value['name'])}}</a></li>
                                @endforeach
                            </ul>
                            @endif
                        </div>
                    </div>
                </div>
                <!-- footer single wedget -->
            </div>
        </div>
    </div>

       <!--  Footer Bottom Area start -->
       {{-- <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-lg-5 text-center text-md-start order-2 order-md-1 mt-4 mt-md-0">
                    <p class="copy-text">{{$copyRightText ?? ''}}</p>
                </div>
                <div class="col-md-6 col-lg-7 text-center text-md-end order-1 order-md-2">
                    <img class="payment-img" src="assets/images/icons/payment.png" 
                    
                    alt="{{getSetting('site_title')}}-payment" />
                </div>
            </div>
        </div>
    </div> --}}
        <!--  Footer Bottom Area End-->

</footer>

<!-- // modal  -->
<div class="modal fade" id="productModalShow" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title text-center w-100">{{translation('QUICK_VIEW ')}}</h4>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">x</span></button>
                </div>
                <div class="modal-body">
                    <!--Product Detail Modal-->
                    <div id="product-detail-modal"></div>
                    <!--End of Product Detail Modal-->
                </div>
            </div>
        </div>
</div>


@push('scripts')
<script>
    $(document).ready(function() {

        $(document).on('submit', '#newslatterform', function(e) {
         e.preventDefault();
            $('#newslatterform').addClass('was-validated');
            if ($('#newslatterform')[0].checkValidity() === false) {
            event.stopPropagation();
            } else {

            // $(document).on('click', '#mc-embedded-subscribe', function(e) {
            //   e.preventDefault();
          var data = {
            'customer_email': $('.email').val(),
          }
          //console.log(data);
          $.ajaxSetup({
            headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
          });
          $.ajax({
            type: "POST",
            url: "/newslatterstore",
            data :data,
            dataType:"json",
            success: function(response) {
             // console.log(response);
             if(response.status==400)
            {
                $('.mail_error').text(response.error.customer_email);  
              
            }
            else
            {   
                $('.email').val(),
                $('.mail_error').text(""); 
                Notify('Subscribed Successfully', true);
               $("#newslatterform").trigger("reset")
            }             
            }
           
          });
         }
        });
    });

</script>
@endpush