@php
$footermenu1=MenuKey("footer-menu-1");
$footermenu2=MenuKey("footer-menu-2");

$currentURL = URL::current();
@endphp
<!-- ========== FOOTER ========== -->
<footer>
<!-- Footer-top-widget -->
    @if(strpos($currentURL,'pages') === false)
        <x-Ecom03.SharedComponent.FooterFeatureProduct  /> 
    @endif
        <!-- End Footer-top-widget -->
        <!-- Footer-newsletter -->
        <div class="bg-primary py-3">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-2 col-sm-12">
                        <div class="d-flex">
                            <i class="ec ec-newsletter font-size-40"></i>
                            <h2 class="font-size-20 mb-0 ml-3">{{translation('FOOTER_NEWSLETTER_TITLE')}}</h2>
                        </div>
                    </div>
                                
                          
                    <div class="col col-lg-5 my-md-0 col-sm-12">
                        <h5 class="font-size-15 ">{!! getSetting('footer_newsletter_info') ?? '' !!}</h5>
                    </div>
                       
                    <div class="col-lg-5 col-sm-12">
                        <!-- Subscribe Form -->
                        <form class="validate needs-validation" id="newslatterform" method="post" novalidate>
                            @csrf
                            <label class="sr-only" for="subscribeSrEmail">Email address</label>
                            <div class="input-group input-group-pill">
                                <input type="email" class="form-control border-2 height-40 email" name="customer_email" id="subscribeSrEmail" placeholder="{{translation('FOOTER_EMAIL_PLACEHOLDER')}}" aria-label="Email address" aria-describedby="subscribeButton" required>
                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-dark btn-sm-wide height-40 py-2" id="subscribeButton">{{translation('FOOTER_SIGNUP_BUTTON')}}</button>
                                    <input type="reset" hidden id="configreset" value="Reset">
                                </div>
                            </div>
                            <span class="text-danger mail_error" style="font-size:16px;"></span>
                        </form>
                        <!-- End Subscribe Form -->
                    </div>
                </div>
            </div>
        </div>
        <!-- End Footer-newsletter -->
        <!-- Footer-bottom-widgets -->
        <div class="pt-md-7 pb-md-9 py-2 bg-gray-13">
            <div class="container mt-1">
                <div class="row">
                    <div class="col-lg-4">
                        <div>
                            <a href="#" class="d-inline-block">
                                <a href="{{url('/')}}"><img src="{{getImageUrlWithKey('website_logo')}}"
                            onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" style="width:156px; height:100%;" 
                            alt="{{getSetting('site_title')}}-logo" /></a>
                            </a>
                        </div>
                        <div class="mb-3">
                            <div class="row no-gutters">
                                <div class="col-auto">
                                    <i class="ec ec-support text-primary font-size-56"></i>
                                </div>
                                <div class="col pl-3">
                                    <div class="font-size-14">
                                        {!! (getSetting('footer_about_description'))? html_entity_decode(getSetting('footer_about_description')): '' !!}
                                    </div>
                                    <a href="tel:{{ getSetting('contact_phone')}}" class="font-size-16 text-gray-90">{{ getSetting('contact_phone')}}</a>
                                </div>
                            </div>
                        </div>
                       
                    </div>
                    <div class="col-lg-7 offset-md-1">
                        <div class="row">
                            <div class="col-12 col-md mb-4 mb-md-0">
                                <h6 class="mb-3 font-weight-bold">{{translation('FOOTER_INFORMATION_TITLE')}}</h6>
                                <!-- List Group -->
                                @if(!empty($footermenulist1))
                                <ul class="list-group list-group-flush list-group-borderless mb-0 list-group-transparent">
                                    @foreach($footermenulist1 as $key=>$value)
                                    <li>
                                        <a class="list-group-item list-group-item-action" 
                                            href="{{$value['link'] ?? ''}}">
                                            {{translation($value['name']) ?? ''}}
                                        </a>
                                    </li>
                                    @endforeach
                                </ul>
                                @endif
                                <!-- End List Group -->
                            </div>
                            
                            <div class="col-12 col-md mb-4 mb-md-0">
                                <h6 class="mb-3 font-weight-bold">{{translation('FOOTER_CUSTOM_LINKS_TITLE')}}</h6>
                                <!-- List Group -->
                                @if(!empty($footermenulist2))
                                <ul class="list-group list-group-flush list-group-borderless mb-0 list-group-transparent">
                                    @foreach($footermenulist2 as $footer2key=>$footer2value)
                                    <li><a class="list-group-item list-group-item-action" href="{{$footer2value['link']}}">{{translation($footer2value['name'])}}</a>
                                    </li>
                                    @endforeach
                                </ul>
                                @endif
                                <!-- End List Group -->
                            </div>
                       
                            <div class="col-12 col-md mb-4 mb-md-0">
                            <div>
                            <h6 class="mb-3 font-weight-bold">{{translation('FOOTER_ADDRESS')}}</h6>
                            <address class="">
                                {{getSetting('contact_address')}} {{getSetting('contact_city')}} {{getSetting('contact_state')}}  {{$countryName->countries_name ?? ''}}
                            </address>
                        </div>
                        <div>
                            <ul class="list-inline mb-0 opacity-7">
                                 @if(!empty(socialLinks('facebook_url')))
                                <li class="list-inline-item mr-0">
                                    <a class="btn font-size-18 btn-icon btn-soft-dark btn-bg-transparent rounded-circle" href="{{socialLinks('facebook_url')}}" target="_blank">
                                        <span class="fab fa-facebook-f btn-icon__inner"></span>
                                    </a>
                                </li>
                                 @endif
                                @if(!empty(socialLinks('google_url')))
                                <li class="list-inline-item mr-0">
                                    <a class="btn font-size-18 btn-icon btn-soft-dark btn-bg-transparent rounded-circle" href="{{socialLinks('google_url')}}" target="_blank">
                                        <span class="fab fa-google btn-icon__inner"></span>
                                    </a>
                                </li>
                                 @endif
                                 @if(!empty(socialLinks('twitter_url')))
                                <li class="list-inline-item mr-0">
                                    <a class="btn font-size-18 btn-icon btn-soft-dark btn-bg-transparent rounded-circle" href="{{socialLinks('twitter_url')}}" target="_blank">
                                        <span class="fab fa-twitter btn-icon__inner"></span>
                                    </a>
                                </li>
                                @endif
                                @if(!empty(socialLinks('instagram_url')))
                                <li class="list-inline-item mr-0">
                                    <a class="btn font-size-18 btn-icon btn-soft-dark btn-bg-transparent rounded-circle" href="{{socialLinks('instagram_url')}}" target="_blank">
                                        <span class="fab fa-instagram btn-icon__inner"></span>
                                    </a>
                                </li>
                                @endif
                            </ul>
                        </div>
                                <!-- <h6 class="mb-3 font-weight-bold">{{translation('FOOTER_NEWSLETTER_TITLE')}}</h6>
                                <div class="subscrib-text">
                                    <p>{!! getSetting('footer_newsletter_info') ?? '' !!}</p>
                                </div> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Footer-bottom-widgets -->

        <!-- Footer-copy-right -->
        <div class="bg-gray-14 py-2">
            <div class="container">
                <div class="flex-center-between d-block d-md-flex">
                    <div class="mb-3 mb-md-0"><a href="#" class="font-weight-bold text-gray-90"></a>{!! $copyRightText ?? '' !!}</div>
                    <div class="text-md-right">
                        @if(!empty($activePayList))
                        @foreach ($activePayList as $payment)
                        <span class="d-inline-block bg-white border rounded p-1">
                            <img class="max-width-5" src="{{getSuperFullImageUrl($payment->method_logo)}}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="{{getSetting('site_title')}}-payment">
                        </span>
                        @endforeach
                        @endif
                    </div>
                </div>
            </div>
        </div>
        <!-- End Footer-copy-right -->
    </footer>
    <!-- ========== END FOOTER ========== -->

    <!-- ========== SECONDARY CONTENTS ========== -->
    <!-- Account Sidebar Navigation -->
    {{-- <aside id="sidebarContent" class="u-sidebar u-sidebar__lg" aria-labelledby="sidebarNavToggler">
        <div class="u-sidebar__scroller">
            <div class="u-sidebar__container">
                <div class="js-scrollbar u-header-sidebar__footer-offset pb-3">
                    <!-- Toggle Button -->
                    <div class="d-flex align-items-center pt-4 px-7">
                        <button type="button" class="close ml-auto"
                            aria-controls="sidebarContent"
                            aria-haspopup="true"
                            aria-expanded="false"
                            data-unfold-event="click"
                            data-unfold-hide-on-scroll="false"
                            data-unfold-target="#sidebarContent"
                            data-unfold-type="css-animation"
                            data-unfold-animation-in="fadeInRight"
                            data-unfold-animation-out="fadeOutRight"
                            data-unfold-duration="500">
                            <i class="ec ec-close-remove"></i>
                        </button>
                    </div>
                    <!-- End Toggle Button -->

                    <!-- Content -->
                    <div class="js-scrollbar u-sidebar__body">
                        <div class="u-sidebar__content u-header-sidebar__content">
                            <form class="js-validate" action="{{route('login')}}"method="post" id="Login_Form" novalidate="novalidate">
                                @csrf
                                <!-- Login -->
                                <div id="login" data-target-group="idForm">
                                    <!-- Title -->
                                    <header class="text-center mb-7">
                                    <h2 class="h4 mb-0">{{ translation('LOGIN') }}</h2>
                                    <p>Login to manage your account.</p>
                                    </header>
                                    <!-- End Title -->

                                    <!-- Form Group -->
                                    <div class="form-group">
                                        <div class="js-form-message js-focus-state">
                                            <label class="sr-only" for="signinEmail">Email</label>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="signinEmailLabel">
                                                        <span class="fas fa-user"></span>
                                                    </span>
                                                </div>
                                                <input type="email" class="form-control" name="email" id="signinEmail" placeholder="{{ translation('EMAIL_PLACEHOLDER') }}" aria-label="Email" aria-describedby="signinEmailLabel" required
                                                data-msg="Please enter a valid email address."
                                                data-error-class="u-has-error"
                                                data-success-class="u-has-success">
                                            </div>
                                            @if($errors->has('email'))
                                                <strong class="text-danger mb-5">{{ $errors->first('email') }}</strong>
                                            @endif 
                                        </div>
                                    </div>
                                    <!-- End Form Group -->

                                    <!-- Form Group -->
                                    <div class="form-group">
                                        <div class="js-form-message js-focus-state">
                                          <label class="sr-only" for="signinPassword">Password</label>
                                          <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="signinPasswordLabel">
                                                    <span class="fas fa-lock"></span>
                                                </span>
                                            </div>
                                            <input type="password" class="form-control" name="password" id="signinPassword" placeholder="{{ translation('PASSWORD_PLACEHOLDER') }}" aria-label="Password" aria-describedby="signinPasswordLabel" required
                                               data-msg="Your password is invalid. Please try again."
                                               data-error-class="u-has-error"
                                               data-success-class="u-has-success">
                                          </div>
                                          @if($errors->has('password'))
                                                <strong class="text-danger mb-5">{{ $errors->first('password') }}</strong>
                                            @endif
                                        </div>
                                    </div>
                                    <!-- End Form Group -->

                                    <div class="d-flex justify-content-end mb-4">
                                        <a class="js-animation-link small link-muted" href="{{url('/forgot-password')}}"
                                           data-target="#forgotPassword"
                                           data-link-group="idForm"
                                           data-animation-in="slideInUp">{{ translation('FORGATE_PASSWORD') }}</a>
                                    </div>

                                    <div class="mb-2">
                                        <button type="submit" class="btn btn-block btn-sm btn-primary transition-3d-hover">{{ translation('LOGIN') }}</button>
                                    </div>
                                </form>

                                    <div class="text-center mb-4">
                                        <span class="small text-muted">Do not have an account?</span>
                                        <a class="js-animation-link small text-dark" href="{{url('/register')}}"
                                           data-target="#signup"
                                           data-link-group="idForm"
                                           data-animation-in="slideInUp">{{ translation('SIGN_UP') }}
                                        </a>
                                    </div>

                                    <div class="text-center">
                                        <span class="u-divider u-divider--xs u-divider--text mb-4">OR</span>
                                    </div>

                                    <!-- Login Buttons -->
                                    <div class="d-flex">
                                        <a class="btn btn-block btn-sm btn-soft-facebook transition-3d-hover mr-1" href="#">
                                          <span class="fab fa-facebook-square mr-1"></span>
                                          Facebook
                                        </a>
                                        <a class="btn btn-block btn-sm btn-soft-google transition-3d-hover ml-1 mt-0" href="#">
                                          <span class="fab fa-google mr-1"></span>
                                          Google
                                        </a>
                                    </div>
                                    <!-- End Login Buttons -->
                                </div>

                                <!-- Signup -->
                                
                                <div id="signup" style="display: none; opacity: 0;" data-target-group="idForm">
                                    <!-- Title -->
                                    <header class="text-center mb-7">
                                    <h2 class="h4 mb-0">Welcome to Electro.</h2>
                                    <p>Fill out the form to get started.</p>
                                    </header>
                                    <!-- End Title -->
                                    <form action="{{route('register')}}" method="post" id="REGISTER_FORM"  novalidate="novalidate">
                                        @csrf   
                                        <!-- Form Group -->
                                        <div class="form-group">
                                            <div class="js-form-message js-focus-state">
                                                <label class="sr-only" for="signupEmail">First Name</label>
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" id="signupEmailLabel">
                                                            <span class="fas fa-user"></span>
                                                        </span>
                                                    </div>
                                                    <input type="text" class="form-control" name="first_name" id="signupEmail" placeholder="First Name" aria-label="Email" aria-describedby="signupEmailLabel" required
                                                    data-msg="Please enter first name."
                                                    data-error-class="u-has-error"
                                                    data-success-class="u-has-success">
                                                    @if($errors->has('first_name'))
                                                        <strong class="text-danger mb-5">{{ $errors->first('first_name') }}</strong>
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                        <!-- End Input -->

                                        <div class="form-group">
                                            <div class="js-form-message js-focus-state">
                                                <label class="sr-only" for="signupEmail">Last Name</label>
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" id="signupEmailLabel">
                                                            <span class="fas fa-user"></span>
                                                        </span>
                                                    </div>
                                                    <input type="text" class="form-control" name="last_name" id="signupEmail" placeholder="Last Name" aria-label="Email" aria-describedby="signupEmailLabel" required
                                                    data-msg="Please enter last name."
                                                    data-error-class="u-has-error"
                                                    data-success-class="u-has-success">
                                                    @if($errors->has('last_name'))
                                                        <strong class="text-danger mb-5">{{ $errors->first('last_name') }}</strong>
                                                    @endif
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <div class="js-form-message js-focus-state">
                                                <label class="sr-only" for="signupEmail">Your Email</label>
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" id="signupEmailLabel">
                                                            <span class="fas fa-envelope"></span>
                                                        </span>
                                                    </div>
                                                    <input type="email" class="form-control" name="email" id="signupEmail" placeholder="Email" aria-label="Email" aria-describedby="signupEmailLabel" required
                                                    data-msg="Please enter a valid email address."
                                                    data-error-class="u-has-error"
                                                    data-success-class="u-has-success">
                                                    @if($errors->has('email'))
                                                        <strong class="text-danger mb-5">{{ $errors->first('email') }}</strong>
                                                    @endif
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Form Group -->
                                        <div class="form-group">
                                            <div class="js-form-message js-focus-state">
                                                <label class="sr-only" for="signupPassword">Password</label>
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" id="signupPasswordLabel">
                                                            <span class="fas fa-lock"></span>
                                                        </span>
                                                    </div>
                                                    <input type="password" class="form-control" name="password" id="signupPassword" placeholder="Password" aria-label="Password" aria-describedby="signupPasswordLabel" required
                                                    data-msg="Please enter a password."
                                                    data-error-class="u-has-error"
                                                    data-success-class="u-has-success">
                                                </div>
                                            </div>
                                        </div>
                                        <!-- End Input -->

                                        <div class="mb-2">
                                            <button type="submit" class="btn btn-block btn-sm btn-primary transition-3d-hover">Get Started</button>
                                        </div>
                                    </form>
                                    <div class="text-center mb-4">
                                        <span class="small text-muted">Already have an account?</span>
                                        <a class="js-animation-link small text-dark" href="{{url('login')}}"
                                            data-target="#login"
                                            data-link-group="idForm"
                                            data-animation-in="slideInUp">Login
                                        </a>
                                    </div>

                                    <div class="text-center">
                                        <span class="u-divider u-divider--xs u-divider--text mb-4">OR</span>
                                    </div>

                                    <!-- Login Buttons -->
                                    <div class="d-flex">
                                        <a class="btn btn-block btn-sm btn-soft-facebook transition-3d-hover mr-1" href="#">
                                            <span class="fab fa-facebook-square mr-1"></span>
                                            Facebook
                                        </a>
                                        <a class="btn btn-block btn-sm btn-soft-google transition-3d-hover ml-1 mt-0" href="#">
                                            <span class="fab fa-google mr-1"></span>
                                            Google
                                        </a>
                                    </div>
                                    <!-- End Login Buttons -->
                                </div>
                                <!-- End Signup -->

                                <!-- Forgot Password -->
                                <div id="forgotPassword" style="display: none; opacity: 0;" data-target-group="idForm">
                                    <!-- Title -->
                                    <header class="text-center mb-7">
                                        <h2 class="h4 mb-0">Recover Password.</h2>
                                        <p>Enter your email address and an email with instructions will be sent to you.</p>
                                    </header>
                                    <!-- End Title -->

                                    <form action="{{ route('password.email') }}" method="post" id="forgot" novalidate="novalidate">
                                        @csrf

                                        <!-- Form Group -->
                                        <div class="form-group">
                                            <div class="js-form-message js-focus-state">
                                                <label class="sr-only" for="recoverEmail">Your email</label>
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" id="recoverEmailLabel">
                                                            <span class="fas fa-envelope"></span>
                                                        </span>
                                                    </div>
                                                    <input type="email" class="form-control @error('email') is-invalid @enderror" name="email" id="recoverEmail" placeholder="{{ translation('EMAIL_PLACEHOLDER') }}" aria-label="Your email" aria-describedby="recoverEmailLabel" required
                                                    data-msg="Please enter a valid email address."
                                                    data-error-class="u-has-error"
                                                    data-success-class="u-has-success">
                                                </div>
                                                @if($errors->has('email'))
                                                    <strong class="text-danger mb-5">{{ $errors->first('email') }}</strong>
                                                @endif
                                            </div>
                                        </div>
                                        <!-- End Form Group -->

                                        <div class="mb-2">
                                            <button type="submit" class="btn btn-block btn-sm btn-primary transition-3d-hover">Reset Password</button>
                                        </div>
                                    </form>

                                    <div class="text-center mb-4">
                                        <span class="small text-muted">Remember your password?</span>
                                        <a class="js-animation-link small" href="javascript:;"
                                           data-target="#login"
                                           data-link-group="idForm"
                                           data-animation-in="slideInUp">Login
                                        </a>
                                    </div>
                                </div>
                                <!-- End Forgot Password -->
                            </form>
                        </div>
                    </div>
                    <!-- End Content -->
                </div>
            </div>
        </div>
    </aside> --}}
    <!-- End Account Sidebar Navigation -->
    <!-- ========== END SECONDARY CONTENTS ========== -->

    <!-- Go to Top -->
    <a class="js-go-to u-go-to" href="#"
        data-position='{"bottom": 15, "right": 15 }'
        data-type="fixed"
        data-offset-top="400"
        data-compensation="#header"
        data-show-effect="slideInUp"
        data-hide-effect="slideOutDown">
        <span class="fas fa-arrow-up u-go-to__inner"></span>
    </a>
    <!-- End Go to Top -->

@push('scripts')
<script>
    $(document).ready(function() {

        $(document).on('submit', '#newslatterform', function(e) {
         e.preventDefault();
            $('#newslatterform').addClass('was-validated');
            if ($('#newslatterform')[0].checkValidity() === false) {
            event.stopPropagation();
            } else {
          var data = {
            'customer_email': $('.email').val(),
          }
       
          $.ajaxSetup({
            headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
          });
          $.ajax({
            type: "POST",
            url: "/newslatterstore",
            data :data,
            dataType:"json",
            success: function(response) {
             // console.log(response);
             if(response.status==400)
            {
                $('.mail_error').text(response.error.customer_email);  
              
            }
            else
            {   
             $('.email').val(),
             $('.mail_error').text(""); 
             Notify('{{translation('SUBSCRIBE_SUCCESS_MSG')}}', true);
             $("#newslatterform").trigger("reset")
             $('#newslatterform').removeClass('was-validated');
            }             
            }
           
          });
         }
        });
    });

</script>
{{-- <script>
    $(document).ready(function() {
        $('#Login_Form').validate({
            rules: {
                email: {
                    required: true,
                    email: true,
                    maxlength: 150
                },
                password: {
                    minlength: 8,
                    required: true
                },
            },
            messages: {
                email: {
                        required: "Please enter email",
                        email: "Please enter valid email",
                        maxlength: "Email cannot be more than 150 characters.",
                    },
                    password: {
                        required: "Please enter password",
                        minlength: "Password must be at least 8 characters."
                    },
                },
            highlight: function(element) {
                $(element).addClass('is-invalid');
                $(element).css("border", " 1px solid red")
            },
            unhighlight: function(element, errorClass, validClass) {
                $(element).removeClass('is-invalid');
                $(element).css("border", "1px solid #ebebeb")
            }
        });
    });
 
</script> --}}
@endpush