@php

$main_arr = [
'title' => '',
'sublist' => [
[
'name' => translation('HOME'),
'link' => url('/'),
],
[
'name' =>translation('CHECKOUT'),
'link' =>url()->full()
],
],
];
@endphp
<style>
    .accordion .card {
        overflow: inherit;
    }
</style>
<!-- Breadcrumb Area start -->
<x-Ecom03.SharedComponent.BreadCrumb :data="$main_arr" />
<!-- Breadcrumb Area End -->

<!-- ========== MAIN CONTENT ========== -->
<main id="content" role="main" class="checkout-page">
    {{-- <div class="container"> --}}
        <div class=" border-bottom">
            <h1 class="text-left heading-h1">{{ translation('CHECKOUT') }}</h1>
        </div>
        <form class="js-validate" method="POST" action="{{route('placeOrder')}}" id="placeOrderForm" novalidate="novalidate">
            @csrf
            <div class="row">
                <div class="col-lg-5 order-lg-2 mb-7 order-2 ">
                    <div class="pl-lg-3 ">
                        <div class="bg-gray-1 rounded-lg">
                            <!-- Order Summary -->
                            <div class="p-4 mb-4 checkout-table mt-2">
                                <!-- Title -->
                                <div class="border-bottom border-color-1 mb-4">
                                    <h5 class="section-title mb-0 pb-2">
                                    {{ translation('CHECKOUT_ORDER_TITLE') }}
                                    </h5>
                                </div>
                                <!-- End Title -->
                                <table class="table shipping">
                                    <thead>
                                        <tr>
                                            <th class="product-name">{{ translation('CHECKOUT_PRODUCT_TITLE') }}</th>
                                            <th></th>
                                            <th>{{translation('CHECKOUT_PRODUCT_QUANTITY')}}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @if(!empty($list['cart_list']))
                                            @foreach ($list['cart_list'] as $cart )
                                                <tr class="cart_item">
                                                    <td>
                                                        <img src="{{getFullImageUrl($cart->product->product_image ?? '')}}"
                                                        onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                                                        class="product_img" alt="product_img">  
                                                    </td>
                                                    <td class="px-3">
                                                        <span>{{ $cart->product->products_name ?? ''}} 
                                                        </span>
                                                        <br>
                                                        <div class="product-quantity">{{currencyFormat($cart->final_price*$cart->qty  )}}</div>
                                                    </td>
                                                <td class="d-flex">
                                                        <b>×</b> <strong>{{ $cart->qty ??''}}</strong>
                                                </td>
                                                </tr>
                                            @endforeach
                                        @endif
                                    </tbody>
                                </table>
                                <!-- End Product Content -->
                                @if (!empty($shippingMethodList) && sizeof($shippingMethodList) > 0 )
                                    <div class="payment-method pb-">
                                        <div class="payment-accordion element-mrg">
                                            <div class="panel-group" id="accordion">
                                                <div class="panel payment-accordion">
                                                    <div class="panel-heading" id="method-one">
                                                        <h5 class="panel-title my-2">
                                                            <a data-bs-toggle="collapse" data-parent="#accordion">{{translation('SHIPPING_METHODS')}}
                                                            </a>
                                                        </h5>
                                                    </div>
                                                    @if(!empty($shippingMethodList))
                                                        <div id="method1" class="panel-collapse collapse show">
                                                            <div class="panel-body payment_section">
                                                                <div class="row">
                                                                    @foreach ($shippingMethodList as $shippingKey=>$shipping)
                                                                    <div class="col-md-6 col-sm-12">
                                                                        <div class="form-group d-flex">
                                                                            <input type="radio" name="shipping_method"
                                                                            class="ship-radio-choose"
                                                                            id="{{ $shipping->method_key }}_id" value="{{ $shipping->method_key }}"
                                                                            @if($shippingKey==0)checked @endif required>
                                                                            <label for="{{ $shipping->method_key }}_id"
                                                                                class="text-dark h6">{{$shipping->method_name}}</label>
                                                                            <div class="d-flex">
                                                                                <img src="{{getSuperFullImageUrl($shipping->method_logo)}}"
                                                                                    alt="parment_img"
                                                                                    class="img-round payment-img "
                                                                                    onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                                                                                    height="20">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    @endforeach
                                                                </div>
                                                            </div>
                                                        </div>
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @else
                                    <div class="col-12 m-2">
                                        <input type="radio" name="shipping_method" value="cod">
                                        <label for="">{{translation('PAYMENT_TYPE_COD')}}</label>
                                    </div>
                                @endif

                                @if (webFunctionStatus(config('constkey.is_coupon_enabled')))
                                    @if(!session()->has('coupon_id'))
                                        <div class="row border-top py-3">
                                            <div class="col-lg-12 col-sm-12 mb-3 mb-md-0 w-xl-40 coupon_area">
                                                <!-- Apply coupon Form -->
                                                <label class="sr-only" for="subscribeSrEmailExample1">{{ translation('COUPON_CODE') }}</label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control coupon" name="text" id="coupon_code" placeholder="{{ translation('COUPON_CODE_PLACEHOLDER') }}" aria-label="Coupon code" name="coupon_code" aria-describedby="subscribeButtonExample2">
                                                    <div class="input-group-append">
                                                        @auth
                                                            <button class="btn btn-block btn-dark px-4 coupon" type="button" id="applyButton"><i class="fas fa-tags d-md-none"></i>
                                                                <span class="d-none d-md-inline">{{ translation('COUPON_APPLY_BUTTON')}}</span>
                                                            </button>
                                                        @endauth
                                                        @guest
                                                            <button class="btn btn-block btn-dark px-4 coupon" type="button" id="cpnbtn"><i class="fas fa-tags d-md-none"></i>
                                                                <span class="d-none d-md-inline">{{ translation('COUPON_APPLY_BUTTON')}}</span>
                                                            </button>
                                                        @endguest
                                                    </div>
                                                </div><!-- End Apply coupon Form -->
                                                <div class="alert alert-warning alert-dismissible fade " role="alert" id="coupon_alert">
                                                    <strong class="coupon_error"></strong> 
                                                    <button type="button" class="close coupon_alt_btn" data-dismiss="alert" aria-label="Close">
                                                      <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                            </div>
                                            <div class="coupon_applied mx-auto d-none">
                                                <button type="button" class="btn btn-success disabled">{{translation('COUPON_SUCCESS_MSG')}}</button>
                                            </div>
                                        </div>
                                    @endif
                                @endif

                                <div class="pb-2">
                                    <div class="your-order-total">
                                        <div class="d-flex justify-content-between mb-2">{{translation('CHECKOUT_PRODUCT_SUBTOTAL')}} : <span>{{currencyFormat($list['total_product_price'])}}</span>
                                        </div>
                                        <div class="coupon_disc_amount">
                                            @if (!empty($list['coupon_discount']))
                                                <div class="d-flex justify-content-between mb-2">{{translation('COUPON_DISCOUNT')}} : <span>{{currencyFormat($list['coupon_discount'])}}</span></div>
                                            @endif
                                        </div>
                                        @if(getSetting('ENABLE_TAX')=='1')
                                            @if(getSetting('tax_type')=='exclusive')
                                                <div class="tax_block "> 
                                                    @foreach (tax_calculate($list['product_total'])[0] as $tax_name=>$tax_prices) 
                                                        <div class="d-flex justify-content-between mb-2">
                                                            {{$tax_name}} : <span>{{currencyFormat($tax_prices)}}</span>
                                                        </div>
                                                    @endforeach
                                                </div>
                                                <div class="d-flex justify-content-between border-top py-2 fw-bold border-bottom">
                                                    {{translation('CHECKOUT_PRODUCT_TOTAL')}} : <span class="subtotal">{{currencyFormat(tax_calculate($list['product_total'])[1])}}</span>
                                                </div>
                                            @else
                                                <div class="d-flex justify-content-between border-top">{{translation('CHECKOUT_PRODUCT_TOTAL')}} : <span class="subtotal">{{currencyFormat($list['product_total'])}}</span></div>
                                            @endif
                                        @else
                                            <div class="d-flex justify-content-between border-top">{{translation('CHECKOUT_PRODUCT_TOTAL')}} : <span class="subtotal">{{currencyFormat($list['product_total'])}}</span></div>
                                        @endif
                                    </div>
                                </div>

                                @if(!empty($paymentList))
                                    <div class="payment-method">
                                        <div class="payment-accordion element-mrg">
                                            <div class="panel-group" id="accordion">
                                                <div class="panel payment-accordion">
                                                    <div class="panel-heading" id="method-one">
                                                        <h6 class="panel-title my-2">
                                                            <a data-bs-toggle="collapse" data-parent="#accordion">
                                                                <b>{{ translation('PAYMENT_TYPE') }}</b>
                                                            </a>
                                                        </h6>
                                                    </div>
                                                    <div class="pt-3 mb-3">
                                                        <!-- Basics Accordion -->
                                                        <div id="basicsAccordion1">
                                                            @foreach ($paymentList as $key=>$payment)
                                                            <!-- Card -->
                                                            <div class="mb-4">
                                                                <div id="basicsHeading{{$payment->payment_method_id}}" class="payment-type">
                                                                    <div class="custom-control custom-radio d-flex">
                                                                        <input type="radio" class="custom-control-input" id="stylishRadio{{$payment->method_key }}_id"
                                                                        name="payment_method" value="{{ $payment->method_key }}" @if ($key==0) checked @endif>
                                                                        <label class="custom-control-label form-label" for="stylishRadio{{ $payment->method_key }}_id"
                                                                        data-toggle="collapse" data-target="#basicsCollapseOnee{{$payment->payment_method_id}}"
                                                                        aria-expanded=@if ($key==0) "true" @else "false" @endif
                                                                        aria-controls="basicsCollapseOnee{{$payment->payment_method_id}}">
                                                                        {{ $payment->method_name }}
                                                                        </label>
                                                                        <div class="">
                                                                            <img src="{{getSuperFullImageUrl($payment->method_logo)}}" alt="parment_img" class="img-round payment-img" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" height="20">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- End Card -->
                                                            @endforeach
                                                        </div>
                                                        <!-- End Basics Accordion -->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endif
                                <button type="submit" class="btn btn-primary-dark-w btn-block ">{{ translation('PLACE_ORDER') }}</button>
                            </div>
                            <!-- End Order Summary -->
                        </div>
                    </div>
                </div>
                <div class="col-lg-7 order-lg-1 order-1 billing-detail-wrapper">
                    <div class="mt-5">
                        <!-- Title -->
                        <div class="border-bottom border-color-1 mb-4 d-flex justify-content-between">
                            <h5 class="section-title mb-0 pb-2">{{ translation('BILLING_DETAILS_TITLE') }}</h5>
                            @if(!empty($addressList) && sizeof($addressList) > 0)
                                <div class="mb-0 pb-2">
                                    <button type="button" class="btn btn-primary-dark-w" data-toggle="modal" data-target="#newAddressModal">
                                    <i class="fa fa-plus"></i> 
                                    {{translation('NEW_ADDRESS_BUTTON')}}
                                    </button>
                                </div>
                            @endif
                        </div>
                        <!-- End Title -->

                        <!-- Start of Default Addresses -->
                        @if(!empty($addressList) && sizeof($addressList) > 0)
                            <div class="row">
                                <div class="col-md-12">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>{{ translation('DEFAULT_ADDRESS') }}</th>
                                            </tr>
                                        </thead>
                                        <tbody id="addressListBox">
                                            @foreach ($addressList as $addrKey=>$addressList)
                                            <tr>
                                                <td class="d-flex align-items-center">
                                                    <input type="radio" name="address_id"  class="default_address"
                                                        id="add_{{$addressList->address_id}}"  value='{{$addressList->address_id}}' @if($addressList->is_default=='1') checked @else @if($addrKey==0) checked @endif @endif/>
                                                    <label for="add_{{ $addressList->address_id }}">
                                                        {{ $addressList->customer_name.','. $addressList->customer_email}},
                                                        {{ $addressList->street_address.', '. $addressList->city.',
                                                        '.$addressList->state }},
                                                        {{ $addressList->country_name.'-'. $addressList->zipcode }},
                                                        {{ $addressList->phone}}
                                                    </label>
                                                </td>
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- End of Default Addresses -->
                        @else
                            <!-- Billing Form -->
                            <div class="row">
                                <div class="col-md-6">
                                    <!-- Input -->
                                    <div class="js-form-message">
                                        <label class="form-label">
                                        {{ translation('CONTACT_NAME') }}
                                            <span class="text-danger">*</span>
                                        </label>
                                        <input type="text" class="form-control" name="customer_name" placeholder="" aria-label="Jack" required="" data-msg="{{translation('ERROR_CONTACT_NAME')}}" required data-error-class="u-has-error" data-success-class="u-has-success" autocomplete="off" value="{{old('customer_name')}}">
                                        @if ($errors->has('customer_name'))
                                        <span class="text-danger">
                                            {{ $errors->first('customer_name') }}
                                        </span>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-md-6">
                                
                                    <div class="js-form-message mb-5">
                                        <label class="form-label">
                                        {{ translation('EMAIL') }} 
                                            <span class="text-danger">*</span>
                                        </label>
                                        <input type="email" class="form-control" name="customer_email"
                                            value="{{old('customer_email')}}" placeholder="" aria-label="Wayley" required
                                            data-msg="{{translation('ERROR_EMAIL')}}." data-error-class="u-has-error"
                                            data-success-class="u-has-success">
                                        @if ($errors->has('customer_email'))
                                        <span class="text-danger">{{ $errors->first('customer_email') }}</span>
                                        @endif
                                    </div>
                                </div>
                                <div class="w-100"></div>
                                <div class="col-md-6">
                                    <div class="js-form-message mb-5">
                                        <label class="form-label">
                                        {{ translation('PHONE') }}
                                            <span class="text-danger">*</span>
                                        </label>
                                        <input type="text" class="form-control" name="customer_phone"
                                            value="{{old('customer_phone')}}" placeholder="" aria-label="Wayley" required
                                            data-msg="{{translation('ERROR_PHONE')}}"  data-error-class="u-has-error"
                                            data-success-class="u-has-success">
                                        @if ($errors->has('customer_phone'))
                                        <span class="text-danger">{{ $errors->first('customer_phone') }}</span>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="js-form-message mb-5">
                                        <label class="form-label">
                                        {{ translation('STREET_ADDRESS') }}
                                            <span class="text-danger">*</span>
                                        </label>
                                        <input type="text" class="form-control" name="customer_address"
                                            value="{{old('customer_address')}}" placeholder="" aria-label="Wayley"
                                            required="" data-msg="{{translation('ERROR_STRET_ADDRESS')}}" data-error-class="u-has-error"
                                            data-success-class="u-has-success">
                                        @if ($errors->has('customer_address'))
                                        <span class="text-danger">{{ $errors->first('customer_address') }}</span>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="js-form-message mb-5">
                                        <label class="form-label">
                                        {{ translation('CITY') }}
                                            <span class="text-danger">*</span>
                                        </label>
                                        <input type="text" class="form-control" name="customer_city"
                                            value="{{old('customer_city')}}" placeholder="" aria-label="Wayley" required=""
                                            data-msg="{{translation('ERROR_CITY')}}" data-error-class="u-has-error"
                                            data-success-class="u-has-success">
                                        @if ($errors->has('customer_city'))
                                        <span class="text-danger">{{ $errors->first('customer_city') }}</span>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="js-form-message mb-5">
                                        <label class="form-label">
                                        {{ translation('STATE') }}
                                            <span class="text-danger">*</span>
                                        </label>
                                        <input type="text" class="form-control" name="customer_state"
                                            value="{{old('customer_state')}}" placeholder="" aria-label="Wayley" required=""
                                            data-msg="{{translation('ERROR_STATE')}}" data-error-class="u-has-error"
                                            data-success-class="u-has-success">
                                        @if ($errors->has('customer_state'))
                                        <span class="text-danger">{{ $errors->first('customer_state') }}</span>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="js-form-message mb-5">
                                        <label class="form-label">
                                        {{ translation('COUNTRY') }} 
                                            <span class="text-danger">*</span>
                                        </label>
                                        <select class="form-control js-select selectpicker dropdown-select"
                                            name="countries_id" required="" data-msg="{{translation('ERROR_COUNTRY')}}" required  data-error-class="u-has-error" data-success-class="u-has-success"
                                            data-live-search="true"
                                            data-style="form-control border-color-1 font-weight-normal">
                                            <option selected value disabled>{{translation('COUNTRY_PLACEHOLDER')}}</option>
                                            @foreach($countries as $key=>$country)
                                                <option value="{{$country->countries_id ?? ''}}" @if($Ipcountry->countries_id==$country->countries_id) selected @endif>{{$country->countries_name ??''}}</option>
                                            @endforeach
                                        </select>
                                        @if ($errors->has('countries_id'))
                                            <span class="text-danger">
                                                {{ $errors->first('countries_id') }}
                                            </span>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="js-form-message mb-5">
                                        <label class="form-label">
                                        {{ translation('ZIPCODE') }}
                                            <span class="text-danger">*</span>
                                        </label>
                                        <input type="text" class="form-control" name="customer_postcode"
                                            placeholder="" aria-label="99999" required=""
                                            data-msg="{{translation('ERROR_ZIPCODE')}}" data-error-class="u-has-error"
                                            data-success-class="u-has-success">
                                    </div>
                                </div>
                            </div>
                            <!-- End Billing Form -->
                        @endif

                        <!-- Shipping Addres start here --------->
                        <div id="shopCartAccordion3" class="accordion rounded mb-2">
                            <!-- Card -->
                            <div class="card border-0">
                                <div id="shopCartHeadingFour"
                                    class="custom-control custom-checkbox d-flex align-items-center">
                                    <input type="checkbox" class="custom-control-input" id="shippingdiffrentAddress"
                                        name="is_shipping_diff">
                                    <label class="custom-control-label form-label" for="shippingdiffrentAddress"
                                        data-toggle="collapse" data-target="#shopCartfour" aria-expanded="false"
                                        aria-controls="shopCartfour">
                                        {{ translation('CHECKOUT_SHIP_DIFFRENT_ADDRESS') }}
                                    </label>
                                </div>
                                <div id="shopCartfour" class="collapse mt-5" aria-labelledby="shopCartHeadingFour" data-parent="#shopCartAccordion3" style="">
                                    <!-- Title -->
                                     <div class="border-bottom border-color-1 mb-4">
                                         <h5 class="section-title mb-0 pb-2 ">{{ translation('SHIPPING_DETAIL_TITLE') }}</h5>
                                     </div>
                                     <!-- End Title -->

                                    <!-- Shipping Form -->
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="js-form-message mb-5">
                                                <label class="form-label">
                                                {{ translation('CONTACT_NAME') }}
                                                    <span class="text-danger">*</span>
                                                </label>
                                                <input type="text" class="form-control" name="shipping_customer_name" placeholder="" value="{{old('shipping_customer_name')}}" aria-label="Jack" required="" data-msg="{{translation('ERROR_CONTACT_NAME')}}" data-error-class="u-has-error" data-success-class="u-has-success" autocomplete="off">
                                            </div>
                                            @if ($errors->has('shipping_customer_name'))
                                            <span class="text-danger">{{ $errors->first('shipping_customer_name')}}</span>
                                            @endif
                                        </div>
                                        <div class="col-md-6">
                                            <div class="js-form-message mb-5">
                                                <label class="form-label">
                                                {{ translation('EMAIL') }} 
                                                    <span class="text-danger">*</span>
                                                </label>
                                                <input type="text" class="form-control" name="shipping_customer_email"
                                                    placeholder="" value="{{old('shipping_customer_email')}}"
                                                    aria-label="Jack" required="" data-msg="{{translation('ERROR_EMAIL')}}"
                                                    data-error-class="u-has-error" data-success-class="u-has-success"
                                                    autocomplete="off">
                                            </div>
                                            @if ($errors->has('shipping_customer_email'))
                                                 <span class="text-danger">{{ $errors->first('shipping_customer_email')}}</span>
                                            @endif
                                        </div>
                                        <div class="w-100"></div>
                                        <div class="col-md-6">
                                            <div class="js-form-message mb-5">
                                                <label class="form-label">
                                                {{ translation('PHONE') }}
                                                    <span class="text-danger">*</span>
                                                </label>
                                                <input type="text" class="form-control" name="shipping_customer_phone" value="{{old('shipping_customer_phone')}}"
                                                    aria-label="Jack" required=""
                                                    data-msg="{{translation('ERROR_PHONE')}}"
                                                    data-error-class="u-has-error" data-success-class="u-has-success"
                                                    autocomplete="off">
                                            </div>
                                            @if ($errors->has('shipping_customer_phone'))
                                                 <span class="text-danger">{{ $errors->first('shipping_customer_phone')}}</span>
                                            @endif
                                        </div>
                                        <div class="col-md-6">
                                            <div class="js-form-message mb-5">
                                                <label class="form-label">
                                                {{ translation('STREET_ADDRESS') }}
                                                    <span class="text-danger">*</span>
                                                </label>
                                                <input type="text" class="form-control" name="shipping_customer_address" placeholder="" value="{{old('shipping_customer_address')}}" aria-label="Jack" required="" data-msg="{{translation('ERROR_STRET_ADDRESS')}}" data-error-class="u-has-error" data-success-class="u-has-success" autocomplete="off">
                                            </div>
                                            @if ($errors->has('shipping_customer_address'))
                                            <span class="text-danger">{{ $errors->first('shipping_customer_address')}}</span>
                                            @endif
                                        </div>
                                        <div class="col-md-6">
                                            <div class="js-form-message mb-5">
                                                <label class="form-label">
                                                {{ translation('CITY') }}
                                                    <span class="text-danger">*</span>
                                                </label>
                                                <input type="text" class="form-control" name="shipping_customer_city"
                                                    value="{{old('shipping_customer_city')}}" placeholder="" aria-label="Wayley"
                                                    required="" data-msg="{{translation('ERROR_CITY')}}"
                                                    data-error-class="u-has-error" data-success-class="u-has-success">
                                                @if ($errors->has('shipping_customer_city'))
                                                <span class="text-danger">{{ $errors->first('shipping_customer_city') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="js-form-message mb-5">
                                                <label class="form-label">
                                                {{ translation('STATE') }}
                                                    <span class="text-danger">*</span>
                                                </label>
                                                <input type="text" class="form-control" name="shipping_customer_state"
                                                    value="{{old('shipping_customer_state')}}" placeholder="" aria-label="Wayley"
                                                    required="" data-msg="{{translation('ERROR_STATE')}}"
                                                    data-error-class="u-has-error" data-success-class="u-has-success">
                                                @if ($errors->has('shipping_customer_state'))
                                                <span class="text-danger">{{ $errors->first('shipping_customer_state') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="js-form-message mb-5">
                                                <label class="form-label">
                                                {{ translation('COUNTRY') }} 
                                                    <span class="text-danger">*</span>
                                                </label>
                                                <select class="form-control js-select selectpicker dropdown-select" id="shippingCountry"
                                                    name="shipping_countries_id"
                                                    data-msg="{{translation('ERROR_COUNTRY')}}" data-error-class="u-has-error" 
                                                    data-success-class="u-has-success" data-live-search="true"
                                                    data-style="form-control border-color-1 font-weight-normal">
                                                    <option selected value disabled>{{ translation('COUNTRY_PLACEHOLDER') }}</option>
                                                    @foreach($countries as $key=>$country)
                                                        <option value="{{$country->countries_id ?? ''}}" @if($Ipcountry->countries_id==$country->countries_id) selected @endif>
                                                            {{$country->countries_name ?? ''}} 
                                                        </option>
                                                    @endforeach
                                                </select>
                                                @if ($errors->has('shipping_countries_id'))
                                                <span class="text-danger">
                                                    {{ $errors->first('shipping_countries_id') }}
                                                </span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <!-- Input -->
                                            <div class="js-form-message mb-5">
                                                <label class="form-label">
                                                {{ translation('ZIPCODE') }} 
                                                    <span class="text-danger">*</span>
                                                </label>
                                                <input type="text" class="form-control"
                                                    name="shipping_customer_postcode" placeholder="" aria-label="99999"
                                                    required="" data-msg="{{translation('ERROR_ZIPCODE')}}"
                                                    value="{{old('shipping_customer_postcode')}}"
                                                    data-error-class="u-has-error" data-success-class="u-has-success">

                                                @if ($errors->has('shipping_customer_postcode'))
                                                <span class="text-danger">{{ $errors->first('shipping_customer_postcode')}}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div><!-- End Shipping Form -->
                                </div>
                            </div><!-- End Card -->
                        </div>

                        <!-- Input -->
                        <div class="js-form-message mt-3">
                            <label class="form-label">
                            {{ translation('CHECKOUT_ORDER_NOTE') }} 
                            </label>
                            <div class="input-group">
                                <textarea class="form-control pt-3" placeholder="{{translation('ORDER_NOTE_PLACEHOLDER')}}" name="note"></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    {{-- </div> --}}
</main>
<!-- ========== END MAIN CONTENT ========== -->

<!---============================ LOGIN, REGISTER MODAL START HERE ============================--->

<div class="modal fade enquiry-form" id="modal_popup" tabindex="-1" aria-labelledby="exampleModalLabel" aria-modal="true" role="dialog">
    <input type="hidden" name="login_source" id="login_source" value="checkout">
    <div class="modal-dialog prdtmodal-dialog py-4">
        <div class="modal-content">
            <div class="col-md-12 ">
                <button type="button" class="btn-close prdtbtn-close" data-dismiss="modal" aria-label="Close">X</button>
            </div>
            <!-- Log In -->
            <div class="pt-4 px-4 pb-2 d-none" id="sublogin">
                <div class="pl-3 border-bottom">
                    <h2 class=" enquiry_heading">{{translation('LOGIN_TITLE')}}</h2>
                    <div class="alert alert-dismissible fade login_alert d-none" role="alert">
                        <strong id="alert_message">
                            <!-----here alert message come throw ajax  ----->
                        </strong>
                        <button type="button" class="btn-close login_alt_btn" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    </div> 
                </div>
                <!---- form start here ---->
                <form class="js-validate mt-4" novalidate="novalidate" action="{{route('login') }}" method="post" id="login-modal-form">
                    @csrf  
                    <!-- Form Group -->
                    <div class="js-form-message form-group">
                        <label class="form-label" for="signinSrEmailExample3">{{ translation('EMAIL') }}
                            <span class="text-danger">*</span>
                        </label>
                        <input type="email" class="form-control" name="email" id="login_email" placeholder="{{ translation('EMAIL_PLACEHOLDER') }}" aria-label="Username or Email address" required  data-msg="" data-error-class="u-has-error" value="{{old('email')}}" data-success-class="u-has-success">
                        <span class="text-danger" id="email-logerror"></span>
                    </div>
                    <!-- End Form Group -->

                    <!-- Form Group -->
                    <div class="js-form-message form-group">
                        <label class="form-label" for="signinSrPasswordExample2">
                            {{ translation('PASSWORD')}} 
                            <span class="text-danger">*</span>
                        </label>
                        <input type="password" class="form-control" name="password" id="login_Password" placeholder="{{ translation('PASSWORD_PLACEHOLDER') }}" value="{{old('password')}}" aria-label="Password" required data-error-class="u-has-error"
                        data-success-class="u-has-success">
                        <span class="text-danger" id="email-logerror"></span>
                        <span class="text-danger" id="invalid-creddential"></span>
                    </div>
                    <!-- End Form Group -->

                    <!-- Checkbox -->
                    <div class="js-form-message mb-3">
                        <div class="custom-control custom-checkbox d-flex align-items-center justify-content-between">
                            <div>
                                <input type="checkbox" name="newsletter" class="custom-control-input" id="myCheck">
                                <label class="custom-control-label form-label" for="myCheck">{{translation('REMEMBER_ME')}}</label>
                            </div>
                            <div> 
                                <label class=" form-label" >
                                    <a href="{{url('/forgot-password')}}" class="text-black"> 
                                        {{ translation('FORGOT_PASSWORD')}}?
                                    </a> 
                                </label>
                            </div>
                        </div>
                    </div><!-- End Checkbox -->
                    <!-- Button -->
                    <div class=" text-center mt-3">
                        <button type="submit" class="btn btn-primary-dark-w px-5 w-50 userLogin" id="modalSignInBtn">{{ translation('SIGN_IN') }}</button>
                    </div>
                    <div class="col-12 text-center">
                        <p class="mb-0  mt-4"><small class="text-dark me-2">{{ translation('DONT_HAVE_ACCOUNT')}}?</small> <a href="javascript:void(0);" class="text-dark fw-bold" id="modalExchSignUpBtn">{{translation('SIGN_UP')}}</a></p>
                    </div><!-- End Button -->
                </form>
                <!----- form end here ----->
            </div>
            <!-- Log In--->

            <!-- Registration -->
            <div class="pt-4 px-4 pb-2 d-none" id="subregister">
                <div class="pl-3 border-bottom ">
                    <h2 class=" enquiry_heading">{{translation('REGISTER_TITLE')}}</h2>
                </div>
                <!---- form start here ---->
                <form id="register-modal-form" method="post" class="js-validate needs-validation mt-4" novalidate="novalidate">
                    <div class="row">
                        <div class="col-md-12">
                            <!-- Input -->
                            <div class="js-form-message form-group">
                                <label class="form-label" for="register_name">{{translation('NAME')}} <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="register_name" value="{{old('name')}}" name="name" required=""  placeholder="{{translation('NAME_PLACEHOLDER')}}" aria-label=""  data-error-class="u-has-error" data-success-class="u-has-success" autocomplete="off">
                                <span class="text-danger" id="register-name"></span>
                            </div>
                            
                        </div>
 
                        <div class="col-md-12">
                            <!-- Input -->
                            <div class="js-form-message form-group">
                                <label class="form-label" for="register_email">{{translation('EMAIL')}}
                                    <span class="text-danger">*</span>
                                </label>
                                <input type="email" class="form-control" name="email"  value="{{old('email')}}"  data-msg="" autocomplete="off" required="" id="register_email" placeholder="{{translation('EMAIL_PLACEHOLDER')}}" aria-label="Email address" data-error-class="u-has-error" data-success-class="u-has-success">
                                <span class="text-danger" id="register-email"></span>
                            </div>
                             
                        </div>
                        <div class="col-md-12">
                            <div class="js-form-message form-group">
                                <label class="form-label" for="register_password">{{translation('PASSWORD')}} <span class="text-danger">*</span></label>
                                <input type="password" class="form-control" name="password" id="register_password" data-msg="" autocomplete="off" placeholder="{{translation('PASSWORD_PLACEHOLDER')}}" aria-label="Password" required="" data-error-class="u-has-error" data-success-class="u-has-success">
                                <span class="text-danger" id="register-password"></span> 
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="js-form-message form-group">
                                <label class="form-label" for="confirm_register_password">{{translation('CONFIRM_PASSWORDS')}}<span class="text-danger">*</span></label>
                                <input type="password" class="form-control" name="password_confirmation" id="confirm_register_password" autocomplete="off" placeholder="{{translation('CONFIRM_PASSWORDS_PLACEHOLDER')}}" aria-label="Password" required="" name="password_confirmation"  data-error-class="u-has-error" data-success-class="u-has-success">
                                <span class="text-danger" id="register-password_confirmation"></span>
                            </div>
                        </div>
                    </div>
                    <div class="text-center mb-3">
                        <button type="submit" id="modalSignUpBtn" class="btn btn-primary-dark-w px-5 w-50 registerButton">{{translation('REGISTER_BUTTON')}}</button>
                    </div>
                    <div class="col-12 text-center">
                        <div class="text-dark ">
                            <small>{{translation('ALREADY_REGISTER')}} ?</small>
                            <a href="javascript:void(0);" id="modalExchSignInBtn" class="text-dark fw-bold ml-1">
                                {{translation('SIGN_IN')}}
                            </a>
                        </div> 
                    </div>
                </form>
                <!----- form end here ----->
            </div>
            <!-- Registration -->

        </div>
    </div>
</div>

<!---============================ LOGIN, REGISTER MODAL END HERE ============================--->

    <!-- Add New Address Modal Start Here-->
    <div class="modal fade" id="newAddressModal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">{{translation('ADD_ADDRESS')}}</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="modalAddressform" class="needs-validation" novalidate >
                <div class="row p-">

                    <div class="col-lg-6 col-md-6">
                        <div class="billing-info mb-20px">
                            <label>{{translation('CONTACT_NAME')}} <span class="text-danger">*</span></label>
                            <input type="text" name="customer_name" class="form-control"
                                value="{{old('customer_name')}}" required>
                            <span class="text-danger add_customer_name"></span>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="billing-info mb-20px">
                            <label>{{translation('EMAIL')}}<span
                                    class="text-danger">*</span></label>
                            <input type="email" name="customer_email" value="{{old('customer_email')}}"
                                class="form-control" required>
                            <span class="text-danger add_customer_email"></span>
                        </div>
                    </div>

                    <div class="col-lg-6 ">
                        <div class="billing-info mb-20px">
                            <label>{{translation('PHONE')}}<span
                                    class="text-danger">*</span></label>
                            <input type="text" name="phone" value="{{old('phone')}}"
                                class="form-control" required>
                            <span class="text-danger add_phone"></span>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="billing-info mb-20px">
                            <label>{{translation('STREET_ADDRESS')}}<span class="text-danger">*</span></label>
                            <input class="billing-address form-control" value="{{old('street_address')}}" type="text" name="street_address" required>
                            <span class="text-danger add_street_address"></span>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="billing-info mb-20px">
                            <label>{{translation('CITY')}}<span class="text-danger">*</span></label>
                            <input type="text" name="city" value="{{old('customer_city')}}"
                                class="form-control" required>
                            <span class="text-danger add_city"></span>
                        </div>
                    </div>

                    <div class="col-lg-6 ">
                        <div class="billing-info mb-20px">
                            <label>{{translation('STATE')}}<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="state" value="{{old('customer_state')}}"  required />
                            <span class="text-danger add_state"></span>
                        </div>
                    </div>

                    @if(!empty($countries))
                    <div class="col-lg-6 ">
                        <div class="billing-info mb-20px">
                            <label>{{translation('COUNTRY')}}<span class="text-danger">*</span></label>
                            <select name="countries_id" class="form-control" required>
                                <option selected value="" disabled>
                                    {{translation('COUNTRY_PLACEHOLDER')}}
                                </option>
                                @foreach($countries as $key=>$country)
                                <option value="{{$country->countries_id ?? ''}}" @if($Ipcountry->
                                    countries_id==$country->countries_id) selected
                                    @endif>{{$country->countries_name ?? ''}}</option>
                                @endforeach
                            </select>
                            <span class="text-danger add_countries_id"></span>
                        </div>
                    </div>
                    @endif
                    
                    <div class="col-lg-6 ">
                        <div class="billing-info mb-20px">
                            <label>{{translation('ZIPCODE')}}<span class="text-danger">*</span></label>
                            <input type="text" name="zipcode" value="{{old('customer_postcode')}}"
                                class="form-control" required>
                            <span class="text-danger add_zipcode"></span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-primary float-right" id="addressformbutton">{{translation('SUBMIT')}}</button>
                </div>
             </form>
            </div>
        </div>
        </div>
    </div>
<!-- Add New Address Modal End Here -->
  
<!---============================== scripts start here ===============================--->
@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
<script>
    $(document).ready(function () {

             // Add Address function  ajax start

             $(document).on('click', '#addressformbutton', function (e) {
                e.preventDefault();
                $('#modalAddressform').addClass('was-validated');
                if ($('#modalAddressform')[0].checkValidity() === false) {
                    event.stopPropagation();
                } else {
                var newAddress = document.getElementById("modalAddressform");
                var formData = new FormData(newAddress);
                formData.append('page_source','checkout');
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{url('account/add-address')}}",  
                    data: formData,
                    cache: false,
                    contentType: false,
                    processData: false,

                    success: function (response) {
                        if (response.status == 400) {
                            $.each(response.error, function (key, err_val) {
                                $('.add_' + key).text(err_val);
                            });
                        } 
                        else {
                            var addressList= `<tr>
                            <td class="d-flex gap-3">
                                <input type="radio" name="default_address" class="default_address" checked
                                    id="add_${response.addressData.address_id}"
                                    value='${response.addressData.address_id}'/>
                                <label for="add_${response.addressData.address_id}">
                                    ${response.addressData.customer_name},${response.addressData.customer_email},
                                    ${response.addressData.street_address},${response.addressData.city},
                                    ${response.addressData.state},
                                    ${response.addressData.country_name}, ${response.addressData.zipcode},
                                    ${response.addressData.phone}
                                </label>
                               </td>
                           </tr>`;
                            $("input[name='address_id']").removeAttr('checked');
                            $(addressList).prependTo("#addressListBox");
                            $('#modalAddressform').removeClass('was-validated');
                            $('#newAddressModal').modal('hide');
                            $('#modalAddressform').trigger("reset");
                            Notify('{{translation('SUCCESSFULLY_SEND')}}!', true);
                        }
                    }
                });
              }
            });
            //  Add Address End 

        // change Shipping ajax
        $('#shippingdiffrentAddress').on('click ', function(){
            if($("#shippingdiffrentAddress").prop('checked') == true){
                $('#shippingCountry').attr('required',' ');
            }else{
                $('#shippingCountry').removeAttr('required');
            }
        })
        $(document).on('change', '.ship-radio-choose', function () {
            var methodKey = $(this).attr('value');
            var url = `{{ url('shipping-details/${methodKey}') }}`;
            $.ajax({
                url: url,
                type: "GET",
                success: function (response) {
                    console.log(response);
                    $('#shippingHtml').html("");
                    $('#shippingPrice').html("");
                    $('#shippingHtml').html(response.shippingHtml);
                    $('#shippingPrice').html(response.value);
                }
            });
        });
    });

     // Coupon Ajax Start Here
        $(document).ready(function () {
            $(document).on('click', '#applyButton', function (e) {
                e.preventDefault();
                if ($('#coupon_code').val() != '') {
                    var data = {
                        'coupon_code': $('#coupon_code').val(),
                    }
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        type: "POST",
                        url: "/apply-coupon",
                        data: data,
                        dataType: "json",

                        beforeSend: function () {
                            $('#applyButton').addClass('disabled');
                            var html = '<i class="fa-solid fa-spinner fa-spin-pulse"></i> {{translation('APPLYING')}}...';
                            $('#applyButton').html(html);
                        },

                        success: function (response) {
                          
                            if (response.status == 201) {
                                $('#coupon_alert').removeClass('fade');
                                $('#coupon_alert').addClass('show');
                                $('.coupon_error').text(response.message);
                                $('#applyButton').html('Apply');
                            }
                            if (response.status == 200) {

                                if(response.coupon_response.taxCalculation.length!=0)
                                {    
                                    $taxhtml='';
                                    $.each(response.coupon_response.taxCalculation,function(key,tax_val) {
                                    $taxhtml+=`<div>${key}: <span>${tax_val}</span></div>`;
                                    });
                                    $('.tax_block').html($taxhtml);
                                }

                                $('.subtotal').text(response.coupon_response.amount);
                                var coupon_html = `<div class="d-flex justify-content-between mb-1">{{translation('COUPON_DISCOUNT')}}: <span>${response.coupon_response.discount_amount}</span></div>`;
                                $('.coupon_disc_amount').html(coupon_html);

                                Notify('{{translation('APPLIED_SUCCESS_MSG')}}', true);
                                $('#coupon_code').val('');
                                
                                $('.coupon_applied').removeClass('d-none');
                                $('.coupon_area').addClass('d-none');
                                $('#applyButton').html('{{translation('COUPON_SUCCESS_MSG')}}');
                            }
                        },
                        complete: function (response) {
                            $('#couponForm').removeClass('was-validated');
                            $('#applyButton').removeClass('disabled');
                            
                        }
                    });
                }
                else {
                    $('#coupon_alert').addClass('show');
                    $('#coupon_alert').removeClass('d-none');
                    $('.coupon_error').text('{{translation('ERROR_COUPON_MSG')}}');
                }
            });
        });

        $('.coupon_alt_btn').click(function() {
            $('#coupon_alert').addClass('fade');
            $('#coupon_alert').removeClass('show');
        });

        $('.login_alt_btn').click(function() {
            $('.login_alert').addClass('d-none');
            $('.login_alert').addClass('fade');
            $('.login_alert').removeClass('show');
        });


        $("#cpnbtn").click(function() {
            $("#modal_popup").modal('show');
            $("#sublogin").removeClass('d-none');
            $("#subregister").addClass('d-none');
        });

         // Sign in to SignUp form

        $("#modalExchSignUpBtn").click(function() {
            $("#subregister").removeClass('d-none');
            $("#sublogin").addClass('d-none');
        });

        // Sign up to SignIn form

        $("#modalExchSignInBtn").click(function() {
            $("#subregister").addClass('d-none');
            $("#sublogin").removeClass('d-none');
        });

        // Forgot password button to forgot password form

        $("#modalExForgPassBtn").click(function() {
            $("#sublogin").modal('hide');
            $("#forgot_password").removeClass('d-none');
        });



    // Login Ajax Start ModalloginForm

    $(document).on('click', '#modalSignInBtn', function(e) {
        e.preventDefault();
        $('#login-modal-form').addClass('was-validated');
        if ($('#login-modal-form')[0].checkValidity() === false) {
            event.stopPropagation();
        } else {
            var data = {
                'email': $('#login_email').val(),
                'password': $('#login_Password').val(),
                'login_source': $('#login_source').val(),
                'remember':$('#rememberMe').val(),
            }
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "{{ url('/customer-login') }}",
                data: data,
                dataType: "json",

                beforeSend: function() {
                    $('#modalSignInBtn').addClass('disabled');
                    $('#modalSignInBtn').html(
                        ' <i class="fa-solid fa-spinner fa-spin-pulse"></i>  {{translation('LOGGING')}}....'
                    );
                },
                success: function(response) {
                    console.log(response);
                    if (response.status =="200") {
                        $('#login-modal-form').trigger("reset");
                        $('#login-modal-form').removeClass('was-validated');
                        $("#login-popup").modal('hide');
                        location.reload();
                    }

                    if (response.status =="201") {
                        $(".login_alert").removeClass('d-none');
                        $(".login_alert").addClass('alert-danger');
                        $(".login_alert").addClass('show');
                        $("#alert_message").html(response.message);
                        $('#modalSignInBtn').html('{{translation('SIGN_IN')}}');
                    }
                },
                
                complete: function(response) {
                    $('#modalSignInBtn').removeClass('disabled');
                    $('#modalSignInBtn').html('{{translation('SIGN_IN')}}');
                }
            });
        }
    });

    // Register Ajax start here

    $(document).on('click', '#modalSignUpBtn', function(e) {
        e.preventDefault();
        $('#register-modal-form').addClass('was-validated');
        if ($('#register-modal-form')[0].checkValidity() === false) {
            event.stopPropagation();
        } else {
            var data = {
                'name': $('#register_name').val(),
                'email': $('#register_email').val(),
                'password': $('#register_password').val(),
                'password_confirmation': $('#confirm_register_password').val(),
            }

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "{{ url('customer-register') }}",
                data: data,
                dataType: "json",

                beforeSend: function() {
                    $('#modalSignUpBtn').addClass('disabled');
                    $('#modalSignUpBtn').html(
                        ' <i class="fa-solid fa-spinner fa-spin-pulse"></i> {{translation('REGISTERING')}}...'
                    );
                },

                success: function(response) {
                    if (response.status == 400) {
                        $.each(response.error, function(key, err_val) {
                            $('#' + 'register-' + key).text(err_val);
                        });
                    }
                    if (response.status == 200) {

                        $('#register-modal-form').trigger("reset");
                        $('#register-modal-form').removeClass('was-validated');
                        $(".login_alert").removeClass('d-none');
                        $("#sublogin").removeClass('d-none');
                        $(".login_alert").addClass('show');
                        $(".login_alert").removeClass('alert-danger');
                        $(".login_alert").addClass('alert-success');
                        $("#alert_message").html("{{translation('REGISTER_SUCCESS_MSG')}}!");
                        $("#subregister").addClass('d-none');
                    }
                },
                complete: function() {
                    $('#modalSignUpBtn').removeClass('disabled');
                    $('#modalSignUpBtn').html('{{translation('SIGN_UP')}}');
                }
            });
        }
    });
</script>
@endpush
<!---============================== Scripts End Here ===============================--->