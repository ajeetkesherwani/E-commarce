@if (!empty($cart_list) && sizeof($cart_list)>0)
<div class="mb-10 cart-table" id="cart-table">
    <form class="mb-4" action="#">
        <table class="table" cellspacing="0">
            <thead>
                <tr>
                    <th class="product-remove">&nbsp;</th>
                    <th class="product-thumbnail">&nbsp;</th>
                    <th class="product-name">Product</th>
                    <th class="product-price">Price</th>
                    <th class="product-quantity w-lg-15">Quantity</th>
                    <th class="product-subtotal">Total</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($cart_list as $cart )
                <tr class="">
                    <td class="text-center">
                        <a href="javascript:void(0)" onclick="actionOnCart({{$cart->cart_id }},'del')" class="text-gray-32 font-size-26">×</a>
                    </td>
                    <td class="d-none d-md-table-cell">
                        <a href="{{url('product/'.$cart->product->product_slug)}}"><img class="img-fluid max-width-100 p-1 border border-color-1" src="{{getFullImageUrl($cart->product->product_image)}}" 
                            onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                            alt=" {{ $cart->product->products_name ?? ''}}"></a>
                    </td>
                    <td data-title="Product">
                        <a href="{{url('product/'.$cart->product->product_slug)}}" class="text-gray-90">{{$cart->product->products_name ?? ''}}</a>
                        @if (isset($cart->attributes) && !empty($cart->attributes))
                        <div>
                            @foreach ($cart->attributes as $attribute)
                                @if (isset($attribute->product_options))
                                    <span> {{ $attribute->product_options->products_options_name }} : {{ $attribute->products_options_values_name }} </span><br/>
                                @endif
                            @endforeach
                        </div>
                        @endif
                    </td>

                    <td data-title="Price">
                        <span class="amount">{{ currencyFormat($cart->final_price ?? 0)}}</span>
                    </td>

                    <td data-title="Quantity">
                        <span class="sr-only">Quantity</span>
                        <!-- Quantity -->
                        <div class="border rounded-pill py-1 px-3 border-color-1">
                            <div class="js-quantity row align-items-center">
                                <div class="col">
                                    <input class="js-result form-control h-auto border-0 rounded p-0 shadow-none" type="number" id="{{ $cart->cart_id }}_qty" data-cart="{{ $cart->cart_id }}" name="qtybutton" value="{{ $cart->qty }}" min=1 step=1>
                                </div>
                                <div class="col-auto pr-1" data-cart="{{ $cart->cart_id }}">
                                    <a class="js-minus btn btn-icon btn-xs btn-outline-secondary rounded-circle border-0 qtybutton" href="javascript:;">
                                        <small class="fas fa-minus btn-icon__inner"></small>
                                    </a>
                                    <a class="js-plus btn btn-icon btn-xs btn-outline-secondary rounded-circle border-0 qtybutton"  href="javascript:;">
                                        <small class="fas fa-plus btn-icon__inner"></small>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <!-- End Quantity -->
                    </td>
                    <td data-title="Total">
                        <span class="">  
                            @php
                            $qty = (int) $cart->qty;
                            $price = $cart->final_price ?? 0;
                            echo currencyFormat($qty*$price);
                            @endphp
                        </span>
                    </td>
                </tr>
                @endforeach
                <tr>
                <td colspan="6" class="border-top space-top-2 justify-content-center">
                    <div class="pt-md-3">
                        <div class="d-block d-md-flex flex-center-between">
                            <div class="mb-3 mb-md-0 w-xl-40">
                                <!-- Apply coupon Form -->
                                @if(webFunctionStatus(config('constkey.is_coupon_enabled')))
                                <form class="js-focus-state">
                                    <label class="sr-only" for="subscribeSrEmailExample1">Coupon code</label>
                                    <div class="input-group">
                                        <input type="text" class="form-control" name="text" id="subscribeSrEmailExample1" placeholder="Coupon code" aria-label="Coupon code" aria-describedby="subscribeButtonExample2" required>
                                        <div class="input-group-append">
                                            <button class="btn btn-block btn-dark px-4" type="button" id="subscribeButtonExample2"><i class="fas fa-tags d-md-none"></i><span class="d-none d-md-inline">Apply coupon</span></button>
                                        </div>
                                    </div>
                                </form>
                                @endif
                                <!-- End Apply coupon Form -->
                            </div>
                            <div class="d-md-flex">
                                <a href="{{ url('checkout') }}" class="btn btn-primary-dark-w ml-md-2 px-5 px-md-4 px-lg-5 w-100 w-md-auto d-none d-md-inline-block">Proceed to checkout</a>
                            </div>
                        </div>
                    </div>
                </td>
            </tr>
            </tbody>
        </table>
    </form>
</div>
<div class="mb-8 cart-total">
    <div class="row">
        <div class="col-xl-5 col-lg-6 offset-lg-6 offset-xl-7 col-md-8 offset-md-4">
            <div class="border-bottom border-color-1 mb-3">
                <h3 class="d-inline-block section-title mb-0 pb-2 font-size-26">Cart totals</h3>
            </div>
            <table class="table mb-3 mb-md-0">
                <tbody>
                    <tr class="cart-subtotal">
                        <th>Subtotal</th>
                        <td data-title="Subtotal"><span class="amount">{{ currencyFormat($grand_total) }}</span></td>
                    </tr>
                  
                    <tr class="order-total">
                        <th>Total</th>
                        <td data-title="Total"><strong><span class="amount">{{ currencyFormat($grand_total) }}</span></strong></td>
                    </tr>
                </tbody>
            </table>
            <button type="button" class="btn btn-primary-dark-w ml-md-2 px-5 px-md-4 px-lg-5 w-100 w-md-auto d-md-none">Proceed to checkout</button>
        </div>
    </div>
</div>
@else
<img src="{{ LoadAssets('assets/img/EmptyImages/Cart-Empty.jpg')}}" 
onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
class="rounded mx-auto d-block" height="200px" alt="{{getSetting('site_title')}} Wishlist-Empty">
<p class="h4 text-center text-dark mt-3">Your cart is empty !</p>
<div class="text-center my-3">
<a href="{{url('/')}}" class="btn btn-primary  btn-sm" role="button" aria-pressed="true">Continue to shop</a>
@endif

@push('scripts')
    <script>

         $(document).ready(function() {
           $(document).on("click", ".qtybutton", function() {
                // alert("hello");
                // initialization of quantity counter
                $.HSCore.components.HSQantityCounter.init('.js-quantity');
            });
           });
    </script>
@endpush