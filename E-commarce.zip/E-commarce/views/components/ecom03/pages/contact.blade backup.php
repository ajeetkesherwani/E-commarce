@php

$main_arr = [
  'title'=>'Contact-us',
  'sublist' => [
    [
    'name'=>'HOME',
    'link'=>url("/")
    ],
    [
    'name'=>'Contact',
    'link'=>url("")
    ], 
  ]
];
@endphp

<!-- Breadcrumb Area start -->
<x-Ecom01.SharedComponent.BreadCrumb :data="$main_arr" /> 
<!-- Breadcrumb Area End -->

<!-- contact area start -->
<div class="contact-area mtb-60px">
    <div class="container">
		
		
		<div class="custom-row-2 mb-3">
            <div class="col-lg-4 col-md-5">
                <div class="contact-info-wrap">
                    <div class="single-contact-info">
                        <div class="contact-icon">
                            <i class="fa fa-phone"></i>
                        </div>
                        <div class="contact-info-dec">
                            <p><a href="tel:{{ getSetting('phone')}}" class="link-dark">
                                    {{ getSetting('phone')}}
                                </a></p>

                        </div>
                    </div>
                    <div class="single-contact-info">
                        <div class="contact-icon">
                            <i class="fa fa-globe"></i>
                        </div>
                        <div class="contact-info-dec">
                            <p><a href="mailto:{{ getSetting('email') }}">{{ getSetting('email')}}</a></p>
                        </div>
                    </div>
                    <div class="single-contact-info">
                        <div class="contact-icon">
                            <i class="fa fa-map-marker"></i>
                        </div>
                        <div class="contact-info-dec">
                            <p>Address,</p>
                            <p>{{getSetting('address')}} {{$countryName->countries_name ?? ''}}</p>
                        </div>
                    </div>
                    <div class="contact-social">
                        <h3>Follow Us</h3>
                        <div class="social-info">
                            <ul>
                                <li>
                                    <a href="{{getSetting('facebook_url')}}" target="_blank"><i
                                            class="ion-social-facebook"></i></a>
                                </li>
                                <li>
                                    <a href="{{getSetting('twitter_url')}}" target="_blank"><i
                                            class="ion-social-twitter"></i></a>
                                </li>
                                <li>
                                    <a href="{{getSetting('youtube_url')}}" target="_blank"><i
                                            class="ion-social-youtube"></i></a>
                                </li>
                                <li>
                                    <a href="{{getSetting('google_url')}}" target="_blank"><i
                                            class="ion-social-google"></i></a>
                                </li>
                                <li>
                                    <a href="{{getSetting('instagram_url')}}" target="_blank"><i
                                            class="ion-social-instagram"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-8 col-md-7">
                <div class="contact-form">
                    <div class="contact-title mb-30">
                        <h2>@lang('pages.contactus.pageName')</h2>
                    </div>
                    <form class="contact-form-style" id="contact-form" action="{{url('/contactstore')}}" method="POST">
                        @csrf

                        <div class="row">
                            <div class="col-lg-6">
                                <input name="name" id="name" placeholder="@lang('placeholders.contactus.name')*" type="text" />
                                <span class="text-danger" id="customers_name" ></span>
                                @if ($errors->has('name'))
                                <span class="text-danger">{{ $errors->first('name') }}</span>
                                @endif
                            </div>
                            <div class="col-lg-6">
                                <input name="email"  id="email" placeholder="@lang('placeholders.contactus.email')*" type="email" />
                                <span class="text-danger" id="email_address" ></span>
                                @if ($errors->has('email'))
                                <span class="text-danger">{{ $errors->first('email') }}</span>
                                @endif
                            </div>
                            <div class="col-lg-12">
                                <input name="subject" id="subjects" placeholder="@lang('placeholders.contactus.subject')*" type="text" />
                                <span class="text-danger" id="subject" ></span>
                                @if ($errors->has('subject'))
                                <span class="text-danger">{{ $errors->first('subject') }}</span>
                                @endif
                            </div>
                            <div class="col-lg-12">
                                <textarea name="message"  id="messages" placeholder="@lang('placeholders.contactus.message')*"></textarea>
                                <span class="text-danger" id="message" ></span>
                                @if ($errors->has('message'))
                                <span class="text-danger">{{ $errors->first('message') }}</span>
                                @endif
                            </div>
                            <button class="col-lg-3" type="button" id="contactusbtn">@lang('pages.contactus.contactbtn')</button>
                            <input type="reset" hidden id="configreset" value="Reset">
                        </div>
                    </form>
                    <!-- <p class="form-messege"></p>-->
                </div>
            </div>
        </div>
		

        
    </div>
</div>

<!-- contact area end -->

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
<script>
    $(document).ready(function () {
        $('#contact-form"').validate({
            rules: {
                name: {
                    minlength: 2,
                    required: true
                },
                email: {
                    required: true,
                },
                subject: {
                    required: true
                },
                message: {
                    required: true
                },
            },
            highlight: function (element) {
                $(element).closest('.cls').removeClass('success').addClass('error');
                $(element).css("border", "1px solid red");
            },
        });
});



</script>

@endpush


@push('scripts')
<script>
    $(document).ready(function () {
        //alert('hello');
        $(document).on('click', '#contactusbtn', function (e) {
            e.preventDefault();
            var data = {
                'customers_name': $('#name').val(),
                'email_address': $('#email').val(),
                'subject': $('#subjects').val(),
                'message': $('#messages').val(),
            }
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "/contactstore",
                data: data,
                dataType: "json",
                success: function (response) {
                    // console.log(response);
                    if (response.status == 400) {
                        $.each(response.error, function (key, err_val) {
                            $('#' + key).text(err_val);
                        });

                    }
                    else {
                        Notify('Details Send Successfully', true);
                        $('#contact-form').trigger("reset");
                    }
                }

            });
        });
    });
</script>
@endpush