@php
$main_arr = [
  'sublist' => [
    [
    'name'=>translation('HOME'),
    'link'=>url("/")
    ],
    [
    'name'=>translation('DASHBOARD'),
    'link'=>url()->full()
    ], 
    
  ]
];
@endphp
<!-- Breadcrumb Area start -->
<x-Ecom03.SharedComponent.BreadCrumb :data="$main_arr" /> 
<!-- Breadcrumb Area End -->
<div class="container myaccount-section">
  <div class="row mb-md-8">
    <div class="col-xl-12 col-wd-12gdot5 mx-auto">
      <h3 class="text-black px-3">{{translation('HELLO')}}, {{ Auth::user()->first_name }}</h3>
      <div class="px-3 mt-5">
        <div class="border-bottom section-title">
          <div class="mb-0"> {{ translation('ACCOUNT_DASHBOARD') }}</div> 
        </div>
      </div>
      <div class="d-flex  align-items-center account-information">
        <div class="col-lg-4 ">
        <a href="{{ url('account/my-account') }}" class=" bg-gray-1 d-block">
          <div class="p-3">
            <div class="d-flex align-items-center justify-content-center mb-2 flex-row">
              <div class="mr-2">
                <svg width="22" height="22" xmlns="http://www.w3.org/2000/svg">
                    <path d="M11 0a11 11 0 100 22 11 11 0 000-22zm0 4.3a3.9 3.9 0 110 7.8 3.9 3.9 0 010-7.8zm0 15.2c-2.6 0-5-1.2-6.5-3a5 5 0 014.4-2.7h.3c.6.3 1.2.4 1.8.4l1.8-.3h.3a5 5 0 014.4 2.6 8.5 8.5 0 01-6.5 3z" fill="currentColor" fill-rule="nonzero"></path>
                </svg>
              </div>
              <div>
                <strong>
                  {{ translation('ACCOUNT_TITLE') }}
                </strong>
              </div>
             
                <svg width="18" height="18" xmlns="http://www.w3.org/2000/svg" class="svg-icon">
                      <path d="M17.7 2.7L15.3.3C15 0 14.5 0 14.1.1h-.2L2.7 11.4l-1.2 1.2L0 18l5.3-1.4L18 4v-.2c.2-.4.1-.9-.2-1.2z" fill="currentColor" fill-rule="evenodd"></path>
                </svg>
              
            </div>
         
            <ul>
              <li>{{ Auth::user()->first_name }} {{ Auth::user()->last_name }}</li>
              <li>
                <b>{{Auth::user()->email}}</b>
              </li>
              <li>*******</li>
            </ul>
           
          </div>
          </a>
        </div>
        <div class="col-lg-4 ">
        <a href="{{ url('account/addreses') }}" class="bg-gray-1 d-block">
          <div class="p-3">
        
            <div class="d-flex align-items-center justify-content-center mb-2 flex-row">
              <div class="mr-2">
                <svg width="20" height="22" xmlns="http://www.w3.org/2000/svg">
                  <path d="M18.7 6.9c.3 0 .6-.3.6-.5V4.6c0-.2-.3-.5-.6-.5H18v-2c0-1.2-1-2.1-2-2.1H2A2 2 0 000 2v18c0 1 1 2 2 2h13.8c1.2 0 2-1 2-2v-2.1h1c.2 0 .4-.3.4-.5v-1.8c0-.2-.2-.5-.5-.5H18v-2.7h.8c.3 0 .6-.3.6-.5V10c0-.2-.3-.5-.6-.5H18V7h.8zM9 5.5A2.8 2.8 0 119 11a2.8 2.8 0 010-5.5zm4.8 10.2c0 .4-.4.8-1 .8H5.2c-.5 0-1-.4-1-.8v-.8c0-1.4 1.3-2.5 3-2.5h.1a4.5 4.5 0 003.4 0h.3c1.6 0 2.8 1 2.8 2.4v.9z" fill="currentColor" fill-rule="nonzero"></path>
                </svg>
              </div>
              <div>
                <strong>
                  {{translation('ACCOUNT_ADDRESS_TITLE') }}
                </strong>
              </div> 
             
                <svg width="18" height="18" xmlns="http://www.w3.org/2000/svg" class="svg-icon">
                  <path d="M17.7 2.7L15.3.3C15 0 14.5 0 14.1.1h-.2L2.7 11.4l-1.2 1.2L0 18l5.3-1.4L18 4v-.2c.2-.4.1-.9-.2-1.2z" fill="currentColor" fill-rule="evenodd">
                  </path>
                </svg>
              
            </div>
            <ul>
              @if(!empty($userAddress))
                <li class="">{{$userAddress->street_address}}</li>
                <li class="">{{$userAddress->city}},{{$userAddress->state}}</li>
                <li class="">{{country_name($userAddress->countries_id)}},{{$userAddress->zipcode}}</li>
              @endif
            </ul>
          
          </div>
          </a>
        </div>
        <div class="col-lg-4">
        <a href="{{ url('account/orders') }}" class="bg-gray-1 d-block">
          <div class="p-3 ">
            <div class="d-flex align-items-center justify-content-center mb-2 flex-row">
              <div class="mr-2 ">
                <svg width="29" height="22" xmlns="http://www.w3.org/2000/svg">
                  <path d="M0 19.6C0 21 1 22 2.4 22h23.5c1.3 0 2.4-1 2.4-2.4V11H0v8.6zm9.4-3.3c0-.3.3-.6.6-.6h6.7c.3 0 .6.3.6.6v2c0 .3-.3.6-.6.6H10a.6.6 0 01-.6-.6v-2zm-6.3 0c0-.3.3-.6.6-.6h3.6c.3 0 .6.3.6.6v2c0 .3-.3.6-.6.6H3.7a.6.6 0 01-.6-.6v-2zm25.2-14v2.4H0V2.4C0 1 1 0 2.4 0h23.5c1.3 0 2.4 1 2.4 2.4z" fill="currentColor" fill-rule="nonzero"></path>
                </svg>
              </div>
              <div>
                <strong>
                  {{ translation('ACCOUNT_ORDER_TITLE') }}
                </strong>
              </div> 
              
                <svg width="18" height="18" xmlns="http://www.w3.org/2000/svg" class="svg-icon">
                  <path d="M17.7 2.7L15.3.3C15 0 14.5 0 14.1.1h-.2L2.7 11.4l-1.2 1.2L0 18l5.3-1.4L18 4v-.2c.2-.4.1-.9-.2-1.2z" fill="currentColor" fill-rule="evenodd"></path>
                </svg>
             
            </div>
            <ul>
              {{-- @dd($order_count); --}}
              @if(!empty($order_count))
                <li>{{$order_count}}</li>
              @else
                <li>There is no any order.</li>
              @endif
            </ul>
           
          </div>
          </a>
        </div>
      </div>
    </div>
  </div>
  <!-- Brand Carousel -->
  <x-Ecom03.SharedComponent.BrandSlider />
  <!-- End Brand Carousel -->
</div>


