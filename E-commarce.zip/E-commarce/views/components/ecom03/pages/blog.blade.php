@php

$main_arr = [
  'title'=>'',
  'sublist' => [
    [
    'name'=>translation('HOME'),
    'link'=>url("/")
    ],
    [
    'name'=>translation('BLOG'),
    'link'=>url()->full()
    ], 
  ]
];
@endphp

<!-- Breadcrumb Area start -->
<x-Ecom03.SharedComponent.BreadCrumb :data="$main_arr" /> 
<!-- Breadcrumb Area End -->

@if(!empty($allBlog) && sizeof($allBlog)>0)

<div class="container">
    <div class="row">
        <div class="col-xl-9 col-wd">
            <div class="max-width-1100-wd">
                <div class="row">
                    @foreach($allBlog as $blogKey=>$blogData)
                    <x-Ecom03.SharedComponent.PostGrid :data="$blogData" />
                    @endforeach
                </div>
            </div>

              <!--  Pagination Area Start -->
              <div class="pro-pagination-style text-center">
                <div class="row">
                    <div class="col-md-12 d-flex justify-content-center p-2">
                        {{ $allBlog->links('vendor.pagination.semantic-ui') }}
                    </div>
                </div>
            </div>
            <!--  Pagination Area End -->
        </div>
        @if (!empty($recentPost))
        <div class="col-xl-3 col-wd">
            <aside class="mb-7">
                <div class="border-bottom border-color-1 mb-5">
                    <h3 class="section-title section-title__sm mb-0 pb-2 font-size-18">{{ translation('RECENT_POST') }}</h3>
                </div>
                @foreach ($recentPost as $blog)
                <article class="mb-4">
                    <div class="media">
                        <div class="width-75 height-75 mr-3">
                            <img class="img-fluid object-fit-cover" src="{{getFullImageUrl($blog->img)}}" 
                            alt="{{ $blog->post_title ?? '' }}" 
                            onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                            />
                        </div>
                        <div class="media-body">
                            <h4 class="font-size-14 mb-1"><a href="{{ url('blog/'.$blog->slug) }}" class="text-gray-39">{{ $blog->post_title ?? '' }}</a></h4>
                            <span class="text-gray-5">{{ date("M d, Y", strtotime($blog->created_at)) }}</span>
                        </div>
                    </div>
                </article>
              @endforeach
            </aside>
        </div>
        @endif
    </div>
    <!-- Brand Carousel -->
    
    <!-- End Brand Carousel -->
</div>
@endif