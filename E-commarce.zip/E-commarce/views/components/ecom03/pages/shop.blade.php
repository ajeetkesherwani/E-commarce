@php
$main_arr = [
'title' => $sideFilter['cat_details']->category_name ?? '',
'sublist' => $breadCumbArr,
];

$ExtSize = '';
$lSize = '';
// Make conditions for div sizes

if (in_array(config('constkey.sidebar_filter'), $cKey) || in_array(config('constkey.sidebar_category'), $cKey)) {
$ExtSize = 'col-lg-9';
$lSize = 'col-md-12';
} else {
$ExtSize = 'col-lg-12';
$lSize = 'col-md-6';
}
$per_page=substr(url()->full(),-2);
if($per_page==00)
$per_page=substr(url()->full(),-3);
@endphp
<!-- Breadcrumb Area start -->
<x-Ecom03.SharedComponent.BreadCrumb :data="$main_arr" /> 
<!-- Breadcrumb Area End -->

<!-- Shop Category Area End -->
<div class="container">
    <form id="filterForm" action="{{url("/category/".urlencode($filtersData['slug']))}}" method="get">
        <input type="hidden" name="filter">
        <div class="row mb-8">
            @if (in_array(config('constkey.sidebar_category'), $cKey))
                <div class="d-none d-xl-block col-xl-3 col-wd-2gdot5">
                    @if (in_array(config('constkey.sidebar_category'), $cKey))
                        @if ($sideFilter['cat_list']->isEmpty() && sizeof($sideFilter['cat_list'])>0)
                            <div class="mb-6 border border-width-2 border-color-3 borders-radius-6">
                                <!-- List -->
                                <ul id="sidebarNav" class="list-unstyled mb-0 sidebar-navbar view-all">
                                    <li>
                                        <div class="dropdown-title">
                                            {{ translation('PRODUCT_CATEGORIES') }}
                                        </div>
                                    </li>
                                    @foreach ($sideFilter['cat_list'] as $key => $cat)
                                        <li>
                                            <a class="dropdown-toggle dropdown-toggle-collapse" 
                                            href="{{ url('category/' . $cat->categories_slug) }}">
                                                {{$cat->category_name ?? 'No Data' }}
                                            </a>
                                        </li>
                                    @endforeach
                                </ul>
                                <!-- End List -->
                            </div>
                        @endif
                    @endif
                    @if (in_array(config('constkey.sidebar_filter'), $cKey))
                        <div class="mb-6">
                            <div class="border-bottom border-color-1 mb-5">
                                <h3 class="section-title section-title__sm mb-0 pb-2 font-size-18">
                                    {{ translation('PRODUCT_FILTER_BY') }}
                                </h3>
                            </div> 
                            @if (!empty($brandArray) && sizeof($brandArray)>0)
                                <div class="border-bottom pb-4 mb-4">
                                    <!-- Checkboxes -->
                                    <h4 class="font-size-14 mb-3 font-weight-bold">
                                        {{ translation('PRODUCT_BRAND')}}
                                    </h4>
                                    <div class="form-group mb-2 pb-1">
                                        @foreach ($brandArray as $brands)
                                            <div class="custom-control custom-checkbox mb-2">
                                                <input type="checkbox" name="choosenBrands[]" class="custom-control-input" id={{$brands}} onClick="filterItem()" value='{{ $brands}}' @if(in_array($brands,$filtersData['brands'])) checked @endif >
                                                <label class="custom-control-label" for="{{$brands}}"> 
                                                    {{ brandIDtoName($brands)}}
                                                </label>
                                                <span class="checkmark"></span>
                                            </div>
                                        @endforeach
                                    </div>
                                </div>
                            @endif 
                            <!-- Options start -->
                            @if (!empty($productAttributes))
                                @foreach ($productAttributes as $optionName=>$option)
                                    <div class="border-bottom pb-4 mb-4">
                                        <h4 class="font-size-14 mb-3 font-weight-bold">
                                            {{$optionName ?? '' }}
                                        </h4>
                                        @if (!empty($option))
                                        <!-- Checkboxes -->
                                        @foreach ($option as $optionValue)
                                        <div class="form-group d-flex align-items-center justify-content-between mb-2 pb-1">
                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" class="custom-control-input optionChoose" id="option_{{$optionValue}}" name="option_{{$optionName}}_[]" onClick="filterItem()"
                                                value="{{ $optionValue }}" 
                                                @if(in_array($optionValue,$filtersData['options'])) checked @endif>
                                                <label class="custom-control-label" for="option_{{$optionValue}}">
                                                    {{optIdToName($optionValue)}}
                                                </label>
                                            </div>
                                        </div>
                                        @endforeach
                                        @endif
                                    </div>
                                @endforeach
                            @endif<!-- Options End -->
                        </div>
                    @endif
                    <x-Ecom03.SharedComponent.LatestProduct  /> 
                </div>
            @endif
            <div class="col-xl-9 col-wd-9gdot5">
                <!-- Shop-control-bar Title -->
                <div class="flex-center-between mb-3">
                    @if(!empty($sideFilter['cat_details']->category_name))
                        <h3 class="font-size-25 mb-0">
                            {{$sideFilter['cat_details']->category_name}}
                        </h3>
                    @endif
                    <span>
                        @php
                            $item =  $products->total() ?? 1 ;
                            $data  = translation('PAGINATION_TOTAL_ITEM');
                            printf($data, $item);
                        @endphp
                    </span>
                </div>
                <!-- End shop-control-bar Title -->
                <!-- Shop-control-bar -->
                <div class="bg-gray-1 flex-center-between borders-radius-9 py-1">
                    <div class="d-xl-none">
                        <!-- Account Sidebar Toggle Button -->
                        <a id="sidebarNavToggler1" class="btn btn-sm py-1 font-weight-normal" href="javascript:;" role="button"
                            aria-controls="sidebarContent1"
                            aria-haspopup="true"
                            aria-expanded="false"
                            data-unfold-event="click"
                            data-unfold-hide-on-scroll="false"
                            data-unfold-target="#sidebarContent1"
                            data-unfold-type="css-animation"
                            data-unfold-animation-in="fadeInLeft"
                            data-unfold-animation-out="fadeOutLeft"
                            data-unfold-duration="500">
                            <i class="fas fa-sliders-h"></i> <span class="ml-1">{{ translation('FILTER') }}</span>
                        </a>
                        <!-- End Account Sidebar Toggle Button -->
                    </div>
                    <div class="px-3 d-none d-xl-block">
                        <ul class="nav nav-tab-shop" id="pills-tab" role="tablist">
                        
                            <li class="nav-item">
                                <a class="nav-link active" id="pills-two-example1-tab" data-toggle="pill" href="#pills-two-example1" role="tab" aria-controls="pills-two-example1" aria-selected="false">
                                    <div class="d-md-flex justify-content-md-center align-items-md-center">
                                        <i class="fa fa-align-justify"></i>
                                    </div>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="pills-three-example1-tab" data-toggle="pill" href="#pills-three-example1" role="tab" aria-controls="pills-three-example1" aria-selected="true">
                                    <div class="d-md-flex justify-content-md-center align-items-md-center">
                                        <i class="fa fa-list"></i>
                                    </div>
                                </a>
                            </li>
                        
                        </ul>
                    </div>
                    <div class="d-flex"> 
                        @if (in_array(config('constkey.sidebar_filter'), $cKey))
                            <!-- Select -->
                            <span class=""> 
                            <select class="js-select selectpicker dropdown-select max-width-200 max-width-160-sm right-dropdown-0 px-2 px-xl-0 filter_style" name="sortBy"  id="sortBy" 
                                data-style="btn-sm bg-white font-weight-normal py-2 border text-gray-20 bg-lg-down-transparent border-lg-down-0" onChange="filterItem()">
                                <option value=""  @if($filtersData['sortBy']==null) 
                                selected  @endif>{{ translation('FILTER') }}</option>
                                <option value="latest" @if($filtersData['sortBy']=='latest') selected @endif>{{ translation('SORT_BY_LATEST') }}</option>
                                <option value="pricemintohigh" @if($filtersData['sortBy']=='pricemintohigh') selected @endif>{{ translation('PRICE_MIN_TO_MAX') }}</option>
                                <option value="pricehightomin" @if($filtersData['sortBy']=='pricehightomin') selected @endif>{{ translation('PRICE_MAX_TO_MIN') }}</option>
                                <option value="instock" @if($filtersData['sortBy']=='instock') selected @endif>{{ translation('IN_STOCK') }}</option>
                            </select>
                            </span>
                            <!-- End Select -->
                        @endif

                        @if (in_array(config('constkey.listing_pagination'), $cKey))
                        <span class="ml-2 d-none d-xl-block">
                            <!-- Select -->
                            <select class="js-select selectpicker dropdown-select max-width-120 filter_style"
                                data-style="btn-sm bg-white font-weight-normal py-2 border text-gray-20 bg-lg-down-transparent border-lg-down-0" name="perPageItem" onChange="filterItem()">
                                <option value="20" @if($filtersData['perPageItem']==20) selected @endif>20</option>
                                <option value="40"  @if($filtersData['perPageItem']==40) selected @endif>40</option>
                                <option value="80" @if($filtersData['perPageItem']==80) selected @endif>80</option>
                                <option value="200" @if($filtersData['perPageItem']==200) selected @endif>200</option>
                            </select>
                            <!-- End Select -->
                        </apan>
                        @endif
                    </div>
                </div>
                <!-- End Shop-control-bar -->
                <!-- Shop Body -->
                <input style="display:none" type="checkbox" name="category" value='{{ $sideFilter['cat_details']->categories_id }}' checked />
                <!-- Tab Content -->
                <div class="tab-content filterProductData" id="pills-tabContent">
                    <div class="tab-pane fade pt-2 show active" id="pills-two-example1" role="tabpanel" aria-labelledby="pills-two-example1-tab" data-target-group="groups">
                        <ul class="row list-unstyled products-group no-gutters">
                            @if (!empty($products) && sizeof($products) > 0)
                                @foreach ($products as $product)
                                    {{-- Here htl code come from component with grid view --}}
                                    <x-ecom03.shared-component.product  viewtype="grid" :data="$product" />
                                @endforeach
                            @else
                                <img src="{{ LoadAssets('assets/images/EmptyImages/Wishlist-Empty.png') }}" class="rounded mx-auto d-block" width="286px" height="200px"
                                    onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                                    alt="{{ getSetting('site_title') }} Wishlist-Empty">
                                <p class="h4 text-center text-dark mt-3">
                                {{ translation('EMPTY_CATEGORY_PRODUCT_MSG') }} 
                                </p>
                                <div class="text-center my-3">
                                    <a href="{{ url('/') }}" class="btn btn-primary btn-lg btn-block" role="button"
                                        aria-pressed="true">{{ translation('CONTINUE_TO_SHOP') }}</a>
                                </div>
                            @endif
                        </ul>
                    </div>
                    <div class="tab-pane fade pt-2" id="pills-three-example1" role="tabpanel" aria-labelledby="pills-three-example1-tab" data-target-group="groups">
                        <ul class="d-block list-unstyled products-group prodcut-list-view">
                            @if (!empty($products) && sizeof($products) > 0)
                                @foreach ($products as $product)
                                    <x-ecom03.shared-component.product  :data="$product" viewtype="list"/>
                                @endforeach
                            @else
                                <img src="{{ LoadAssets('assets/images/EmptyImages/Wishlist-Empty.png') }}" class="rounded mx-auto d-block" width="286px" height="     200px" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" alt="{{ getSetting('site_title') }}     Wishlist-Empty">
                                <p class="h4 text-center text-dark mt-3">
                                {{ translation('EMPTY_CATEGORY_PRODUCT_MSG') }}
                                        
                                </p>
                                <div class="text-center my-3">
                                    <a href="{{ url('/') }}" class="btn btn-primary btn-lg btn-block" role="button" aria-pressed="true">{{ translation('CONTINUE_TO_SHOP') }}</a>
                                </div>
                            @endif
                        </ul>
                    </div>
                </div>
                <!-- End Tab Content -->

                <!----------- Mobile view sidebar filter & brands --------------->
                @if (in_array(config('constkey.sidebar_filter'), $cKey))
                <!-- Sidebar Navigation -->
                    <aside id="sidebarContent1" class="u-sidebar u-sidebar--left" aria-labelledby="sidebarNavToggler1">
                        <div class="u-sidebar__scroller">
                            <div class="u-sidebar__container">
                                <div class="">
                                    <!-- Toggle Button -->
                                    <div class="d-flex align-items-center pt-3 px-4 bg-white">
                                        <button type="button" class="close ml-auto"
                                            aria-controls="sidebarContent1"
                                            aria-haspopup="true"
                                            aria-expanded="false"
                                            data-unfold-event="click"
                                            data-unfold-hide-on-scroll="false"
                                            data-unfold-target="#sidebarContent1"
                                            data-unfold-type="css-animation"
                                            data-unfold-animation-in="fadeInLeft"
                                            data-unfold-animation-out="fadeOutLeft"
                                            data-unfold-duration="500">
                                            <span aria-hidden="true"><i class="ec ec-close-remove"></i></span>
                                        </button>
                                    </div>
                                    <!-- End Toggle Button -->
                    
                                    <!-- Content -->
                                    <div class="js-scrollbar u-sidebar__body">
                                        <div class="u-sidebar__content u-header-sidebar__content px-4">
                                            <div class="mb-6">
                                                <div class="border-bottom border-color-1 mb-5">
                                                    <h3 class="section-title section-title__sm mb-0 pb-2 font-size-18">{{ translation('PRODUCT_FILTER_BY') }}</h3>
                                                </div>
                                                @if (!empty($brandArray) && sizeof($brandArray)>0)
                                                <div class="border-bottom pb-4 mb-4">
                                                    <h4 class="font-size-14 mb-3 font-weight-bold">{{ translation('PRODUCT_BRAND')}}</h4>
                    
                                                    <!-- Checkboxes -->
                                                    @foreach ($brandArray as $brands)
                                                    <div class="form-group d-flex align-items-center justify-content-between mb-2 pb-1">
                                                        <div class="custom-control custom-checkbox">
                                                            <input type="checkbox" name="choosenBrands[]"  class="custom-control-input" id={{$brands}} onClick="filterItem()" value='{{ $brands}}' @if(in_array($brands,$filtersData['brands'])) checked @endif >
                                                            <label class="custom-control-label" for="{{$brands}}"> 
                                                                {{ brandIDtoName($brands)}}
                                                            </label>
                                                            <span class="checkmark"></span>
                                                        </div>
                                                    </div>
                                                    @endforeach
                                                    <!-- End Checkboxes -->
                                                </div>
                                                @endif
                                                @if (!empty($productAttributes))
                                                    @foreach ($productAttributes as $optionName=>$option)
                                                        <div class="border-bottom pb-4 mb-4">
                                                            <h4 class="font-size-14 mb-3 font-weight-bold">{{$optionName ?? '' }}</h4>
                                                            <!-- Checkboxes -->
                                                            @if (!empty($option))
                                                                @foreach ($option as $optionValue)
                                                                    <div class="form-group d-flex align-items-center justify-content-between mb-2 pb-1">
                                                                        <div class="custom-control custom-checkbox">
                                                                            <input type="checkbox" class="custom-control-input optionChoose" id="option_{{$optionValue}}" name="option_{{$optionName}}_[]" onClick="filterItem()"
                                                                            value="{{ $optionValue }}" 
                                                                            @if(in_array($optionValue,$filtersData['options'])) checked @endif>
                                                                            <label class="custom-control-label" for="option_{{$optionValue}}">
                                                                                {{optIdToName($optionValue)}}
                                                                            </label>
                                                                        </div>
                                                                    </div>
                                                                @endforeach
                                                            @endif
                                                            <!-- End Checkboxes -->
                                                        </div>
                                                    @endforeach
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Content -->
                                </div>
                            </div>
                        </div>
                    </aside>
                <!-- End Sidebar Navigation -->
                @endif 
                <!-----------End Mobile view sidebar filter & brands --------------->

                <!-- End Shop Body -->
                <input style="display:none" type="text" name="page" id="page" value="" />
                <input style="display:none" type="text" name="options" id="options" value="" />
                <input style="display:none" type="text" name="brands" id="brands" value="" />
                
                <!-- Shop Pagination -->
                <input type="hidden" id="nextPage" value="1">
                    {{ $products->links('vendor.pagination.theme3Pagination') }}
                <!-- End Shop Pagination -->
            </div>
        </div>
        <button type="submit" hidden id="filterFormButton"></button>
    </form>
     <!-- Brand Carousel -->
     <x-Ecom03.SharedComponent.BrandSlider />
     <!-- End Brand Carousel -->
</div>
@push('scripts')
{{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> --}}
<script>
    //  const optionList = {{ Illuminate\Support\Js:: from($sideFilter['cat_details'] -> options) }};
     const optionList = {{ Illuminate\Support\Js:: from($productAttributes) }};
    function filterItem(currentpage = 0) {
        var count = 0;
        for (const key in optionList) {
            count++;
        }
        $("html").scrollTop(0);
        var ChoosenAttributes = [];
        var brands = [];

        let brandHtml = $('input[name="choosenBrands[]"]:checked');
        if (brandHtml.length > 0) {
            brandHtml.each((label, data) => {
                brands.push(data.value);
            });
        }
        if (count > 0) {
            var i=0;
            for (const key in optionList) {
                let options = [];
                let optionHtml = $(`input[name="option_${key}_[]"]:checked`);
                if (optionHtml.length > 0) {
                    optionHtml.each((label, data) => {
                        options.push(data.value);
                    });
                }
                ChoosenAttributes[i] = options;
                i++;
            }
        }
        console.log( ChoosenAttributes);
        $('#page').val($('#nextPage').val());
        $('#options').val(ChoosenAttributes.toString());
        $('#brands').val(brands.toString());
        $("#filterForm").submit();
    }
</script>
@endpush




