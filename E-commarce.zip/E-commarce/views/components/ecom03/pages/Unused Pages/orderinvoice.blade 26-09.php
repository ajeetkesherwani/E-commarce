<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        @import url(https://fonts.googleapis.com/css?family=Nunito:300,400,500,600,700&display=swap);

        tr {
            border-color: #e9ecef;
        }

        .invoice_wrapper table {
?            line-height: 24px;
        }

        a {
            text-decoration: none;
            /* color: #8492a6 */
            color: #000
        }

        .text-muted,
        svg {
            color: #000
        }

        .invoice_wrapper table tr td {
            padding: 1px;
        }



        h5 {
            font-size: 1.25rem;
            margin-top: 0;
            margin-bottom: .5rem;
            color: #000;
            font-weight: 600;
        }

        h6 {
            margin: 0
        }

        table th {
            font-weight: 400;
            text-align: left;
            color: #000;
            font-weight: 700;
        }

        .invoice_table th {

            padding: .5rem;
        }

        .address_section {
            border-bottom: 1px solid #e9ecef;
        }

        .address_section a {
            letter-spacing: 0.6px;
        }

        .address_section span {
            padding-right: 5px;
        }

        .table_border {
            border-bottom: 1px solid #e9ecef;
        }
    </style>
</head>

<body style="background-color: #F8F9FA; font-family: Nunito,sans-serif; font-size:16px">
    <div class="wrapper" style=" max-width: 800px; margin:auto;">
        <div class="invoice_wrapper">
            <table cellspacing="0" cellpadding="0"
                style="background-color:#fff; border-radius:6px;padding: 1.5rem 1rem;border:none;box-shadow:none;width:100%;">
                <tbody>
                    <tr valign="top">
                        <td style="border-bottom: 1px solid #e9ecef;padding-bottom: 14px;" colspan="5   ">
                            <table>
                                <tbody>
                                    <tr>
                                        <td>
                                            <img src="https://e-nnovation.net/backend/public/storage/12H68X91//media/website_logo/1659084043.png" height="24" alt="logo_img"
                                            onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"    
                                            style="margin-bottom: .5rem;"><br>

                                        </td>

                                    </tr>
                                    <tr>
                                        <td>
                                            <span align="left">
                                                <svg version="1.1" id="Layer_1" width="15" fill="#000" stroke="#000" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                                viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;padding-right: 4px; " xml:space="preserve">
                                           <g>
                                               <g>
                                                   <g>
                                                       <path d="M3.217,126.14L224.87,302.686c1.579,1.331,15.821,13.047,31.13,13.047c15.377,0,29.747-11.281,31.292-12.535
                                                           l221.5-177.067c2.031-1.621,3.208-4.07,3.208-6.664C512,95.94,492.86,76.8,469.333,76.8H42.667C19.14,76.8,0,95.94,0,119.467
                                                           C0,122.069,1.186,124.518,3.217,126.14z M42.667,93.867h426.667c12.8,0,23.441,9.446,25.31,21.726L276.599,289.894
                                                           c-3.038,2.44-12.672,8.772-20.599,8.772c-7.689,0-17.109-6.502-20.284-9.165L17.357,115.584
                                                           C19.234,103.305,29.867,93.867,42.667,93.867z"/>
                                                       <path d="M156.86,274.893L37.393,368.759c-3.703,2.91-4.343,8.277-1.434,11.981c1.681,2.142,4.181,3.26,6.707,3.26
                                                           c1.852,0,3.712-0.597,5.274-1.826l119.467-93.867c3.703-2.91,4.344-8.277,1.434-11.981
                                                           C165.931,272.614,160.563,271.983,156.86,274.893z"/>
                                                       <path d="M355.14,274.893c-3.703-2.91-9.071-2.27-11.981,1.434s-2.27,9.071,1.434,11.981l119.467,93.867
                                                           c1.562,1.229,3.422,1.826,5.265,1.826c2.526,0,5.035-1.118,6.716-3.26c2.91-3.703,2.27-9.071-1.434-11.981L355.14,274.893z"/>
                                                       <path d="M503.467,153.6c-4.71,0-8.533,3.823-8.533,8.533v230.4c0,14.114-11.486,25.6-25.6,25.6H42.667
                                                           c-14.114,0-25.6-11.486-25.6-25.6v-230.4c0-4.71-3.823-8.533-8.533-8.533S0,157.423,0,162.133v230.4
                                                           C0,416.06,19.14,435.2,42.667,435.2h426.667c23.526,0,42.667-19.14,42.667-42.667v-230.4
                                                           C512,157.423,508.177,153.6,503.467,153.6z"/>
                                                   </g>
                                               </g>
                                           </g>
                                           <g>
                                           </g>
                                           <g>
                                           </g>
                                           <g>
                                           </g>
                                           <g>
                                           </g>
                                           <g>
                                           </g>
                                           <g>
                                           </g>
                                           <g>
                                           </g>
                                           <g>
                                           </g>
                                           <g>
                                           </g>
                                           <g>
                                           </g>
                                           <g>
                                           </g>
                                           <g>
                                           </g>
                                           <g>
                                           </g>
                                           <g>
                                           </g>
                                           <g>
                                           </g>
                                           </svg>
                                           
                                            </span>
                                            <a href="mailto:test@supportnanny.com"
                                                    class="text-muted">test@supportnanny.com
                                                </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>

                                            <span align="left">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                    class="feather feather-phone fea icon-sm" style="margin-top: 7px;padding-right: 4px;">
                                                    <path
                                                        d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z">
                                                    </path>
                                                </svg>
                                            </span>
                                            <a href="tel:+152534-468-854" class="text-muted"
                                                style="padding-bottom:1rem">(+45) 4584-458-695</a>

                                        </td>
                                    </tr>

                                </tbody>
                            </table>
                        </td>

                        <td valign="top" class="address_section">
                            <table>
                                <tbody>
                                    <tr>
                                        <td>
                                            <span>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15"
                                                    viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                    class="feather feather-map-pin fea icon-sm" style="margin-top:6px">
                                                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                                                    <circle cx="12" cy="10" r="3"></circle>
                                                </svg></span>

                                                <a href=""> Ashok Bhawan,
                                                    <br>Nehru Place,<br>
                                                    Delhi India 110019
                                                </a>
                                            <!-- <a href=""> {{$orderdetails->address[1]['customer_name'] ?? ''}}
                                                <br>{{$orderdetails->address[1]['customer_address'] ?? ''}}<br>
                                                {{$orderdetails->address[1]['customer_city'] ?? ''}}<br>
                                                {{$orderdetails->address[1]['customer_state'] ?? ''}}<br>
                                                {{$orderdetails->address[1]['customer_country'] ?? ''}}<br>
                                                {{$orderdetails->address[1]['customer_postcode'] ?? ''}}<br>
                                                Email: {{$orderdetails->address[1]['customer_email'] ?? ''}}<br>
                                                Phone: {{$orderdetails->address[1]['customer_phone'] ?? ''}}
                                            </a> -->

                                        </td>

                                    </tr>


                                </tbody>
                            </table>
                        </td>
                    </tr>

                    <tr>

                        <td colspan="5" style=" padding-top: 1.5rem;">
                            <table style="text-align:left;width:100%">
                                <thead>
                                    <h6 style="font-size:16px"> Billing Adderss</h6>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <p>{{$orderdetails->address[0]['customer_name'] ?? ''}}<br>
                                               {{$orderdetails->address[0]['customer_address'] ?? ''}}<br>
                                               {{$orderdetails->address[0]['customer_city'] ?? ''}}<br>
                                               {{$orderdetails->address[1]['customer_state'] ?? ''}}<br>
                                                 {{$orderdetails->address[1]['customer_country'] ?? ''}}<br>
                                                {{$orderdetails->address[1]['customer_postcode'] ?? ''}}<br>
                                                <br>
                                                <a href="">Phone: {{$orderdetails->address[0]['customer_phone'] ?? ''}}</a>
                                                <br>
                                                <a href="">Email: {{$orderdetails->address[0]['customer_email'] ?? ''}}</a>
                                            </p>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                        <td>
                            <table>
                                <tbody>
                                    <tr>
                                        <td style="text-align:left;font-weight: 700;"> Invoice No. :</td>
                                        <td class="text-muted"> {{$orderdetails['order_number'] ?? ''}} </td>
                                    </tr>
                                    <tr>
                                        <td style="text-align:left;font-weight: 700;"> Date :</th>
                                        <td class="text-muted"> {{dateFormate($orderdetails['created_at'])}}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                    @if(!empty($orderdetails->item))
                    <tr>
                        <td colspan="5">
                            <table cellspacing="0px" cellpadding="2px" class="invoice_table"
                                style="border-radius:6px ;border:1px solid #e9ecef; margin:1rem 0; width:100%">
                                <thead>
                                    <tr class="heading  top_row ">
                                        <th class="table_border" style="width:20%; padding-left:16px">
                                        S.No.
                                        </th>
                                        <th class="table_border" style="width:20%; padding-left:16px">
                                        Item
                                        </th>
                                        <th class="table_border" style="width:20%; text-align:center;">
                                        Price
                                        </th>
                                        <th class="table_border" style="width:20%;text-align:right;padding-right:16px ">
                                        Qty
                                        </th>
                                        <th class="table_border" style="width:20%;text-align:right;padding-right:16px ">
                                        Total
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                  @foreach ($orderdetails->item as $key=>$item)
                                    <tr class="item">
                                        <td class="table_border" style="width:10%; padding:0.4rem 0 0.4rem 1rem">
                                        {{$key+1}}
                                        </td>
                                        <td class="table_border" style="width:30%; padding:0.4rem 0 0.4rem 1rem">
                                        {{$item->product->description[0]['products_name'] ?? ''}}
                                          @if(!empty($orderdetails['attrOptArray']))
                                            @foreach($orderdetails['attrOptArray'][$item->product->product_id] as $attsubarr)
                                            @foreach($attsubarr as $attrkey=>$attrVal)
                                                <p>{{$attrkey}} : {{$attrVal}}</p>
                                            @endforeach
                                            @endforeach
                                          @endif
                                        </td>
                                        <td class="table_border" style="width:20%;text-align:center ">
                                        {{currencyFormat($orderdetails['sub_total']/$item['qty'] ?? '')}}
                                        </td>
                                        <td class="table_border " style="width:10%;text-align:center ">
                                        {{$item['qty'] ?? ''}}
                                        </td>
                                        <td class="table_border" style="width:20%; text-align:right;padding-right:16px">
                                        {{currencyFormat($orderdetails['sub_total']) ?? ''}}
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </td>
                    </tr>
                    @endif
                    <tr>
                        <td></td>
                        <td colspan="4">
                            <table cellspacing="0px" cellpadding="2px" style="float: right; width:70%">
                                <tbody>

                                    <tr class="text-muted" style="text-align:right">
                                        <td style="text-align:left"> Subtotal :</th>
                                        <td>{{ currencyFormat($orderdetails['sub_total']) ??''}}</td>
                                    </tr>
                                    <tr class="text-muted" style="text-align:right">
                                        <td style="text-align:left"> Discount :</th>
                                        <td>{{ currencyFormat($orderdetails['discount_total']) ?? ''}}</td>
                                    </tr>
                                    <tr class="text-muted" style="text-align:right">
                                        <td style="text-align:left"> Shipping Charge :</th>
                                        <td>{{ currencyFormat($orderdetails['shipping_total']) ?? ''}}0</td>
                                    </tr>
                                    <tr class="text-muted" style="text-align:right">
                                        <td style="text-align:left"> Tax Amount :</th>
                                        <td>{{ currencyFormat($orderdetails['tax_amount']) ?? ''}}</td>
                                    </tr>
                                    <tr style="text-align:right">
                                        <td style="text-align:left;font-weight: 700;"> Total :</th>
                                        <td>{{ currencyFormat($orderdetails['grand_total']) ?? ''}}</td>
                                    </tr>

                                </tbody>
                            </table>


                        </td>
                    </tr>

                    <tr class="invoice_footer">
                        <td colspan="5" style="border-top: 1px solid #e9ecef;padding-top:14px">
                            <a href="" style="font-size:16px;font-weight:700; ">Terms &amp; Conditions</a>

                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</body>

</html>