@php
$main_arr = [
'title'=>'',
'sublist' => [
[
'name'=>translation('HOME'),
'link'=>url("/")
],
[
'name'=>translation( 'SEARCH_RESULT' ) .'   '.  $searchQuery,
'link'=>url()->full()
],
]
];
@endphp

<!-- Breadcrumb Area Start -->
<x-Ecom03.SharedComponent.BreadCrumb :data="$main_arr" />
<!-- Breadcrumb Area End -->

<!-- Shop Category Area End -->
<div class="shop-category-area">
    @if(!empty($product_count) )
    <div class="container">
        <form id="filterForm" action="{{url("/search/".urlencode($searchQuery))}}" method="get">
            <input type="hidden" name="filter">
            <div class="row mb-5">
                <div class="col-lg-12 order-lg-last col-md-12 order-md-first">
                    <!-- Shop Top Area Start -->
                    <div class="bg-gray-1 flex-center-between borders-radius-9 py-1">
                    <div class="d-xl-none">
                        <!-- Account Sidebar Toggle Button -->
                        <a id="sidebarNavToggler1" class="btn btn-sm py-1 font-weight-normal" href="javascript:;" role="button"
                            aria-controls="sidebarContent1"
                            aria-haspopup="true"
                            aria-expanded="false"
                            data-unfold-event="click"
                            data-unfold-hide-on-scroll="false"
                            data-unfold-target="#sidebarContent1"
                            data-unfold-type="css-animation"
                            data-unfold-animation-in="fadeInLeft"
                            data-unfold-animation-out="fadeOutLeft"
                            data-unfold-duration="500">
                            <i class="fas fa-sliders-h"></i> <span class="ml-1">{{translation('FILTER')}}</span>
                        </a>
                        <!-- End Account Sidebar Toggle Button -->
                    </div>
                    <div class="px-3 d-none d-xl-block">
                        <ul class="nav nav-tab-shop" id="pills-tab" role="tablist">
                        
                            <li class="nav-item">
                                <a class="nav-link active" id="pills-two-example1-tab" data-toggle="pill" href="#pills-two-example1" role="tab" aria-controls="pills-two-example1" aria-selected="false">
                                    <div class="d-md-flex justify-content-md-center align-items-md-center">
                                        <i class="fa fa-align-justify"></i>
                                    </div>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="pills-three-example1-tab" data-toggle="pill" href="#pills-three-example1" role="tab" aria-controls="pills-three-example1" aria-selected="true">
                                    <div class="d-md-flex justify-content-md-center align-items-md-center">
                                        <i class="fa fa-list"></i>
                                    </div>
                                </a>
                            </li>
                        </ul>
                    </div>

                    <div class="d-flex">
                        @if(!empty($product_count))
                            <span class="mt-2 mr-3">
                                @php
                                    $item =  $product_count ?? 1 ;
                                    $data  = translation('PAGINATION_TOTAL_ITEM');
                                    printf($data, $item);
                                @endphp
                            </span>
                        @endif
                        <!-- Select -->
                        <select class="js-select selectpicker dropdown-select max-width-200 max-width-160-sm right-dropdown-0 px-2 px-xl-0 filter_style" name="sortBy"
                            data-style="btn-sm bg-white font-weight-normal py-2 border text-gray-20 bg-lg-down-transparent border-lg-down-0" id="sortBy" onChange="filterItem()">
                            <option value="" @if($filtersData['sortBy']==null) 
                            selected  @endif>{{ translation('FILTER') }}</option>
                            <option value="latest" @if($filtersData['sortBy']=='latest') 
                            selected  @endif>{{ translation('SORT_BY_LATEST') }}</option>
                            <option value="pricemintohigh" @if($filtersData['sortBy']=='pricemintohigh') 
                            selected  @endif>{{ translation('PRICE_MIN_TO_MAX') }}</option>
                            <option value="pricehightomin" @if($filtersData['sortBy']=='pricehightomin') 
                            selected  @endif>{{ translation('PRICE_MAX_TO_MIN') }}</option>
                            <option value="instock" @if($filtersData['sortBy']=='instock') 
                            selected  @endif>{{ translation('IN_STOCK') }}</option>
                        </select>
                        <!-- End Select -->
                        <input type="hidden" name="searchQuery" value="{{$searchQuery}}" id="searchQuery">
                        <span class="d-none d-xl-block">
                            <!-- Select -->
                            <select class="js-select selectpicker dropdown-select max-width-120 filter_style"
                                data-style="btn-sm bg-white font-weight-normal py-2 border text-gray-20 bg-lg-down-transparent border-lg-down-0" name="perPageItem"  onChange="filterItem()">
                                <option value="20" @if($filtersData['perPageItem']==10) selected @endif>20</option>
                                <option value="40" @if($filtersData['perPageItem']==40) selected @endif>40</option>
                                <option value="80" @if($filtersData['perPageItem']==80) selected @endif>80</option>
                                <option value="200" @if($filtersData['perPageItem']==200) selected @endif>200</option>
                            </select>
                            <!-- End Select -->
                        </span>
                    </div>
                </div><!-- Shop Top Area End -->

                    <!-- Shop Bottom Area Start -->
                    <div class="shop-bottom-area mt-35" id="filterProductData">
                        <!-- Shop Tab Content Start -->
                        <div class="tab-content filterProductData" id="pills-tabContent">
                            <!-- Tab One Start -->
                            <div class="tab-pane fade pt-2 show active" id="pills-two-example1" role="tabpanel" aria-labelledby="pills-two-example1-tab" data-target-group="groups">
                                    <ul class="row list-unstyled products-group no-gutters">
                                        @if(!empty($products) && sizeof($products)>0)
                                        @foreach($products as $product)
                                            {{-- Here htl code come from component with grid view --}}
                                                <x-ecom03.shared-component.product  viewtype="grid" :data="$product" />
                                            @endforeach
                                        @else
                                        <img src="{{ LoadAssets('assets/images/EmptyImages/Wishlist-Empty.png') }}"
                                            class="rounded mx-auto d-block" width="286px" height="200px"
                                            onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                                            alt="{{ getSetting('site_title') }} Wishlist-Empty">
                                        <p class="h4 text-center text-dark mt-3">
                                        {{translation('EMPTY_SEARCH_PRODUCT_MSG')}} .
                                        </p>
                                        <div class="text-center my-3">
                                            <a href="{{ url('/') }}" class="btn btn-primary btn-lg btn-block" role="button"
                                                aria-pressed="true">{{translation('CONTINUE_TO_SHOP')}}</a>
                                        </div>
                                        @endif
                                    </ul>
                                </div>
                            <!-- Tab One End -->
                            <!-- Tab Two Start -->
                            <div class="tab-pane fade pt-2" id="pills-three-example1" role="tabpanel" aria-labelledby="pills-three-example1-tab" data-target-group="groups">
                                <ul class="d-block list-unstyled products-group prodcut-list-view">
                                    @if(!empty($products) && sizeof($products)>0)
                                    @foreach($products as $product)
                                    {{-- Here htl code come from component with List view --}}
                                    <x-ecom03.shared-component.product  :data="$product" viewtype="list"/>
                                    @endforeach
                                    @else
                                    <img src="{{ LoadAssets('assets/images/EmptyImages/Wishlist-Empty.png') }}" class="rounded mx-auto d-block" width="286px" height="200px" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" alt="{{ getSetting('site_title') }}     Wishlist-Empty">
                                    <p class="h4 text-center text-dark mt-3">
                                    {{translation('EMPTY_SEARCH_PRODUCT_MSG')}}
                                    </p>
                                    <div class="text-center my-3">
                                        <a href="{{ url('/') }}" class="btn btn-primary btn-lg btn-block" role="button" aria-pressed="true">{{translation('CONTINUE_TO_SHOP')}}</a>
                                    </div>
                                    @endif
                                </ul>
                            </div><!-- Tab Two End -->
                        </div>
                        <!-- Shop Tab Content End -->
                       
                        <!-- Shop Pagination -->
                        <input style="display:none" type="text" name="page" id="page" value="" />
                        {{ $products->links('vendor.pagination.theme3Pagination') }}
                        <!-- Shop Bottom Area End -->
                    </div>
                </div>
            </div>
            <button type="submit" hidden id="filterFormButton"></button>
        </form>    
        <!-- Brand Carousel -->
        <x-Ecom03.SharedComponent.BrandSlider />
        <!-- End Brand Carousel -->
    </div>
    @else
        <img src="{{ LoadAssets('assets/images/EmptyImages/Cart-Empty.jpg')}}" 
        onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
        class="rounded mx-auto d-block" width="286px" height="200px" alt="{{getSetting('site_title')}} Search-Empty">
        <p class="h4 text-center text-dark mt-2">
        {{translation('EMPTY_SEARCH_PRODUCT_MSG')}}
        </p>
        <div class="text-center my-3">
            <a href="{{url('/')}}" class="btn btn-primary btn-lg btn-block" role="button" aria-pressed="true">
            {{translation('CONTINUE_TO_SHOP')}}
            </a>
        </div>
    @endif
</div>
@push('scripts')
<script>
function filterItem(){
    $("html").scrollTop(0);
    $('#page').val($('#nextPage').val());
    $("#filterForm").submit();
    }
</script>
@endpush

