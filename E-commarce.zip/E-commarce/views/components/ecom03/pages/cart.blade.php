@php
$main_arr = [
    'title' => '',
    'sublist' => [
        [
            'name' =>translation('HOME'),
            'link' => url('/'),
        ],
        [
            'name' =>translation('CART'),
            'link' => url()->full()
        ],
    ],
];
@endphp

<!-- Breadcrumb Area start -->
<x-Ecom03.SharedComponent.BreadCrumb :data="$main_arr" /> 
<!-- Breadcrumb Area End -->

<!-- ========== MAIN CONTENT ========== -->
    <main  role="main"  >
      @if (!empty($list['cart_list']) && sizeof($list['cart_list']) > 0)
        <div class="container cart-page">
            <div class="row align-items-center cart-wrapper-border pb-3 button-row">
                <div class="col-lg-6 col-sm-12 pl-md-0">
                    <h5 class="mb-0">
                    {{translation('CART_TITLE')}} 
                    </h5>
                </div>
                 <div class="col-lg-6 col-sm-12 text-right pr-md-0">
                    <a href="{{ url('/') }}" class="btn btn-soft-secondary mb-3 mb-md-0 font-weight-normal px-5 px-md-4 px-lg-5 w-100 w-md-auto">{{ translation('CONTINUE_TO_SHOP') }}</a>
                </div>
            </div>
            <span class="">
                <div class="row mb-6">
                  
                     <div class="cart-table col-lg-8 col-sm-12 mb-3 mb-md-0 w-xl-40">
                        <form class="mb-4" action="#">
                            <table class="table" cellspacing="0">
                                <thead>
                                    <tr class="border-bottom">
                                        
                                        <th class="product-name">{{ translation('CART_PRODUCT_IMAGE') }}</th>
                                        <th class="product-thumbnail" style="width:350px;">&nbsp;</th>
                                        <th class="product-price" style="width:150px; text-align:center">{{ translation('CART_PRODUCT_UNIT_PRICE') }}</th>
                                        <th class="product-quantity text-center" style="width:200px; text-align:center">{{ translation('CART_PRODUCT_QUANTITY') }}</th>
                                        <th class="product-subtotal text-center" style="width:120px;">{{ translation('CART_SUBTOTAL') }}</th>
                                        <th class="product-remove">&nbsp;</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @if (!empty($list['cart_list']))
                                        @foreach ($list['cart_list'] as $cart)
                                        <tr class="peticularRow" id="cart-table_{{$cart->cart_id}}"
                                            @if($cart->product->products_prices!=null)
                                                value="{{count($cart->product->products_prices)}}"
                                            @else 
                                                value="0"
                                            @endif
                                            >
                                            <td class="d-md-table-cell">
                                                <a href="{{ url('product/' . $cart->product->product_slug) }}">
                                                    <img class="img-fluid max-width-100" src="{{ getFullImageUrl($cart->product->product_image) }}" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" alt="{{ $cart->product->products_name ?? '' }}" height="50">
                                                </a>
                                            </td>
                                            <td data-title="Product">
                                                <a href="{{ url('product/' . $cart->product->product_slug) }}" class="text-gray-90">
                                                    {{ $cart->product->products_name ?? '' }}
                                                </a>
                                                @if (isset($cart->attributes) && !empty($cart->attributes))
                                                <div>
                                                    @foreach ($cart->attributes as $attribute)
                                                        @if (isset($attribute->product_options))
                                                            <span>{{ $attribute->product_options->products_options_name }} : {{ $attribute->products_options_values_name }}
                                                            </span><br />
                                                        @endif
                                                    @endforeach
                                                </div>
                                            @endif
                                            </td>
                                            <td data-title="Price" class="text-center">
                                                <span class="prd_prc__{{$cart->cart_id}}">
                                                    {{ currencyFormat($cart->final_price ?? 0) }}
                                                </span>
                                            </td>
                                            @if($cart->product->products_prices !=null)
                                                <input type="hidden" id="holesale_price" value="{{count($cart->product->products_prices)}}">
                                            @endif
                                            <td data-title="Quantity">
                                                <span class="sr-only">{{ translation('CART_SUBTOTAL') }}</span>
                                                <!-- Quantity -->
                                                <div class="border rounded-pill py-1 px-3 border-color-1">
                                                    <div class="js-quantity d-flex align-items-center">
                                                            <input class="js-result form-control h-auto border-0 rounded p-0 shadow-none crt" data-cart="{{ $cart->cart_id }}" id="{{ $cart->cart_id }}_qty" type="number" name="qtybutton" value="{{ $cart->qty }}" min="1" step=1 onblur="qtyItm({{$cart->cart_id}})">
                                                        <div class="d-flex " data-cart="{{$cart->cart_id }}">
                                                            <a class="js-minus btn btn-icon btn-xs btn-outline-secondary rounded-circle border-0 cartqtybutton" href="javascript:;" id="Js_minus">
                                                                <small class="fas fa-minus btn-icon__inner"></small>
                                                            </a>
                                                            <a class="js-plus btn btn-icon btn-xs btn-outline-secondary rounded-circle border-0 cartqtybutton" href="javascript:;" >
                                                                <small class="fas fa-plus btn-icon__inner"></small>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End Quantity -->
                                            </td>
                                            <td data-title="Total" class="text-center">
                                                <span class="total_price_{{$cart->cart_id}}">
                                                @php
                                                    $qty = (int) $cart->qty;
                                                    $price = $cart->final_price ?? 0;
                                                    echo currencyFormat($qty * $price);
                                                @endphp
                                                </span>
                                            </td>
                                            <td class="text-center">
                                                <a href="javascript:void(0)" data-id="{{$cart->cart_id}}" onclick="actionOnCart({{$cart->cart_id }},'del')" class="text-gray-32 font-size-26">×</a>
                                            </td>
                                        </tr>
                                        @if($cart->product->products_prices !=null)
                                           <input type="hidden"  class="minordqty"  id="{{ $cart->cart_id }}_min_qty" value="{{$cart->product->products_prices->min('product_qty')}}">
                                           <input type="hidden"  class="ordqty"   id="{{ $cart->cart_id }}_ord_qty"  value="{{$cart->qty}}">
                                        @endif
                                        @endforeach
                                    @endif
                                </tbody>
                            </table>
                        </form>
                    </div>
                    <div class="col-lg-3 col-sm-12  cart-total offset-md-1">
                        <div class="border-bottom border-color-1">
                            <h4 class="d-inline-block section-title mb-0 py-2">{{ translation('CART_TOTAL') }}</h4>
                        </div>
                        <table class="table mb-3 mb-md-0">
                            <tbody>
                                <tr class="order-total border-0">
                                    <th class="px-0 py-3">{{translation('CART_TOTAL')}}</th>
                                    <td data-title="Total" class="px-0 py-3">
                                        <strong>
                                            <span class="amount grandAmount">
                                                {{ currencyFormat($list['product_total'])}}
                                            </span>
                                        </strong>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <button type="button" class="btn btn-primary-dark-w px-5 w-100 w-md-auto mt-2"><a href="{{ url('checkout') }}" class="text-white">{{ translation('PROCEED_CHECKOUT') }}</a></button>
                    </div>
                </div>
                
            </span>
        
        </div>
        @else
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-4 mx-auto">
                    <img src="{{ LoadAssets('assets/img/EmptyImages/Cart-Empty.jpg')}}" 
                    onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                    class="rounded mx-auto d-block mb-5" height="200px" alt="{{getSetting('site_title')}} Wishlist-Empty">
                        <p class="h4 text-center text-dark mt-3">{{ translation('EMPTY_CART_MSG') }}</p>
                        <div class="text-center my-3 mb-5">
                        <a href="{{url('/')}}" class="btn btn-primary  btn-sm" role="button" aria-pressed="true">{{ translation('CONTINUE_TO_SHOP') }}</a>
                </div>
            </div>
        </div>
        @endif
        <div class="container">
            <!-- Brand Carousel -->
            <x-Ecom03.SharedComponent.BrandSlider />
            <!-- End Brand Carousel -->
        </div>
    </main>
<!-- ========== END MAIN CONTENT ========== -->




<!-- script start here -->
@push('scripts')
    <script>
        // initialization of quantity counter
        $.HSCore.components.HSQantityCounter.init('.js-quantity');

        $(document).on("click", ".cartqtybutton", function() {
            let cart_id = $(this).parent().parent().find('input').data('cart');
            var min_ord_qty = $(`#${cart_id}_min_qty`).val();
            var ord_qty=$(`#${cart_id}_ord_qty`).val();
            var qty = $(`#${cart_id}_qty`).val();
        
            if(min_ord_qty !='undefined')
            {   
                if(Number(qty)<Number(min_ord_qty))
                {   
                    Notify(`Please Add minimum ${min_ord_qty} Qty.`, false);
                    // $('#Js_minus').removeClass('js-minus');
                    $(`#${cart_id}_qty`).val(ord_qty);
                }
                else
                {
                    actionOnCart(cart_id, 'add'); 
                }
            }else{
                actionOnCart(cart_id, 'add');
            }
        });
        function actionOnCart(cart_id, type) {
            var qty = $(`#${cart_id}_qty`).val();
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url: '{{ route('incDecDelCart') }}',
                method: 'POST',
                data: {
                    cart_id: cart_id,
                    qty: qty,
                    type: type,
                },
                success: function(response) {
                    console.log(response)
                    if(response.cart_response.total_count > 0){
                        $(response.cart_response.cart_list).each(function(key,value) {
                            $('.product_total').text(response.cart_response.products_total);
                            $('.grandAmount').text(response.cart_response.grand_totals);
                            $('.count-cart-total').text(response.cart_response.total_count);
                            if(cart_id==value.cart_id){
                                $('.prd_prc__'+value.cart_id).text(value.fin_price);
                                $('.total_price_'+value.cart_id).text(value.total);
                                $('.quantity_'+value.product_id).text(value.qty);
                            } 
                        });  
                    } else{
                            $('.count-cart-total').text(response.cart_response.total_count);
                      var html = `<div class="container">
                                <div class="row">
                                    <div class="col-12 col-lg-4 mx-auto">
                                        <img src="{{ LoadAssets('assets/img/EmptyImages/Cart-Empty.jpg')}}"  onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" class="rounded mx-auto d-block mb-5" height="200px" alt="{{getSetting('site_title')}} Wishlist-Empty">
                                        <p class="h4 text-center text-dark mt-3">{{ translation('EMPTY_CART_MSG') }}</p>
                                        <div class="text-center my-3 mb-5">
                                        <a href="{{url('/')}}" class="btn btn-primary  btn-sm" role="button" aria-pressed="true">{{ translation('CONTINUE_TO_SHOP') }}</a>
                                    </div>
                                </div>
                            </div>`;
                        $('.cart-page').html(html);
                        // $('.CartModal').html(html);
                        $('.button-row').remove();
                    } 
                    $('.count-cart-total').html(response.cart_response.total_count);

                    var msg = type === 'del' ? '{{translation('CART_ITEM_REMOVED_MSG')}}!' : '{{translation('CART_ITEM_UPDATE_MSG')}}!';
                    Notify(msg, true);
                    if(type === 'del'){
                        $('#cart-table_'+cart_id).hide();
                        $('.cartProduct_id_'+cart_id).hide();
                    }
                    // $.fn.qtyButton();
                },
                error: function(error) {
                    Notify('{{translation('ERROR_CART_ADD')}}', false);
                }
            });

        }
        function qtyItm(id) {
        var qtyItem = $('#'+id+'_qty').val();
        if (qtyItem < 1) {
        $('#'+id+'_qty').val('1');
        }
        // Validation for minimum qty of wholesale product  
        let cart_id = id;
        var min_ord_qty=$(`#${cart_id}_min_qty`).val();
        var ord_qty=$(`#${cart_id}_ord_qty`).val();
        var qty = $(`#${cart_id}_qty`).val();

        if(min_ord_qty !='undefined')
        {   
        if(qty<min_ord_qty)
        {
        $(`#${cart_id}_qty`).val(ord_qty);
        Notify(`Sorry !</strong> Please Add minimum ${min_ord_qty} Qty.`, false);
        }
        else
        {
        actionOnCart(cart_id, 'add'); 
        }
        }else{
        actionOnCart(cart_id, 'add');
        }
    }
    </script>
@endpush
<!-- script end here -->
