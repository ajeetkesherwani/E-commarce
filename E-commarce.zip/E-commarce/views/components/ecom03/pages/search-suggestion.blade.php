@if(!empty($categorys) && sizeof($categorys) > 0)
<b>{{translation('SEARCH_CATEGORY_TITLE')}}</b>
<ul>
	@foreach($categorys as $category)
		<li class="m-2">
			<a style="color: rgb(28, 26, 26);" href="{{ url('category/'.$category->categories_slug )  }}">{{ $category->category_name }}</a>
		</li>
	@endforeach
</ul>
<hr />
@endif

@if(!empty($products) && sizeof($products) > 0 )
<b>{{translation('SEARCH_PRODUCT_TITLE')}}</b>
<ul>
	@foreach($products as $product)
		<li class="m-2">
			<a style="color: rgb(28, 26, 26);" href="{{ url('product/'.$product->product_slug )  }}">{{ $product->products_name }}</a>
		</li>
	@endforeach
</ul>
@endif