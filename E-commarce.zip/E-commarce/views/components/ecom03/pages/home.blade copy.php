    <!-- ========== MAIN CONTENT ========== -->
    <main id="content" role="main">
        <!-- Slider Section -->
        @if(!empty($slider_data))
        <div class="mb-5">
            <div class="bg-img-hero" >
                <div class="min-height-420 overflow-hidden">
                    <div class="js-slick-carousel u-slick" data-pagi-classes="text-center position-absolute right-0 bottom-0 left-0 u-slick__pagination u-slick__pagination--long justify-content-center mb-3 col-lg-12 pl-2 pb-1">
                        @foreach($slider_data as $key=>$data)
                        <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <img class="d-block w-100" src="{{$data->image ?? $data->banners_title}}"">
                                </div>    
                            </div>
                            <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="sr-only">Previous</span>
                            </a>
                            <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
        @endif
        <!-- End Slider Section -->

        <div class="container">
        <!-- Website Feature Section -->
        @if(!empty($web_features))
        <div class="mb-5">
            <div class="row">
                @foreach($web_features as $key=>$feature_data)
                <div class="col-md-6 mb-4 mb-xl-0 col-xl-3">
                    <a href="#" class="d-black text-gray-90">
                        <div class="min-height-132 py-1 d-flex bg-gray-1 align-items-center">
                            <div class="col-6 col-xl-5 col-wd-6 pr-0">
                                <img class="img-fluid" src="{{getFullImageUrl($feature_data->feature_icon)}}" alt="{{getSetting('site_title')}} - {{$feature_data->feature_title}}"  onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"  >
                            </div>
                            <div class="col-6 col-xl-7 col-wd-6">
                                <div class="mb-2 pb-1 font-size-18 font-weight-light text-ls-n1 text-lh-23">
                                    {{$feature_data->feature_title}}
                                </div>
                                <div class="link text-gray-90 font-weight-bold font-size-15" >
                                    {{$feature_data->feature_subtitle}}
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                @endforeach
            </div>
        </div>
        @endif
        <!-- End of Website Feature-->
        
        @if(!empty($featureGroupList))
            <!-- Deals-and-tabs -->
            <div class="mb-5">
                <div class="row">

                    <!-- Deal -->
                    <div class="col-md-auto mb-6 mb-md-0">
                        <div class="p-3 border border-width-2 border-primary borders-radius-20 bg-white min-width-370">
                            <div class="d-flex justify-content-between align-items-center m-1 ml-2">
                                <h3 class="font-size-22 mb-0 font-weight-normal text-lh-28 max-width-120">Special Offer</h3>
                                <div class="d-flex align-items-center flex-column justify-content-center bg-primary rounded-pill height-75 width-75 text-lh-1">
                                    <span class="font-size-12">Save</span>
                                    <div class="font-size-20 font-weight-bold">$120</div>
                                </div>
                            </div>
                            <div class="mb-4">
                                <a href="" class="d-block text-center"><img class="img-fluid" src="https://e-nnovation.net/backend/public/storage/03H78P2W//product/104/1664441378.jpg" alt="Image Description" style="height:300px; width:300px;"></a>
                            </div>
                            <h5 class="mb-2 font-size-14 text-center mx-auto max-width-180 text-lh-18"><a href="#" class="text-blue font-weight-bold">Game Console Controller + USB 3.0 Cable</a></h5>
                            <div class="d-flex align-items-center justify-content-center mb-3">
                                <del class="font-size-18 mr-2 text-gray-2">$99,00</del>
                                <ins class="font-size-30 text-red text-decoration-none">$79,00</ins>
                            </div>
                            <div class="mb-3 mx-2">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <span class="">Availavle: <strong>6</strong></span>
                                    <span class="">Already Sold: <strong>28</strong></span>
                                </div>
                                <div class="rounded-pill bg-gray-3 height-20 position-relative">
                                    <span class="position-absolute left-0 top-0 bottom-0 rounded-pill w-30 bg-primary"></span>
                                </div>
                            </div>
                            <div class="mb-2">
                                <h6 class="font-size-15 text-gray-2 text-center mb-3">Hurry Up! Offer ends in:</h6>
                                <div class="js-countdown d-flex justify-content-center"
                                    data-end-date="2020/11/30"
                                    data-hours-format="%H"
                                    data-minutes-format="%M"
                                    data-seconds-format="%S">
                                    <div class="text-lh-1">
                                        <div class="text-gray-2 font-size-30 bg-gray-4 py-2 px-2 rounded-sm mb-2">
                                            <span class="js-cd-hours"></span>
                                        </div>
                                        <div class="text-gray-2 font-size-12 text-center">HOURS</div>
                                    </div>
                                    <div class="mx-1 pt-1 text-gray-2 font-size-24">:</div>
                                    <div class="text-lh-1">
                                        <div class="text-gray-2 font-size-30 bg-gray-4 py-2 px-2 rounded-sm mb-2">
                                            <span class="js-cd-minutes"></span>
                                        </div>
                                        <div class="text-gray-2 font-size-12 text-center">MINS</div>
                                    </div>
                                    <div class="mx-1 pt-1 text-gray-2 font-size-24">:</div>
                                    <div class="text-lh-1">
                                        <div class="text-gray-2 font-size-30 bg-gray-4 py-2 px-2 rounded-sm mb-2">
                                            <span class="js-cd-seconds"></span>
                                        </div>
                                        <div class="text-gray-2 font-size-12 text-center">SECS</div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="d-none p-3 border border-width-2 border-primary borders-radius-20 bg-white min-width-370">
                            <div class="d-flex justify-content-between align-items-center m-1 ml-2">
                                <div class="bg-gray-1 bg-animation rounded height-20 w-50"></div>
                                <div class="bg-gray-1 bg-animation u-lg-avatar rounded-circle"></div>
                            </div>
                            <div class="mb-4">
                                <div class="bg-gray-1 height-300"></div>
                            </div>
                            <div class="mb-4">
                                <div class="bg-gray-1 bg-animation rounded height-20 w-60 mx-auto mb-1"></div>
                                <div class="bg-gray-1 bg-animation rounded height-20 w-50 mx-auto"></div>
                            </div>
                            <div class="d-flex align-items-center justify-content-center mb-4">
                                <div class="bg-gray-1 bg-animation rounded height-12 w-20 ml-auto mr-2"></div>
                                <div class="bg-gray-1 bg-animation rounded height-20 w-30 mr-auto"></div>
                            </div>
                            <div class="mb-3 mx-2">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <div class="bg-gray-1 bg-animation rounded height-12 w-30"></div>
                                    <div class="bg-gray-1 bg-animation rounded height-12 w-30"></div>
                                </div>
                                <div class="rounded-pill bg-gray-1 height-20 position-relative">

                                </div>
                            </div>
                            <div class="mb-2">
                                <div class="bg-gray-1 bg-animation rounded height-12 w-60 mx-auto mb-3"></div>
                                <div class="d-flex justify-content-center">
                                    <div class="">
                                        <div class="u-avatar bg-gray-1 bg-animation rounded mb-1"></div>
                                        <div class="bg-gray-1 bg-animation rounded height-12 w-90 mx-auto"></div>
                                    </div>
                                    <div class="mx-1 pt-1 text-gray-1 font-size-24">:</div>
                                    <div class="">
                                        <div class="u-avatar bg-gray-1 bg-animation rounded mb-1"></div>
                                        <div class="bg-gray-1 bg-animation rounded height-12 w-90 mx-auto"></div>
                                    </div>
                                    <div class="mx-1 pt-1 text-gray-1 font-size-24">:</div>
                                    <div class="">
                                        <div class="u-avatar bg-gray-1 bg-animation rounded mb-1"></div>
                                        <div class="bg-gray-1 bg-animation rounded height-12 w-90 mx-auto"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Deal -->

                    <!-- Tab Prodcut -->
                    <div class="col">
                        <!-- Features Section -->
                        <div class="">
                            <!-- Nav Classic -->
                            <div class="position-relative bg-white text-center z-index-2">
                                <ul class="nav nav-classic nav-tab justify-content-center" id="pills-tab" role="tablist">
                                    @foreach($featureGroupList as $groupKey=>$featureGroup)
                                    @if(!empty($featureGroup->featured_product) && sizeof($featureGroup->featured_product) > 0 )
                                    <li class="nav-item">
                                        <a class="nav-link {{$groupKey==0 ? 'active':''}}" id="pills-two-example1-tab" data-toggle="pill" href="#{{ str_replace(' ','',$featureGroup->group_name) }}" role="tab" aria-controls="pills-two-example1" aria-selected="{{$groupKey==0 ? 'true':''}}">
                                            <div class="d-md-flex justify-content-md-center align-items-md-center">
                                                {{$featureGroup->group_name}}
                                            </div>
                                        </a>
                                    </li>
                                    @endif
                                    @endforeach
                                </ul>
                            </div>
                            <!-- End Nav Classic -->

                            <!-- Tab Content -->
                            <div class="tab-content" id="pills-tabContent">
                                @foreach($featureGroupList as $groupKey=>$featureGroup)
                                <div class="tab-pane fade pt-2 {{$groupKey==0 ? 'show active':''}}" role="tabpanel" id="{{ str_replace(' ','',$featureGroup->group_name) }}" aria-labelledby="pills-one-example1-tab">
                                    <ul class="row list-unstyled products-group no-gutters">
                                    @foreach ($featureGroup->featured_product as $featured_product )
                                    @if(!empty($featured_product->product))
                                    <x-ecom03.shared-component.product :data="$featured_product->product"  viewtype="grid"/>
                                    @endif
                                    @endforeach
                                    </ul>
                                </div>
                                @endforeach
                            </div>
                            <!-- End Tab Content -->
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Deals-and-tabs -->
            @endif
        </div>
        <!-- Full banner -->
        @if(!empty($home_page_middle_group_1))
        <div class="container">
            <div class="row">
                @if(!empty($home_page_middle_group_1))
                    @foreach($home_page_middle_group_1 as $home_page_middle_group_1_Val)
                        <div class="col-lg-{{$banner_group_size1}} col-md-{{$banner_group_size1}} col-sm-12 col-xs-12">
                            <div class="mb-6 text-center">
                                <a href="{{$home_page_middle_group_1_Val->banners_url}}">
                                    <img src="{{$home_page_middle_group_1_Val->image}}"
                                    onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="{{getSetting('site_title')}}-{{$home_page_middle_group_1_Val->banners_title}}" class="img-fluid"  />
                                </a>
                            </div>
                        </div>
                    @endforeach
                @endif
            </div>
        </div>
        @endif

        <div class="container">
            @if (!empty($popular_category) && sizeof($popular_category) > 0 )
                <div class="mb-5">
                    <div class="section-title mt-res-sx-30px mt-res-md-30px underline-shape">
                    <h2>{{ translation('POPULAR_CATEGORIES_TITLE') }}</h2>
                    <p>{{ translation('POPULAR_CATEGORIES_SUB_TITLE') }}</p>
                    </div>
                    <div class="row">
                    @foreach($popular_category as $key=>$value)
                    <div class="col-md-6 mb-4 mb-xl-0 col-xl-3">
                        <a href="{{ App\Models\Ecom\Services\EcomService::url($value->categories_id , 'category')}}" class="d-black text-gray-90">
                            <div class="min-height-132 py-1 d-flex bg-gray-1 align-items-center">
                                <div class="col-6 col-xl-5 col-wd-6 pr-0">
                                    <img class="img-fluid" src="{{getFullImageUrl($value->categories_image)}}"
                                    alt="{{$value->category_name ?? ''}}" 
                                    onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" />
                                </div>
                                <div class="col-6 col-xl-7 col-wd-6">
                                    <div class="mb-2 pb-1 font-size-18 font-weight-light text-ls-n1 text-lh-23">
                                        {{$value->category_name ?? ''}}
                                    </div>
                                    <div class="link text-gray-90 font-weight-bold font-size-15" href="{{url('category/'.$value->categories_slug)}}">
                                       {{translation('SHOP_NOW')}}
                                        <span class="link__icon ml-1">
                                            <span class="link__icon-inner"><i class="ec ec-arrow-right-categproes"></i></span>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                        @endforeach
                    </div>
                </div>
            @endif
        </div>

        <!-- End Products-4-1-4 -->
        <div class="container">
            <!-- End Recently viewed -->
        @if (!empty($blog) && sizeof($blog)>0 )
        <section class="blog-area mb-30px">
         <div class="container">
        <div class="row">
            <div class="col-md-12">
                <!-- Section title -->
                <div class="section-title underline-shape mt-50">
                    <h2>{{ translation('BLOG_TITLE') }}</h2>
                    <p>{{translation('BLOG_DESCRIPTION') }}</p>
                </div>
                <!-- Section title -->
            </div>
        </div>
        <div class="container mb-5">
            <div class="row">
                <div class="col-xl-12 col-wd">
                    <div class="max-width-1100-wd">
                        <div class="row">
                     <!-- Single Blogs -->
                     @foreach ($blog->take(3) as $blog)
                     <x-Ecom03.SharedComponent.PostGrid :data="$blog" />
                     @endforeach
                     <!-- Single Blogs  End -->
                    </div>
                </div>
            </div>    
        </div>
    </div>
            <!-- single item -->
</div>
</section>
@endif
    <!-- Brand Carousel -->
    <x-Ecom03.SharedComponent.BrandSlider />
    <!-- End Brand Carousel -->
</div>
</main>
<!-- ========== END MAIN CONTENT ========== -->

<!--Starting of Newslatter Modal-->
<div class="modal fade newsletter-popup1" id="onloadModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content  border-0">
            <div class="modal-body newsmodal p-0">
                <!-- Here Html Come From ajax -->
            </div>
        </div>
    </div>
</div>
<!--Ending of NewsLatter Modal-->


@push('scripts')
<script>
    $(document).ready(function () {
        $(document).on('click', '#modal_subscribe', function (e) {
            e.preventDefault();
            $('#newsltrModalForm').addClass('was-validated');
          if ($('#newsltrModalForm')[0].checkValidity() === false) {
                event.stopPropagation();
          } else {
            var data = {
                'customer_email': $('#customeremail').val(),
            }
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "/newslatterstore",
                data: data,
                dataType: "json",

                beforeSend: function() {
                $("#modal_subscribe").addClass('disabled');
                $("#modal_subscribe").html('Submitting...');
                },
                success: function (response) {
                    if (response.status == 400) {
                        $('#email_err').text(response.error.customer_email);
                    }
                    else {
                        $('#onloadModal').modal('hide');
                        Notify("{{translation('SUBSCRIBE_SUCCESS_MSG')}}", true);
                    }
                },
                complete: function() {
                $('#newsltrModalForm').removeClass('was-validated');
                $("#modal_subscribe").removeClass('disabled');
                $("#modal_subscribe").html('{{translation('SUBMIT')}}');
                }
            });
          }
        });  
    });

</script>
@endpush