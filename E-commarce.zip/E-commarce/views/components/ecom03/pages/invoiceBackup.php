<div class="checkout-area mtb-60px">
    <div class="container">
      <div class=" col-lg-12 col-md-12 col-sm-12 col-12 paddingg-1">
        <div class="cardd-1">
          <div class="card-headerr-1 p-4"> 
            <div class="float-right">
              <h3 class="mb-0">Invoice {{$orderdetails['order_number'] ?? ''}} </h3>
              Date: {{dateFormate($orderdetails['created_at'],getSetting('date_format'))}}</div>
          </div>
          <div class="card-body">
            <div class="row mb-4">
              <div class="col-sm-6">
                <h5 class="mb-3"> Billing Adderss </h5>
                <h3 class="text-darkk-1 mb-1">{{$orderdetails->address[0]['customer_name'] ?? ''}}</h3>
                <div>{{$orderdetails->address[0]['customer_address'] ?? ''}}</div>
                <div>{{$orderdetails->address[0]['customer_city'] ?? ''}} {{$orderdetails->address[1]['customer_state'] ?? ''}} {{$orderdetails->address[1]['customer_country'] ?? ''}} {{$orderdetails->address[1]['customer_postcode'] ?? ''}}</div>
                <div>Email: {{$orderdetails->address[0]['customer_email'] ?? ''}}</div>
                <div>Phone: {{$orderdetails->address[0]['customer_phone'] ?? ''}}</div>
              </div>
              <div class="col-sm-6 text-end">
                <h5 class="mb-3 "> Shiping Adderss</h5>
                <h3 class="text-darkk-1 mb-1">{{$orderdetails->address[1]['customer_name'] ?? ''}}</h3>
                <div>{{$orderdetails->address[1]['customer_address'] ?? ''}}</div>
                <div>{{$orderdetails->address[1]['customer_city'] ?? ''}} {{$orderdetails->address[1]['customer_state'] ?? ''}} {{$orderdetails->address[1]['customer_country'] ?? ''}} {{$orderdetails->address[1]['customer_postcode'] ?? ''}}</div>
                <div>Email: {{$orderdetails->address[1]['customer_email'] ?? ''}}</div>
                <div>Phone: {{$orderdetails->address[1]['customer_phone'] ?? ''}}</div>
              </div>
            </div>
            @if(!empty($orderdetails->item))

            <div class="table-responsive-sm">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th class="center">#</th>
                    <th>Item</th>
                    <th>Description</th>
                    <th class="right">Price</th>
                    <th class="center">Qty</th>
                    <th class="right">Total</th>
                  </tr>
                </thead>
                <tbody>
                  @foreach ($orderdetails->item as $item)
                    
                    <tr>
                      <td class="center">1</td>
                      <td class="left">{{$item->product->description[0]['products_name'] ?? ''}}</td>
                      <td class="left">{{$item->product->description[0]['products_description'] ?? ''}}</td>
                      <td class="right">{{currencyFormat($item['unit_price']) ?? ''}}</td>
                      <td class="center">{{$item['qty'] ?? ''}}</td>
                      <td class="right">{{currencyFormat($item['total_price']) ?? ''}}</td>
                    </tr>
                  @endforeach
                
                </tbody>
              </table>
            </div>
            @endif
            <div class="row">
              <div class="col-lg-9 col-sm-12"> </div>
              <div class="col-lg-3 col-sm-12 ml-auto">
                <table class="table table-clear">
                  <tbody>
                    <tr>
                      <td class="left"><strong class="text-darkk-1">Subtotal</strong></td>
                      <td class="right">{{ currencyFormat($orderdetails['sub_total']) ??''}}</td>
                    </tr>
                    <tr>
                      <td class="left"><strong class="text-darkk-1">Discount</strong></td>
                      <td class="right">{{ currencyFormat($orderdetails['discount_total']) ?? ''}}</td>
                    </tr>
                    <tr>
                        <td class="left"><strong class="text-darkk-1">Shipping Charge</strong></td>
                        <td class="right">{{ currencyFormat($orderdetails['shipping_total']) ?? ''}}</td>
                      </tr>
                      <tr>
                        <td class="left"><strong class="text-darkk-1">Tax Amount</strong></td>
                        <td class="right">{{ currencyFormat($orderdetails['tax_amount']) ?? ''}}</td>
                      </tr>
                    
                    <tr>
                      <td class="left"><strong class="text-darkk-1">Total</strong></td>
                      <td class="right"><strong class="text-darkk-1">{{ currencyFormat($orderdetails['grand_total']) ?? ''}}</strong></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="card-footer bg-white">
            <p class="mb-0">Ecolife.com, South Block, New delhi, 110034</p>
          </div>
        </div>
      </div>
    </div>
  </div>