@php
$main_arr = [
'title'=>'',
'sublist' => [
[
'name'=>translation('HOME'),
'link'=>url("/")
],
[
'name'=>translation('DASHBOARD'),
'link'=>url("account/dashboard")
],
[
'name'=>translation('ADDRESS'),
'link'=>url()->full()
],
]
];
@endphp 
<!-- Breadcrumb Area start -->
<x-Ecom03.SharedComponent.BreadCrumb :data="$main_arr" /> 
<!-- Breadcrumb Area End -->
<div class="container myaccount-section">
    <div class="row mb-8">
        <div class="col-xl-12 col-wd-12gdot5 mx-auto px-5">
            <div class="d-flex justify-content-between align-items-center">
                <div class="row w-100 border-bottom section-title">
                    <div class="col-lg-9 px-md-0 ">
                        <h5 class="text-black">{{translation('ADDRESS_TITLE')}}</h5>
                    </div>
                    <div class="col-lg-3">
                        <a href="#" class="btn btn-sm btn-block  btn-wide transition-3d-hover p-0 text-black"id="addAddress" >
                            <small class="fas fa-plus"></small> 
                            {{translation('NEW_ADDRESS_BUTTON')}}
                        </a>
                    </div>
                </div>
            </div>
            <div class="">
                <div class="row d-flex account-information CustomerAddress">
                </div>

                <!-- Update Address Modal Start-->
                <div class="form-popup-bg editAddress">
                    <div class="form-container">
                        <button id="btnCloseForm" class="close-button">X</button>
                        <h3>{{translation('UPDATED_ADDRESS')}}</h3>
                        <form id="custUpdateAddress" class="needs-validation" novalidate>
                            <div class="row">
                                <input type="hidden" id="address_id">
                                
                                <div class="col-lg-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="">{{translation('NAME')}}</label>
                                        <input type="text" class="form-control" id="customer_name" placeholder="{{translation('NAME_PLACEHOLDER')}}" required />
                                        <span class="text-danger addup_customer_name"></span>
                                    </div>
                                </div>

                                <div class="col-lg-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="">{{translation('EMAIL')}}</label>
                                        <input type="text" class="form-control" id="customer_email" placeholder="{{translation('EMAIL_PLACEHOLDER')}}" required />
                                        <span class="text-danger addup_customer_email"></span>
                                    </div>
                                </div>

                                <div class="col-lg-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="">{{translation('STREET_ADDRESS')}}</label>
                                        <input type="text" class="form-control" id="street_address" placeholder="{{translation('STREET_ADDRESS_PLACEHOLDER')}}" required />
                                        <span class="text-danger addup_street_address"></span>
                                    </div>
                                </div>

                                <div class="col-lg-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="">{{translation('CITY')}}</label>
                                        <input type="text" class="form-control" placeholder="{{translation('CITY_PLACEHOLDER')}}" id="city" name="contact-phone" required="" aria-required="true">
                                        <span class="text-danger addup_city"></span>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="">{{translation('STATE')}}</label>
                                        <input class="form-control" type="text" id="state" placeholder="{{translation('STATE_PLACEHOLDER')}}" required/>
                                        <span class="text-danger addup_state"></span>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="">{{translation('ZIPCODE')}}</label>
                                        <input type="number" class="form-control"  id="zipcode" placeholder="{{translation('ZIPCODE_PLACEHOLDER')}}" required/>
                                        <span class="text-danger addup_zipcode"></span>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="">{{translation('PHONE')}}</label>
                                        <input type="number" class="form-control" id="phone" placeholder="{{translation('PHONE_PLACEHOLDER')}}" required/>
                                        <span class="text-danger addup_phone"></span>
                                    </div>
                                </div>
                                @if(!empty($countriesdata))
                                <div class="col-lg-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="">{{translation('COUNTRY')}}</label>
                                        <select class="form-control form-input m-0" id="countries_id" aria-label="Default select example" required=""> 
                                            <option selected="" disabled="" value="">{{translation('COUNTRY_PLACEHOLDER')}}</option>
                                            @foreach($countriesdata as $key=>$data)
                                            <option value="{{$data->countries_id}}" class="updcountry">                             {{$data->countries_name}}
                                            </option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                @endif
                                <div class="col-md-4 col-sm-12 pl-0 mx-auto mt-2">
                                    <a href="#" class="btn btn-sm btn-block btn-primary-dark btn-wide transition-3d-hover" id="updateAddressButton" type="submit">
                                        {{translation('SUBMIT')}}
                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- Update Address Modal End-->

                <!-- Add Address Modal Start-->

                <div class="form-popup-bg addAddress" id="addAddressModal">
                    <div class="form-container">
                        <button id="btnCloseForm" class="close-button">X</button>
                        <h3>{{translation('ADD_ADDRESS')}}</h3>
                        <form id="custAddAddress" class="needs-validation" novalidate>
                            <div class="row">
                                <div class="col-lg-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="">{{translation('NAME')}}</label>
                                        <input type="text" class="form-control" id="addcustname" placeholder="{{translation('NAME_PLACEHOLDER')}}" required />
                                        <span class="text-danger add_customer_name"></span>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="">{{translation('EMAIL')}}</label>
                                        <input type="text" class="form-control" id="addcustemail" placeholder="{{translation('EMAIL_PLACEHOLDER')}}" required />
                                        <span class="text-danger add_customer_email"></span>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="">{{translation('STREET_ADDRESS')}}</label>
                                        <input type="text" class="form-control" id="addsstreet" placeholder="{{translation('STREET_ADDRESS_PLACEHOLDER')}}" required />
                                        <span class="text-danger add_street_address"></span>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="">{{translation('CITY')}}</label>
                                        <input type="text" class="form-control" placeholder="{{translation('CITY_PLACEHOLDER')}}" id="addscity" name="contact-phone" required="" aria-required="true">
                                        <span class="text-danger add_city"></span>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="">{{translation('STATE')}}</label>
                                        <input class="form-control" type="text" id="addsstate" placeholder="{{translation('STATE_PLACEHOLDER')}}" required/>
                                        <span class="text-danger add_state"></span>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="">{{translation('ZIPCODE')}}</label>
                                        <input type="number" class="form-control"  id="addszipcode" placeholder="{{translation('ZIPCODE_PLACEHOLDER')}}" required/>
                                        <span class="text-danger add_zipcode"></span>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="">{{translation('PHONE')}}</label>
                                        <input type="text" class="form-control" id="addsphone" placeholder="{{translation('PHONE_PLACEHOLDER')}}" name="addsphone" required/>
                                        <span class="text-danger add_phone"></span>
                                    </div>
                                </div>
                                @if(!empty($countriesdata))
                                <div class="col-lg-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="">{{translation('COUNTRY')}}</label>
                                        <select class="form-control form-input m-0" id="addscountry" aria-label="Default select example" required=""> 
                                            <option selected="" disabled="" value="">{{translation('COUNTRY_PLACEHOLDER')}}</option>
                                            @foreach($countriesdata as $key=>$data)
                                            <option value="{{$data->countries_id}}" class="updcountry" >                             
                                                {{$data->countries_name}}
                                            </option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                @endif
                                <div class="col-md-4 col-sm-12 pl-0 mx-auto mt-2">
                                    <a href="#" class="btn btn-sm btn-block btn-primary-dark btn-wide transition-3d-hover" id="addressformbutton" type="submit">
                                        {{translation('SUBMIT')}}
                                    </a>
                                    <input type="reset" hidden>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Add Address Modal End -->

            </div>
        </div>
    </div>
    <div class="modal fade" id="DeleteAddressModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header justify-space-between">
                    <h5 class="modal-title" id="exampleModalLabel">{{translation('DELETE_ADDRESS')}}</h5>
                    <button type="button" class="close modal-close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="delete_add_id">
                    <h4 class="p-2">{{translation('DELETE_ADDRESS_CONFIRM')}}?</h4>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary modal-close" data-dismiss="modal">{{translation('CLOSE_BUTTON')}}</button>
                    <button type="button" class="btn btn-primary delete_add_cnf ">{{translation('DELETE_CONFIRMATION_BUTTON')}}</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Brand Carousel -->
    <x-Ecom03.SharedComponent.BrandSlider />
    <!-- End Brand Carousel -->
</div>


<!-- script push to footer -->
@push('styles')
<style>
    .form-input {
        margin: 10px 0px;
    }
</style>
@endpush

@push('scripts')
<script>

    function loadaddresss(){
        $('.form-popup-bg').removeClass('is-visible');
        $('.addAddress').removeClass('is-visible');
        $.ajax({
            url: "{{url('account/show-address')}}",
            type: "GET",
            dataType: 'json',
            success: function (response) {
                var addressHtml = '';
                if(response.address.length !=0){
                $.each(response.address, function (key, value) {
                    var is_default = value.is_default;
                    checked = '';
                    if (is_default === 1) checked = "checked";
                    addressHtml += `<div class="col-lg-4 card p-3 d-flex ">
                                <div class=""> 
                                    <div class="entries-info  m-1">
                                        <div class="d-flex flex-row justify-content-between align-items-center CustomerAddress">
                                            <div class="form-check form-switch">
                                                <input class="form-check-input mySwitch" type="checkbox" id="mySwitch" name="darkmode" value="${value.address_id}" ${checked}>
                                                <label class="form-check-label" for=""> {{translation('DEFAULT')}}</label>
                                            </div>
                                        </div>
                                        <div class="entries-info pb-5">
                                            <p class="mb-0">${value.customer_name}</p>
                                            <p class="mb-0">${value.customer_email}</p>
                                            <p class="mb-0">${value.street_address}</p>
                                            <p class="mb-0">${value.city}</p>
                                            <p class="mb-0">${value.state}</p>
                                            <p class="mb-0">${value.zipcode}</p>
                                            <p class="mb-0">${value.country_name}</p>
                                            <p class="mb-0">${value.phone}</p>
                                        </div>
                                        <div class="address-bottom">
                                            <div class="d-flex align-items-center justify-content-between mt-2 mb-2 flex-row">
                                                <a href="" class=" text-black d-flex flex-row delete_address" value="${value.address_id}">
                                                    {{translation('DELETE_BUTTON')}}
                                                </a>
                                                <a href="" class="text-black d-flex flex-row edit_address" value="${value.address_id}">
                                                    {{translation('EDIT_BUTTON')}} 
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </div>
                            </div>`;
                  });
                 }
                else
                {
                    addressHtml+=`<p class="mt-2 mb-0">{{translation('EMPTY_ADDRESS_MSG')}}</p>`;
                }
                $('.CustomerAddress').html(addressHtml);
            }
        });
    }

  // load all address through ajax
    loadaddresss();

        // add function  ajax
        $(document).on('click', '#addressformbutton', function (e) {
            e.preventDefault();
            $('#custAddAddress').addClass('was-validated');
            // $('#custAddAddress').validate({
            //     rules: {
            //         addsphone: {
            //             required: true,
            //             maxlength: 15,
            //             minlength:9,
            //         },
            //     },
            //     messages: {
            //         addsphone: {
            //             required: "Please enter phone number",
            //             maxlength: "Phone Number cannot be more than 15 number.",
            //             minlength: "Phone Number cannot be less than 9 number.",
            //         },
            //     },
            // });
            if ($('#custAddAddress')[0].checkValidity() === false) {
                event.stopPropagation();
            } 
            else {
            var data = {
                'customer_name': $('#addcustname').val(),
                'customer_email': $('#addcustemail').val(),
                'street_address': $('#addsstreet').val(),
                'city': $('#addscity').val(),
                'state': $('#addsstate').val(),
                'zipcode': $('#addszipcode').val(),
                'countries_id': $('#addscountry').val(),
                'phone': $('#addsphone').val(),
            }
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "{{url('account/add-address')}}",
                data: data,
                dataType: "json",
                success: function (response) {
                    if (response.status == 400) {
                        $.each(response.error, function (key, err_val) {
                            $('.add_' + key).text(err_val);
                        });
                    } else {
                        $('#custAddAddress').removeClass('was-validated');
                        $('#addAddressModal').removeClass('is-visible');
                        $('#custAddAddress').trigger("reset");
                        Notify('{{translation('SUCCESSFULLY_SEND')}}!', true);
                        loadaddresss();
                    }
                }
            });
          }
        });


        //delete modal
        $(document).on("click", ".delete_address", function (e) {
            e.preventDefault();
            var addId = $(this).attr('value');
            $('#delete_add_id').val(addId);
            $('#DeleteAddressModal').modal('show');
        });

      // final delete
        $(document).on("click", ".delete_add_cnf", function (e) {
            e.preventDefault();
            var address_id = $('#delete_add_id').val();
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url: "{{ url('account/delete-address/') }}",
                type: "POST",
                data: {
                    address_id: address_id
                },
                success: function (response) {
                    console.log(response);
                    $('#DeleteAddressModal').modal('hide');
                    Notify('{{translation('DELETE_SUCCESS_MSG')}}!', true);
                    loadaddresss();
                }
            });
        });



        //Edit Address

        $(document).on("click", ".edit_address", function (e) {
            e.preventDefault();
            var addrsId = $(this).attr('value');
            $('.editAddress').addClass('is-visible');
            console.log('fdskjingfdn');
            var url = `{{url('account/address/${addrsId}/edit')}}`;
            $.ajax({
                url: url,
                type: "GET",
                success: function (response) {
                    //console.log(response);
                    if (response.status == 400) {
                        $('#errorlist').html("");
                        $('#errorlist').addClass("alert alert-danger");
                        $('#errorlist').append('<p>' + response.message + '</p>');

                    }
                    else {
                        $.each(response.addressdata, function (key, adds_val) {
                            $('#' + key).val(adds_val);

                        });
                    }
                }
            });

        });


        //update Address

        $(document).on("click", "#updateAddressButton", function (e) {
            e.preventDefault();
            $('#custUpdateAddress').addClass('was-validated');
            if ($('#custUpdateAddress')[0].checkValidity() === false) {
                event.stopPropagation();
            } else {
            var data = {
                'customer_name': $('#customer_name').val(),
                'customer_email': $('#customer_email').val(),
                'street_address': $('#street_address').val(),
                'city': $('#city').val(),
                'state': $('#state').val(),
                'zipcode': $('#zipcode').val(),
                'countries_id': $('#countries_id').val(),
                'phone': $('#phone').val(),
                'address_id': $("#address_id").val(),
            }
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "{{url('account/update-address')}}",
                data: data,
                dataType: "json",
                success: function (response) {
                    console.log(response);
                    if (response.status == 400) {
                        $.each(response.error, function (key, err_val) {
                            $('.addup_' + key).text(err_val);
                        });
                    }
                    else {
                        $('#custUpdateAddress').removeClass('was-validated');
                        $('.form-popup-bg').removeClass('is-visible');
                        Notify('{{translation('ADDRESS_UPDATE_SUCCESS_MSG')}}!', true);
                        loadaddresss();
                    }

                }
            });
           }
        });

    //     // Make default address 

        var switchStatus = false;
        $(document).on('click', '.mySwitch', function () {
            if ($(this).is(':checked')) {
                var data = { 'address_id': $(this).val(), }
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{url('account/makedefault-address')}}",
                    data: data,
                    dataType: "json",
                    success: function (response) {
                        console.log(response);
                        if (response.status == 400) {
                            Notify('Some thing error !', false);
                            loadaddresss();
                        }
                        else {
                            Notify('{{translation('DEFAULT_ADDRESS_SUCCESS_MSG')}}!', true);
                            loadaddresss();
                        }

                    }
                });
            }
        });
        $('#addAddress').on('click', function(event) {
            $('#addAddressModal').addClass('is-visible');
        });
        //close popup when clicking x or off popup
        $('.form-popup-bg').on('click', function(event) {
            if ($(event.target).is('.form-popup-bg') || $(event.target).is('#btnCloseForm')) {
            event.preventDefault();
            $(this).removeClass('is-visible');
            }
        });
</script>
@endpush