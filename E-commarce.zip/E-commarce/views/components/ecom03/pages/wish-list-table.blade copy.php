<div class="mb-16 wishlist-table" id="wishlist-table">
    @if (!empty($wishlist_item) && sizeof($wishlist_item)>0)
    <form class="mb-4" action="#" method="post">
        <div class="table-responsive">
            <table class="table" cellspacing="0">
                <thead>
                    <tr>
                        <th class="product-remove">&nbsp;</th>
                        <th class="product-thumbnail">&nbsp;</th>
                        <th class="product-name">Product</th>
                        <th class="product-price">Unit Price</th>
                        <th class="product-Stock w-lg-15">Product SKU</th>
                        <th class="product-subtotal min-width-200-md-lg">&nbsp;</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($wishlist_item as $key=>$data )
                    <tr>
                        <td class="text-center">
                            <a href="javascript:void(0);" class="text-gray-32 font-size-26"
                                onclick="actionOnWishlist({{$data->wishlist_id}})">×</a>
                        </td>
                        <td class="d-none d-md-table-cell">
                            <a href="{{url('product/'.$data->product->product_slug)}}"><img
                                    class="img-fluid max-width-100 p-1 border border-color-1"
                                    src="{{getFullImageUrl($data->product->product_image)}}"
                                    onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                                    alt="{{ $data->product->products_name ?? ''}}"></a>
                        </td>

                        <td data-title="Product">
                            <a href="{{url('product/'.$data->product->product_slug)}}" class="text-gray-90">{{
                                $data->product->products_name ?? ''}}</a>
                        </td>

                        <td data-title="Unit Price">
                            <span class="">{{ currencyFormat($data->product->product_sale_price ?? 0)}}</span>
                        </td>

                        <td data-title="Stock Status">
                            <!-- Stock Status -->
                            <span>{{ $data->product->product_sku ?? ''}}</span>
                            <!-- End Stock Status -->
                        </td>

                        <td>
                            <button type="button"
                                class="btn btn-soft-secondary mb-3 mb-md-0 font-weight-normal px-5 px-md-4 px-lg-5 w-100 w-md-auto">
                                <a href="{{url('product/'.$data->product->product_slug)}}">
                                    View Product
                                </a>
                            </button>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </form>
    @else
    <img src="{{ LoadAssets('assets/img/EmptyImages/Wishlist-Empty.png')}}"
        onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
        class="rounded mx-auto d-block" height="200px" alt="{{getSetting('site_title')}} Wishlist-Empty">
    <p class="h4 text-center text-dark mt-3">Your wishlist is empty !</p>
    <div class="text-center my-3">
        <a href="{{url('/')}}" class="btn btn-primary  btn-sm" role="button" aria-pressed="true">Continue to
            shop</a>
        @endif
    </div>
</div>