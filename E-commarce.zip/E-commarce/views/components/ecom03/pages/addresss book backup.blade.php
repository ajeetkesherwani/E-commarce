<div class="container myaccount-section">
    <div class="row mb-8">
        <div class="col-xl-12 col-wd-12gdot5 mx-auto px-5">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="text-black ">My Addresses</h3>
            <div>
                <a href="#" class="btn btn-sm btn-block btn-primary-dark btn-wide transition-3d-hover" ><small class="fas fa-plus"></small> Add a new address</a>
            </div>
            </div>
            <p>
                {{translation('MODIFY_YOUR_ADDRESS_BOOK_ENTRIES')}}
            </p>
        <div class="row  d-flex account-information CustomerAddress">
            <div class="col-lg-4 card p-3 d-flex  ">
                <div class="m-auto">
                    <div class="text-center">
                        <a href=""> <div class="fas fa-plus " id="btnOpenForm"></div></a>
                        <h4>Add Address</h4>
                    </div>
                    <div class="form-popup-bg">
                        <div class="form-container">
                            <button id="btnCloseForm" class="close-button">X</button>
                            <h3>Add a new address</h3>
                            <form action="">
                                <div class="form-group">
                                    <label for="">Full Name</label>
                                    <input type="text" class="form-control" />
                                </div>
                                <div class="form-group">
                                    <label for="">Mobile Number</label>
                                    <input type="text" class="form-control" placeholder="" id="contact-Phone" name="contact-phone" required="" aria-required="true">
                                </div>
                                <div class="form-group">
                                    <label for="">E-Mail Address</label>
                                    <input class="form-control" type="text" />
                                </div>
                                
                                <div class="form-group">
                                    <label for="">Flat, House no. , Building, Company, Apartment</label>
                                    <input type="text" class="form-control" />
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="">Pin Code</label>
                                        <input type="text" class="form-control " id="pincode" placeholder="" required="">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="">City</label>
                                        <input type="text" class="form-control " id="state" placeholder="" required="">
                                    </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="">State</label>
                                            <input type="text" class="form-control" />
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="">Select Country</label>
                                            <select class="form-control form-input" id="addscountry" aria-label="Default select example" required=""> 
                                                <option selected="" disabled="" value=""></option>
                                                <option value="1">Afghanistan</option>
                                                <option value="2">Albania</option>
                                                <option value="3">Algeria</option>
                                                <option value="4">American Samoa</option>
                                                <option value="5">Andorra</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-12 pl-0">
                                    <a href="#" class="btn btn-sm btn-block btn-primary-dark btn-wide transition-3d-hover"> Add Address</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Brand Carousel -->
    <x-Ecom03.SharedComponent.BrandSlider />
    <!-- End Brand Carousel -->
</div>

<!-- script push to footer -->
@push('styles')
<style>
    .form-input {
        margin: 10px 0px;
    }
</style>
@endpush

@push('scripts')
<script>

    function loadaddresss() {
        $.ajax({
            url: "{{url('account/show-address')}}",
            type: "GET",
            dataType: 'json',
            success: function (response) {
                var addressHtml = `<div class="col-lg-6  col-md-6">
                    <div class="d-flex align-items-center justify-content-center pointer border-dot mr-6"  data-bs-toggle="modal" data-bs-target="#myModal">                   
                                    <div class=" mt-3">
                                            <span type="button" class="material-symbols-outlined icon-dash symbol-pd">
                                                add
                                            </span>
                                        </div>   
                                        </div>                                            
                                    </div>`;

                $.each(response.address, function (key, value) {
                    var is_default = value.is_default;
                    checked = '';
                    if (is_default === 1) checked = "checked";

                    addressHtml += ` <div class="col-lg-6 col-md-6  align-items-center ">
                        <div class="entries-info border m-1">
                            <p>${value.street_address}</p>
                            <p>${value.city}</p>
                            <p>${value.state}</p>
                            <p>${value.zipcode}</p>
                            <p>${value.country_name}</p>
                            <p>${value.phone}</p>
                            <div class="entries-edit-delete  d-flex flex-row justify-content-between align-items-center py-2 flex-grow-1">
                            <div class="">
                             <form action="/action_page.php">
                               <div class="form-check form-switch">
                                 <input class="form-check-input mySwitch" type="checkbox" id="mySwitch"  name="darkmode" value="${value.address_id}" ${checked}>
                                 <label class="form-check-label" for="mySwitch">Make Default</label>
                               </div>
                             </form>
                            </div>    
                            <div>
                                <a href="javascript:void(0);" class="edit edit_address" value="${value.address_id}">Edit</a> <a href="javascript:void(0);" class="delete_address" value="${value.address_id}">Delete</a>
                            </div>
                            </div>
                            </div>
                            </div>`;
                });

                $('.CustomerAddress').html(addressHtml);
            }
        });
    }

    // load all address through ajax
    loadaddresss();


    $(document).ready(function () {

        // add function  ajax
        $(document).on('click', '#addressformbutton', function (e) {
            e.preventDefault();
            $('#custAddAddress').addClass('was-validated');
            if ($('#custAddAddress')[0].checkValidity() === false) {
                event.stopPropagation();
            } else {
            var data = {
                'street_address': $('#addsstreet').val(),
                'city': $('#addscity').val(),
                'state': $('#addsstate').val(),
                'zipcode': $('#addszipcode').val(),
                'countries_id': $('#addscountry').val(),
                'phone': $('#addsphone').val(),
            }
            //console.log(data);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "{{url('account/add-address')}}",
                data: data,
                dataType: "json",
                success: function (response) {
                    if (response.status == 400) {
                        $.each(response.error, function (key, err_val) {
                            $('.add_' + key).text(err_val);
                        });
                    } else {
                        $('#custAddAddress').removeClass('was-validated');
                        $('#myModal').modal('hide');
                        $('#customeraddress').trigger("reset");
                        Notify('Send Successfully', true);
                        loadaddresss();
                    }
                }
            });
          }
        });


        //delete modal
        $(document).on("click", ".delete_address", function (e) {
            e.preventDefault();
            var addId = $(this).attr('value');
            $('#delete_add_id').val(addId);
            $('#DeleteAddressModal').modal('show');
        });

        // final delete
        $(document).on("click", ".delete_add_cnf", function (e) {
            e.preventDefault();
            var address_id = $('#delete_add_id').val();
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url: "{{ url('account/delete-address/') }}",
                type: "POST",
                data: {
                    address_id: address_id
                },
                success: function (response) {
                    console.log(response);
                    $('#DeleteAddressModal').modal('hide');
                    Notify('Deleted Successfully', true);
                    loadaddresss();
                }
            });
        });



        //Edit Address
        $(document).on("click", ".edit_address", function (e) {
            e.preventDefault();
            var addrsId = $(this).attr('value');;
            $('#updateAddressModal').modal('show');
            var url = `{{url('account/address/${addrsId}/edit')}}`;

            $.ajax({
                url: url,
                type: "GET",
                success: function (response) {
                    //console.log(response);
                    if (response.status == 400) {
                        $('#errorlist').html("");
                        $('#errorlist').addClass("alert alert-danger");
                        $('#errorlist').append('<p>' + response.message + '</p>');

                    }
                    else {
                        $.each(response.addressdata, function (key, adds_val) {
                            $('#' + key).val(adds_val);

                        });
                    }
                }
            });

        });


        //update Address

        $(document).on("click", "#updateAddressButton", function (e) {
            e.preventDefault();
            $('#custUpdateAddress').addClass('was-validated');
            if ($('#custUpdateAddress')[0].checkValidity() === false) {
                event.stopPropagation();
            } else {
            var data = {
                'street_address': $('#street_address').val(),
                'city': $('#city').val(),
                'state': $('#state').val(),
                'zipcode': $('#zipcode').val(),
                'countries_id': $('#countries_id').val(),
                'phone': $('#phone').val(),
                'address_id': $("#address_id").val(),
            }
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "{{url('account/update-address')}}",
                data: data,
                dataType: "json",
                success: function (response) {
                    console.log(response);
                    if (response.status == 400) {
                        $.each(response.error, function (key, err_val) {
                            $('.addup_' + key).text(err_val);
                        });
                    }
                    else {
                        $('#custUpdateAddress').removeClass('was-validated');
                        $('#updateAddressModal').modal('hide');
                        Notify('Address Updated Successfully', true);
                        loadaddresss();
                    }

                }
            });
           }
        });

        // Make default address 

        var switchStatus = false;
        $(document).on('click', '.mySwitch', function () {
            if ($(this).is(':checked')) {
                var data = { 'address_id': $(this).val(), }
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{url('account/makedefault-address')}}",
                    data: data,
                    dataType: "json",
                    success: function (response) {
                        console.log(response);
                        if (response.status == 400) {
                            Notify('Some thing error !', false);
                            loadaddresss();
                        }
                        else {
                            Notify('Default Address Updated Successfully', true);
                            loadaddresss();
                        }

                    }
                });
            }
        });

        $(document).on('click', '.modal-close', function (e) {
            $('#DeleteAddressModal').modal('hide');
        });

    });
</script>
@endpush 