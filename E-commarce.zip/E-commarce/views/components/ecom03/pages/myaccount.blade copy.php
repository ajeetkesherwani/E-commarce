@php

$main_arr = [
    'title' => 'My Profile',
    'sublist' => [
        [
            'name' => 'HOME',
            'link' => url('/'),
        ],
        [
            'name' => 'Profile',
            'link' => url(''),
        ],
    ],
];
@endphp

<!-- Breadcrumb Area start -->
<x-Ecom03.SharedComponent.BreadCrumb :data="$main_arr" /> 
<!-- Breadcrumb Area End -->

<div class="container">
    <div class="row">
        <div class="col-md-7 mx-auto mb-5">
            <div class="mb-4">
                <h4 class=" mb-0 fw-bold">
                    My Profile
                </h4>
            </div>
                <div class="row">
                <!-- Form Group -->
               <div class="col-lg-6">
                <div class="js-form-message form-group">
                    <label class="form-label" for="">First Name
                        <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control" name="Name" id="" placeholder="First Name" aria-label="Username or Email address" required
                    data-msg="Please enter a valid "
                    data-error-class="u-has-error"
                    data-success-class="u-has-success">
                </div>
                </div>
                <div class="col-lg-6">
                <div class="js-form-message form-group">
                    <label class="form-label" for="signinSrEmailExample3">Last Name
                        <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control" name="last" id="signinSrEmailExample3" placeholder="Last Name" aria-label="Username or Email address" required
                    data-msg="Please enter ."
                    data-error-class="u-has-error"
                    data-success-class="u-has-success">
                </div>
                </div>
                                            <!-- End Form Group -->
                <div class="col-lg-6">
                    <div class="js-form-message form-group">
                        <label class="form-label" for="signinSrEmailExample3">Email Address
                            <span class="text-danger">*</span>
                        </label>
                        <input type="email" class="form-control" name="email" id="signinSrEmailExample3" placeholder=" Email address" aria-label="Username or Email address" required
                        data-msg="Please enter a valid email address."
                        data-error-class="u-has-error"
                        data-success-class="u-has-success">
                    </div>
                    </div>
                <!-- Form Group -->
                <div class="col-lg-6">
                    <div class="js-form-message form-group">
                        <label class="form-label" for="signinSrphoneExample3">Phone No
                            <span class="text-danger">*</span>
                        </label>
                        <input type="tel" class="form-control" name="phone" id="signinSrphoneExample3" placeholder="Phone No" aria-label="" required
                        data-msg="Please enter a valid phone no."
                        data-error-class="u-has-error"
                        data-success-class="u-has-success">
                    </div>
                    </div>
               </div>
                <!-- End Form Group -->

                <!-- Checkbox -->
                <div>
                    <div class="js-form-message mb-3">
                        <div class="custom-control custom-checkbox d-flex align-items-center">
                            <input type="checkbox" class="custom-control-input" id="rememberCheckbox" name="rememberCheckbox" required
                            data-error-class="u-has-error"
                            data-success-class="u-has-success">
                            <label class="custom-control-label form-label" for="rememberCheckbox">
                                Change Password
                            </label>
                        </div>
                    </div>
                </div>
                <div class="row d-none">
                    <div class="col-lg-6">
                        <div class="js-form-message form-group">
                            <label class="form-label" for="">New Password
                                <span class="text-danger">*</span>
                            </label>
                            <input type="" class="form-control" name="password" id="password" placeholder="New Password" aria-label="" required
                            data-msg="Please enter a valid password."
                            data-error-class="u-has-error"
                            data-success-class="u-has-success">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="js-form-message form-group">
                            <label class="form-label" for="">Confirm Password
                                <span class="text-danger">*</span>
                            </label>
                            <input type="" class="form-control" name="password" id="password" placeholder="Confirm Password" aria-label="" required
                            data-msg="Please enter a valid password."
                            data-error-class="u-has-error"
                            data-success-class="u-has-success">
                        </div>
                    </div>
                </div>
                <!-- End Checkbox -->

                <!-- Button -->
                
                    <div class="mb-3 mt-4">
                        <button type="submit" class="btn btn-primary-dark-w px-5 ">Update</button>
                    </div>
                    
             
                <!-- End Button -->
            </div>
            </form>
        </div>
    </div>

@push('scripts')
    <script>
        $(document).ready(function() {
            $(document).on('click', '#updateprofile', function(e) {
                e.preventDefault();
                $('.edit_user_form').addClass('was-validated');
                if ($('.edit_user_form')[0].checkValidity() === false) {
                    event.stopPropagation();
                } else {

                if ($("#passwordCheckbox").prop('checked') == true) {
                    var passwordCheckbox = $('#passwordCheckbox').val();
                } else {
                    var passwordCheckbox = 0;
                }
                var data = {
                    'first_name': $('#first_name').val(),
                    'last_name': $('#last_name').val(),
                    'password': $('#password').val(),
                    'confirmpassword': $('#confirmpassword').val(),
                    'passwordCheckbox': passwordCheckbox,
                }

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{ url('account/update-profile') }}",
                    data: data,
                    dataType: "json",
                    success: function(response) {
                        if (response.status == 400) {
                            $.each(response.error, function(key, err_val) {
                                $('.' + key).text(err_val);
                            });
                        } else {
                            $('.edit_user_form').removeClass('was-validated');
                            Notify('Profile Updated Successfully', true);
                            $('#passwordCheckbox').prop('checked', false);
                            $('#cpasstoggle').hide(2000);
                            location.reload();
                        }
                    }
                });
               }
            });

            // Resend Verify email

            $(document).on('click', '#resendEmailbutton', function(e) {
                $.ajaxSetup({
                    headers: {
                        "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr(
                            "content"
                        ),
                    },
                });
                var email = $('#user_email').val();
                var customer_id = $('#user_id').val();
                var first_name = $('#first_name').val();
                $.ajax({
                    type: "POST",
                    url: "{{ url('resend-email') }}",
                    data: {
                        'email': email,
                        'customer_id': customer_id,
                        'first_name': first_name,
                    },
                    dataType: "json",
                    success: function(response) {
                        if (response.status == 200) {
                            Notify("Email Send Successfully", true);
                        }
                    },
                    error: function(data) {
                        console.log(data);
                    },
                });
            });

        });
    </script>
@endpush
