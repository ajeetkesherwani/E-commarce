@php
$main_arr = [
'title'=>'',
'sublist' => [
[
'name'=>translation('HOME'),
'link'=>url("/")
],
[
'name'=>translation('LOGIN'),
'link'=>url()->full()
],
]
];
@endphp
<!-- Breadcrumb Area start -->
<x-Ecom03.SharedComponent.BreadCrumb :data="$main_arr" /> 
<!-- Breadcrumb Area End -->
<!-- login area start -->
<div class="container">
    <div class=" my-xl-8 ">
        <div class="row">
            <div class="col-md-5 mx-auto card px-4 pb-5">
                <!-- Title -->
                <div class="text-center my-4">
                    <h5 class="d-inline-block mb-0 fw-bold">
                        {{ translation('LOGIN_TITLE') }}
                    </h5>
                </div>
                @if (session('status'))
                    <div class="alert alert-success">
                        {{ session('status') }}
                    </div>
                @endif

                @error('failed')
                <div>
                <strong class="text-danger" style="margin-top:-50px;">{{ $message }}</strong>
                </div>
                @enderror  
                <!-- End Title -->
                <form class="js-validate" novalidate="novalidate" action="{{route('login') }}" method="post" id="Login_Form">
                    @csrf  
                    <!-- Form Group -->
                    <div class="js-form-message form-group">
                        <label class="form-label" for="signinSrEmailExample3">{{ translation('EMAIL') }}
                            <span class="text-danger">*</span>
                        </label>
                        <input type="email" class="form-control" name="email" id="signinSrEmailExample3" placeholder="{{ translation('EMAIL_PLACEHOLDER') }}" aria-label="Username or Email address" required 
                        data-msg="{{translation('ERROR_EMAIL')}}"
                        data-error-class="u-has-error" value="{{old('email')}}"
                        data-success-class="u-has-success">
                        @error('email')
                            <strong class="text-danger mb-5">{{ $message }}</strong>
                        @enderror
                    </div>
                    <!-- End Form Group -->

                    <!-- Form Group -->
                    <div class="js-form-message form-group">
                        <label class="form-label" for="signinSrPasswordExample2">{{ translation('PASSWORD') }} <span class="text-danger">*</span></label>
                        <input type="password" class="form-control" name="password" id="signinSrPasswordExample2" placeholder="{{ translation('PASSWORD_PLACEHOLDER') }}" value="{{old('password')}}" aria-label="Password" required
                        data-msg="{{translation('ERROR_PASSWORD')}}"
                        data-error-class="u-has-error"
                        data-success-class="u-has-success">
                        @error('password')
                            <strong class="text-danger" style="margin-top:-50px;">
                                {{ $message }}
                            </strong>
                        @enderror
                    </div>
                    <!-- End Form Group -->

                    <!-- Checkbox -->
                    <div class="js-form-message mb-3">
                        <div class="custom-control custom-checkbox d-flex align-items-center justify-content-between">
                            <div>
                                <input type="checkbox" class="custom-control-input" id="rememberCheckbox" name="rememberCheckbox" 
                                data-error-class="u-has-error"
                                data-success-class="u-has-success">
                                <label class="custom-control-label form-label" for="rememberCheckbox">
                                    {{ translation('REMEMBER_ME') }}
                                </label>
                            </div>
                            <div> 
                                <label class=" form-label" >
                                    <a href="{{url('/forgot-password')}}" class="text-black"> 
                                        {{ translation('FORGOT_PASSWORD') }}?
                                    </a>
                                </label>
                            </div>
                        </div>
                    </div><!-- End Checkbox -->
                    <!-- Button -->
                    <div class=" text-center mt-3">
                        <button type="submit" class="btn btn-primary-dark-w px-5 w-50 userLogin">{{ translation('SIGIN_BUTTON') }}</button>
                    </div>
                    <div class="col-12 text-center">
                        <p class="mb-0  mt-4"><small class="text-dark me-2">{{ translation('DONT_HAVE_ACCOUNT') }}</small> <a href="{{url('/register')}}" class="text-dark fw-bold">{{ translation('SIGN_UP') }}</a></p>
                    </div><!-- End Button -->
                </form>
            </div>
        </div>
    </div>
</div>
 <!-- login area end -->

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
<script>
    $(document).ready(function() {
        $(document).on('click', '.userLogin', function(e) {
             e.preventDefault();
            $('#Login_Form').addClass('was-validated');
            if ($('#Login_Form')[0].checkValidity() === false) {
                event.stopPropagation();
            } 
            else {
                $('#Login_Form').validate({
                    rules: {
                        email: {
                            required: true,
                            email: true,
                            maxlength: 150
                        },
                        password: {
                            minlength: 6,
                            required: true
                        },
                    },
                    messages: {
                        email: {
                                required: "Please enter email",
                                email: "Please enter valid email",
                                maxlength: "Email cannot be more than 150 characters.",
                            },
                            password: {
                                required: "Please enter password",
                                minlength: "Password must be at least 6 characters."
                            },
                        },
                });
                $('#Login_Form').removeClass('was-validated');
                $('#Login_Form').submit();
            }
        });
    });
 
</script>
@endpush