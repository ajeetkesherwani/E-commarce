@php
$main_arr = [
    'title' => $sideFilter['current_brand']->brand_name ?? '',
    'sublist' => $breadCumbArr,
];

// end of div sizes
@endphp

<!-- Breadcrumb Area End -->
<x-Ecom03.SharedComponent.BreadCrumb :data="$main_arr" />
<!-- Shop Category Area End -->
<div class="container">
    @if (!empty($products) && sizeof($products) > 0)
        <form id="filterForm" action="{{url("/brand/".urlencode($filtersData['slug']))}}" method="get">
            <input type="hidden" name="filter">
            <div class="row mb-12">
                <div class="col-xl-12 col-wd-9gdot5">
                    <!-- Shop-control-bar Title -->
                    <div class="flex-center-between mb-3">
                        <h3 class="font-size-25 mb-0">{{$sideFilter['current_brand']->brand_name ?? ''}}</h3>
                        <p class="font-size-14 text-gray-90 mb-0">
                            @php
                                $item =  $products->total() ?? 1 ;
                                $data  = translation('PAGINATION_TOTAL_ITEM');
                                printf($data, $item);
                            @endphp
                        </p>
                    </div>
                    <!-- End shop-control-bar Title -->
                    <!-- Shop-control-bar -->
                    <div class="bg-gray-1 flex-center-between borders-radius-9 py-1">
                        <div class="d-xl-none">
                            <!-- Account Sidebar Toggle Button -->
                            <a id="sidebarNavToggler1" class="btn btn-sm py-1 font-weight-normal" href="javascript:;" role="button"
                                aria-controls="sidebarContent1"
                                aria-haspopup="true"
                                aria-expanded="false"
                                data-unfold-event="click"
                                data-unfold-hide-on-scroll="false"
                                data-unfold-target="#sidebarContent1"
                                data-unfold-type="css-animation"
                                data-unfold-animation-in="fadeInLeft"
                                data-unfold-animation-out="fadeOutLeft"
                                data-unfold-duration="500">
                                <i class="fas fa-sliders-h"></i> <span class="ml-1">{{ translation('FILTER') }}</span>
                            </a>
                            <!-- End Account Sidebar Toggle Button -->
                        </div>
                        <div class="px-3 d-none d-xl-block">
                            <ul class="nav nav-tab-shop" id="pills-tab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="pills-two-example1-tab" data-toggle="pill" href="#pills-two-example1" role="tab" aria-controls="pills-two-example1" aria-selected="false">
                                        <div class="d-md-flex justify-content-md-center align-items-md-center">
                                            <i class="fa fa-align-justify"></i>
                                        </div>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="pills-three-example1-tab" data-toggle="pill" href="#pills-three-example1" role="tab" aria-controls="pills-three-example1" aria-selected="true">
                                        <div class="d-md-flex justify-content-md-center align-items-md-center">
                                            <i class="fa fa-list"></i>
                                        </div>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="d-flex">
                            @if (in_array(config('constkey.sidebar_filter'), $cKey))
                                <!-- Select -->
                                <select class="js-select selectpicker dropdown-select max-width-200 max-width-160-sm right-dropdown-0 px-2 px-xl-0 filter_style" name="sortBy" id="sortBy" onChange="filterItem()" data-style="btn-sm bg-white font-weight-normal py-2 border text-gray-20 bg-lg-down-transparent border-lg-down-0" >
                                    <option value="" @if($filtersData['sortBy']==null) 
                                    selected  @endif>{{ translation('FILTER') }}</option>
                                    <option value="latest" @if($filtersData['sortBy']=='latest') 
                                    selected  @endif>{{ translation('SORT_BY_LATEST') }}</option>
                                    <option value="pricemintohigh" @if($filtersData['sortBy']=='pricemintohigh') 
                                    selected  @endif>{{ translation('PRICE_MIN_TO_MAX') }}</option>
                                    <option value="pricehightomin" @if($filtersData['sortBy']=='pricehightomin') selected  @endif>{{ translation('PRICE_MAX_TO_MIN') }}</option>
                                    <option value="instock" @if($filtersData['sortBy']=='instock') selected  @endif>{{ translation('IN_STOCK') }}</option>
                                </select>
                                <!-- End Select -->
                                <input style="display:none" type="hidden" name="brands" value='{{ $sideFilter['current_brand']->brand_id }}' />
                            @endif
                            <!-- current selected brand-->
                            
                            <!-- end current brand -->

                            @if (in_array(config('constkey.listing_pagination'), $cKey))
                                <!-- Select -->
                                <select class="js-select selectpicker dropdown-select max-width-120 filter_style"
                                    data-style="btn-sm bg-white font-weight-normal py-2 border text-gray-20 bg-lg-down-transparent border-lg-down-0" name="perPageItem" onChange="filterItem()" >
                                    <option value="20" @if($filtersData['perPageItem']==20) selected @endif>20</option>
                                    <option value="40" @if($filtersData['perPageItem']==40) selected @endif>40</option>
                                    <option value="80" @if($filtersData['perPageItem']==80) selected @endif>80</option>
                                    <option value="200" @if($filtersData['perPageItem']==200) selected @endif>200</option>
                                </select>
                                <!-- End Select -->
                            @endif
                        </div>
                    </div>
                    <!-- End Shop-control-bar -->
                    <!-- Shop Body -->
                    <!-- Tab Content -->
                    <div class="tab-content " id="filterProductData" >
                        <div class="tab-pane fade pt-2 show active" id="pills-two-example1" role="tabpanel" aria-labelledby="pills-two-example1-tab" data-target-group="groups">
                            <ul class="row list-unstyled products-group no-gutters">
                                @if (!empty($products) && sizeof($products) > 0)
                                {{-- Here htl code come from component with grid view --}}
                                @foreach ($products as $product)
                                    {{-- Here htl code come from component with grid view --}}
                                    <x-ecom03.shared-component.product  viewtype="grid" :data="$product" />
                                @endforeach
                                @endif
                            </ul>
                        </div>
                        <div class="tab-pane fade pt-2" id="pills-three-example1" role="tabpanel" aria-labelledby="pills-three-example1-tab" data-target-group="groups">
                            <ul class="d-block list-unstyled products-group prodcut-list-view">
                                @if (!empty($products) && sizeof($products) > 0)
                                @foreach ($products as $product)
                                {{-- Here html code come from component with List view --}}
                                <x-ecom03.shared-component.product  :data="$product" viewtype="list"/>
                                @endforeach
                                @endif
                            </ul>
                        </div>
                    </div>
                    <!-- End Tab Content -->
                    <!-- End Shop Body -->
                    <!-- Shop Pagination -->
                    <input style="display:none" type="text" name="page" id="page" value="" />
                    <input type="hidden" id="nextPage" value="1">
                    {{ $products->links('vendor.pagination.theme3Pagination') }}
                    <!-- End Shop Pagination -->
                </div>
            </div>
            <button type="submit" hidden id="filterFormButton"></button>
        </form>
    @else
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-4 mx-auto">
                <img src="{{ LoadAssets('assets/images/EmptyImages/Wishlist-Empty.png') }}" class="rounded mx-auto d-block" width="286px" height="200px"
                    onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" alt="{{ getSetting('site_title') }} Wishlist-Empty">
                <p class="h4 text-center text-dark mt-3">
                {{ translation('EMPTY_BRAND_PRODUCT_MSG') }}  
                </p>
                <div class="col-10 mx-auto text-center my-3">
                    <a href="{{ url('/') }}" class="btn btn-primary-dark-w btn-block" role="button"
                        aria-pressed="true">{{ translation('CONTINUE_TO_SHOP') }}</a>
                </div>
            </div>
        </div>
    </div>
    @endif
    <!-- Brand Carousel -->
    <x-Ecom03.SharedComponent.BrandSlider />
    <!-- End Brand Carousel -->
</div>

@push('scripts')
    <script>
        function filterItem(){
            $("html").scrollTop(0);
            $('#page').val($('#nextPage').val());
            $("#filterForm").submit();
        }
    </script>
@endpush
