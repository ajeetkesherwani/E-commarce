@php
$main_arr = [
'sublist' => [
[
'name'=>translation('HOME'),
'link'=>url("/")
],
[
'name'=>translation('LOGIN'),
'link'=>url("login")
],
[
'name'=>translation('REGISTER'),
'link'=>url()->full()
],
]
];
@endphp 
<!-- Breadcrumb Area start -->
<x-Ecom03.SharedComponent.BreadCrumb :data="$main_arr" /> 
<!-- Breadcrumb Area End -->
<div class="container">
    <div class=" my-xl-8 ">
        <div class="row">
            <div class="col-md-5  mx-auto card px-4 pb-5">
                <!-- Title -->
                <div class=" text-center  my-4">
                    <h5 class="d-inline-block mb-0 fw-bold">{{translation('REGISTER_TITLE')}}</h5>
                </div>
                <!-- End Title -->
                <form  action="{{route('register')}}" method="post" class="js-validate registationForm" novalidate="novalidate">
                   @csrf
                    <div class="row">
                        <div class="col-md-12">
                            <!-- Input -->
                            <div class="js-form-message form-group">
                                <label class="form-label" for="signupName">{{translation('NAME')}} <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="signupName" value="{{old('name')}}" name="name" required=""  placeholder="{{translation('NAME_PLACEHOLDER')}}" aria-label=""  data-error-class="u-has-error" data-success-class="u-has-success" data-msg="{{translation('ERROR_NAME')}}" autocomplete="off">
                                @error('name')
                                    <strong class="text-danger mb-5">
                                        {{ $message }}
                                    </strong>
                                @enderror
                            </div>
                            <!-- End Input -->
                        </div>

                        <div class="col-md-12">
                            <!-- Input -->
                            <div class="js-form-message form-group">
                                <label class="form-label" for="signupEmail">{{translation('EMAIL')}}
                                    <span class="text-danger">*</span>
                                </label>
                                <input type="email" class="form-control" name="email"  value="{{old('email')}}" autocomplete="off" required="" id="signupEmail" placeholder="{{translation('EMAIL_PLACEHOLDER')}}" aria-label="Email address" data-msg="{{translation('ERROR_EMAIL')}}" data-error-class="u-has-error" data-success-class="u-has-success">
                                @error('email')
                                    <strong class="text-danger mb-5">
                                        {{ $message }}
                                    </strong>
                                @enderror
                            </div>
                            <!-- End Input -->
                        </div>
                        <div class="col-md-12">
                            <div class="js-form-message form-group">
                                <label class="form-label" for="signinSrPasswordExample1">{{translation('PASSWORD')}} <span class="text-danger">*</span></label>
                                <input type="password" class="form-control" name="password" id="signinSrPasswordExample1" autocomplete="off" placeholder="{{translation('PASSWORD_PLACEHOLDER')}}" aria-label="Password" data-msg="{{translation('ERROR_PASSWORD')}}" required="" data-error-class="u-has-error" data-success-class="u-has-success">
                                @error('password')
                                    <strong class="text-danger mb-5">
                                        {{ $message }}
                                    </strong>
                                @enderror
                                <div class="error-msg text-danger d-none"></div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="js-form-message form-group">
                                <label class="form-label" for="signinSrPasswordExample2">{{translation('CONFIRM_PASSWORDS')}}<span class="text-danger">*</span></label>
                                <input type="password" class="form-control" name="password_confirmation" id="signinSrPasswordExample2" autocomplete="off" placeholder="{{translation('CONFIRM_PASSWORDS_PLACEHOLDER')}}" data-msg="{{translation('ERROR_CONFIRM_PASSWORD')}}" aria-label="Password" required=""  data-error-class="u-has-error" data-success-class="u-has-success">
                                @error('password_confirmation')
                                    <strong class="text-danger mb-5">
                                        {{ $message }}
                                    </strong>
                                @enderror
                            </div>
                        </div>
                    </div>
                    <div class="text-center mb-3">
                        <button type="submit" class="btn btn-primary-dark-w px-5 w-50 registerButton">{{translation('REGISTER_BUTTON')}}</button>
                    </div>
                    <div class="col-12 text-center">
                        <div class="text-dark ">{{translation('ALREADY_REGISTER')}}<a href="{{url('login')}}" class="text-dark fw-bold ml-1">{{translation('SIGN_IN')}}</a></div> 
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@push('scripts')
<script>
    $(document).ready(function() {
        $(document).on('click', '.registerButton', function(e) {
             e.preventDefault();
            $('.registationForm').addClass('was-validated');
            if ($('.registationForm')[0].checkValidity() === false) {
                event.stopPropagation();
            } 
            else {
                var passsword = $('#signinSrPasswordExample1').val();
                var confirmpasssword = $('#signinSrPasswordExample2').val();
                if( passsword == confirmpasssword){
                    $('.registationForm').removeClass('was-validated');
                $('.registationForm').submit();
                }
                else{
                    event.stopPropagation();
                    $('.error-msg').removeClass('d-none');
                    $('.error-msg').html('{{translation('ERROR_PASSWORD_AND_CONFIRM_PASSWORD_MSG')}}');
                    setTimeout(function() {
                        $(".error-msg").addClass("d-none");
                        $('.error-msg').html('');
                    }, 3000);
                }
                
            }
        });
    });
</script>
@endpush