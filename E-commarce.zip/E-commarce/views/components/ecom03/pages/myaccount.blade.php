@php
$main_arr = [
'title' => translation('MY_ACCOUNT'),
'sublist' => [
[
    'name' =>  translation('HOME'),
    'link' => url('/'),
],
[
    'name' => translation('DASHBOARD'),
    'link' => url('account/dashboard'),
],
[
    'name' => translation('MY_ACCOUNT'),
    'link' => url()->full()
],
],
];
@endphp

<!-- Breadcrumb Area start -->
<x-Ecom03.SharedComponent.BreadCrumb :data="$main_arr" /> 
<!-- Breadcrumb Area End -->
<div class="container">
    <div class="row">
        <div class="col-md-7 mx-auto mb-5 card p-5">
            <div class="mb-4 border-bottom section-title">
                <h4 class=" fw-bold ">
                    {{translation('ACCOUNT_TITLE')}}
                </h4>
            </div>
            <form class="needs-validation edit_user_form" novalidate>
                <div class="row">
                    <!-- Form Group -->
                    <div class="col-lg-6">
                        <div class="js-form-message form-group">
                            <label class="form-label" for="">{{ translation('NAME') }}
                                <span class="text-danger">*</span>
                            </label>
                            <input type="text" class="form-control" name="Name" id="name" placeholder="{{ translation('NAME_PLACEHOLDER') }}" value="{{ $userData->first_name ?? '' }}" aria-label="Username or Email address" required
                            data-msg="{{translation('ERROR_NAME')}}"
                            data-error-class="u-has-error"
                            data-success-class="u-has-success">
                            <span class="text-danger first_name"></span>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="js-form-message form-group">
                            <label class="form-label" for="signinSrEmailExample3">{{ translation('PHONE') }}
                                <span class="text-danger">*</span>
                            </label>
                            <input type="text" class="form-control" name="" id="contact" placeholder="{{ translation('PHONE_PLACEHOLDER') }}" value="{{ $userData->contact ?? '' }}"  aria-label="Username or Email address" required
                            data-msg="{{('ERROR_PHONW')}}"
                            data-error-class="u-has-error"
                            data-success-class="u-has-success">
                            <span class="text-danger contact"></span>
                        </div>
                    </div>
                    <!-- End Form Group -->
                    <div class="col-lg-6">
                        <div class="js-form-message form-group">
                            <label class="form-label" for="signinSrEmailExample3">{{ translation('EMAIL') }}
                                <span class="text-danger">*</span>
                            </label>
                            <input type="email" class="form-control" name="email" id="email" value="{{ $userData->email ?? '' }}" placeholder=" {{ translation('EMAIL_PLACEHOLDER') }}" aria-label="Username or Email address" required
                            data-msg="{{('ERROR_EMAIL')}}"
                            data-error-class="u-has-error"
                            data-success-class="u-has-success">
                        </div>
                    </div>
                    <!-- Form Group -->
                    @if (!empty($userData->email_verified_at))
                    <div class="col-lg-6 m-auto">
                        <div class="js-form-message form-group mb-0">
                            <input type="hidden" id="user_email" value="{{ $userData->email }}">
                            <input type="hidden" id="user_id" value="{{ $userData->customer_id }}">
                            <input type="hidden" id="first_name" value="{{ $userData->first_name }}">
                            <div class="d-flex align-items-center justify-content-center">                            
                                <label class="form-label pr-2 mb-0" for="signinSrphoneExample3">{{ translation('EMAIL_VERIFY') }}
                                     <span class="text-danger">*</span>
                                </label>
                                <a href="javascript:void(0)" class="btn btn-outline-primary" id="resendEmailbutton">{{ translation('EMAIL_VERIFIED_BUTTON') }}</a>
                            </div>
                        </div>
                    </div>
                    @else
                    <div class="col-lg-6 m-auto">
                        <div class="js-form-message form-group mb-0">
                            <label class="form-label mb-0" for="signinSrphoneExample3">
                                <i class="fa fa-check bg-success text-white" aria-hidden="true"></i> 
                                {{ translation('EMAIL_VERIFIED') }}
                            </label>
                        </div>
                    </div>
                    @endif
                </div>
                <!-- End Form Group -->
                <!-- Checkbox -->
                <div>
                    <div class="js-form-message mb-3">
                        <div class=" custom-control custom-checkbox d-flex align-items-center justify-content-between">
                           <div>
                           <input type="checkbox" class="custom-control-input" id="ChangePasswordCheckbox" value="1" name="ChangePasswordCheckbox"
                            data-error-class="u-has-error"
                            data-success-class="u-has-success">
                            <label class="custom-control-label form-label" for="ChangePasswordCheckbox">
                                {{ translation('CHANGE_PASSWORD_BUTTON') }}
                            </label>
                           </div>
                            
                        </div>
                    </div>
                </div>
                <div class="row password-section" style="display: none;">
                    <div class="col-lg-12">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="js-form-message form-group">
                                    <label class="form-label" for="">{{ translation('NEW_PASSWORD') }}
                                        <span class="text-danger">*</span>
                                    </label>
                                    <input type="password" class="" name="password" id="password" placeholder="{{ translation('NEW_PASSWORD_PLACEHOLDER') }}" data-msg="{{('ERROR_PASSWORD')}}" >
                                    <span class="text-danger password"></span>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="js-form-message form-group">
                                    <label class="form-label" for="">{{ translation('CONFIRM_PASSWORDS') }}
                                        <span class="text-danger">*</span>
                                    </label>
                                    <input type="" class="" name="confirmpassword" id="confirmpassword" placeholder="{{ translation('CONFIRM_PASSWORDS_PLACEHOLDER') }}" aria-label="" 
                                    data-msg="{{('ERROR_CONFIRM_PASSWORD')}}"
                                    data-error-class="u-has-error"
                                    data-success-class="u-has-success" >
                                    <span class="text-danger confirmpasswordmsg " hidden>{{ translation('ENTER_CONFIRM_PASSWORD') }}</span>
                                    <span class="text-danger confirmpassword"></span>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <span class="text-danger d-none" id="ConfirmPasswordCheck">
                                {{ translation('ERROR_PASSWORD_AND_CONFIRM_PASSWORD_MSG') }} 
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Checkbox -->

                <!-- Button -->
                <div class="mb-3 mt-4">
                    <button type="submit" id="updateprofile" class="btn btn-primary-dark-w px-5 ">{{ translation('UPDATE_BUTTON') }}</button>
                </div>
                <!-- End Button -->
            </form>
        </div>
    </div>
    <!-- Brand Carousel -->
    <x-Ecom03.SharedComponent.BrandSlider />
    <!-- End Brand Carousel -->
</div> 

@push('scripts')
    <script>
        $(document).ready(function() {
            $(document).on('click', '#updateprofile', function(e) {
                e.preventDefault();
                $('.edit_user_form').addClass('was-validated');
                $('#password').removeAttr('required','');
                $('#confirmpassword').removeAttr('required','');
                if ($('.edit_user_form')[0].checkValidity() === false) {
                    event.stopPropagation();
                } else {
                if ($("#ChangePasswordCheckbox").prop('checked') == true) {
                    $('#password').addClass('form-control');
                    $('#confirmpassword').addClass('form-control');
                    $('#password').attr('required','');
                    $('#confirmpassword').attr('required','');   
                    if($('#password').val() == $('#confirmpassword').val()){
                        var passwordCheckbox = $('#ChangePasswordCheckbox').val();
                    }else{
                        checkPassword();
                    }
                } else {
                    var passwordCheckbox = 0;
                }
                var data = {
                    'name': $('#name').val(),
                    'contact': $('#contact').val(),
                    'password': $('#password').val(),
                    'confirmpassword': $('#confirmpassword').val(),
                    'passwordCheckbox': passwordCheckbox,
                }
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{ url('account/update-profile') }}",
                    data: data,
                    dataType: "json",
                    success: function(response) {
                        if (response.status == 400) {
                            $.each(response.error, function(key, err_val) {
                                $('.' + key).text(err_val);
                            });
                        } else {
                            $('.edit_user_form').removeClass('was-validated');
                            Notify('{{translation('PROFILE_UPDATE_MSG')}}', true);
                            $('#ChangePasswordCheckbox').prop('checked', false);
                            $('#cpasstoggle').hide(2000);
                            location.reload();
                        }
                    }
                });
               }
            });

            // Resend Verify email

            $(document).on('click', '#resendEmailbutton', function(e) {
                $.ajaxSetup({
                    headers: {
                        "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr(
                            "content"
                        ),
                    },
                });
                var email = $('#user_email').val();
                var customer_id = $('#user_id').val();
                var first_name = $('#first_name').val();
                $.ajax({
                    type: "POST",
                    url: "{{ url('resend-email') }}",
                    data: {
                        'email': email,
                        'customer_id': customer_id,
                        'first_name': first_name,
                    },
                    dataType: "json",
                    success: function(response) {
                        if (response.status == 200) {
                            Notify("{{translation('EMAIL_SUCCESS_MSG')}}", true);
                        }
                    },
                    error: function(data) {
                        console.log(data);
                    },
                });
            });

            $("#ChangePasswordCheckbox").on("click",function() {
                $('#password').attr('required');
                $('#confirmpassword').attr('required');
                if ($("#ChangePasswordCheckbox").prop('checked') == true){
                $('#password').attr('required',' ');
                $('#confirmpassword').attr('required',' ');
                $('#password').addClass('form-control');
                $('#confirmpassword').addClass('form-control');
                }else
                {
                $('#password').removeAttr('required');
                $('#confirmpassword').removeAttr('required'); 
                }
                $(".password-section").toggle(1000);
            });
        });
         
        function checkPassword(e) {
            $('#ConfirmPasswordCheck').removeClass('d-none');
            e.stopPropagation();
        }
    </script>
@endpush
