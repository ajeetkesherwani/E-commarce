<div class="col-newsletter-popup col-content" style="background-image:url({{ getFullImageUrl(getSetting('newsletter_image')) }});">
    <button type="button" class="btn-close prdtbtn-close close close-popup" data-dismiss="modal" aria-label="Close">&times;</button>
    <div class="content-popup">
      <div class="content">
        <h2>{{ getSetting('newsletter_title') ?? '' }}</h2>
         <p class="mb-2">{{ getSetting('newsletter_subtitle') ?? '' }}</p>			
      </div>
      <form class="form needs-validation" novalidate id="newsltrModalForm" id="newsltrModalForm">
        <div class="field newsletter">
          <div class="control">
            <input name="email" class="form-control" required id="customeremail" type="email" id="newsletter-popup" placeholder="{{translation('NEWSLETTER_EMAIL_PLACEHOLDER')}}" >
          </div>
        </div>
        <div class="actions">
          <button class="action" id="modal_subscribe" title="Subscribe" type="submit">
            <span>{{translation('NEWSLETTER_SUBSCRIBE_BUTTON')}}</span>
          </button>
        </div>
      </form>	
      <span id="email_err" class="text-danger"></span> 
      <ul class="p-0 mt-4">

        @if (!empty(socialLinks('facebook_url')))
        <li><a href="{{ socialLinks('facebook_url') }}"><i class="fab fa-facebook-f"></i></a></li>
        @endif
        @if (!empty(socialLinks('twitter_url')))
        <li><a href="{{ socialLinks('twitter_url') }}"><i class="fab fa-twitter"></i></a></li>
        @endif
        @if (!empty(socialLinks('linkedin_url')))
        <li><a href="{{ socialLinks('linkedin_url') }}"><i class="fab fa-linkedin-in"></i></a></li>
        @endif
        @if (!empty(socialLinks('pinterest_url')))
        <li><a href="{{ socialLinks('pinterest_url') }}"><i class="fab fa-pinterest-p"></i></a></li>
        @endif
        @if (!empty(socialLinks('instagram_url')))
        <li><a href="{{ socialLinks('instagram_url') }}"><i class="fab fa-instagram"></i></a></li>
        @endif
        @if (!empty(socialLinks('youtube_url')))
        <li><a href="{{ socialLinks('youtube_url') }}"><i class="fab fa-youtube"></i></a></li>
        @endif

      </ul>
    </div>
</div>