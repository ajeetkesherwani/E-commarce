@php

$main_arr = [
'title'=>'Checkout Page',
'sublist' => [
[
'name'=>'HOME',
'link'=>url("/")
],
[
'name'=>'checkout',
'link'=>url("")
],
]
];
@endphp

<x-Theme1.SharedComponent.BreadCrumb :data="$main_arr" />
<!-- Breadcrumb Area End -->
<!-- checkout area start -->
<div class="checkout-area mt-60px mb-40px">
    <form action="{{ route('placeOrder') }}" method="POST" id="placeOrderForm" novalidate="novalidate">
        @csrf
        <div class="container">
            <div class="row">
                <div class="col-lg-7">
                    <div class="billing-info-wrap">
                        <h3>Billing Details</h3>

                        @if(!empty($addressList) && sizeof($addressList) > 0)
                        <div class="row">
                            <div class="col-md-12">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Default Address</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($addressList as $addressList)
                                        <tr>
                                            <td>
                                                <input type="radio" name="default_address" class="default_address"
                                                    id="add_{{$addressList->address_id}}"
                                                    value='<?php echo json_encode($addressList); ?>' />
                                                <label for="add_{{ $addressList->address_id }}">
                                                    &nbsp;&nbsp;&nbsp;
                                                    {{ $addressList->street_address.', '. $addressList->city.',
                                                    '.$addressList->state }},
                                                    {{ $addressList->country_name.'-'. $addressList->zipcode }}

                                                    {{ $addressList->phone}}
                                                </label>

                                            </td>
                                        </tr>
                                        @endforeach

                                    </tbody>
                                </table>
                            </div>
                        </div>
                        @endif

                        <div class="row">
                            <div class="col-lg-6 col-md-6">
                                <div class="billing-info mb-20px">
                                    <label>First Name</label>
                                    <input type="text" name="customer_name" class="form-control" value="{{old('customer_name')}}"/>
                                    @if ($errors->has('customer_name'))
                                    <span class="text-danger">{{ $errors->first('customer_name') }}</span>
                                    @endif
                                </div>
                            </div>

                            <div class="col-lg-6 col-md-6">
                                <div class="billing-info mb-20px">
                                    <label>Last Name</label>
                                    <input type="text" name="customer_last_name"
                                        value="{{old('customer_last_name')}}" class="form-control"/>
                                    @if ($errors->has('customer_last_name'))
                                    <span class="text-danger">{{ $errors->first('customer_last_name') }}</span>
                                    @endif
                                </div>
                            </div>

                            <div class="col-lg-12">
                                <div class="billing-info mb-20px">
                                    <label>Email Address</label>
                                    <input type="text" name="customer_email" value="{{old('customer_email')}}" />
                                    @if ($errors->has('customer_email'))
                                    <span class="text-danger">{{ $errors->first('customer_email') }}</span>
                                    @endif
                                </div>
                            </div>

                            {{-- <div class="col-lg-12">
                                <div class="billing-info mb-20px">
                                    <label>Company Name</label>
                                    <input type="text" name="customer_company" value="{{old('customer_company')}}" />
                                    @if ($errors->has('customer_company'))
                                    <span class="text-danger">{{ $errors->first('customer_company') }}</span>
                                    @endif
                                </div>
                            </div> --}}

                            <div class="col-lg-12">
                                <div class="billing-info mb-20px">
                                    <label>Street Address</label>
                                    <input class="billing-address" value="{{old('customer_address')}}"
                                        placeholder="House number and street name" type="text"
                                        name="customer_address" />
                                    @if ($errors->has('customer_address'))
                                    <span class="text-danger">{{ $errors->first('customer_address') }}</span>
                                    @endif
                                </div>

                            </div>
                            <div class="col-lg-12">
                                <div class="billing-info mb-20px">
                                    <label>Town / City</label>
                                    <input type="text" name="customer_city" value="{{old('customer_city')}}" />
                                    @if ($errors->has('customer_city'))
                                    <span class="text-danger">{{ $errors->first('customer_city') }}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6">
                                <div class="billing-info mb-20px">
                                    <label>State / County</label>
                                    <input type="text" name="customer_state" value="{{old('customer_state')}}" />
                                    @if ($errors->has('customer_state'))
                                    <span class="text-danger">{{ $errors->first('customer_address') }}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6">
                                <div class="billing-info mb-20px">
                                    <label>Postcode / ZIP</label>
                                    <input type="text" name="customer_postcode" value="{{old('customer_postcode')}}" />
                                    @if ($errors->has('customer_postcode'))
                                    <span class="text-danger">{{ $errors->first('customer_postcode') }}</span>
                                    @endif
                                </div>
                            </div>
                            {{-- <div class="col-lg-12">
                                @if(!empty($countries))
                                <div class="billing-select mb-20px">
                                    <label>Country</label>
                                    <select name="customer_country" class="form-control">
                                        <option selected valsue="" disabled>Select a country</option>
                                        @foreach($countries as $key=>$country)
                                        <option value="{{$country->countries_name ?? ''}}">{{$country->countries_name ??
                                            ''}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                @if ($errors->has('customer_country'))
                                <span class="text-danger">{{ $errors->first('customer_country') }}</span>
                                @endif
                                @endif
                            </div> --}}
                            <div class="col-lg-6 col-md-6">
                                <div class="billing-info mb-20px">
                                    <label>Phone</label>
                                    <input type="text" name="customer_phone" value="{{old('customer_phone')}}" />
                                    @if ($errors->has('customer_phone'))
                                    <span class="text-danger">{{ $errors->first('customer_phone') }}</span>
                                    @endif
                                </div>
                            </div>
                            
                        </div>
                        <div class="checkout-account mt-25">
                            <input class="checkout-toggle is_shipping_diff_box" type="checkbox"
                                name="is_shipping_diff" />
                            <label>Ship to a different address?</label>
                        </div>
                        <div class="different-address open-toggle mt-30">
                            <div class="row">
                                <div class="col-lg-6 col-md-6">
                                    <div class="billing-info mb-20px">
                                        <label>First Name</label>
                                        <input type="text" name="shipping_customer_name"
                                            value="{{old('shipping_customer_name')}}" class="form-con" />
                                        @if ($errors->has('shipping_customer_name'))
                                        <span class="text-danger">{{ $errors->first('shipping_customer_name') }}</span>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <div class="billing-info mb-20px">
                                        <label>Last Name</label>
                                        <input type="text" name="shipping_customer_last_name"
                                            value="{{old('shipping_customer_last_name')}}" />
                                        @if ($errors->has('shipping_customer_last_name'))
                                        <span class="text-danger">{{ $errors->first('shipping_customer_last_name')
                                            }}</span>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="billing-info mb-20px">
                                        <label>Email Address</label>
                                        <input type="text" name="shipping_customer_email"
                                            value="{{old('shipping_customer_email')}}" />
                                        @if ($errors->has('shipping_customer_email'))
                                        <span class="text-danger">{{ $errors->first('shipping_customer_email') }}</span>
                                        @endif
                                    </div>
                                </div>
                                {{-- <div class="col-lg-12">
                                    <div class="billing-info mb-20px">
                                        <label>Company Name</label>
                                        <input type="text" name="shipping_customer_company"
                                            value="{{old('shipping_customer_company')}}" />
                                        @if ($errors->has('shipping_customer_company'))
                                        <span class="text-danger">{{ $errors->first('shipping_customer_company')
                                            }}</span>
                                        @endif
                                    </div>
                                </div> --}}
                                {{-- <div class="col-lg-12">
                                    @if(!empty($countries))
                                    <div class="billing-select mb-20px">
                                        <label>Country</label>
                                        <select name="shipping_customer_country" class="form-control" required>
                                            <option selected value="" disabled>Select a country</option>
                                            @foreach($countries as $key=>$country)
                                            <option value="{{$country->countries_name ?? ''}}">
                                                {{$country->countries_name ?? ''}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    @endif
                                    @if ($errors->has('shipping_customer_country'))
                                    <span class="text-danger">{{ $errors->first('shipping_customer_country') }}</span>
                                    @endif
                                </div> --}}
                                <div class="col-lg-12">
                                    <div class="billing-info mb-20px">
                                        <label>Street Address</label>
                                        <input class="billing-address" placeholder="House number and street name"
                                            value="{{old('shipping_customer_address')}}" type="text"
                                            name="shipping_customer_address" />
                                        @if ($errors->has('shipping_customer_address'))
                                        <span class="text-danger">{{ $errors->first('shipping_customer_address')
                                            }}</span>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="billing-info mb-20px">
                                        <label>Town / City</label>
                                        <input type="text" name="shipping_customer_city"
                                            value="{{old('shipping_customer_city')}}" />
                                        @if ($errors->has('shipping_customer_city'))
                                        <span class="text-danger">{{ $errors->first('shipping_customer_city') }}</span>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <div class="billing-info mb-20px">
                                        <label>State / County</label>
                                        <input type="text" name="shipping_customer_state"
                                            value="{{old('shipping_customer_state')}}" />
                                        @if ($errors->has('shipping_customer_state'))
                                        <span class="text-danger">{{ $errors->first('shipping_customer_state') }}</span>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <div class="billing-info mb-20px">
                                        <label>Postcode / ZIP</label>
                                        <input type="text" name="shipping_customer_postcode"
                                            value="{{old('shipping_customer_postcode')}}" />
                                        @if ($errors->has('shipping_customer_postcode'))
                                        <span class="text-danger">{{ $errors->first('shipping_customer_postcode')
                                            }}</span>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <div class="billing-info mb-20px">
                                        <label>Phone</label>
                                        <input type="text" name="shipping_customer_phone"
                                            value="{{old('shipping_customer_phone')}}" />
                                        @if ($errors->has('shipping_customer_phone'))
                                        <span class="text-danger">{{ $errors->first('shipping_customer_phone') }}</span>
                                        @endif
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                        <div class="additional-info-wrap">
                            <h4>Additional information</h4>
                            <div class="additional-info">
                                <label>Order notes</label>
                                <textarea placeholder="Notes about your order, e.g. special notes for delivery. "
                                    name="note"></textarea>
                            </div>
                        </div>
                    </div>
                    {{-- Shipping Method --}}
                    {{-- @php
                    dd($shippingMethodList);
                    @endphp --}}
                    {{--
                    @if (!empty($shippingMethodList) && sizeof($shippingMethodList) > 0 )
                    <div class="payment-method">
                        <div class="payment-accordion element-mrg">
                            <div class="panel-group" id="accordion">
                                <div class="panel payment-accordion">
                                    <div class="panel-heading" id="method-one">
                                        <h6> Choose Shipping Type ( In Development )</h6>
                                    </div>
                                    <div id="method1" class="panel-collapse collapse show m-4">
                                        <div class="panel-body">
                                            <div class="row">
                                                @foreach ($shippingMethodList as $shipping)
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="{{ $shipping->method_key }}_id">
                                                            <img src="{{getSuperFullImageUrl($shipping->method_logo)}}"
                                                                alt="{{ $shipping->method_name }}"
                                                                class="img-round ship-img" height="40">
                                                        </label>
                                                        {{ $shipping->method_name }} <input type="radio"
                                                            name="shipping_method" class="ship-radio-choose mt-4"
                                                            id="{{ $shipping->method_key }}_id"
                                                            value="{{ $shipping->method_key }}">
                                                    </div>
                                                </div>
                                                @endforeach
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                    @else
                    <input type="radio" name="payment_method" value="cod">
                    @endif --}}

                    {{-- Shipping Method End --}}
                </div>
                <div class="col-lg-5">
                    <div class="your-order-area">
                        <h3>Your order</h3>
                        <div class="your-order-wrap gray-bg-4">
                            <div class="your-order-product-info">
                                <div class="your-order-top">
                                    <ul>
                                        <li>Product</li>
                                        <li>Total</li>
                                    </ul>
                                </div>
                                <div class="your-order-middle">
                                    <ul>
                                        
                                        @if (!empty($list['cart_list']))
                                        @foreach ($list['cart_list'] as $cart )
                                        <li>
                                            <span class="order-middle-left">
                                                {{ $cart->product->products_name ?? ''}} X {{ $cart->qty }}
                                            </span>
                                            <span class="order-price">
                                                @php
                                                $qty = (int) $cart->qty;
                                                $price = $cart->final_price ?? 0;
                                                echo currencyFormat($qty*$price);
                                                @endphp
                                            </span>
                                        </li>
                                        @endforeach
                                        @else
                                        @endif
                                    </ul>
                                </div>
                                <div class="your-order-bottom">
                                    <div class="your-order-top">
                                        <ul>
                                            <li>Shipping</li>
                                        </ul>
                                    </div>
                                    <div class="your-order-middle">
                                        <ul class="w-100 d-block">
                                            @if (!empty($shippingMethodList) && sizeof($shippingMethodList) > 0 )
                                            @foreach ($shippingMethodList as $shipping)
                                            <li>
                                                <span class="order-middle-left">
                                                    {{-- <span class="order-price"> --}}
                                                        <input type="radio" name="shipping_method"
                                                            class="ship-radio-choose mt-4"
                                                            id="{{ $shipping->method_key }}_id"
                                                            value="{{ $shipping->method_key }}"> {{
                                                        $shipping->method_name }}
                                                        {{-- </span> --}}
                                                    {{-- <label for="{{ $shipping->method_key }}_id">
                                                        <img src="{{getSuperFullImageUrl($shipping->method_logo)}}"
                                                            alt="{{ $shipping->method_name }}"
                                                            class="img-round ship-img" height="40">
                                                    </label> --}}
                                                </span>
                                            </li>
                                            @endforeach
                                            @else
                                            <input type="radio" name="payment_method" value="cod">
                                            @endif
                                        </ul>
                                    </div>
                                    <ul id="shippingHtml">

                                    </ul>
                                </div>
                                <div class="your-order-total">
                                    <ul>
                                        <li class="order-total">Total</li>
                                        <li>{{ currencyFormat($list['grand_total']) }}</li>
                                    </ul>
                                </div>
                            </div>
                            <!-- payment -->
                            @if (!empty($paymentList) && sizeof($paymentList) > 0 )
                            <div class="payment-method">
                                <div class="payment-accordion element-mrg">
                                    <div class="panel-group" id="accordion">
                                        <div class="panel payment-accordion">
                                            <div class="panel-heading" id="method-one">
                                                <h4 class="panel-title">
                                                    <a data-bs-toggle="collapse" data-parent="#accordion">
                                                        Choose payment type ( In Development )
                                                    </a>
                                                </h4>
                                            </div>
                                            <div id="method1" class="panel-collapse collapse show">
                                                <div class="panel-body">
                                                    <div class="row">
                                                        @foreach ($paymentList as $payment)
                                                        <div
                                                            class="col-md-{{ (strtolower($payment->method_key) == 'stripe') ? 12 : 6 }}">
                                                           
                                                            <div class="form-group d-flex">
                                                                <input type="radio" name="payment_method"
                                                                        class="payment-radio-choose payment-type"
                                                                        id="{{ $payment->method_key }}_id"
                                                                        value="{{ $payment->payment_method_id }}">
                                                                    <label for="{{ $payment->method_key }}_id">
                                            
                                                                    </label>
                                                                    <div class="d-flex"> 
                                                                        <img src="{{getSuperFullImageUrl($payment->method_logo)}}"
                                                                        alt="{{ $payment->method_name }}"
                                                                        class="img-round payment-img " height="40"></div>
                                                            </div>
                                                            {{-- @if(strtolower($payment->method_key) == 'stripe')
                                                            <div id="stripe_card">
                                                                @include('payment.stripe')
                                                            </div>
                                                            @endif --}}
                                                        </div>
                                                        @endforeach
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            @else
                            <input type="radio" name="payment_method" value="cod">
                            @endif
                            <!-- payment end -->

                        </div>
                        <div class="Place-order mt-25">
                            <button type="submit" class="btn-hover form-control">Place Order</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>



{{-- <!-- The Modal -->
<div class="modal" id="myModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Modal body -->
            <div class="modal-body">
                @include('payment.stripe')
            </div>

            <!-- Modal footer -->
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
            </div>

        </div>
    </div>
</div>
 --}}


@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
<script>
    $(document).ready(function () {
        $('#stripe_card').hide();
        $('#placeOrderForm').validate({
            rules: {
                customer_name: {
                    required: true
                },
                customer_last_name: {
                    required: true
                },
                customer_company: {
                    required: true
                },
                customer_country: {
                    required: true
                },
                customer_address: {
                    required: true
                },
                customer_city: {
                    required: true
                },
                customer_state: {
                    required: true
                },
                customer_postcode: {
                    required: true
                },
                customer_phone: {
                    required: true
                },
                customer_email: {
                    required: true
                },
                shipping_customer_name: {
                    required: true
                },
                shipping_customer_last_name: {
                    required: true
                },
                shipping_customer_company: {
                    required: true
                },
                shipping_customer_country: {
                    required: true
                },
                shipping_customer_address: {
                    required: true
                },
                shipping_customer_city: {
                    required: true
                },
                shipping_customer_state: {
                    required: true
                },
                shipping_customer_postcode: {
                    required: true
                },
                shipping_customer_phone: {
                    required: true
                },
                shipping_customer_email: {
                    required: true
                },

            },
            errorElement: 'span',
            errorPlacement: function(error, element) {
                error.addClass('invalid-feedback');
                // element.closest('.billing-info').append(error);
            },
            highlight: function(element, errorClass, validClass) {
                $(element).addClass('is-invalid');
                $(element).css("border", " 1px solid red")
            },
            unhighlight: function(element, errorClass, validClass) {
                $(element).removeClass('is-invalid');
                $(element).css("border", "1px solid #ebebeb")
            }


        });



        $(document).on('click', '.default_address', function () {
            var detail = JSON.parse($(this).val());
            console.log('detail', detail);
            $('input[name="customer_name"]').val();
            $('input[name="customer_last_name"]').val();
            $('input[name="customer_company"]').val();
            $('select[name="customer_country"]').val(detail.country_name);
            $('input[name="customer_address"]').val(detail.street_address);
            $('input[name="customer_city"]').val(detail.city);
            $('input[name="customer_state"]').val(detail.state);
            $('input[name="customer_postcode"]').val(detail.zipcode);
            $('input[name="customer_phone"]').val(detail.phone);
            $('input[name="customer_email"]').val();

        });

        $(document).on('click', '.payment-img', function () {
            $('.payment-img').removeClass('activePayment');         // removew old one
            $(this).addClass('activePayment');                      // add new one
        });

        // payment show hide

        // $(document).on('click', '.payment-type', function () {     
        //     $pay_method=$(this).val();   
        //     if($pay_method=='stripe') 
        //     {
        //         $('#stripe_card').show('slow');
        //     }
        //     else
        //     {
        //         $('#stripe_card').hide('slow');
        //     }                    
        // });

        //Shipping ajax

        $(document).on('change', '.ship-radio-choose', function () {
            var methodKey = $(this).attr('value');
            var url = `{{url('shipping-details/${methodKey}')}}`;

            $.ajax({
                url: url,
                type: "GET",
                success: function (response) {
                    console.log(response);
                    $('#shippingHtml').html("");
                    $('#shippingHtml').html(response.shippingHtml);
                }
            });
        });

    });
</script>
@endpush