@php

$main_arr = [
  'title'=>'',
  'sublist' => [
    [
    'name'=>translation('HOME'),
    'link'=>url("/")
    ],
    [
    'name'=>translation('CONTACT'),
    'link'=>url()->full()
    ], 
  ]
];
@endphp

<<!-- Breadcrumb Area start -->
<x-Ecom03.SharedComponent.BreadCrumb :data="$main_arr" /> 
<!-- Breadcrumb Area End -->
<div class="container mb-5">
    <div class="row mb-2">
        <div class="col-md-8 col-xl-9">
            <div class="mr-xl-6">
                <div class="contact-title mb-30">
                    {{-- <h2>@lang('pages.contactus.pageName')</h2> --}}
                </div>
                <div class="border-bottom border-color-1 mb-5">
                    <h3 class="section-title mb-0 pb-2 font-size-25">{{translation('CONTACT_TITLE')}}</h3>
                </div>
                <form class="js-validate" id="contact-form" novalidate="novalidate">
                    <div class="row">
                        <div class="col-md-6">
                            <!-- Input -->
                            <div class="js-form-message mb-4">
                                <label class="form-label">
                                    {{ translation('NAME') }}
                                    <span class="text-danger">*</span>
                                </label>
                                <input type="text" class="form-control" name="firstName" placeholder="" aria-label="" required="" data-msg="{{translation('ERROR_NAME')}}" id="name" data-error-class="u-has-error" data-success-class="u-has-success" autocomplete="off">
                                <span class="text-danger" id="customers_name" ></span>
                                @if ($errors->has('name'))
                                <span class="text-danger">{{ $errors->first('name') }}</span>
                                @endif
                            </div><!-- End Input -->
                        </div>
                        <div class="col-md-6">
                            <!-- Input -->
                            <div class="js-form-message mb-4">
                                <label class="form-label">
                                {{ translation('EMAIL') }}
                                    <span class="text-danger">*</span>
                                </label>
                                <input type="email" class="form-control" name="lastName" placeholder="" aria-label="" required="" id="email" data-msg="{{translation('ERROR_EMAIL')}}" data-error-class="u-has-error" data-success-class="u-has-success">
                                <span class="text-danger" id="email_address" ></span>
                                @if ($errors->has('email'))
                                <span class="text-danger">{{ $errors->first('email') }}</span>
                                @endif
                            </div><!-- End Input -->
                        </div>
                        <div class="col-md-12">
                            <!-- Input -->
                            <div class="js-form-message mb-4">
                                <label class="form-label">
                                {{ translation('PHONE') }} <span class="text-danger">*</span>
                                </label>
                                <input type="text" class="form-control" id="phone" name="phone" placeholder="" aria-label="" data-msg="{{translation('ERROR_PHONE')}}" required data-error-class="u-has-error" data-success-class="u-has-success">
                                <span class="text-danger" id="subject" ></span>
                                @if ($errors->has('subject'))
                                <span class="text-danger">{{ $errors->first('Phone') }}</span>
                                @endif
                            </div><!-- End Input -->
                        </div>
                        <div class="col-md-12">
                            <div class="js-form-message mb-4">
                                <label class="form-label">
                                {{ translation('MESSAGE') }}
                                </label>
                                <div class="input-group">
                                    <textarea class="form-control" id="messages" name="text" placeholder="" ></textarea>
                                    <span class="text-danger" id="message" ></span>
                                    @if ($errors->has('message'))
                                    <span class="text-danger">{{ $errors->first('message') }}</span>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <button type="button" class="btn btn-primary-dark-w px-5 contact_form" id="contactusbtn">{{ translation('SUBMIT') }}</button>
                        <input type="reset" hidden id="configreset" value="Reset">
                    </div>
                </form>
                {{-- {!!shortCodeToForm('FORM_CONTACT')!!} --}}
            </div>
        </div>
        <div class="col-md-4 col-xl-3">
            <div class="border-bottom border-color-1 mb-5">
                <h3 class="section-title mb-0 pb-2 font-size-25">{{ translation('CONTACT_ADDRESS') }}</h3>
            </div>
            <div class="mr-xl-6">
                <address class="mb-6">
                    {{getSetting('contact_address')}} {{getSetting('contact_city')}} {{getSetting('contact_state')}}  {{$countryName->countries_name ?? ''}}
                    <p class="text-gray-90">email us:
                        <a class="text-blue text-decoration-on " href="mailto:{{ getSetting('contact_email') }}">
                            {{ getSetting('contact_email')}}
                        </a>
                    </p>
                </address>
            </div>
        </div>
    </div><!-- contact area end -->
</div><!-- end container-->

@push('scripts')
<script>
    $(document).ready(function(e){
        $(document).on('click', '#contactusbtn', function (e) {
            e.preventDefault();
            $('#contact-form').addClass('was-validated');
            if ($('#contact-form')[0].checkValidity() === false) {
                event.stopPropagation();
            } else {
                var data = {
                    'customers_name': $('#name').val(),
                    'email_address': $('#email').val(),
                    'phone': $('#phone').val(),
                    'message': $('#messages').val(),
                }
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "/contactstore",
                    data: data,
                    dataType: "json",
                    beforeSend: function() {
                    $("#contactusbtn").addClass('disabled');
                        var html = '<i class="fa-solid fa-spinner fa-spin-pulse"></i> {{translation('SUBMITTING')}}...';
                        $("#contactusbtn").html(html);
                    },
                    success: function (response) {
                        if (response.status == 400) {
                            $.each(response.error, function (key, err_val) {
                                $('#' + key).text(err_val);
                            });
                        }
                        else {
                            Notify('{{translation('CONTACT_SUCCESS_MSG')}}', true);
                            $('#contact-form').trigger("reset");
                        }
                    },
                    complete: function(response) {
                        $('#contactusbtn').removeClass('disabled');
                        $('#contact-form').removeClass('was-validated');
                        $('#contactusbtn').html('{{translation('SUBMIT')}}');
                    }
                });
           }
        });
    });
</script>
@endpush