@php
$main_arr = [
'title'=>'',
'sublist' => [
[
'name'=>translation('HOME'),
'link'=>url("/")
],
[
'name'=>translation('WISHLIST'),
'link'=>url()->full()
],
]
];
@endphp
<style>
    td .btn a {
        color: grey;
    }

    td .btn:hover a {
        color: white;
    }
</style>
<!-- Breadcrumb Area start -->
<x-Ecom03.SharedComponent.BreadCrumb :data="$main_arr" />
<!-- Breadcrumb Area End -->
<div class="container wishlist-table">
    <div class="my-6">
        {{-- <h1 class="text-center">{{translation('WISHLIST_TITLE')}} {{getSetting('site_title')}}</h1> --}}
        <h1 class="text-center">{{translation('WISHLIST_TITLE')}}</h1>
    </div>
    <div class="mb-16" id="wishlist-table">
        @if (!empty($wishlist_item) && sizeof($wishlist_item)>0)
        <form class="mb-4" action="#" >
            <div class="table-responsive">
                <table class="table" cellspacing="0">
                    <thead>
                        <tr>
                            <th class="product-remove">&nbsp;</th>
                            <th class="product-thumbnail">&nbsp;</th>
                            <th class="product-name">{{translation('WISHLIST_PRODUCT_NAME')}}</th>
                            <th class="product-price">{{translation('WISHLIST_UNIT_PRICE')}}</th>
                            <th class="product-Stock w-lg-15">{{translation('WISHLIST_PRODUCT_SKU')}}</th>
                            <th class="product-subtotal min-width-200-md-lg">&nbsp;</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($wishlist_item as $key=>$data )
                        <tr id="wishlist-table_{{$data->wishlist_id}}">
                            <td class="text-center">
                                <a href="javascript:void(0);" class="text-gray-32 font-size-26"
                                    onclick="actionOnWishlist({{$data->wishlist_id}})">×</a>
                            </td>
                            <td class="d-none d-md-table-cell">
                                <a href="{{url('product/'.$data->product->product_slug)}}"><img
                                        class="img-fluid max-width-100 p-1 border border-color-1"
                                        src="{{getFullImageUrl($data->product->product_image)}}"
                                        onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                                        alt="{{ $data->product->products_name ?? ''}}"></a>
                            </td>
                            <td data-title="Product">
                                <a href="{{url('product/'.$data->product->product_slug)}}" class="text-gray-90">{{
                                    $data->product->products_name ?? ''}}</a>
                            </td>
                            <td data-title="Unit Price">
                                <span class="">{{ currencyFormat($data->product->sale_price ?? 0)}}</span>
                            </td>
                            <td data-title="Stock Status">
                                <span>{{ $data->product->product_sku ?? ''}}</span>
                            </td>
                            <td>
                                <a  href="{{url('product/'.$data->product->product_slug)}}" role="button"
                                    class="btn btn-soft-secondary mb-3 mb-md-0 font-weight-normal px-5 px-md-4 px-lg-5 w-100 w-md-auto">
                                    {{translation('WISHLIST_VIEW_BUTTON')}}
                                </a>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </form>
        @else
        <img src="{{ LoadAssets('assets/img/EmptyImages/Wishlist-Empty.png')}}"
            onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
            class="rounded mx-auto d-block" height="200px" alt="{{getSetting('site_title')}} Wishlist-Empty">
        <p class="h4 text-center text-dark mt-3">{{translation('EMPTY_WISHLIST_MSG')}} </p>
        <div class="text-center my-3">
            <a href="{{url('/')}}" class="btn btn-primary-dark-w btn-sm" role="button" aria-pressed="true">{{translation('CONTINUE_TO_SHOP')}}</a>
            @endif
        </div>
        
    </div>
    <!-- Brand Carousel -->
    <x-Ecom03.SharedComponent.BrandSlider />
    <!-- End Brand Carousel -->
</div>
@push('scripts')
    <script>
        function actionOnWishlist(wishlist_id) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url: '{{ route("inDelWishlist") }}',
                method: 'POST',
                data: {
                    wishlist_id: wishlist_id,
                },
                success: function (response) {
                    $('#wishlist-table_'+wishlist_id).hide();
                    $('.count-wishlist-total').text(response.wish_list_item_count);
                    console.log(response.wish_list_item_count);
                    if(response.wish_list_item_count<1){
                    var html =`<img src="{{ LoadAssets('assets/img/EmptyImages/Wishlist-Empty.png')}}" 
                                onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" class="rounded mx-auto d-block" height="200px" alt="{{getSetting('site_title')}} Wishlist-Empty">
                                <p class="h4 text-center text-dark mt-3">{{translation('EMPTY_WISHLIST_MSG')}}</p>
                                <div class="text-center my-3">
                                <a href="{{url('/')}}" class="btn btn-primary-dark-w btn-sm" role="button" aria-pressed="true">{{translation('CONTINUE_TO_SHOP')}}</a>
                                </div>`;
                        $('.wishlist-table').html(html);
                    }
                    Notify("{{translation('WISHLIS_ITEM_REMOVED_MSG')}}!", true);
                },
                error: function (error) {
                    Notify(error.message, false);
                }
            });

        }

    </script>
    @endpush