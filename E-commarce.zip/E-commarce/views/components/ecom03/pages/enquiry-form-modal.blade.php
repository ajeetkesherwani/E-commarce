<div class="row modal-body">
    <div class="row p-2">
      <div class="col">
        <input type="text" value="{{ $products->products_name ?? '' }}" class="form-control" name="products_qty" placeholder="Qty Needed" aria-label="qty">
      </div>
      <div class="col">
        <input type="email" class="form-control" name="email_address" placeholder="Your Email" aria-label="email">
      </div>
    </div>
    <div class="row p-2">
      <div class="col">
        <input type="text" name="customers_name" class="form-control" placeholder="Your Name" >
      </div>
      <div class="col">
        <input type="text" class="form-control" name="company_name" placeholder="Company Name" >
      </div>
    </div>
    <div class="row p-2">
      <div class="col">
        <select class="form-select" aria-label="Default select example">
          <option selected>Open this select menu</option>
          <option value="1">One</option>
          <option value="2">Two</option>
          <option value="3">Three</option>
        </select>
      </div>
      <div class="col">
        <input type="file" name="enquiry_file" class="form-control" placeholder="Last name" aria-label="Last name">
      </div>
    </div>
    <div class="row p-2">
      <div class="col">
        <select class="form-select" aria-label="Default select example">
          <option selected>Size</option>
          <option value="1">One</option>
          <option value="2">Two</option>
          <option value="3">Three</option>
        </select>
      </div>
      <div class="col">
        <select class="form-select" aria-label="Default select example">
          <option selected>COlor</option>
          <option value="1">One</option>
          <option value="2">Two</option>
          <option value="3">Three</option>
        </select>
      </div>
    </div>
    <div class="row p-2">
      <div class="col">
        <input type="text" class="form-control" name="phone" placeholder="phone" >
      </div>
    </div>
    <div class="row p-2">
      <div class="col">
        <input type="text" name="subject" class="form-control" placeholder="Enquiry Subject" aria-label="Enquiry Message"></textarea>
      </div>
    </div>
    <div class="row p-2">
      <div class="col">
        <textarea type="text" name="message" class="form-control" placeholder="Enquiry Message" aria-label="Enquiry Message"></textarea>
      </div>
    </div>
    <div class="row p-2">
      <div class="col">
        <input type="checkbox" name="newsletter" id="myCheck" onclick="myFunction()">
        <label for="myCheck">(Newsletter) Free Marketing Tips</label>
      </div>
      <div class="col">
        <div class="txt-right prdttxt-right">
          <button type="button" class="btn btn-primary" id="enquiryformbutton">Submit</button>
        </div>
      </div>
    </div>
    <div class="modal-footer prdtmodal-footer"> </div>
  </div>

