  <div class="text-center thankyou_wrapper mt-5">
    <h2 class="fw-bold">{{translation('ORDER_THANK_YOU_MSG')}}</h2>
    <h5>{{translation('ORDER_SUCCESS_MSG')}}</h5>
    <div class="pb-3">
        <p class="mb-0">{{translation('ORDER_NUMBER')}} : <strong class="font-dark">{{$list->order_number}}</strong></p>
        <p class=" mb-0">{{translation('ORDER_SUCCESS_NOTE')}}</p>
        <p class=" mb-0">
            <a href="mailto:{{getSetting('contact_email')}}">
            {{getSetting('contact_email')}} </a> {{ translation('CALL_US') }}<a href="tel:{{getSetting('contact_phone')}}">
                {{getSetting('contact_phone')}}</a>
         </p>
    </div>
    <div class="col-2 mx-auto mb-5">
        <a href="{{url('/order/'.$list->order_number.'/download-invoice')}}" class="btn btn-primary-dark-w  btn-block">{{translation('ORDER_DOWNLOAD_INVOICE')}}</a>  
    </div>
                      
</div>