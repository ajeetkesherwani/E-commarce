    <div class="tab-pane fade pt-2 show active" id="pills-two-example1" role="tabpanel" aria-labelledby="pills-two-example1-tab" data-target-group="groups">
    <ul class="row list-unstyled products-group no-gutters">
         @if (!empty($products) && sizeof($products) > 0)
        {{-- Here htl code come from component with grid view --}}
        @foreach ($products as $product)
            {{-- Here htl code come from component with grid view --}}
            <x-ecom03.shared-component.product  viewtype="grid" :data="$product" />
        @endforeach
        @else
        <img src="{{ LoadAssets('assets/images/EmptyImages/Wishlist-Empty.png') }}"
            class="rounded mx-auto d-block" width="286px" height="200px"
            onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
            alt="{{ getSetting('site_title') }} Wishlist-Empty">
        <p class="h4 text-center text-dark mt-3">
            Opps!! There is no product avaliable for this category.
        </p>
        <div class="text-center my-3">
            <a href="{{ url('/') }}" class="btn btn-primary btn-lg btn-block" role="button"
                aria-pressed="true">Continue to shop</a>
        </div>
        @endif
    </ul>
</div>
<div class="tab-pane fade pt-2" id="pills-three-example1" role="tabpanel" aria-labelledby="pills-three-example1-tab" data-target-group="groups">
    <ul class="d-block list-unstyled products-group prodcut-list-view">
        @if (!empty($products) && sizeof($products) > 0)
        @foreach ($products as $product)
        {{-- Here html code come from component with List view --}}
        <x-ecom03.shared-component.product  :data="$product" viewtype="list"/>
          @endforeach
          @else
          <img src="{{ LoadAssets('assets/images/EmptyImages/Wishlist-Empty.png') }}" class="rounded mx-auto d-block" width="286px" height="        200px" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" alt="{{ getSetting('site_title') }}     Wishlist-Empty">
        <p class="h4 text-center text-dark mt-3">
                Opps!! There is no product avaliable for this
                category
        </p>
        <div class="text-center my-3">
            <a href="{{ url('/') }}" class="btn btn-primary btn-lg btn-block" role="button"
                aria-pressed="true">Continue to shop</a>
        </div>
        @endif
    </ul>
</div>

<!--  Pagination Area Start -->
{{-- <input type="hidden" id="nextPage" value="1">
<div class="pro-pagination-style text-center"> --}}
    {{-- Pagination --}}
    {{-- <div class="row">
        <div class="col-md-12 d-flex justify-content-center p-2">
            {{ $products->links('vendor.pagination.for-ajax') }}
        </div>
    </div>
</div> --}}
<!--  Pagination Area End -->