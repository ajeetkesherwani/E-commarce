@php
$main_arr = [
'title'=>'',
'sublist' => [
[
'name'=>translation('HOME'),
'link'=>url("/")
],
[
'name'=>translation('LOGIN'),
'link'=>url("/login")
],
[
'name'=>translation('FORGOT_PASSWORD'),
'link'=>url()->full()
],
]
];
@endphp
<!-- Breadcrumb Area start -->
<x-Ecom03.SharedComponent.BreadCrumb :data="$main_arr" /> 
<!-- Breadcrumb Area End -->
<!-- login area start -->
<div class="login-register-area my-0">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 col-sm-12 card mb-6 mt-6 mx-auto login-page  p-4 bg-white">
                    <div class="card border-0">
                        <div class="card-body">
                            <h4 class="card-title fw-bold text-center">{{ translation('FORGOT_PASSWORD') }}</h4> 
                            @if (session('status'))
                                <div class="alert alert-success">
                                    {{ session('status') }}
                                </div>
                            @endif

                            @error('success')
                                <strong class="text-danger" style="margin-top:-50px;">{{ $message }}</strong>
                            @enderror 
                            <form class="login-form mt-4" action="{{ route('password.email') }}" method="post" id="forgot"  novalidate="novalidate">
                                @csrf
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="mb-3">
                                            <label class="form-label fw-bold">{{ translation('EMAIL') }} <span class="text-danger">*</span></label>
                                            <div class="form-icon position-relative">
                                                <input type="email" class="form-control ps-3 @error('email') is-invalid @enderror" placeholder="{{ translation('EMAIL_PLACEHOLDER') }}" name="email" required>
                                            </div>
                                            @error('email')
                                                <strong class="text-danger mb-5">
                                                    {{ $message }}
                                                </strong>
                                            @enderror
                                        </div>
                                    </div><!--end col-->
                                    <div class="col-lg-5 mb-0 mx-auto mb-2">
                                        <div class="d-grid">
                                            <button type="submit" class="btn btn-primary-dark-w py-2 w-100" style="border:#ef1e1e; border-radius: 20px;" id="resetButton">{{translation('RESET_BUTTON')}}</button>
                                        </div>
                                    </div><!--end col-->
                                    <div class="col-12 text-center">
                                        
                                        <a href="{{url('/login')}}" class="text-dark fw-bold"><i class="fa fa-arrow-left" aria-hidden="true"></i>&nbsp;{{translation('BACK_TO_LOGIN_BUTON')}}</a>
                                    </div><!-- End Button -->
                                </div><!--end row-->
                            </form>
                        </div>
                    </div>
            </div>
        </div>
    </div>
</div>
<!--script start here-->
@push('scripts')
<script>
    $(document).ready(function() {
        $(document).on('click', '#resetButton', function(e) {
            e.preventDefault();
            $('#forgot').addClass('was-validated');
            if ($('#forgot')[0].checkValidity() === false) {
                event.stopPropagation();
            } 
            else {
                $('#forgot').validate({
                    rules: {
                        email: {
                            required: true,
                            email: true,
                            maxlength: 50
                        },
                    },
                    messages: {
                        email: {
                                required: "Please enter the email address",
                                email: "Email must be a valid email address",
                                maxlength: "Email cannot be more than 50 characters",
                            },
                        },
                    highlight: function(element) {
                        $(element).addClass('error');
                        $(".error").css("color", "red");
                        $(element).css("border", " 1px solid red")
                    }
                });
                $('#forgot').removeClass('was-validated');
                $('#forgot').submit();
            }
        });
    });
</script>
@endpush
<!-- script end-->