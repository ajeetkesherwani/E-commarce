@php 
$main_arr = [
'title'=>'',
'sublist' => [
[
'name'=>translation('HOME'),
'link'=>url("/")
],
[
'name'=>translation('DASHBOARD'),
'link'=>url("account/dashboard")
],
[
'name'=>translation('ORDERS'),
'link'=>url()->full()
],
]
];
@endphp
<!-- Breadcrumb Area start -->
<x-Ecom03.SharedComponent.BreadCrumb :data="$main_arr" /> 
<!-- Breadcrumb Area End -->
<div class="container myaccount-section">
  <div class="row ">
    <div class="col-xl-12 col-wd-12gdot5 mx-auto px-5">
      <div class="d-flex justify-content-between align-items-center my-3  border-bottom section-title">
        <div class="">
          <h3 class="text-black ">{{translation('ACCOUNT_ORDER_TITLE')}}</h3>
        </div>
        @if(!empty($orderdetails) && sizeof($orderdetails) > 0) 
          <div class="d-flex align-items-center">
            {{-- <a href="#" class="pr-2 text-black">{{translation('SEARCH_ORDER')}}</a> --}}
            <div>
                <input type="email" class="form-control py-2  height-40 " name="email" id="searchOrder" placeholder="{{translation('SEARCH_ORDER_PLACEHOLDER')}}" aria-label="Search for Products" aria-describedby="searchProduct1" required="">
            </div>
          </div>  
        @endif            
      </div>
      @if(!empty($orderdetails) && sizeof($orderdetails) > 0) 
        <div class="order-container search-product  mb-4  mt-3">
          @foreach($orderdetails as $key=>$data)  
            <div class="row mx-0 border mb-4">
              <div class="col-lg-12 border-bottom  order-header py-1 px-3">
                <div class="d-flex justify-content-between d-md-flex">
                  <div class="d-flex my-2 gap-2">
                      <div class="mr-2 font-weight-400">{{translation('ORDER_NO')}}</div>
                      <div class="font-weight-600">{{$data->order_number}}</div>
                  </div>
                  @switch($data->order_status)
                  @case(2)
                    <div class="d-flex my-2 gap-2">
                        <div class="mr-2 font-weight-400">{{translation('ORDER_STATUS')}}:</div>
                        <div class="font-weight:600">{{translation('IN_PROGRESS')}}</div>
                    </div>
                    @break
                    @case(3)
                    <div class="d-flex my-2 gap-2">
                      <div class="mr-2 font-weight-400" >{{translation('ORDER_STATUS')}}:</div>
                      <div class="font-weight-600">{{translation('DISPATCH')}}</div>
                    </div>
                    @break
                    @case(4)
                    <div class="d-flex my-2 gap-2">
                      <div class="mr-2 font-weight-400">{{translation('ORDER_STATUS')}}:</div>
                      <div class="font-weight-600">{{translation('DELIVERED')}}</div>
                    </div>
                    @break
                    @default
                    <div class="d-flex my-2 gap-2">
                      <div class="mr-2 font-weight-400">{{translation('ORDER_STATUS')}}:</div>
                      <div class="font-weight-600">{{translation('PENDING')}}</div>
                    </div>
                    @break
                  @endswitch
                  @switch($data->payment_status)
                  @case(1)
                    <div class="d-flex my-2 gap-2">
                        <div class="mr-2 font-weight-400" >{{translation('ORDER_PAYMENT_STATUS')}}:</div>
                        <div class="font-weight-600">{{translation('ORDER_PAID')}}</div>
                    </div>
                    @break
                    @case(2)
                    <div class="d-flex my-2 gap-2">
                      <div class="mr-2 font-weight-400">{{translation('ORDER_PAYMENT_STATUS')}}:</div>
                      <div class="font-weight-600">{{translation('ORDER_FAILED')}}</div>
                    </div>
                    @break
                    @default
                    <div class="d-flex my-2 gap-2">
                      <div class="mr-2 font-weight-400">{{translation('ORDER_PAYMENT_STATUS')}}:</div>
                      <div class="font-weight-600">{{translation('PENDING')}}</div>
                    </div>
                    @break
                  @endswitch
                  <div class="my-2 action_btn py-0" >
                      <a href="{{url('/account/'.$data->order_number.'/download-invoice')}}"  class="font-weight-600" style="color: #0035af;">Download Invoice</a>
                  </div>
                </div>
              </div>
              @if(!empty($data->item) && sizeof($data->item)>0)
                @foreach($data->item as $subdata) 
                  <div class="row pt-3 pb-2 mx-0 ">
                    <div class="col-lg-2">
                      <a href="{{ url('product/'.$subdata->product->product_slug) }}">
                        <img src="{{ getFullImageUrl($subdata->product->product_image) }}" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" " alt="product-img" class="img-fluid" style=" width: 60%;">
                      </a>
                    </div>
                    <div class="col-lg-5 product-order-content">
                
                          <div class="font-weight-400">{{$subdata->product_name}}</div>
                      
                      <div class="d-flex my-1 gap-2 ">
                          <div class="order-quantity ">
                            <div class="mr-2 font-weight-600">{{translation('QUANTITY')}}:</div>
                          </div>
                          <div>{{$subdata->qty}}</div>
                      </div>
                      <div class="d-flex my-1 gap-2 ">
                          <div class=""><strong class="mr-2 font-weight-600">{{translation('PRODUCT_SIZE')}}:</strong></div>
                          @if(!empty($subdata->attribute) && sizeof($subdata->attribute)>0)
                            @foreach($subdata->attribute as $attrdata)
                            @if(!empty($attrdata['Size']))
                              <div>{{$attrdata['Size']}}</div>
                            @endif
                            @endforeach
                          @endif
                      </div>
                    </div>
                    <div class="col-lg-3 text-center">{{ currencyFormat($subdata->total_price)}}</div>
                    <div class="col-lg-2 text-center ">
                      <div class="bg-gray  py-2 mb-2 action_btn " onclick="showOrderInvoiceModal('{{$data->order_number}}')"  style="background-color: #eaeaea !important;">
                          <a href="javascript:void(0);" class="text-dark d-block" style="font-weight: 600;
                              font-size: 14px;">{{translation('ORDER_DETAILS')}}</a>
                      </div>
                      <div class="mb-2" style="">
                        <a href="{{ url('product/'.$subdata->product->product_slug) }}" class="text-dark ">{{translation('ITEM_REORDER')}}</a>
                      </div>
                      <div class="mb-2"> 
                        <a href="#" class="text-dark ">{{translation('ORDER_TRACK')}}</a>
                      </div>
                    </div>
                  </div>
                @endforeach
              @endif
            </div>
          @endforeach
        </div>
      @else
        <div>
          <img src="{{ LoadAssets('assets/img/EmptyImages/Cart-Empty.jpg')}}" 
            onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
            class="rounded mx-auto d-block mb-5" height="200px" alt="{{getSetting('site_title')}} Wishlist-Empty">
            <p class="h4 text-center text-dark mt-3">{{translation('ORDER_EMPTY_MSG')}}</p>
            <div class="text-center my-3 mb-5">
            <a href="{{url('/')}}" class="btn btn-primary-dark-w  btn-sm" role="button" aria-pressed="true">{{ translation('CONTINUE_TO_SHOP') }}</a>
        </div>
      @endif
    </div>
  </div>
  <div class="row">
    <div class="col-md-12 d-flex justify-content-center p-2">
      {!! $orderdetails->links('vendor.pagination.theme3SimplePagination') !!}
    </div>
  </div>
  <!-- Brand Carousel -->
  <x-Ecom03.SharedComponent.BrandSlider />
  <!-- End Brand Carousel -->
</div>

{{-- Starting of order invoice modal --}}
<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
  aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">

        <button type="button" class="close productmodalbtn" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="orderInvoice">

      </div>
    </div>
  </div>
</div>
{{-- order invoice modal area end --}}

@push('scripts')
<script>

  function showOrderInvoiceModal(orderNumber) {
    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      }
    });
    $.ajax({
      type: "POST",
      url: "{{url('account/show-order-invoice')}}",
      data: {order_number: orderNumber},
      dataType: "json",
      success: function (response) {
        $('#orderInvoice').html(response.orderDeatil_html);
        $('.bd-example-modal-lg').modal('show');
      },
      error: function (data) {

      }
    });

  };

  // filter table on order number

  $("#searchOrder").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $(".search-product").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });

  // Jquery for hide modal
  $(".productmodalbtn").click(function () {
    $(".bd-example-modal-lg").modal('hide');
  });

</script>
@endpush