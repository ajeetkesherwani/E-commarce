@php
$avgrating = AvgRating($products->product_id);
$currentURL = URL::current();
use App\Models\Ecom\Services\EcomService;

@endphp
<!-- Breadcrumb Area start -->
<x-Ecom03.SharedComponent.BreadCrumb :data="$breadCumbArr" />
<!-- Breadcrumb Area End -->

<!-- Shop details Area start -->
<main id="content" role="main">
    <div class="container">
        <div class="mb-xl-14 mb-6">
            <div class="row">
                <div class="col-md-5 mb-4 mb-md-0">
                    <!--Product Image-->
                    <div id="sliderSyncingNav" class="js-slick-carousel u-slick mb-2" data-infinite="true"
                        data-arrows-classes="d-none d-lg-inline-block u-slick__arrow-classic u-slick__arrow-centered--y rounded-circle"
                        data-arrow-left-classes="fas fa-arrow-left u-slick__arrow-classic-inner u-slick__arrow-classic-inner--left ml-lg-2 ml-xl-4"
                        data-arrow-right-classes="fas fa-arrow-right u-slick__arrow-classic-inner u-slick__arrow-classic-inner--right mr-lg-2 mr-xl-4"
                        data-nav-for="#sliderSyncingThumb">
                        @if (!empty($products->products_to_gallery))
                        <div class="js-slide" style="cursor: pointer;">
                            <img class="img-fluid" src="{{ getFullImageUrl($products->product_image) }}" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" alt="{{  $products->products_name ?? ''  }}">
                        </div>
                        @foreach ($products->products_to_gallery as $key => $data)
                        <div class="js-slide">
                            <img class="img-fluid" src="{{$data}}" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" alt="{{ $products->products_name ?? '' }}">
                        </div>
                        @endforeach
                        @endif
                    </div>

                    <!--Product Image Gallery -->
                    @if (!empty($products->products_to_gallery)) 
                    <div id="sliderSyncingThumb"
                        class="js-slick-carousel u-slick u-slick--slider-syncing u-slick--slider-syncing-size u-slick--gutters-1 u-slick--transform-off"
                        data-infinite="true" data-slides-show="5" data-is-thumbs="true"
                        data-nav-for="#sliderSyncingNav"> 
                        <div class="js-slide" style="cursor: pointer;"> 
                            <img class="img-fluid" src="{{$products->image_url}}" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" alt="{{ $products->products_name ?? ''  }}">
                        </div>
                        @foreach ($products->products_to_gallery as $key => $data)
                        <div class="js-slide" style="cursor: pointer;"> 
                            <img class="img-fluid" src="{{$data}}"
                                onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'" alt="">
                        </div>
                        @endforeach
                    </div>
                    @endif
                   <!--End of Product Image Gallery -->
                </div>
                <div class="col-md-7 mb-md-6 mb-lg-0">
                      <!--Show Brand Name-->
                      @if(!empty($products->products_to_brand))
                        <div class="font-size-12 text-gray-5 mb-2 d-inline-block">
                            {{translation('PRODUCT_BRAND')}}
                            @if (in_array($products->product_type_id, ['1', '2', '4']) && $products->products_to_brand
                            != '')
                            @if (!empty($products->products_to_brand))
                            <a href="{{ EcomService::url($products->products_to_brand->brand_id ?? '', 'brand') }}">
                                :{{ $products->products_to_brand->brand_name ?? '' }}
                            </a>
                            @endif
                            @endif
                        </div>
                        @endif
                    <div class="mb-2">
                        <!--Start of Product Details -->
                        <div class="border-bottom mb-3 pb-md-1 pb-3">
                            <h2 class="font-size-25 text-lh-1dot2">
                                {{ $products->products_name ?? '' }}
                            </h2>
                            <div class="mb-2">
                                <a class="d-inline-flex align-items-center small font-size-15 text-lh-1" href="#">
                                    <div class="text-warning mr-2">
                                       @if (!empty($avgrating))
                                            @for($i=0;$i<5;$i++) @if($i<$avgrating) 
                                                    <small class="fas fa-star text-warning"> </small>
                                                @else
                                                    <small class="fas fa-star text-muted"></small>
                                                @endif
                                            @endfor
                                        @endif
                                    </div>
                                    
                                    @if(!empty($review_count))
                                    <span class="text-secondary font-size-13">({{translation('PRODUCT_REVIEW')}}
                                        {{$review_count}})
                                    </span>
                                    @endif
                                </a>
                            </div>
                        </div>
                         <!--End of Product Details -->

                    
                        <!-- Show Wishlist -->
                        <div class="flex-horizontal-center flex-wrap mb-3">
                            @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))
                            <a href="javascript:void(0);" onclick="addToWishListFromDetail({{ $products->product_id }})"
                                class="text-gray-6 font-size-14 mr-2"><i
                                    class="ec ec-favorites mr-1 font-size-15"></i>{{translation('ADD_TO_WISHLIST')}}</a>
                            @endif
                        </div>

                        <!-- Show Product Features -->
                        @if(!empty($products->products_to_features) && sizeof($products->products_to_features)>0)
                        <div>
                            <ul class="font-size-15  text-gray-110 feature-list pl-0">
                                @foreach($products->products_to_features as $features)
                                <li class="font-size-14 text-gray-110">{{$features->feature_title ?? ''}} :
                                    <span>{{$features->feature_value ?? ''}}</span>
                                </li>
                                @endforeach
                            </ul>
                        </div>
                        @endif

                        
                        <form action="{{route('addUpdateToCart')}}" method="post" id="cartform">
                            @csrf
                            <!-- Attributes Work Start Here-->
                            @if (!empty($products->productAttribute) && sizeof($products->productAttribute) > 0)
                            <div class="border-top border-bottom py-3 mb-4">
                                @foreach ($products->productAttribute as $attribute)
                                <div class="d-flex align-items-center">
                                    <h6 class="font-size-14 mb-0">{{ ucfirst($attribute->option_name ?? '') }}</h6>
                                    @if (isset($attribute->option_value_list) && !empty($attribute->option_value_list))
                                    <ul id="attributes_{{ $attribute->options_id }}">
                                        @foreach ($attribute->option_value_list as $idx => $option_value)
                                        <li class="input-container float-sm-start">
                                            <label>
                                                <input class="input-radio" type="radio"
                                                    attribute="{{ $attribute->options_id }}"
                                                    name="attributes_{{ $attribute->options_id }}" {{ $idx==0
                                                    ? 'checked' : '' }}
                                                    value="{{ $attribute->options_id }}_{{ $option_value->options_values_id }}"
                                                    title="{{ $option_value->productOptionsValue->products_options_values_name }}">
                                                <span class="radio-label">{{
                                                    $option_value->productOptionsValue->products_options_values_name
                                                    }}</span>
                                            </label>
                                        </li>
                                        @endforeach
                                    </ul>
                                    @endif
                                </div>
                                @endforeach
                            </div>
                            @endif
                            <!--End of  Attributes Work  Here-->

                            <!-- Show WholeSale Price Tabel Start -->
                            @if($products->products_prices !=null)
                            <div class="table-responsive">
                                <table class="table table-bordered text-center">
                                    <thead class="table-primary">
                                        <tr>
                                            <th scope="col">{{translation('PRODUCT_QTY')}}</th>
                                            @foreach($products->products_prices as $productQty)
                                            <th scope="col">{{$productQty->product_qty}}</th>
                                            @endforeach
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th scope="row">{{translation('PRODUCT_PRICE')}}</th>
                                            @foreach($products->products_prices as $producprice)
                                                <td><b class="text-danger">{{currencyFormat($producprice->sale_price)}}</b>
                                                </td>
                                            @endforeach
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            @endif
                            <!-- Show WholeSale Price Tabel End-->

                            <div class="mb-4 border-bottom pb-2">
                                <div class="d-flex align-items-baseline">
                                    {{translation('PRODUCT_PRICE')}} : &nbsp; 
                                    @if($products->products_prices==null)
                                        <!-- Normal Product Price Show Start -->
                                        @if($products->discount_type != 'no')
                                            <del class="font-size-20 text-danger discount_amount">
                                                {{currencyFormat($products->max_sale_price) }}
                                            </del>
                                            @endif
                                                <ins class="font-size-30 text-decoration-none old-price">
                                                    {{ currencyFormat($products->sale_price ?? '0.00') }}
                                                </ins>
                                            @if($products->discount_type != 'no')
                                            @if($products->discount_type == 'flat')
                                                <span class="text-success ms-1">
                                                    &nbsp; {{ currencyFormat($products->discount_amount) }} off
                                                </span>
                                            @else
                                                <span class="font-size-20 text-success ms-1">
                                                    &nbsp; {{ currencyFormat( $products->discount_amount )}}% off
                                                </span>
                                            @endif
                                        @endif
                                        <!-- Normal Product Price Show End -->
                                    @else
                                    <!-- Wholesale Prices Start-->
                                    @foreach($products->products_prices as $holeprice)
                                        @if($holeprice->discount_percent !='0')
                                            <del class="font-size-20  text-danger discount_amount">
                                                {{currencyFormat($holeprice->max_sale_price) }}
                                            </del>
                                        @endif
                                            <ins class="font-size-30 text-decoration-none old-price">
                                                &nbsp; {{ currencyFormat($holeprice->sale_price ?? '0.00') }}
                                            </ins>
                                        / {{$holeprice->product_qty}} Unit
                                        @if($holeprice->discount_percent != '0')
                                            <span class="font-size-20 text-success ms-1">
                                                &nbsp; {{ currencyFormat( $holeprice->discount_percent )}}% off
                                            </span>
                                        @endif
                                     @break;
                                    @endforeach
                                    <!-- Wholesale Prices End-->
                                    @endif
                                </div>
                            </div>

                            @if($products->products_prices !=null)
                            <input type="hidden" hidden class="minordqty"
                                value="{{$products->products_prices->min('product_qty')}}">
                            @endif

                            <div class="d-md-flex align-items-end mb-3">
                                <div class="max-width-150 mb-4 mb-md-0">
                                    <!-- Quantity -->
                                    <div class="border rounded-pill py-2 px-3 border-color-1">
                                        <div class="js-quantity row align-items-center">
                                            <div class="col">
                                                @if($products->products_prices !=null)
                                                    @foreach($products->products_prices as $producprice)
                                                       <input class="js-result form-control h-auto border-0 rounded p-0 shadow-none"
                                                            id="qtyItemAdd" type="text" name="qty"
                                                            value="{{$producprice->product_qty}}" onblur="QtyToPrice()">
                                                        @break
                                                    @endforeach
                                                @else
                                                  <input class="js-result form-control h-auto border-0 rounded p-0 shadow-none"
                                                      id="qtyItemAdd" type="text" name="qty" value="1" onblur="QtyToPrice()">
                                                @endif
                                            </div>
                                            <div class="col-auto pr-1">
                                                <a class="js-minus btn btn-icon btn-xs btn-outline-secondary rounded-circle border-0 qtybutton"
                                                    href="javascript:;" >
                                                    <small class="fas fa-minus btn-icon__inner"></small>
                                                </a>
                                                <a class="js-plus btn btn-icon btn-xs btn-outline-secondary rounded-circle border-0 qtybutton"
                                                    href="javascript:;" >
                                                    <small class="fas fa-plus btn-icon__inner"></small>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Quantity -->
                                </div>
                                <input type="hidden" name="product_slug" value="{{$products->product_slug}}">
                                <!-- if cart enabled -->
                                @if (webFunctionStatus(config('constkey.is_cart_enabled')))
                                <div class="ml-md-3">
                                    <button type="submit"
                                        class="btn  px-5 btn-primary-dark transition-3d-hover"><i class="ec ec-add-to-cart mr-2 font-size-20"></i> {{translation('ADD_TO_CART')}}</button>
                                </div>
                                @endif

                                <!-- if enquiry enabled -->
                                @if (webFunctionStatus(config('constkey.is_enquiry_enabled')))
                                <div class="ml-md-3">
                                    <a href="javascript:void(0);" onclick="showEnquiryForm()"
                                        class="btn px-5 btn-primary-dark transition-3d-hover"><i
                                        class="ec ec-phone mr-2 font-size-20"></i>{{ translation('PRODUCT_ENQUIRY_BUTTON')}}</a>
                                </div>
                                @endif
                            </div>
                        </form>

                        <!-- Social Shares -->
                        <div class="row widget mt-4 mb-1">
                            <div class="col-sm-12 mb-1">
                                <div class="d-flex">
                                    <div class="d-block py-2 h6 mb-0 pr-2">
                                        {{translation('PRODUCT_SHARE')}}:
                                    </div>
                                    <div>
                                        <ul class="list-unstyled social-icon social text-center mb-0 mt-2">
                                            <li class="list-inline-item">
                                                <a href="https://api.whatsapp.com/send?text={{ $currentURL }}" target="_blank"
                                                    style="color:green;">
                                                <svg xmlns=" http://www.w3.org/2000/svg" width="16" height="16"
                                                    fill="currentColor" class="bi bi-whatsapp" viewBox="0 0 16 16">
                                                    <path
                                                        d="M13.601 2.326A7.854 7.854 0 0 0 7.994 0C3.627 0 .068 3.558.064 7.926c0 1.399.366 2.76 1.057 3.965L0 16l4.204-1.102a7.933 7.933 0 0 0 3.79.965h.004c4.368 0 7.926-3.558 7.93-7.93A7.898 7.898 0 0 0 13.6 2.326zM7.994 14.521a6.573 6.573 0 0 1-3.356-.92l-.24-.144-2.494.654.666-2.433-.156-.251a6.56 6.56 0 0 1-1.007-3.505c0-3.626 2.957-6.584 6.591-6.584a6.56 6.56 0 0 1 4.66 1.931 6.557 6.557 0 0 1 1.928 4.66c-.004 3.639-2.961 6.592-6.592 6.592zm3.615-4.934c-.197-.099-1.17-.578-1.353-.646-.182-.065-.315-.099-.445.099-.133.197-.513.646-.627.775-.114.133-.232.148-.43.05-.197-.1-.836-.308-1.592-.985-.59-.525-.985-1.175-1.103-1.372-.114-.198-.011-.304.088-.403.087-.088.197-.232.296-.346.1-.114.133-.198.198-.33.065-.134.034-.248-.015-.347-.05-.099-.445-1.076-.612-1.47-.16-.389-.323-.335-.445-.34-.114-.007-.247-.007-.38-.007a.729.729 0 0 0-.529.247c-.182.198-.691.677-.691 1.654 0 .977.71 1.916.81 2.049.098.133 1.394 2.132 3.383 2.992.47.205.84.326 1.129.418.475.152.904.129 1.246.08.38-.058 1.171-.48 1.338-.943.164-.464.164-.86.114-.943-.049-.084-.182-.133-.38-.232z" />
                                                    </svg>
                                                </a>
                                            </li>
                                            <li class="list-inline-item">
                                                <a href="https://twitter.com/intent/tweet?text={{ $currentURL }}"
                                                    target="_blank" style="color:skyblue;">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                                        fill="currentColor" class="bi bi-twitter" viewBox="0 0 16 16">
                                                        <path
                                                            d="M5.026 15c6.038 0 9.341-5.003 9.341-9.334 0-.14 0-.282-.006-.422A6.685 6.685 0 0 0 16 3.542a6.658 6.658 0 0 1-1.889.518 3.301 3.301 0 0 0 1.447-1.817 6.533 6.533 0 0 1-2.087.793A3.286 3.286 0 0 0 7.875 6.03a9.325 9.325 0 0 1-6.767-3.429 3.289 3.289 0 0 0 1.018 4.382A3.323 3.323 0 0 1 .64 6.575v.045a3.288 3.288 0 0 0 2.632 3.218 3.203 3.203 0 0 1-.865.115 3.23 3.23 0 0 1-.614-.057 3.283 3.283 0 0 0 3.067 2.277A6.588 6.588 0 0 1 .78 13.58a6.32 6.32 0 0 1-.78-.045A9.344 9.344 0 0 0 5.026 15z" />
                                                    </svg>
                                                </a>
                                            </li>
                                            <li class="list-inline-item">
                                                <a href="https://www.facebook.com/sharer/sharer.php?u={{ $currentURL }}"
                                                    target="_blank" style="color: rgb(85, 105, 218)">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                                        fill="currentColor" class="bi bi-facebook" viewBox="0 0 16 16">
                                                        <path
                                                            d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951z">
                                                        </path>
                                                    </svg>
                                                </a>
                                            </li>
                                        </ul><!--end icon-->
                                    </div>
                                </div>
                            </div>
                         
                        </div>

                        <!-- Start of Warnings for wholesale products-->
                        <div class="qty_alert"></div>
                        @if(session()->has('warning'))
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            {{ session()->get('warning') }}
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        @endif
                        <!-- End of Warnings for wholesale products-->
                    </div>
                </div>
            </div>
        </div>
        <!-- End Single Product Body -->

        <!-- Single Product Tab -->
        <div class="mb-8">
            <div class="position-relative position-md-static px-md-6">
                <ul class="nav nav-classic nav-tab nav-tab-lg justify-content-xl-center flex-nowrap flex-xl-wrap overflow-auto overflow-xl-visble border-0 pb-1 pb-xl-0 mb-n1 mb-xl-0"
                    id="pills-tab-8" role="tablist">

                    <li class="nav-item flex-shrink-0 flex-xl-shrink-1 z-index-2">
                        <a class="nav-link active" id="Jpills-two-example1-tab" data-toggle="pill"
                            href="#Jpills-two-example1" role="tab" aria-controls="Jpills-two-example1"
                            aria-selected="false">{{ translation('PRODUCT_DESCRIPTION_TITLE')}}</a>
                    </li>
                    <li class="nav-item flex-shrink-0 flex-xl-shrink-1 z-index-2">
                        <a class="nav-link" id="Jpills-three-example1-tab" data-toggle="pill"
                            href="#Jpills-three-example1" role="tab" aria-controls="Jpills-three-example1"
                            aria-selected="false">{{ translation('PRODUCT_DETAILS_TITLE')}}</a>
                    </li>
                    <li class="nav-item flex-shrink-0 flex-xl-shrink-1 z-index-2">
                        <a class="nav-link" id="Jpills-four-example1-tab" data-toggle="pill"
                            href="#Jpills-four-example1" role="tab" aria-controls="Jpills-four-example1"
                            aria-selected="false">{{ translation('PRODUCT_REVIEWS_TITLE')}}</a>
                    </li>
                </ul>
            </div>
            <!-- Tab Content -->
            <div class="borders-radius-17 border p-4 mt-4 mt-md-0 px-lg-10 py-lg-9">
                <div class="tab-content" id="Jpills-tabContent">
                    <div class="tab-pane fade active show" id="Jpills-two-example1" role="tabpanel"
                        aria-labelledby="Jpills-two-example1-tab">
                        {!! $products->products_description ?? '' !!}
                    </div>
                    <div class="tab-pane fade" id="Jpills-three-example1" role="tabpanel"
                        aria-labelledby="Jpills-three-example1-tab">
                        @if (!empty($products) && in_array($products->product_type_id, ['1', '2', '4']))
                        <div class="mx-md-5 pt-1">
                            <div class="table-responsive mb-4">
                                <table class="table table-hover">
                                    <tbody>
                                        <tr>
                                            <th class="px-4 px-xl-5 border-top-0">{{ translation('PRODUCT_SKU') }}</th>
                                            <td class="border-top-0">{{ $products->product_sku }}</td>
                                        </tr>
                                        <tr>
                                            <th class="px-4 px-xl-5">{{ translation('PRODUCT_MODEL') }}</th>
                                            <td>{{ $products->product_model }}</td>
                                        </tr>
                                        <tr>
                                            <th class="px-4 px-xl-5">{{ translation('PRODUCT_CONDITION') }}</th>
                                            <td>{{ $products->product_condition == 1 ? 'New' : 'Refurbished' }}</td>
                                        </tr>
                                        <tr>
                                            <th class="px-4 px-xl-5">{{ translation('PRODUCT_BRAND_NAME') }}</th>
                                            <td>{{ !empty($products->products_to_brand) ?
                                                $products->products_to_brand->brand_name : '' }}</td>
                                        </tr>
                                        @if (!empty($products->products_to_features) &&
                                        sizeof($products->products_to_features) > 0)
                                        @foreach ($products->products_to_features as $featKey => $featVal)
                                        <tr>
                                            <th class="px-4 px-xl-5">{{ $featVal->feature_title ?? '' }}</th>
                                            <td>{{ $featVal->feature_value ?? '' }}</td>
                                        </tr>
                                        @endforeach
                                        @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        @endif
                    </div>
                    <div class="tab-pane fade" id="Jpills-four-example1" role="tabpanel"
                        aria-labelledby="Jpills-four-example1-tab">
                        <div class="row mb-8">

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <h3 class="font-size-18 mb-6">
                                        @php
                                            $item =  $average ?? 1 ;
                                            $data  = translation('REVIEW_AVERAGE');
                                            printf($data, $item);
                                        @endphp 
                                    </h3>
                                    <h2 class="font-size-30 font-weight-bold text-lh-1 mb-0">{{round($average ?? 0,1)}}
                                    </h2>
                                    <div class="text-lh-1">{{ translation('OVERALL') }}</div>
                                </div>

                                <!-- Ratings -->
                                <ul class="list-unstyled">
                                    @if(!empty($reviewCounter) && sizeof($reviewCounter)>0)
                                    @foreach($reviewCounter as $reViewData)
                                    <li class="py-1">
                                        <a class="row align-items-center mx-gutters-2 font-size-1" href="javascript:;">
                                            <div class="col-auto mb-2 mb-md-0">
                                                <div class="text-warning text-ls-n2 font-size-16" style="width: 80px;">
                                                    @for($i=1;$i<=5;$i++) @if($i<=$reViewData['avg']) <small
                                                        class="fas fa-star"></small>
                                                        @else
                                                            <small class="far fa-star text-muted"></small>
                                                        @endif
                                                    @endfor
                                                </div>
                                            </div>
                                            <div class="col-auto mb-2 mb-md-0">
                                                <div class="progress ml-xl-5" style="height: 10px; width: 200px;">
                                                    <div class="progress-bar" role="progressbar"
                                                        style="width:{{$reViewData['percentage']}}%;"
                                                        aria-valuenow="{{$reViewData['count']}}" aria-valuemin="0"
                                                        aria-valuemax="100"></div>
                                                </div>
                                            </div>
                                            <div class="col-auto text-right">
                                                <span class="text-gray-90">{{$reViewData['count']}}</span>
                                            </div>
                                        </a>
                                    </li>
                                    @endforeach
                                    @endif
                                </ul>
                                <!-- End Ratings -->
                            </div>

                            <div class="col-md-6">
                                <h3 class="font-size-18 mb-5">{{ translation('PRODUCT_ADD_REVIEWS') }}</h3>
                                <!-- Form -->
                                <form id="reviewform">
                                    <div class="row align-items-center">
                                        <div class="col-md-4 col-lg-3">
                                            <label for="rating" class="form-label mb-0">{{
                                                translation('PRODUCT_QUALITY_RATING') }}</label>
                                        </div>
                                        <div class="col-md-8 col-lg-9 ">
                                            <a href="#" class="d-block">
                                                <div class="rate">
                                                    <input type="radio" id="star5" name="quality_rating"
                                                        class="quality_rating" value="5" />
                                                    <label for="star5" title="text">{{ translation('5STAR') }}</label>
                                                    <input type="radio" id="star4" name="quality_rating"
                                                        class="quality_rating" value="4" />
                                                    <label for="star4" title="text">{{ translation('4STAR') }}</label>
                                                    <input type="radio" id="star3" name="quality_rating"
                                                        class="quality_rating" value="3" />
                                                    <label for="star3" title="text">{{ translation('3STAR') }}3</label>
                                                    <input type="radio" id="star2" name="quality_rating"
                                                        class="quality_rating" value="2" />
                                                    <label for="star2" title="text">{{ translation('2STAR') }}</label>
                                                    <input type="radio" id="star1" name="quality_rating"
                                                        class="quality_rating" value="1" />
                                                    <label for="star1" title="text">{{ translation('1STAR') }}</label>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="row align-items-center mb-4">
                                        <div class="col-md-4 col-lg-3">
                                            <label for="rating"
                                                class="form-label mb-0">{{translation("PRODUCT_PRICE_RATING")}}</label>
                                        </div>
                                        <div class="col-md-8 col-lg-9 ">
                                            <a href="#" class="d-block">
                                                <div class="rate">
                                                    <input type="radio" id="stars5" name="price_rating"
                                                        class="price_rating" value="5" />
                                                    <label for="stars5" title="text">{{ translation('5STAR') }}</label>
                                                    <input type="radio" id="stars4" name="price_rating"
                                                        class="price_rating" value="4" />
                                                    <label for="stars4" title="text">{{ translation('4STAR') }}</label>
                                                    <input type="radio" id="stars3" name="price_rating"
                                                        class="price_rating" value="3" />
                                                    <label for="stars3" title="text">{{ translation('3STAR') }}</label>
                                                    <input type="radio" id="stars2" name="price_rating"
                                                        class="price_rating" value="2" />
                                                    <label for="stars2" title="text">{{ translation('2STAR') }}</label>
                                                    <input type="radio" id="stars1" name="price_rating"
                                                        class="price_rating" value="1" />
                                                    <label for="stars1" title="text">{{ translation('1STAR') }}</label>
                                                </div>

                                            </a>
                                        </div>
                                    </div>
                                    @guest
                                    <div class="js-form-message form-group mb-3 row">
                                        <div class="col-md-4 col-lg-3">
                                            <label for="inputName" class="form-label">{{ translation('PRODUCT_REVIEW_NAME') }} 
                                                <span class="text-danger">*</span></label>
                                        </div>
                                        <div class="col-md-8 col-lg-9">
                                            <input type="text" class="form-control customers_name" name="customers_name"
                                                id="inputName" aria-label="" required
                                                data-msg="Please enter your name." placeholder="{{translation('PRODUCT_REVIEW_NAME_PLACEHOLDER')}}" data-error-class="u-has-error"
                                                data-success-class="u-has-success">
                                            <span class="text-danger" id="customers_name"></span>
                                        </div>
                                    </div>
                                    <div class="js-form-message form-group mb-3 row">
                                        <div class="col-md-4 col-lg-3">
                                            <label for="emailAddress" class="form-label">{{ translation('PRODUCT_REVIEW_EMAIL') }}
                                                <span class="text-danger">*</span></label>
                                        </div>
                                        <div class="col-md-8 col-lg-9">
                                            <input type="email" class="form-control customers_email"
                                                name="customers_email" id="emailAddress"
                                                aria-label="" required placeholder="{{translation('PRODUCT_REVIEW_EMAIL_PLACEHOLDER')}}"
                                                data-msg="Please enter a valid email address."
                                                data-error-class="u-has-error" data-success-class="u-has-success">
                                            <span class="text-danger" id="customers_email"></span>
                                        </div>
                                    </div>
                                    @endguest

                                    <input type="hidden" value="{{ $products->product_id }}" class="products_id"
                                        name="products_id">
                                    <input type="hidden" value="0" name="reviews_read">

                                    <div class="js-form-message form-group mb-3 row">
                                        <div class="col-md-4 col-lg-3">
                                            <label for="emailAddress" class="form-label">{{ translation('PRODUCT_REVIEW_TITLE')}} </label>
                                        </div>
                                        <div class="col-md-8 col-lg-9">
                                            <input type="text" class="form-control customers_email reviews_title"
                                                name="reviews_title" id="emailAddress"
                                                aria-label="" placeholder="{{translation('PRODUCT_REVIEW_TITLE_PLACEHOLDER')}}" required
                                                data-msg="Please enter a valid email address."
                                                data-error-class="u-has-error" data-success-class="u-has-success">
                                            <span class="text-danger" id="customers_email"></span>
                                        </div>
                                    </div>

                                    <div class="js-form-message form-group mb-3 row">
                                        <div class="col-md-4 col-lg-3">
                                            <label for="descriptionTextarea" class="form-label">{{
                                                translation('PRODUCT_YOUR_REVIEW') }}</label>
                                        </div>
                                        <div class="col-md-8 col-lg-9">
                                            <textarea class="form-control reviews_text" name="reviews_text" rows="3"
                                                id="descriptionTextarea" data-msg="Please enter your message." placeholder="{{translation('PRODUCT_REVIEW_MESSAGE_PLACEHOLDER')}}"
                                                data-error-class="u-has-error" required
                                                data-success-class="u-has-success"></textarea>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="offset-md-4 offset-lg-3 col-auto">
                                            <button type="submit" id="reviewformbutton"
                                                class="btn btn-primary-dark btn-wide transition-3d-hover">{{
                                                translation('PRODUCT_REVIEW_SUBMIT') }}</button>
                                        </div>
                                    </div>
                                </form>
                                <!-- End Form -->
                            </div>
                        </div>
                        <!-- Review -->
                        @if (!$review_data->isEmpty())
                        @foreach ($review_data as $key => $data)
                        <div class="border-bottom border-color-1 pb-4 mb-4">
                            <!-- Review Rating -->
                            {{ translation('PRODUCT_QUALITY_RATING') }}:
                            <div
                                class="d-flex justify-content-between align-items-center text-secondary font-size-1 mb-2">
                                <div class="text-warning text-ls-n2 font-size-16" style="width: 80px;">
                                    @php
                                    $j = 0;
                                    for ($i = 0; $i < $data->quality_rating; $i++) {
                                        echo '<small class="fas fa-star"></small>';
                                        $j++;
                                        }
                                        for ($k = 5; $k > $j; $k--) {
                                        echo '<small class="far fa-star text-muted"></small>';
                                        }
                                        @endphp
                                </div>
                            </div>

                            {{ translation('PRODUCT_PRICE_RATING') }} :
                            <div
                                class="d-flex justify-content-between align-items-center text-secondary font-size-1 mb-2">
                                <div class="text-warning text-ls-n2 font-size-16" style="width: 80px;">
                                    @php
                                    $j = 0;
                                    for ($i = 0; $i < $data->price_rating; $i++) {
                                        echo '<small class="fas fa-star"></small>';
                                        $j++;
                                        }
                                        for ($k = 5; $k > $j; $k--) {
                                        echo '<small class="far fa-star text-muted"></small>';
                                        }
                                        @endphp
                                </div>
                            </div>

                            <!-- End Review Rating -->

                            <p class="text-gray-90"> Fusce vitae nibh mi. Integer posuere, libero et ullamcorper
                                facilisis, enim eros tincidunt orci, eget vestibulum sapien nisi ut leo. Cras finibus
                                vel est ut mollis. Donec luctus condimentum ante et euismod.</p>

                            <!-- Reviewer -->
                            <div class="mb-2">
                                <strong>{{ $data->customers_name }}</strong>

                            </div>
                            <!-- End Reviewer -->
                        </div>
                        @endforeach
                        @endif
                        <!-- End Review -->

                    </div>
                </div>
            </div>
            <!-- End Tab Content -->
        </div>
        <!-- End Single Product Tab -->
        <!-- Related products -->
        @if (!$related_data->isEmpty())
        <div class="mb-6">
            <div
                class="d-flex justify-content-between align-items-center border-bottom border-color-1 flex-lg-nowrap flex-wrap mb-4">
                <h3 class="section-title mb-0 pb-2 font-size-22">
                    {{translation('PRODUCT_RELETED_TO_YOU')}}
                </h3>
            </div>
            <ul class="row list-unstyled products-group no-gutters">
                @foreach ($related_data as $key => $product)
                <x-ecom03.shared-component.product viewtype="grid" :data="$product" />
                @endforeach
            </ul>
        </div>
        @endif
        <!-- End Related products -->
        <!-- Brand Carousel -->
        <x-Ecom03.SharedComponent.BrandSlider />
        <!-- End Brand Carousel -->
    </div>
</main>
<!--Starting of Enquiry Form Modal-->
@if (webFunctionStatus(config('constkey.is_enquiry_enabled')))
<div class="modal fade enquiry-form" id="EnquiryModal" tabindex="-1" aria-labelledby="exampleModalLabel"
    aria-modal="true" role="dialog">
    <div class="modal-dialog prdtmodal-dialog py-4">
        <div class="modal-content">
            <div class="col-md-12 ">
                <button type="button" class="btn-close prdtbtn-close" data-dismiss="modal" aria-label="Close">X</button>
            </div>
            <div class="pt-4 px-4 pb-2">
                <div class="pl-3">
                    <h2 class=" enquiry_heading">{{translation('ENQUIRY_TITLE')}}</h2>
                </div>
                <form id="enquiryform" class="enquiryformdata required needs-validation" method="POST"
                    enctype="multipart/form-data" novalidate="">
                    <input type="hidden" id="products_id" name="products_id" value="{{ $products->product_id }}">
                    <div class=" modal-body pt-2">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-12 py-2">
                                <label class="form-label">{{translation('ENQUIRY_NAME') }}<span
                                        class="text-danger">*</span></label>
                                <input type="text" name="customers_name" id="enqcustomers_name"
                                    class="form-control enquiry_form " placeholder="{{ translation('ENQUIRY_NAME_PLACEHOLDER') }}"
                                    required="">
                                <span class="text-danger customers_name_enq"></span>
                            </div>
                            <div class="col-lg-6 col-md-6 col-12 py-2">
                                <label class="form-label">
                                    {{translation('ENQUIRY_EMAIL')}}
                                    <span class="text-danger">*</span>
                                </label>
                                <input type="email" class="form-control enquiry_form " name="email_address"
                                    id="email_address" placeholder="{{ translation('ENQUIRY_EMAIL_PLACEHOLDER') }}"
                                    aria-label="email" required="">

                                <span class="text-danger email_address_enq"></span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-12 py-2 ">
                                <label class="form-label">{{translation('ENQUIRY_PHONE_NO')}}</label>
                                <input type="text" class="form-control enquiry_form" name="phone" id="phone"
                                    placeholder="{{ translation('ENQUIRY_PHONE_NO_PLACEHOLDER') }}" required>
                            </div>
                            <div class="col-lg-6 col-md-6 col-12 py-2">
                                <label class="form-label">{{translation('ENQUIRY_QUANTITY')}} <span
                                        class="text-danger">*</span></label>
                                <input type="number" class="form-control enquiry_form " name="products_qty" placeholder="{{translation('ENQUIRY_QUANTITY_PLACEHOLDER')}}"
                                    onblur="qtyItem()" id="products_qty" placeholder="Qty Needed" aria-label="qty"
                                    required="">
                                <span class="text-danger products_qty_enq"></span>
                            </div>
                        </div>
                        <div class="row">
                            @php
                            $max_option_id =0
                            @endphp
                            @if (!empty($products->productAttribute))
                            @foreach ($products->productAttribute as $attribute)
                            @if (isset($attribute->option_value_list) && !empty($attribute->option_value_list))
                            @php
                            if ($max_option_id < $attribute->options_id) {
                                $max_option_id = $attribute->options_id;
                                }
                                @endphp
                                <div class="col-lg-6 col-md-6 col-12 py-2">
                                    <label class="form-label">
                                        {{ ucfirst($attribute->option_name ?? '')}}
                                    </label>
                                    <select aria-label="Default select example"
                                        name="attribute_{{ $attribute->options_id }}" id="{{ $attribute->options_id }}"
                                        class="enquiry_form form-control" required="">
                                        <option selected disabled value="">Select{{ ucfirst($attribute->option_name ??
                                            '') }}</option>
                                        @foreach ($attribute->option_value_list as $option_value)
                                        <option value="{{ $option_value->options_values_id }}">
                                            {{ $option_value->productOptionsValue->products_options_values_name }}
                                        </option>
                                        @endforeach
                                    </select>
                                </div>
                                @endif
                                @endforeach
                                @endif
                        </div>
                        <input type="hidden" id="products_id" name="max_option_id" value="3">
                        <div class="row">
                            <div class=" col-md-12 col-12 py-2">
                                <label class="form-label">{{translation('ENQUIRY_MESSAGE')}}</label>
                                <textarea type="text" name="message" id="message" class="form-control enquiry_form "  placeholder="{{translation('ENQUIRY_MESSAGE_PLACEHOLDER')}}" aria-label="Enquiry Message"
                                    style="height:65px"></textarea>
                                <span class="text-danger message_enq"></span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-8 col-md-8 col-12 py-2">
                                <input type="checkbox" name="newsletter" checked="" id="myCheck">
                                <label for="myCheck">{{translation('ENQUIRY_NEWSLETTER')}}</label>
                            </div>
                        </div>
                        <div class="col-lg-6 mx-auto">
                            <div class="enquiry_frm_btn text-center">
                                <button type="submit" class="btn enquiry_btn btn-primary-dark w-100"
                                    id="enquirymodalformbutton">{{translation('ENQUIRY_SUBMIT')}}</button>
                                <input type="reset" hidden="">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endif

@push('scripts')
<script>

    // initialization of quantity counter
    $.HSCore.components.HSQantityCounter.init('.js-quantity');

    $(document).on('click', '#enquirymodalformbutton', function (e) {
        e.preventDefault();
        $('#enquiryform').addClass('was-validated');
        if ($('#enquiryform')[0].checkValidity() === false) {
            event.stopPropagation();
        } else {
            let enquiryform = document.getElementById('enquiryform');
            let formData = new FormData(enquiryform);
            var URL = window.location.href;
            var arr = URL.split('/');
            formData.append('page_source', arr.pop());

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "/storeProductEnquiry",
                data: formData,
                dataType: "json",
                contentType: false,
                cache: false,
                processData: false,
                beforeSend: function () {
                    $("#enquirymodalformbutton").addClass('disabled');
                    var html = '<i class="fa-solid fa-spinner fa-spin-pulse"></i> {{translation('SUBMITTING')}}...';
                    $("#enquirymodalformbutton").html(html);
                },
                success: function (response) {
                    console.log(response);
                    if (response.status == 400) {
                        $.each(response.error, function (key, err_val) {
                            $('.' + key + '_enq').text(err_val);
                        });
                    } else {
                        $('#enquiryform').trigger("reset");
                        $('#EnquiryModal').modal('hide');
                        Notify('{{translation('SUCCESSFULLY_SEND')}}', true);
                    }
                },
                complete: function (response) {
                    $('#enquirymodalformbutton').removeClass('disabled');
                    $('#enquiryform').removeClass('was-validated');
                    $('#enquirymodalformbutton').html('{{translation('SUBMIT')}}');
                }

            });
        }

    });

    // Ending of Enquiry Form Modal


    let cart_detail_choosen_attributes = [];
    
    function addToCartFromDetail(product_id) {

        var qtyItemAdd = $('#qtyItemAdd').val();
        let attributes = cart_detail_choosen_attributes.join(',');
        if (attributes == '') {

            $('input[type="radio"]:checked').each(function () {
                if (!cart_detail_choosen_attributes.includes(this.value)) {
                    cart_detail_choosen_attributes.push(this.value);
                }
                console.log(cart_detail_choosen_attributes);
            });
            let attributes = cart_detail_choosen_attributes.join(',');
            addToCart(product_id, qtyItemAdd, attributes);
        } else {
            addToCart(product_id, qtyItemAdd, attributes);
        }

    }



    var enqdetail_choosen_attributes = [];
    var choosen_attributes_ary = [];

    function enqchooseAttributes(params, opid) {
        choosen_attributes_ary = [];
        enqdetail_choosen_attributes[opid] = params.value;

        // Now it can be used reliably with $.map()
        $.map(enqdetail_choosen_attributes, function (val, i) {
            if (val > 0)
                choosen_attributes_ary.push(val);
        });

    }



    $(document).ready(function () {

        $(document).on('click', '#reviewformbutton', function (e) {
            e.preventDefault();
            $('#reviewform').addClass('was-validated');
            if ($('#reviewform')[0].checkValidity() === false) {
                event.stopPropagation();
            } else {
                var data = {
                    'customers_name': $('.customers_name').val(),
                    'customers_email': $('.customers_email').val(),
                    'quality_rating': $('.quality_rating:checked').val(),
                    'price_rating': $('.price_rating:checked').val(),
                    'reviews_title': $('.reviews_title').val(),
                    'products_id': $('.products_id').val(),
                    'reviews_read': $('.reviews_read').val(),
                    'reviews_text': $('.reviews_text').val(),

                }

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "/storereview",
                    data: data,
                    dataType: "json",

                    beforeSend: function () {
                        $("#reviewformbutton").addClass('disabled');
                        var html = '{{translation('SUBMITTING')}}...';
                        $("#reviewformbutton").html(html);
                    },

                    success: function (response) {
                        // console.log(response);
                        if (response.status == 400) {
                            //design

                            $.each(response.error, function (key, err_val) {
                                $('#' + key).text(err_val);
                            });
                        } else {
                            $('#successlist').html("");
                            Notify('{{translation('REVIEW_SUCCESS_MSG')}}', true);
                            $('#reviewform').trigger("reset");
                        }
                    },
                    complete: function (response) {
                        $('#reviewformbutton').removeClass('disabled');
                        $("#reviewformbutton").html("{{translation('SUBMIT')}}");
                        $('#reviewform').removeClass('was-validated');
                    }
                });
            }
        });
    });

    // Show more jquery

    if ($('.ty-compact-list').length > 3) {
        $('.ty-compact-list:gt(2)').hide();
        $('.show-more').show();
    }
    $('.show-more').on('click', function () {
        $('.ty-compact-list:gt(2)').toggle();
        $(this).text() === 'Show more' ? $(this).text('Show less') : $(this).text('Show more');
    });

    // <!--End of Enquiry Form Ajax-->
    function qtyItem() {
        var enqQtyItem = $('#products_qty').val();
        if (enqQtyItem < 1) {
            $('#products_qty').val('1');
        }
    }

</script>
@endpush