@php
    if(Request::segment(1)=='search')
    $segment= Request::segment(2);
@endphp

<!-- Header Start -->
<header class="main-header">
    <!-- Header Top Start -->
    <div class="header-top-nav">
        <div class="container-fluid">
            <div class="row align-items-center">
                <!--Left Start-->
                <div class="col-lg-4 col-md-12">
                    <div class="text-lg-start text-center">
                        <p class="color-white">{{ getSetting('site_slogan') }}</p>
                    </div>
                </div>
                <!--Left End-->
                <!--Right Start-->
                <div class="col-8 d-lg-block d-none">
                    <div class="header-right-nav hover-style-default">
                        <ul>
                            @if(!empty($top_nav_data))
                            @foreach($top_nav_data as $key=>$value)
                            <li class="border-color-white">
                                <a href="{{ url($value->menu_link)}}">{{$value->menu_name}}</a>
                            </li>
                            @endforeach
                            @endif
                            <!-- check registraion enable by subcsriber admin -->
                            @if (webFunctionStatus(config('constkey.is_user_registeration_enabled')))
                            @guest
                            <li class="border-color-white">
                                <a href="{{ url('login') }}">
                                    {{ translation('MY_ACCOUNT')}}
                                </a>
                            </li>
                            @endguest
                            @auth
                            <li class="border-color-black">
                                <a href="route('logout')" onclick="event.preventDefault(); document.getElementById('myLogOutForm').submit();">
                                    {{ translation('LOG_OUT') }}
                                    <form method="POST" id="myLogOutForm" action="{{ route('logout') }}">
                                        @csrf
                                    </form>
                                </a>
                            </li>
                            @endauth
                            @endif
                        </ul>

                        <!-- Header Top Language Currency -->
                        <div class="header-top-set-lan-curr d-flex justify-content-end">

                            @if (webFunctionStatus(config('constkey.is_user_registeration_enabled')))
                            @auth
                            <div class="header-bottom-set">
                                <button class="dropdown-toggle header-action-btn hover-style-default color-white">
                                    <a href="{{ url('account/dashboard') }}">{{ translation('MY_ACCOUNT') }}</a>
                                </button>
                            </div>
                            @endauth
                            @endif

                            <!-- Single Wedge Start -->
                            @if (count($Lang_arr) > 1)
                            <div class="header-top-curr dropdown">
                                <button class="dropdown-toggle header-action-btn hover-style-default color-white"
                                    data-bs-toggle="dropdown">
                                    <img class="me-2" src="{{asset('Flags/'.$def_lang->languages_code.'.svg')}}"
                                    onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                                        alt="N/F" height="13" width="20">{{$def_lang->languages_code ?? ''}}<i
                                        class="ion-ios-arrow-down"></i></button>
                                <ul class="dropdown-menu dropdown-menu-right">
                                    @if(!empty($Lang_arr))
                                    @foreach($Lang_arr as $key=>$data)
                                    <li><a class="dropdown-item" href="{{ url('/lang/locale/'.$data['name']) }}"
                                            alt=""><img src="{{asset('Flags/'.$data['name'].'.svg')}}" alt="N/F"
                                            onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                                            height="10" width="15">
                                            {{$data['name']}}
                                        </a>
                                    </li>
                                    @endforeach
                                    @endif

                                </ul>
                            </div>
                            @endif
                            <!-- Single Wedge End -->
                            <!-- Single Wedge Start -->
                            @if (count($Curr_arr) > 1)
                            <div class="header-top-curr dropdown">
                                <button class="dropdown-toggle header-action-btn hover-style-default color-white pr-1"
                                    data-bs-toggle="dropdown">{{$defcurrency_data->currencies_code}}
                                    {{$defcurrency_data->symbol_left}}<i class="ion-ios-arrow-down"></i></button>
                                <ul class="dropdown-menu dropdown-menu-right">
                                    @if(!empty($Curr_arr))
                                    @foreach($Curr_arr as $key=>$data)
                                    <li>
                                        <a class="dropdown-item" href="{{ url('/currency/locale/'.$data['name']) }}">
                                            {{$data['name']}} {{$data['icon']}} </a>
                                    </li>
                                    @endforeach
                                    @endif
                                </ul>

                            </div>
                            @endif
                            <!-- Single Wedge End -->
                        </div>
                        <!-- Header Top Language Currency -->
                    </div>
                </div>
                <!--Right End-->
            </div>
        </div>
    </div>
    <!-- Header Top End -->
    <!-- Header Buttom Start -->
    <div class="header-navigation sticky-nav d-none d-lg-block">
        <div class="container-fluid">
            <div class="row">
                <!-- Logo Start -->
                <div class="col-md-2 col-sm-2">
                    <div class="logo">
                        <a href="{{url('/')}}"><img src="{{ getImageUrlWithKey('website_logo') }}"
                            onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                                alt="{{getSetting('site_title')}}-logo" /></a>
                    </div>
                </div>
                <!-- Logo End -->
                <!-- Navigation Start -->
                <div class="col-md-10 col-sm-10">
                    <!--Main Navigation Start -->
                    @if(!empty($main_menu))
                    <div class="main-navigation">
                        <ul>
                            @foreach($main_menu as $key=>$value)
                            @if(in_array($value->menu_type, array('1', '2','3')) )
                            <li {{$value->menu_ref_id=="0" ? 'class=menu-dropdown': '' }} >
                                <a href="{{url($value->menu_ref_id==" 0"? '#' : $value->menu_link)}}">{{$value->menu_name}}
                                    @if(!empty($value->menulist))
                                    <i class="ion-ios-arrow-down"></i>
                                    @endif
                                </a>

                                @if(!empty($value->menulist))
                                <ul class="sub-menu">
                                    @foreach($value->menulist as $cmenu)
                                    @if(!empty($cmenu['title']))
                                    <li class="menu-dropdown position-static"><a href="{{url($cmenu['link'])}}">{{
                                            $cmenu['title'] }}
                                            @if(!empty($cmenu['subcate']))
                                            <i class="ion-ios-arrow-down"></i>
                                            @endif
                                        </a>
                                        @if(!empty($cmenu['subcate']))
                                        <ul class="sub-menu sub-menu-2">
                                            @foreach($cmenu['subcate'] as $smenu)
                                            <li class="menu-dropdown position-static"><a href="{{ url($smenu['link'])}}">{{
                                                    $smenu['title'] }}</a></li>
                                            @endforeach
                                        </ul>
                                        @endif
                                    </li>
                                    @endif
                                    @endforeach
                                </ul>
                                @endif
                            </li>
                            @else
                            <li><a href="{{url($value->menu_link)}}" >{{$value->menu_name}}</a></li>
                            @endif
                            @endforeach
                        </ul>
                    </div>
                    @endif
                    <!--Main Navigation End -->
                    <!--Header Bottom Account Start -->
                    <div class="header_account_area">
                        <!--Seach Area Start -->
                        <div class="header_account_list search_list">
                            <a href="javascript:void(0)"><i class="ion-ios-search-strong"></i></a>
                            <div class="dropdown_search">
                                <form id="searchform">
                                    <input placeholder="{{translation('SEARCH_ENTIRE_STORE_HERE') }}" id="searchtext"
                                       value="{{$segment ?? ''}}" name="searchtext" type="text" autocomplete="off" />
                                    <button type="submit" id="searchbutton"><i
                                            class="ion-ios-search-strong"></i></button>
                                </form>
                                <div class="searchItem hide ">
                                    <div class="searchItemList"></div>
                                </div>
                            </div>
                        </div>
                        <!--Seach Area End -->
                        <!--Contact info Start -->
                        <div class="contact-link">
                            <div class="phone">
                                <p>{{translation('CALL_US')}}:</p>
                                <a href="tel:{{ getSetting('contact_phone')}}">{{ getSetting('contact_phone')}}</a>
                            </div>
                        </div>
                        <!--Contact info End -->
                        <!--Cart info Start -->
                        @if (webFunctionStatus(config('constkey.is_cart_enabled')))
                        <div class="cart-info d-flex">

                            @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))
                            <div class="mini-cart-warp">
                                <a href="{{url('wishlist')}}" class="count-cart color-black count-wishlist-total heart">
                                    <span class="item-quantity-tag">{{$wishlist_count}}</span>
                                </a>
                            </div>
                            @endif
                            <div class="mini-cart-warp">
                                <a href="{{ url('cart')}}" class="count-cart count-cart-total color-black ">
                                    <span class="amount-tag">{{ currencyFormat($cart['grand_total'])}} </span>
                                    <span class="item-quantity-tag">{{ $cart['total_count'] }}</span>
                                </a>
                            </div>
                        </div><!--Cart info End -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Header Bottom Account End -->

    <!-- Header mobile area start -->
    <div class="header-bottom d-lg-none sticky-nav py-3 mobile-navigation">
        <div class="container-fluid">
            <div class="row justify-content-between align-items-center">
                <div class="col-md-3 col-sm-3">
                    <a href="#offcanvas-mobile-menu" class="offcanvas-toggle mobile-menu">
                        <i class="ion-navicon"></i>
                    </a>
                </div>
                <div class="col-md-6 col-sm-4 d-flex justify-content-center">
                    <div class="logo m-0">
                        <a href="{{url('/')}}"><img src="{{ getImageUrlWithKey('website_logo') }}"
                            onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="{{getSetting('site_title')}}-logo" /></a>
                    </div>
                </div>
                <div class="col-md-3 col-sm-5">
                    <!--Cart info Start -->
                    <div class="cart-info d-flex m-0 justify-content-end">

                        @if (webFunctionStatus(config('constkey.is_cart_enabled')))
                        <div class="mini-cart-warp">
                            <a href="{{ url('cart')}}"
                                class="count-cart  count-cart-total offcanvas-toggle color-black">
                                <span class="item-quantity-tag">{{ $cart['total_count'] }}</span>
                            </a>
                        </div>
                        @endif

                        <div class="header-bottom-set dropdown">
                            <button class="dropdown-toggle border-0 header-action-btn hover-style-default"
                                data-bs-toggle="dropdown"> <i class="ion-person"></i></button>
                            <ul class="dropdown-menu">
                                @guest
                                    <li>
                                        <a class="dropdown-item" href="{{ url('login') }}">
                                            {{ translation('MY_ACCOUNT')}}
                                        </a>
                                    </li>
                                    @endguest
                                @auth
                                    <li>
                                        <a href="{{ url('account/dashboard') }}">
                                            {{ translation('MY_ACCOUNT') }}
                                        </a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item" href="route('logout')"
                                            onclick="event.preventDefault(); document.getElementById('myLogOutForm').submit();">
                                            {{ translation('LOG_OUT') }}
                                            <form method="POST" id="myLogOutForm" action="{{ route('logout') }}">
                                                @csrf
                                            </form>
                                        </a>
                                    </li>
                                @endauth
                            </ul>
                        </div>
                    </div><!--Cart info End -->
                </div>
            </div>
        </div>
    </div>
    <!-- Header mobile area end -->
</header>
<!-- Header End -->
<div class="mobile-search-option pb-3 d-lg-none hover-style-default">
    <div class="container-fluid">
        <div class="header-account-list">
            <div class="dropdown-search">
                <form id="searchform">
                    <input placeholder="{{ translation('SEARCH_ENTIRE_STORE_HERE') }}" name="searchtext" id="searchtext"
                       value="{{$segment ?? ''}}" autocomplete="off" required type="text" />
                    <button type="submit" id="searchbutton"><i class="ion-ios-search-strong"></i></button>
                </form>
            </div>
            <div class="searchItem hide ">
                <div class="searchItemList"></div>
            </div>
        </div>
    </div>
</div>

<!-- offcanvas overlay start -->
<div class="offcanvas-overlay"></div>
<!-- offcanvas overlay end -->

<!-- OffCanvas Menu Start -->
<div id="offcanvas-mobile-menu" class="offcanvas offcanvas-mobile-menu hover-style-default">
    <button class="offcanvas-close"></button>
    <!-- contact Info -->
    <div class="contact-info d-flex align-items-center justify-content-center color-black py-3">
        <img class="me-3" src="{{LoadAssets('assets/images/icons/mobile-contact.png')}}" 
        onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
        alt="N/F">
        <p>Call us:</p>
        <a class="color-black" href="tel: {{ getSetting('contact_phone')}}"> {{getSetting('contact_phone')}}</a>
    </div>
    <!-- offcanvas  wishlist -->
    @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))
    <div class="user-panel">
        <ul class="d-flex justify-content-between">
            <li>
                <a href="{{url('wishlist')}}" class="count-wishlist-total">
                    <i class="ion-android-favorite-outline"></i>Wishlist ({{$wishlist_count}})
                </a>
            </li>
        </ul>
    </div>
    @endif
    <!-- offcanvas currency -->
    <div class="offcanvas-userpanel">
        <ul>
            <li class="offcanvas-userpanel__role">
                <a href="#">{{$defcurrency_data->currencies_code}} {{$defcurrency_data->symbol_left}}<i
                        class="ion-ios-arrow-down"></i></a>
                <ul class="user-sub-menu">
                    @if(!empty($Curr_arr))
                    @foreach($Curr_arr as $key=>$data)
                    <li><a class="current" href="{{ url('/currency/locale/'.$data['name']) }}">{{$data['name']}}
                            {{$data['icon']}}</a></li>
                    @endforeach
                    @endif
                </ul>
            </li>
        </ul>
    </div>
    <!-- offcanvas language -->
    <div class="offcanvas-userpanel">
        <ul>
            <li class="offcanvas-userpanel__role">
                <a href="#"><img src="{{asset('Flags/'.$def_lang->languages_code.'.svg')}}"
                    onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                    alt="N/F" height="10"  width="15">{{$def_lang->languages_code}}<i class="ion-ios-arrow-down"></i></a>
                <ul class="user-sub-menu">
                    @if(!empty($Lang_arr))
                    @foreach($Lang_arr as $key=>$data)
                    <li><a class="current" href="{{ url('/lang/locale/'.$data['name']) }}"><img
                                onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                                src="{{asset('Flags/'.$data['name'].'.svg')}}" alt="N/F" height="10"
                                width="15">{{$data['name']}}</a></li>
                    @endforeach
                    @endif
                </ul>
            </li>
        </ul>
    </div>
    <div class="menu-close">
        Menu
    </div>
    <!-- offcanvas menu -->
    <div class="inner customScroll">
        <div class="offcanvas-menu mb-4">
            <ul>
                <li><a href="#"><span class="menu-text">Shop</span></a>
                    @if(!empty($CategoryTree))
                    <ul class="sub-menu">
                        @foreach($CategoryTree as $category)
                        @if(isset($category->two_layer_category) &&
                        !empty($category->two_layer_category))
                        <li>
                            @if(!empty($category->category_name))
                            <a href="{{ url('category/'.$category->categories_slug) }}"> {{
                                $category->category_name }}
                            </a>
                            @endif
                            <ul class="sub-menu">
                                <!-- two layer check -->
                                @foreach($category->two_layer_category as $two_layer)
                                <li>
                                    <a href="{{ url('category/'.$two_layer->categories_slug) }}">
                                        <span class="menu-text">{{ $two_layer->category_name }}</span>
                                        @if(
                                        isset($two_layer->three_layer_category) &&
                                        !empty($two_layer->three_layer_category) &&
                                        sizeof($two_layer->three_layer_category) > 0
                                        )

                                        @endif
                                    </a>
                                    <ul class="sub-menu">
                                        <!-- three layer check -->
                                        @if(isset($two_layer->three_layer_category) &&
                                        !empty($two_layer->three_layer_category))
                                        @foreach($two_layer->three_layer_category as $three_layer)
                                        <li>
                                            <span class="menu-text"> <a
                                                    href="{{ url('category/'.$three_layer->categories_slug) }}">
                                                    {{ $three_layer->category_name }}</span>
                                            </a>
                                        </li>
                                        @endforeach
                                        @endif
                                    </ul>
                                </li>
                                @endforeach
                            </ul>
                        </li>
                        @else
                        <li><a href="{{ url('category/'.$category->categories_slug) }}"> {{
                                $category->category_name }} </a></li>
                        @endif
                        @endforeach
                    </ul>
                    @endif
                </li>

                {{--Dyanamics Menubar --}}

                @if(!empty($main_menu))
                @foreach($main_menu as $key=>$value)
                @if(in_array($value->menu_type, array('1', '2','3')) )
                <li><a href="{{url($value->menu_ref_id==" 0"? '#' : $value->menu_link)}}"><span
                            class="menu-text">{{$value->menu_name}}</span></a>
                    @if(!empty($value->menulist))
                    <ul {{$value->menu_ref_id=="0" ? 'class=sub-menu': '' }} >
                        @foreach($value->menulist as $cmenu)
                        @if(!empty($cmenu['title']))
                        <li>
                            <a href="{{ url($cmenu['link'])}}"> {{ $cmenu['title'] }}</a>
                            @if(!empty($cmenu['subcate']))
                            <ul class="sub-menu">
                                @foreach($cmenu['subcate'] as $smenu)
                                <li>
                                    <a href="{{ url($smenu['link'])}}">
                                        <span class="menu-text">{{ $smenu['title'] }}</span>
                                    </a>
                                </li>
                                @endforeach
                            </ul>
                            @endif
                        </li>
                        @else
                        <li><a href="{{url($value->menu_link)}}" target="_blank">{{$value->menu_name}}</a></li>
                        @endif
                        @endforeach
                    </ul>
                    @endif
                </li>
                @else
                <li><a href="{{url($value->menu_link)}}" >{{$value->menu_name}}</a></li>
                @endif
                @endforeach
                @endif
            </ul>
        </div>
        <!-- OffCanvas Menu End -->
        <div class="offcanvas-social mt-5">
            <ul>
                <li>
                    <a href="{{getSetting('facebook_url')}}" target="_blank"><i class="ion-social-facebook"></i></a>
                </li>
                <li>
                    <a href="{{getSetting('twitter_url')}}" target="_blank"><i class="ion-social-twitter"></i></a>
                </li>
                <li>
                    <a href="{{getSetting('google_url')}}" target="_blank"><i class="ion-social-google"></i></a>
                </li>
                <li>
                    <a href="{{getSetting('youtube_url')}}" target="_blank"><i class="ion-social-youtube"></i></a>
                </li>
                <li>
                    <a href="{{getSetting('instagram_url')}}" target="_blank"><i class="ion-social-instagram"></i></a>
                </li>
            </ul>
        </div>
    </div>
</div>
<!-- OffCanvas Menu End -->

@push('scripts')
<script>
    $(document).ready(function () {

        $(document).on('click', '#searchbutton', function (e) {
            e.preventDefault();
            var data = $('#searchtext').val();
            if(data == ''){
                Notify('Please enter some value for search!');exit;
            }else{
                window.location.href = "/search/" + data;
            }
           
        });
        $(document).on('keyup', '#searchtext', function (e) {
            e.preventDefault();
            var searchVal = $(this).val();

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $.ajax({
                url: '{{ route("SearchSuggestion") }}',
                method: 'POST',
                data: {
                    search: searchVal
                },
                success: function (response) {
                    if(response.searchHtml!=''){
                        $('.searchItem').removeClass('hide');
                        $('.searchItemList').html(response.searchHtml);
                    }
                    else{
                        $('.searchItem').addClass('hide');
                    }
                },
                error: function (error) {
                    Notify(error.message, false);
                }
            });
        });
        // hide search suggestion box
        $('.searchItemList').on('mouseleave', function (e) {
            $('.searchItem').addClass('hide');
        });
    });
    $(window).scroll(function () {
        $('.searchItem').addClass('hide');
    });

</script>
@endpush