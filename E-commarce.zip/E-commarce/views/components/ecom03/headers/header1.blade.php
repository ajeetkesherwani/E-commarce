@php
    if(Request::segment(1)=='search')
    $segment= Request::segment(2);
@endphp


 <!-- ========== HEADER ========== -->
 <header id="header" class="u-header u-header-left-aligned-nav">
    <div class="u-header__section">
        <!-- Topbar -->
        <div class="u-header-topbar py-2 d-none d-xl-block">
            <div class="container">
                <div class="d-flex align-items-center">
                    <div class="topbar-left">
                        <a href="#" class="text-gray-110 font-size-13 hover-on-dark">{{ getSetting('site_slogan') }}</a>
                    </div>
                    <div class="topbar-right ml-auto">
                        <ul class="list-inline mb-0">
                            @if (!empty($top_nav_data))
                            @foreach ($top_nav_data as $key => $value)
                                <li class="list-inline-item mr-0 u-header-topbar__nav-item u-header-topbar__nav-item-border">
                                    <a href="{{ url($value->menu_link) }}" class="u-header-topbar__nav-link">
                                        {{ $value->menu_name}}
                                    </a>
                                </li>
                            @endforeach
                            @endif
                            {{-- Language Work Start here --}}
                            @if (count($Lang_arr) > 1)
                            <li class="list-inline-item mr-0 u-header-topbar__nav-item u-header-topbar__nav-item-border u-header-topbar__nav-item-no-border u-header-topbar__nav-item-border-single">
                                <div class="d-flex align-items-center">
                                    <!-- Language -->
                                    <div class="position-relative">
                                        <a id="languageDropdownInvoker" class="dropdown-nav-link dropdown-toggle d-flex align-items-center u-header-topbar__nav-link font-weight-normal" href="javascript:;" role="button"
                                            aria-controls="languageDropdown"
                                            aria-haspopup="true"
                                            aria-expanded="false"
                                            data-unfold-event="hover"
                                            data-unfold-target="#languageDropdown"
                                            data-unfold-type="css-animation"
                                            data-unfold-duration="300"
                                            data-unfold-delay="300"
                                            data-unfold-hide-on-scroll="true"
                                            data-unfold-animation-in="slideInUp"
                                            data-unfold-animation-out="fadeOut">
                                            <span class="d-inline-block d-sm-none">{{translation('LANGUAGE')}}</span>

                                            <span class="d-none d-sm-inline-flex align-items-center">
                                                <img
                                                src="{{ asset('flags/' . $def_lang->languages_code . '.svg') }}" alt="N/F" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                                                height="10" width="15">{{ $def_lang->languages_code }}
                                            </span>
                                        </a>

                                        <div id="languageDropdown" class="dropdown-menu dropdown-unfold" aria-labelledby="languageDropdownInvoker">
                                        @if (!empty($Lang_arr))
                                            @foreach ($Lang_arr as $key => $data)
                                                <a class="dropdown-item active" href="#">
                                                    <img src="{{ asset('flags/'.$data['name'] . '.svg') }}" alt="N/F" height="10" onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                                                    width="15">
                                                    <a href="{{ url('/lang/locale/' . $data['name']) }}">
                                                        {{ $data['name'] }}
                                                    </a>
                                                </a>
                                            @endforeach
                                        @endif
                                        </div>
                                    </div><!-- End Language -->
                                </div>
                            </li>
                            @endif<!--  Language Work End here -->
                            
                            {{-- Currency Work Start here --}}
                            @if (count($Curr_arr) > 1)
                            <li class="list-inline-item mr-0 u-header-topbar__nav-item u-header-topbar__nav-item-border u-header-topbar__nav-item-no-border u-header-topbar__nav-item-border-single">
                                <div class="d-flex align-items-center">
                                    <!-- Language -->
                                    <div class="position-relative">
                                        <a id="languageDropdownInvoker" class="dropdown-nav-link dropdown-toggle d-flex align-items-center u-header-topbar__nav-link font-weight-normal" href="javascript:;" role="button"
                                            aria-controls="languageDropdown"
                                            aria-haspopup="true"
                                            aria-expanded="false"
                                            data-unfold-event="hover"
                                            data-unfold-target="#languageDropdown"
                                            data-unfold-type="css-animation"
                                            data-unfold-duration="300"
                                            data-unfold-delay="300"
                                            data-unfold-hide-on-scroll="true"
                                            data-unfold-animation-in="slideInUp"
                                            data-unfold-animation-out="fadeOut">
                                            <span class="d-inline-block d-sm-none">US</span>
                                            <span class="d-none d-sm-inline-flex align-items-center">
                                                {{ $defcurrency_data->currencies_code }}
                                                {{ $defcurrency_data->symbol_left }}
                                            </span>
                                        </a>
                                        <div id="languageDropdown" class="dropdown-menu dropdown-unfold" aria-labelledby="languageDropdownInvoker">
                                            @if (!empty($Curr_arr))
                                            @foreach ($Curr_arr as $key => $data)
                                            <a class="dropdown-item active" href="#">English</a>
                                            @endforeach
                                            @endif
                                        </div>
                                    </div>
                                    <!-- End Language -->
                                </div>
                            </li>
                            @endif<!-- Currency Work End here -->

                            <!-- check registraion enable by subcsriber admin -->
                            @if (webFunctionStatus(config('constkey.is_user_registeration_enabled')))
                            @guest
                            <li class="list-inline-item mr-0 u-header-topbar__nav-item u-header-topbar__nav-item-border">
                                <!-- Account Sidebar Toggle Button -->
                                <a id="sidebarNavToggler" href="{{ url('login') }}" role="button" class="u-header-topbar__nav-link"
                                    aria-controls="sidebarContent"
                                    aria-haspopup="true"
                                    aria-expanded="false"
                                    data-unfold-event="click"
                                    data-unfold-hide-on-scroll="false"
                                    data-unfold-target="#"
                                    data-unfold-type="css-animation"
                                    data-unfold-animation-in="fadeInRight"
                                    data-unfold-animation-out="fadeOutRight"
                                    data-unfold-duration="500">
                                    <i class="ec ec-user mr-1"></i>{{ translation('ACCOUNT_TITLE') }}
                                </a><!-- End Account Sidebar Toggle Button -->
                            </li>
                            @endguest
                            <!-- Log out work start here -->
                            @auth
                                <li class="list-inline-item mr-0 u-header-topbar__nav-item u-header-topbar__nav-item-border">
                                    <a href="{{ url('account/dashboard') }}" class="u-header-topbar__nav-link">{{ translation('ACCOUNT_TITLE') }}</a>
                                </li>
                                <li class="list-inline-item mr-0 u-header-topbar__nav-item u-header-topbar__nav-item-border">
                                    <!-- Account Sidebar Toggle Button -->
                                    <a id="sidebarNavToggler"  href="route('logout')"
                                        onclick="event.preventDefault();
                                        document.getElementById('myLogOutForm').submit();"  class="u-header-topbar__nav-link"
                                        
                                        aria-controls="sidebarContent"
                                        aria-haspopup="true"
                                        aria-expanded="false"
                                        data-unfold-event="click"
                                        data-unfold-hide-on-scroll="false"
                                        data-unfold-target="#"
                                        data-unfold-type="css-animation"
                                        data-unfold-animation-in="fadeInRight"
                                        data-unfold-animation-out="fadeOutRight"
                                        data-unfold-duration="500">
                                        {{translation('LOGOUT')}}
                                    </a>
                                    <form method="POST" id="myLogOutForm" action="{{route('logout') }}">
                                        @csrf
                                    </form>
                                    <!-- End Account Sidebar Toggle Button -->
                                </li>
                            @endauth<!--Log out work End here-->
                            @endif
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Topbar -->

        <!-- Logo-Search-header-icons -->
        <div class="py-2 bg-primary-down-lg">
            <div class="container my-0dot5 my-xl-0">
                <div class="row align-items-center">
                    <!-- Logo-offcanvas-menu -->
                    <div class="col-auto">
                        <!-- Nav -->
                        <nav class="navbar navbar-expand u-header__navbar py-0 justify-content-xl-between max-width-270 min-width-270">
                            <!-- Logo -->
                            <a class="order-1 order-xl-0 navbar-brand u-header__navbar-brand u-header__navbar-brand-center" href="{{ url('/') }}" aria-label="Electro">
                                <img src="{{ getImageUrlWithKey('website_logo') }}"
                                onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                                alt="{{ getSetting('site_title') }}-logo" />
                            </a>
                            <!-- End Logo -->

                            <!-- Fullscreen Toggle Button -->
                            <button id="sidebarHeaderInvokerMenu" type="button" class="navbar-toggler d-block btn u-hamburger mr-xl-0"
                                aria-controls="sidebarHeader"
                                aria-haspopup="true"
                                aria-expanded="false"
                                data-unfold-event="click"
                                data-unfold-hide-on-scroll="false"
                                data-unfold-target="#sidebarHeader1"
                                data-unfold-type="css-animation"
                                data-unfold-animation-in="fadeInLeft"
                                data-unfold-animation-out="fadeOutLeft"
                                data-unfold-duration="500">
                                <span id="hamburgerTriggerMenu" class="u-hamburger__box">
                                    <span class="u-hamburger__inner"></span>
                                </span>
                            </button>
                            <!-- End Fullscreen Toggle Button -->
                        </nav>
                        <!-- End Nav -->

                        <!-- ========== HEADER SIDEBAR ========== -->
                        <aside id="sidebarHeader1" class="u-sidebar u-sidebar--left" aria-labelledby="sidebarHeaderInvoker">
                            <div class="u-sidebar__scroller">
                                <div class="u-sidebar__container">
                                    <div class="u-header-sidebar__footer-offset">
                                        <!-- Toggle Button -->
                                        <div class="position-absolute top-0 right-0 z-index-2 pt-4 pr-4 bg-white">
                                            <button type="button" class="close ml-auto"
                                                aria-controls="sidebarHeader"
                                                aria-haspopup="true"
                                                aria-expanded="false"
                                                data-unfold-event="click"
                                                data-unfold-hide-on-scroll="false"
                                                data-unfold-target="#sidebarHeader1"
                                                data-unfold-type="css-animation"
                                                data-unfold-animation-in="fadeInLeft"
                                                data-unfold-animation-out="fadeOutLeft"
                                                data-unfold-duration="500">
                                                <span aria-hidden="true"><i class="ec ec-close-remove text-gray-90 font-size-20"></i></span>
                                            </button>
                                        </div>
                                        <!-- End Toggle Button -->

                                        <!-- Content -->
                                        <div class="js-scrollbar u-sidebar__body">
                                            <div id="headerSidebarContent" class="u-sidebar__content u-header-sidebar__content">
                                                <!-- Logo -->
                                                <a class="navbar-brand u-header__navbar-brand u-header__navbar-brand-center mb-3" href="{{url('/')}}" aria-label="Electro">
                                                    <img src="{{getImageUrlWithKey('website_logo')}}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" 
                                                         alt="{{getSetting('site_title')}}-logo" />
                                                </a>
                                                <!-- End Logo -->

                                                <!-- List -->
                                                <ul id="headerSidebarList" class="u-header-collapse__nav">
                                                    @if (!empty($CategoryTree))
                                                    @foreach ($CategoryTree as $category)
                                                    @if (isset($category->two_layer_category) && !empty($category->two_layer_category))

                                                    <li class="u-has-submenu u-header-collapse__submenu">
                                                        @if (!empty($category->category_name))
                                                            <a class="u-header-collapse__nav-link u-header-collapse__nav-pointer" href="{{ url('category/' . $category->categories_slug) }}" data-target="#headerSidebarComputersCollapse{{$category->categories_slug}}" role="button" data-toggle="collapse" aria-expanded="false" aria-controls="headerSidebarComputersCollapse">
                                                               {{$category->category_name}}
                                                            </a>
                                                        @endif
                                                        
                                                        <div id="headerSidebarComputersCollapse{{$category->categories_slug}}" class="collapse" data-parent="#headerSidebarContent">
                                                            <ul class="u-header-collapse__nav-list">
                                                            @foreach ($category->two_layer_category as $two_layer)
                                                                <li class="">
                                                                    <a class="u-header-collapse__submenu-nav-link" href="{{ url('category/' . $two_layer->categories_slug) }}">
                                                                    {{$two_layer->category_name }}
                                                                    </a>
                                                                </li>
                                                             @endforeach  
                                                            </ul>
                                                        </div>
                                                    </li>
                                                @endif
                                                @endforeach
                                                @endif
                                                </ul>
                                                <!-- End List -->
                                            </div>
                                        </div>
                                        <!-- End Content -->
                                    </div>
                                    <div class="u-header-sidebar__footer text-center">
                                        @auth
                                            <button  class="btn btn-primary">
                                                <!-- Account Sidebar Toggle Button -->
                                                <a id="sidebarNavToggler"  href="route('logout')"
                                                    onclick="event.preventDefault();
                                                    document.getElementById('myLogOutForm').submit();"  class="u-header-topbar__nav-link" aria-controls="sidebarContent"
                                                    aria-haspopup="true"
                                                    aria-expanded="false"
                                                    data-unfold-event="click"
                                                    data-unfold-hide-on-scroll="false"
                                                    data-unfold-target="#"
                                                    data-unfold-type="css-animation"
                                                    data-unfold-animation-in="fadeInRight"
                                                    data-unfold-animation-out="fadeOutRight"
                                                    data-unfold-duration="500">
                                                    {{translation('LOGOUT')}}
                                                </a>
                                                <form method="POST" id="myLogOutForm" action="{{route('logout') }}">
                                                    @csrf
                                                </form>
                                                <!-- End Account Sidebar Toggle Button -->
                                            </button>
                                        @endauth
                                    </div>
                                </div>
                            </div>
                        </aside>
                        <!-- ========== END HEADER SIDEBAR ========== -->
                    </div>
                    <!-- End Logo-offcanvas-menu -->
                    <!-- Search Bar -->
                     @if (webFunctionStatus(config('constkey.is_header_search_box_enabled')))
                    <div class="col d-none d-xl-block">
                        <form class="js-focus-state" id="searchform" >
                            <label class="sr-only" for="searchproduct">{{translation('HEADER_SEARCH')}}</label>
                            <div class="input-group">
                                <input type="search" class="form-control py-2 pl-5 font-size-15 border-right-0 height-40 border-width-2 rounded-left-pill border-primary searchtext" name="searchtext" id="" placeholder="{{ translation('HEADER_SEARCH_PLACEHOLDER') }}" aria-label="Search for Products" aria-describedby="searchProduct1" value="{{ $segment ?? '' }}">
                                <div class="input-group-append">
                                    <button class="btn btn-primary height-40 py-2 px-3 rounded-right-pill searchbutton" type="submit" id="">
                                        <span class="ec ec-search font-size-24"></span>
                                    </button>
                                </div>
                            </div>
                        </form>
                        <div class="searchItem hide ">
                            <div class="searchItemList"></div>
                        </div>
                    </div>
                    @endif
                    <!-- End Search Bar -->
                    <!-- Header Icons -->
                    <div class="col col-xl-auto text-right text-xl-left pl-0 pl-xl-3 position-static">
                        <div class="d-inline-flex">
                            <ul class="d-flex list-unstyled mb-0 align-items-center topnavlist">
                                <!-- Search -->
                                <li class="col d-xl-none px-2 px-sm-3 position-static">
                                    <a id="searchClassicInvoker" class="font-size-22 text-gray-90 text-lh-1 btn-text-secondary" href="javascript:;" role="button"
                                        data-toggle="tooltip"
                                        data-placement="top"
                                        title="Search"
                                        aria-controls="searchClassic"
                                        aria-haspopup="true"
                                        aria-expanded="false"
                                        data-unfold-target="#searchClassic"
                                        data-unfold-type="css-animation"
                                        data-unfold-duration="300"
                                        data-unfold-delay="300"
                                        data-unfold-hide-on-scroll="true"
                                        data-unfold-animation-in="slideInUp"
                                        data-unfold-animation-out="fadeOut">
                                        <span class="ec ec-search"></span>
                                    </a>

                                    <!-- Input -->
                                    @if (webFunctionStatus(config('constkey.is_header_search_box_enabled')))
                                    <div id="searchClassic" class="dropdown-menu dropdown-unfold dropdown-menu-right left-0 mx-2" aria-labelledby="searchClassicInvoker">
                                        <form class="js-focus-state input-group px-3" id="searchform">
                                            <input class="form-control searchtext" type="search" name="searchtext" id="" placeholder="{{ translation('HEADER_SEARCH_PLACEHOLDER') }}" value="{{ $segment ?? '' }}" required>
                                            <div class="input-group-append">
                                                <button class="btn btn-primary px-3" type="button" id="" type="submit"><i class="font-size-18 ec ec-search searchbutton"></i></button>
                                            </div>
                                        </form>
                                        <div class="searchItem hide ">
                                            <div class="searchItemList"></div>
                                        </div>
                                    </div>
                                    @endif
                                    <!-- End Input -->
                                </li>
                                @if (webFunctionStatus(config('constkey.is_wishlist_enabled')) ||webFunctionStatus(config('constkey.is_cart_enabled')))
                                     @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))
                                        <li class="col ">
                                            <a href="{{ url('wishlist') }}" class="text-gray-90 " data-toggle="tooltip" data-placement="top" title="Favorites">
                                                <i class="font-size-22 ec ec-favorites">
                                                    <span class="bg-lg-down-black width-22 height-22 bg-primary position-absolute d-flex align-items-center justify-content-center rounded-circle left-12 top-8 font-weight-bold font-size-12 count-wishlist-total">
                                                        {{ $wishlist_count }}
                                                    </span>
                                                </i>
                                            </a>
                                        </li>
                                @endif
                                <li class="col pr-xl-0 px-sm-3 d-xl-none">
                                    <a href="{{url('/cart')}}" class="text-gray-90 position-relative d-flex " data-toggle="tooltip" data-placement="top" title="Cart">
                                        <i class="font-size-22 ec ec-shopping-bag"></i>
                                        <span class="bg-lg-down-black width-22 height-22 bg-primary position-absolute d-flex align-items-center justify-content-center rounded-circle left-12 top-8 font-weight-bold font-size-12 count-cart-total">
                                            {{ $cart['total_count'] ?? '0' }}
                                        </span>
                                    </a>
                                </li>
                                @guest
                                <li class="col d-xl-none px-sm-3">
                                    <a href="{{ url('login') }}" class="text-gray-90" data-toggle="tooltip" data-placement="top" title="My Account">
                                        <i class="font-size-22 ec ec-user"></i>
                                    </a>
                                </li>
                                @endguest
                                @auth
                                <li class="col d-xl-none px-sm-3">
                                    <a href="{{ url('account/dashboard') }}" class="text-gray-90" data-toggle="tooltip" data-placement="top" title="My Account">
                                        <i class="font-size-22 ec ec-user"></i>
                                    </a>
                                </li>
                                @endauth
                                <li class="col pr-xl-0 px-sm-2 d-none d-xl-block">
                                    @if (webFunctionStatus(config('constkey.is_cart_enabled')))
                                    <div id="basicDropdownHoverInvoker" class="text-gray-90 position-relative d-flex " data-toggle="tooltip" data-placement="top" title="Cart"
                                        aria-controls="basicDropdownHover"
                                        aria-haspopup="true"
                                        aria-expanded="false"
                                        data-unfold-event="click"
                                        data-unfold-target="#basicDropdownHover"
                                        data-unfold-type="css-animation"
                                        data-unfold-duration="300"
                                        data-unfold-delay="300"
                                        data-unfold-hide-on-scroll="true"
                                        data-unfold-animation-in="slideInUp"
                                        data-unfold-animation-out="fadeOut">
                                        <a href="#" class="text-gray-90 ">
                                            <i class="font-size-22 ec ec-shopping-bag"></i>
                                            <span class="bg-lg-down-black width-22 height-22 bg-primary position-absolute d-flex align-items-center justify-content-center rounded-circle left-12 top-8 font-weight-bold font-size-12 count-cart-total">
                                                {{ $cart['total_count'] ?? '0' }}
                                            </span>
                                        </a>
                                    </div>
                                    @endif
                                    <div class="cartDetailModal">
                                        <div id="basicDropdownHover" class="cart-dropdown dropdown-menu dropdown-unfold full_cart_items border-top border-top-primary mt-3 border-width-2 border-left-0 border-right-0 border-bottom-0 left-auto right-0 CartModal" aria-labelledby="basicDropdownHoverInvoker">
                                            <ul class="list-unstyled px-3 pt-3" id="cart_items">
                                                @if(!empty($cart['cart_list']) && sizeof($cart['cart_list'])>0)
                                                @foreach ($cart['cart_list'] as $item)
                                                <li class="border-bottom pb-3 mb-3 cartProduct_id_{{$item->cart_id}}">
                                                    <div class="">
                                                        <ul class="list-unstyled row mx-n2">
                                                            <li class="px-2 col-auto">
                                                                <img class="img-fluid" src="{{getFullImageUrl($item->product->product_image)}}" alt="image" style="height:75px;width:75px;">
                                                            </li>
                                                            <li class="px-2 col">
                                                                <h5 class="text-blue font-size-14 font-weight-bold">{{$item->product->products_name ?? ''}}</h5>
                                                                <span class="font-size-14 quantity_{{$item->product_id}}">{{$item->qty}}</span> x <span class="font-size-14">{{currencyFormat($item->product->sale_price ?? '')}}</span>
                                                            </li>
                                                            <li class="px-2 col-auto" onclick="actionOnPopUpCart({{$item->cart_id}},'del')">
                                                                <a href="#" class="text-gray-90"><i class="ec ec-close-remove"></i></a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </li>
                                                @endforeach
                                                @else
                                                <img src="{{ LoadAssets('assets/img/EmptyImages/Cart-Transparent.png')}}" 
                                                    onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                                                    class="rounded mx-auto d-block" height="200px" alt="{{getSetting('site_title')}} Wishlist-Empty">
                                                    <p class="h4 text-center text-dark mt-3">{{translation('EMPTY_CART_MSG')}}!</p>
                                                    <div class="text-center my-3">
                                                    <a href="{{url('/')}}" class="btn btn-primary-dark-w  btn-sm" role="button" aria-pressed="true">{{translation('CONTINUE_TO_SHOP')}}</a>
                                                @endif
                                            </ul>
                                            <div id="cartBtns">
                                            @if(!empty($cart['cart_list']) && sizeof($cart['cart_list'])>0)
                                            <div class="flex-center-between px-4 pt-2 cart-btns">
                                                <a href="{{url('/cart')}}" class="btn btn-soft-secondary mb-3 mb-md-0 font-weight-normal px-5 px-md-4 px-lg-5">{{translation('VIEW_CART')}}</a>
                                                <a href="{{url('/checkout')}}" class="btn btn-primary-dark-w ml-md-2 px-5 px-md-4 px-lg-5">{{translation('CHECKOUT')}}</a>
                                            </div>
                                            @endif
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                @endif
                            </ul>
                        </div>
                    </div>
                    <!-- End Header Icons -->
                </div>
            </div>
        </div>
        <!-- End Logo-Search-header-icons -->

        <!-- Vertical-and-secondary-menu -->
       <div class="vertical-header-wrapper">
       <div class="d-none d-xl-block container">
            <div class="row">
                <!-- Vertical Menu -->
                <div class="col-md-auto d-none d-xl-block">
                    <div class="max-width-270 min-width-270">
                        <!-- Basics Accordion -->
                        <div id="basicsAccordion">
                           <!-- Card -->
                            <div class="card border-0">
                                @if (webFunctionStatus(config('constkey.is_categories_enabled'))) 
                                    <div class="card-header card-collapse border-0" id="basicsHeadingOne">
                                        <button type="button" class="btn-link btn-remove-focus btn-block d-flex card-btn py-3 text-lh-1  shadow-none btn-primary border-0 font-weight-bold text-gray-90"
                                            data-toggle="collapse"
                                            data-target="#basicsCollapseOne"
                                            aria-expanded="false"
                                            aria-controls="basicsCollapseOne">
                                            <span class="ml-0 text-gray-90 mr-2">
                                                <span class="fa fa-list-ul"></span>
                                            </span>
                                            <span class="pl-1 text-gray-90 fw-bold">{{ translation('HEADER_ALL_CATEGORIES_TITLE') }}</span>
                                        </button>
                                    </div>
                                    <div id="basicsCollapseOne" class="collapse vertical-menu"
                                        aria-labelledby="basicsHeadingOne"
                                        data-parent="#basicsAccordion">
                                        <div class="card-body p-0">
                                            <nav class="js-mega-menu navbar navbar-expand-xl u-header__navbar u-header__navbar--no-space hs-menu-initialized">
                                                <div id="navBar" class="collapse navbar-collapse u-header__navbar-collapse">
                                                    <ul class="navbar-nav u-header__navbar-nav  border-primary border-top-0">
                                                    @if (!empty($CategoryTree))
                                                            @foreach ($CategoryTree as $category)
                                                                @if (isset($category->two_layer_category) && !empty($category->two_layer_category))
                                                                <li class="nav-item hs-has-mega-menu  u-header__nav-item"    
                                                                    data-event="hover" 
                                                                    data-position="left"
                                                                    data-animation-in="slideInUp"
                                                                    data-animation-out="fadeOut"
                                                                    >
                                                                    @if (!empty($category->category_name))
                                                                        <a id="basicMegaMenu" 
                                                                            class="nav-link u-header__nav-link u-header__nav-link-toggle" 
                                                                            aria-haspopup="true" 
                                                                            aria-expanded="false"
                                                                            href="{{ url('category/' . $category->categories_slug) }}">
                                                                            {{$category->category_name }}
                                                                        </a>
                                                                    @endif
                                                                    @if(!empty($category->two_layer_category))
                                                                        <div class="hs-mega-menu vmm-tfw u-header__sub-menu" data-parent="#headerSidebarContent" aria-labelledby="basicMegaMenu">
                                                                            <div class="vmm-bg">
                                                                            </div>
                                                                            @if(!empty($category->two_layer_category))
                                                                                <div class="row u-header__mega-menu-wrapper">
                                                                                    <div class="col mb-3 mb-sm-0">
                                                                                        <span class="u-header__sub-menu-title">
                                                                                            {{$category->category_name}}
                                                                                        </span>
                                                                                        <ul class="u-header__sub-menu-nav-group mb-3">
                                                                                            @foreach ($category->two_layer_category as $two_layer)
                                                                                                <li>
                                                                                                    <a class="nav-link u-header__sub-menu-nav-link" href="{{ url('category/' . $two_layer->categories_slug) }}">{{ $two_layer->category_name}}</a>
                                                                                                </li>
                                                                                            @endforeach
                                                                                        </ul>
                                                                                    </div>
                                                                                </div>
                                                                            @endif
                                                                        </div>
                                                                    @endif
                                                                    @endif
                                                                </li>
                                                            @endforeach
                                                        @endif
                                                    </ul>
                                                </div>
                                            </nav>
                                        </div>
                                    </div>
                                @endif
                            </div><!-- End Card -->
                        </div><!-- End Basics Accordion -->
                    </div>
                </div><!-- End Vertical Menu -->
                <!-- Secondary Menu -->
                <div class="col">
                    <!-- Nav -->
                    <nav class="js-mega-menu navbar navbar-expand-md u-header__navbar u-header__navbar--no-space">
                        <!-- Navigation -->
                        <div id="navBar" class="collapse navbar-collapse u-header__navbar-collapse">
                            @if (!empty($main_menu))
                                <ul class="navbar-nav u-header__navbar-nav ">
                                    <!-- Home -->
                                    @foreach ($main_menu as $key => $value)
                                        @if (in_array($value->menu_type, ['1', '2', '3'])) 
                                            <li class="nav-item hs-has-mega-menu u-header__nav-item"
                                                data-animation-in="slideInUp"
                                                data-animation-out="fadeOut"
                                                data-position="left" {{ $value->menu_ref_id == '0' ? 'class=menu-dropdown' : '' }}>
                                                <a id="homeMegaMenu"  class="nav-link u-header__nav-link 
                                                @if (!empty($value->menulist)) 
                                                u-header__nav-link-toggle  @endif text-sale"
                                                href="{{url($value->menu_ref_id == '0' ? '#' : (($value->menu_link == '')  ? '#' : $value->menu_link))}}" aria-haspopup="true" aria-expanded="false">
                                                    {{ $value->menu_name }}
                                                    @if (!empty($value->menulist))
                                                        <i class="ion-ios-arrow-down"></i>
                                                    @endif
                                                </a>
                                                @if (!empty($value->menulist))
                                                    <!-- Home - Mega Menu -->
                                                    <div class="hs-mega-menu w-100 u-header__sub-menu" aria-labelledby="homeMegaMenu">
                                                        <div class="row u-header__mega-menu-wrapper">
                                                            <div class="col-md-3">
                                                                <ul class="u-header__sub-menu-nav-group">
                                                                    @foreach ($value->menulist as $cmenu)
                                                                        @if (!empty($cmenu['title']))
                                                                            <li>
                                                                                <a href="{{url($cmenu['link'])}}" class="nav-link u-header__sub-menu-nav-link"><b>{{$cmenu['title']}}</b>
                                                                                </a>
                                                                                @if (!empty($cmenu['subcate']))
                                                                                    <ul class="u-header__sub-menu-nav-group">
                                                                                        @foreach ($cmenu['subcate'] as $smenu)
                                                                                            <li class="menu-dropdown position-static">
                                                                                                <a href="{{url($smenu['link'])}}" class="nav-link u-header__sub-menu-nav-link">{{ $smenu['title']}}</a>
                                                                                            </li>
                                                                                        @endforeach
                                                                                    </ul>
                                                                                @endif
                                                                            </li>
                                                                        @endif
                                                                    @endforeach
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div><!-- End Home Mega Menu -->
                                                @endif
                                            </li>
                                        @endif
                                    @endforeach<!-- End Home -->
                                </ul>
                            @endif
                        </div><!-- End Navigation -->
                    </nav><!-- End Nav -->
                </div><!-- End Secondary Menu -->
            </div>
        </div>
       </div>
        <!-- End Vertical-and-secondary-menu -->
    </div>
</header>
<!-- ========== END HEADER ========== -->


@push('scripts')
    <script>
        $(document).ready(function() {
            $('.searchItem').hide();
            $(document).on('click', '.searchbutton', function (e) {
                e.preventDefault();
                let formIns = $(this).parents('form:first');
                var data = formIns.find('.searchtext').val();

                //var data = $('.searchtext').val();
                if(data == ''){
                    Notify('{{translation('ERROR_SEARCH_MSG')}}!');exit;
                }else{
                    window.location.href = "/search/" + data;
                }
            });

            $(document).on('keyup', '.searchtext', function(e) {
                e.preventDefault();
                $('.searchItem').show();    
                var searchVal = $(this).val();

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                $.ajax({
                    url: '{{ route('SearchSuggestion') }}',
                    method: 'POST',
                    data: {
                        search: searchVal
                    },
                    success: function(response) {
                        console.log(response)
                        if (response.searchHtml != '') {
                            $('.searchItem').removeClass('hide');
                            $('.searchItemList').html(response.searchHtml);
                        } else {
                            $('.searchItem').addClass('hide');
                        }
                    },
                    error: function(error) {
                        Notify(error.message, false);
                    }
                });
            });
            // hide search suggestion box
            $('.searchItemList').on('mouseleave', function(e) {
                $('.searchItem').hide();
            });

            $(window).scroll(function() {
                $('.searchItem').addClass('hide');
            });
        });
    </script>
@endpush
