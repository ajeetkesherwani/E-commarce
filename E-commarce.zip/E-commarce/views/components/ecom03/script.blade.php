
    <!-- JS Global Compulsory -->
    <script src="{{LoadAssets('assets/vendor/jquery/dist/jquery.min.js')}}"></script>
    <script src="{{LoadAssets('assets/vendor/jquery-migrate/dist/jquery-migrate.min.js')}}"></script>
    <script src="{{LoadAssets('assets/vendor/popper.js/dist/umd/popper.min.js')}}"></script>
    <script src="{{LoadAssets('assets/vendor/bootstrap/bootstrap.min.js')}}"></script>

    <!-- JS Implementing Plugins -->
    <script src="{{LoadAssets('assets/vendor/appear.js')}}"></script>
    <script src="{{LoadAssets('assets/vendor/jquery.countdown.min.js')}}"></script>
    <script src="{{LoadAssets('assets/vendor/hs-megamenu/src/hs.megamenu.js')}}"></script>
    <script src="{{LoadAssets('assets/vendor/svg-injector/dist/svg-injector.min.js')}}"></script>
    <script src="{{LoadAssets('assets/vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js')}}"></script>
    <script src="{{LoadAssets('assets/vendor/jquery-validation/dist/jquery.validate.min.js')}}"></script>
    {{-- <script src="{{LoadAssets('assets/vendor/fancybox/jquery.fancybox.min.js')}}"></script> --}}
    <script src="{{LoadAssets('assets/vendor/typed.js/lib/typed.min.js')}}"></script>
    <script src="{{LoadAssets('assets/vendor/slick-carousel/slick/slick.js')}}"></script>
    <script src="{{LoadAssets('assets/vendor/bootstrap-select/dist/js/bootstrap-select.min.js')}}"></script>

    <!-- JS Electro -->
    <script src="{{LoadAssets('assets/js/hs.core.js')}}"></script>
    <script src="{{LoadAssets('assets/js/components/hs.countdown.js')}}"></script>
    <script src="{{LoadAssets('assets/js/components/hs.header.js')}}"></script>
    <script src="{{LoadAssets('assets/js/components/hs.hamburgers.js')}}"></script>
    <script src="{{LoadAssets('assets/js/components/hs.unfold.js')}}"></script>
    <script src="{{LoadAssets('assets/js/components/hs.focus-state.js')}}"></script>
    <script src="{{LoadAssets('assets/js/components/hs.malihu-scrollbar.js')}}"></script>
    <script src="{{LoadAssets('assets/js/components/hs.validation.js')}}"></script>
    <script src="{{LoadAssets('assets/js/components/hs.fancybox.js')}}"></script>
    <script src="{{LoadAssets('assets/js/components/hs.onscroll-animation.js')}}"></script>
    <script src="{{LoadAssets('assets/js/components/hs.slick-carousel.js')}}"></script>
    <script src="{{LoadAssets('assets/js/components/hs.show-animation.js')}}"></script>
    <script src="{{LoadAssets('assets/js/components/hs.svg-injector.js')}}"></script>
    <script src="{{LoadAssets('assets/js/components/hs.go-to.js')}}"></script>
    <script src="{{LoadAssets('assets/js/components/hs.selectpicker.js')}}"></script>
    <script src="{{LoadAssets('assets/js/components/hs.quantity-counter.js')}}"></script>


 <!-- JS Plugins Init. -->
        <script>
            $(window).on('load', function () {
                // initialization of HSMegaMenu component
                $('.js-mega-menu').HSMegaMenu({
                    event: 'hover',
                    direction: 'horizontal',
                    pageContainer: $('.container'),
                    breakpoint: 767.98,
                    hideTimeOut: 0
                });

                // initialization of svg injector module
                $.HSCore.components.HSSVGIngector.init('.js-svg-injector');
            });

            $(document).on('ready', function () {
                // initialization of header
                $.HSCore.components.HSHeader.init($('#header'));

                // initialization of animation
                $.HSCore.components.HSOnScrollAnimation.init('[data-animation]');

                // initialization of unfold component
                $.HSCore.components.HSUnfold.init($('[data-unfold-target]'), {
                    afterOpen: function () {
                        $(this).find('input[type="search"]').focus();
                    }
                });

                // initialization of popups
                $.HSCore.components.HSFancyBox.init('.js-fancybox');

                // initialization of countdowns
                var countdowns = $.HSCore.components.HSCountdown.init('.js-countdown', {
                    yearsElSelector: '.js-cd-years',
                    monthsElSelector: '.js-cd-months',
                    daysElSelector: '.js-cd-days',
                    hoursElSelector: '.js-cd-hours',
                    minutesElSelector: '.js-cd-minutes',
                    secondsElSelector: '.js-cd-seconds'
                });

                // initialization of malihu scrollbar
                $.HSCore.components.HSMalihuScrollBar.init($('.js-scrollbar'));

                // initialization of forms
                $.HSCore.components.HSFocusState.init();

                // initialization of form validation
                $.HSCore.components.HSValidation.init('.js-validate', {
                    rules: {
                        confirmPassword: {
                            equalTo: '#signupPassword'
                        }
                    }
                });

                // initialization of show animations
                $.HSCore.components.HSShowAnimation.init('.js-animation-link');

                // initialization of fancybox
                $.HSCore.components.HSFancyBox.init('.js-fancybox');

                // initialization of slick carousel
                $.HSCore.components.HSSlickCarousel.init('.js-slick-carousel');

                // initialization of go to
                $.HSCore.components.HSGoTo.init('.js-go-to');

                // initialization of hamburgers
                $.HSCore.components.HSHamburgers.init('#hamburgerTrigger');

                // initialization of unfold component
                $.HSCore.components.HSUnfold.init($('[data-unfold-target]'), {
                    beforeClose: function () {
                        $('#hamburgerTrigger').removeClass('is-active');
                    },
                    afterClose: function() {
                        $('#headerSidebarList .collapse.show').collapse('hide');
                    }
                });

                $('#headerSidebarList [data-toggle="collapse"]').on('click', function (e) {
                    e.preventDefault();

                    var target = $(this).data('target');

                    if($(this).attr('aria-expanded') === "true") {
                        $(target).collapse('hide');
                    } else {
                        $(target).collapse('show');
                    }
                });

                // initialization of unfold component
                $.HSCore.components.HSUnfold.init($('[data-unfold-target]'));

                // initialization of select picker
                $.HSCore.components.HSSelectPicker.init('.js-select');
            });
        </script>

<!-- // toastify -->
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
<script>
    function Notify(msg, status) {
        Toastify({
            text: msg,
            className: "info",
            duration: 1000,
            close: true,
            progressBar: true,
            hideDuration: 1000,
            timeOut: 1000,
            gravity: "top", // `top` or `bottom`
            position: "right", // `left`, `center` or `right`
            style: {
                background: status ? "linear-gradient(to right, yellow, orange)" : "red",
                color: "black", 
            }
        }).showToast();
    }
</script>

@if(getsetting('newsletter_popup')=='yes')
    @if(empty(Cache::get("loaditem")))
        <script>
            window.onload = function showNewsLatter() {
                $.ajax({
                    url: "/onloadnewslatter",
                    success: function (response) {
                        $(".newsmodal").html(response);
                        $('#onloadModal').modal('show');
                    },
                    error: function (error) {    
                    },
                });
            }
        </script>
    @endif
@endif

<!--Enquiry Form Modal -->

<script>
    function showEnquiryForm() {
        $('#EnquiryModal').modal('show');
    }
</script>

<script>

    // Attribute to Price
    function attributeToprice() {
        let detail_choosen_attributes = [];
        attr_id = 0;
        var ele = $(".input-radio");
        $(ele).each(function(i) {
            if (this.checked) {
                if (!detail_choosen_attributes.includes(this.value)) {
                    var aVal = this.value.split('_');
                    detail_choosen_attributes.push({
                        options_id: aVal[0],
                        options_values_id: aVal[1]
                    });
                }
            }
        });

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        var data = {
            'product_id': $('#products_id').val(),
            'OrderdQty' : $('#qtyItemAdd').val(),
            'attribute_array': detail_choosen_attributes,
        }

        $.ajax({
            type: "POST",
            url: "/attribute-price",
            data: data,
            dataType: "json",
            success: function(response) {
                if (response.isdiscount == 'yes') {
                    $('.discount_amount').text(response.totalDiscountPrice);
                }
                $(".old-price").text(response.final_price);
            }
        });

    }

    // Onclick Attributes function call

    $(document).on('click', '.input-radio', function() {
        attributeToprice();
    });

    // Onload Document function call

    $(document).ready(function() {
        attributeToprice();
    });


    //  Calculate Wholesale Price and Normal Price  on  Qty Start

    $(document).on('click', '.qtybutton', function () {
        ValidateMinQty();
    });

    function QtyToPrice() {
        ValidateMinQty();
    }

   //  Calculate Wholesale Price and Normal Price  on  Qty End


    //Validate Minimum Qty
    function ValidateMinQty(){
        var min_ord_qty = $('.minordqty').val();
        var qtyItemAdd = $('#qtyItemAdd').val();
        
        var alertHtml =`<div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <strong>Sorry !</strong> Please Add minimum ${min_ord_qty} Qty.
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            </div>`;
                            
        if (min_ord_qty != 'undefined') {
            if (Number(qtyItemAdd) < Number(min_ord_qty)) {
                $('#qtyItemAdd').val(min_ord_qty);
                $('.qty_alert').html(alertHtml);
            }
            else {
                if(qtyItemAdd<1)
                $('#qtyItemAdd').val(1);
                attributeToprice();
            }
        } 
        else {
            attributeToprice();
        }
    }


</script>

<script>
    function addToCart(product_id, qty = 1, attributes_id = '') {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url: '{{ route("addUpdateToCart") }}',
            method: 'POST',
            data: {
                qty: qty,
                attributes_id: attributes_id,
                product_id: product_id,
             },
            success: function (response) {
                    var html='';
                    var btnHtml=`<div class="flex-center-between px-4 pt-2 cart-btns">
                                <a href="{{url('/cart')}}" class="btn btn-soft-secondary mb-3 mb-md-0 font-weight-normal px-5 px-md-4 px-lg-5">View cart</a>
                                <a href="{{url('/checkout')}}" class="btn btn-primary-dark-w ml-md-2 px-5 px-md-4 px-lg-5">Checkout</a>
                                </div>`;

                    $.each(response.cartlist, function(key, cart_val) {
                    html+=`<li class="border-bottom pb-3 mb-3">
                        <div class="">
                            <ul class="list-unstyled row mx-n2">
                                <li class="px-2 col-auto">
                                    <img class="img-fluid" src="${cart_val.product.image_url}" alt="${cart_val.product.products_name}" style="height:75px;width:75px;">
                                </li>
                                <li class="px-2 col">
                                    <h5 class="text-blue font-size-14 font-weight-bold">${cart_val.product.products_name}</h5>
                                    <span class="font-size-14">${cart_val.qty} × ${cart_val.product.product_base_rate}</span>
                                </li>
                                <li class="px-2 col-auto">
                                    <a href="javascript:void(0)" class="text-gray-90" onclick="actionOnPopUpCart(${cart_val.cart_id},'del')"><i class="ec ec-close-remove"></i></a>
                                </li>
                            </ul>
                        </div>
                      </li>`;
                    });

                    $('#cartBtns').removeClass('d-none');
                    $('#cartBtns').empty();
                    $('#cartBtns').html(btnHtml);
                    $('#cart_items').html(html);
                    $('.count-cart-total').html(response.total_count);
                    Notify('Item Added To Cart !', true);
               
            },
            error: function (error) {
                Notify("Some Error In Add To Cart", false);
            }
        });
    }

        // header cart pop up

        function actionOnPopUpCart(cart_id, type){
        var qty = $(`#${cart_id}_qty`).val();

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
            url:'{{ route("incDecDelPopUpCart") }}',
            method:'POST',
            data:{
                cart_id : cart_id,
                qty:qty, 
                type:type,
            },
            success:function(response){
                var html='';
                var count=0;
                var btnHtml='';

                if(response.cartresponse.total_count>0)
                {
                $.each(response.cartresponse.cart_list, function(key, cart_val) {
                html+=`<li class="border-bottom pb-3 mb-3">
                        <div class="">
                            <ul class="list-unstyled row mx-n2">
                                <li class="px-2 col-auto">
                                    <img class="img-fluid" src="${cart_val.product.image_url}" alt="${cart_val.product.products_name}" style="height:75px;width:75px;">
                                </li>
                                <li class="px-2 col">
                                    <h5 class="text-blue font-size-14 font-weight-bold">${cart_val.product.products_name}</h5>
                                    <span class="font-size-14">${cart_val.qty} × ${cart_val.product.sale_price}</span>
                                </li>
                                <li class="px-2 col-auto">
                                    <a href="javascript:void(0)" class="text-gray-90" onclick="actionOnPopUpCart(${cart_val.cart_id},'del')"><i class="ec ec-close-remove"></i></a>
                                </li>
                            </ul>
                        </div>
                      </li>`;                
                });
                }
                else
                {
                    html+=`<img src="{{ LoadAssets('assets/img/EmptyImages/Cart-Transparent.png')}}" 
                            onerror="this.onerror=null; this.src='{{ asset(config('constkey.no_image')) }}'"
                            class="rounded mx-auto d-block" height="200px" width="200px" alt="{{getSetting('site_title')}} Wishlist-Empty">
                            <p class="h4 text-center text-dark mt-3">Your cart is empty !</p>
                            <div class="text-center my-3">
                            <a href="{{url('/')}}" class="btn btn-primary  btn-sm" role="button" aria-pressed="true">Continue to shop</a>`; 
                    // html+=`<p class="h4 text-center text-dark mt-3">Your cart is empty !
                    //         <div class="text-center> 
                    //         <a href="{{url('/')}}" class="btn btn-primary  btn-sm" role="button" aria-pressed="true">
                    //         </a>
                    //         </div>`;
                    $('#cartBtns').addClass('d-none');
                }
                
                $('#cart_items').empty();
                $('#cart_items').html(html);
                $('.count-cart-total').html(response.cartresponse.total_count);  
                          
                var msg = type=== 'del' ? 'Product Removed From Cart !' : 'Product Qty Updated To Cart !';
                Notify(msg, true);
            },
            error:function(error){
                Notify("Not able to add", false);
            }
        });

        }

     //Wishlist Ajax start
         
     function addToWishListFromDetail(product_id) {
            $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
            url: '{{ route("addUpdateToWishList") }}',
            method: 'POST',
            data: {
                product_id: product_id,
            },
            success: function (response) {
                //  if(response == 1){
                    $('.count-wishlist-total').html(response.wish_list_item_html);
                    Notify('Item Added To WishList !', true);
                    $(".ion-android-favorite-outline").addClass('whishlist-active');
                //  }else{
                //     Notify('Please Login to add products in Wishlist!');
                //  }               
            },
            error: function (error) {
               // Notify(error.message, false);
                Notify('Please Login to add products in Wishlist!');
            }
        });
        }

        //End of Wishlist Ajax 

    function showfunction(slug) {
        var Callurl = `{{ url('showproduct')}}/` + slug;

        $.ajaxSetup({
            headers: {
                "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
            },
        });

        $.ajax({
            type: "POST",
            url: Callurl,
            data: {
                slug: slug,
            },
            success: function (response) {
                $("#product-detail-modal").html(response);
                $('#productModalShow').modal('show');
            },
            error: function (error) { },
        });
    }

    let choosen_attributes = [];

    function addToCartFromModalDetail(product_id) {
        let detail_choosen_attributes = [];
        var qtyItemAdd = $('#modalqtyItemAdd').val();
        let attributes = choosen_attributes.join(',');
        var source = $('#source').val();

        if (attributes == '') {
            $('input[type="radio"]:checked').each(function() {
                if (!detail_choosen_attributes.includes(this.value)) {
                    detail_choosen_attributes.push(this.value);
                }
            });
              let attributes = detail_choosen_attributes.join(',');
              addToCart(product_id, qtyItemAdd, attributes);
            } else {
            addToCart(product_id, qtyItemAdd, attributes);
        }
    }

    function chooseModalAttributes(params) {
        if (!choosen_attributes.includes(params.value)) {
            choosen_attributes.push(params.value);
        }
    }

    // Custome form submitted

    $(".customFrom").on('submit',function(e){
    e.preventDefault();
    $('.customFrom').addClass('was-validated');
    if ($('.customFrom')[0].checkValidity() === false) {
        event.stopPropagation();
    } else {
    let formData = $(this).serialize();
   
    /*Ajax Request Header setup*/
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $.ajax({
        url: "{{ route('customFormSubmit')}}",
        method: 'post',
        data: formData,

        beforeSend: function() {
          $(".customFrom :submit").addClass('disabled');
          $(".customFrom :submit").html('Submitting...');
        },


        success: function(response){
            if(response.status == 0){
                 $.each(response.message, function(i, v) {
                    console.log('#erro_'+i);
                    //$('.result').append(v); 
                    $('#'+i+'-error').html(v);
                });
            } else{
                // $('.result').append(response.message);
                $('.customFrom').removeClass('was-validated');
                Notify('Data send successfully',true);
                $('.customFrom').trigger("reset");
            }
        },

        complete: function() {
          $('.customFrom').removeClass('was-validated');
          $(".customFrom :submit").removeClass('disabled');
          $(".customFrom :submit").html('Submit');
        }
    });
 }

});


// Modal Subscriber

    $(document).ready(function () {
        $(document).on('click', '#modal_subscribe', function (e) {
            e.preventDefault();
            $('#newsltrModalForm').addClass('was-validated');
          if ($('#newsltrModalForm')[0].checkValidity() === false) {
                event.stopPropagation();
          } else {
            var data = {
                'customer_email': $('#customeremail').val(),
            }
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "/newslatterstore",
                data: data,
                dataType: "json",

                beforeSend: function() {
                $("#modal_subscribe").addClass('disabled');
                $("#modal_subscribe").html('Submitting...');
                },
                success: function (response) {
                    if (response.status == 400) {
                        $('#email_err').text(response.error.customer_email);
                    }
                    else {
                        $('#onloadModal').modal('hide');
                        Notify("{{translation('SUBSCRIBE_SUCCESS_MSG')}}", true);
                    }
                },
                complete: function() {
                $('#newsltrModalForm').removeClass('was-validated');
                $("#modal_subscribe").removeClass('disabled');
                $("#modal_subscribe").html('{{translation('SUBMIT')}}');
                }
            });
          }
        });  
    });
</script>

