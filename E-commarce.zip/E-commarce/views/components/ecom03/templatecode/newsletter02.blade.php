<div id="mc_embed_signup" class="subscribe-form">
<form id="newslatterform" class="validate needs-validation" 
name="mc-embedded-subscribe-form" method="post" novalidate>
@csrf
<div id="mc_embed_signup_scroll" class="mc-form row">
    <div class="col-md-12">
        <div class="js-form-message form-group">
            <label class="form-label">Enter Your Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" value="{{old('customer_name')}}" name="customer_name" required=""  placeholder="{{translation('ENTER_YOUR_NAME_HERE')}}" aria-label=""  data-msg="Please enter your first name." data-error-class="u-has-error" data-success-class="u-has-success" autocomplete="off">
            <p class="text-danger subscriber_name_error" style="font-size:16px;"></p>
        </div>
        <!-- End Input -->
    </div>
    <div class="col-md-12">
        <label class="form-label">Enter Your Email<span class="text-danger">*</span></label>
        <input class="form-control email" type="email" placeholder="{{translation('ENTER_YOUR_EMAIL_HERE')}}" name="customer_email" required />
        <p class="text-danger mail_error" style="font-size:16px;"></p>
        <div class="text-center mb-3">
            <button type="submit" class="btn btn-primary-dark-w px-5 w-50 registerButton" name="subscribe">{{translation('SIGN_UP')}}</button>
        </div>
        <input type="reset" hidden id="configreset" value="Reset">
    </div>
</div>
</form>
</div>
