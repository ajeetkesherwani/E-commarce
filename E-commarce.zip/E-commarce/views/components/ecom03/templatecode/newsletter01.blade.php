<form class="validate needs-validation" id="newslatterform" method="post" novalidate>
    @csrf
    <label class="sr-only" for="subscribeSrEmail">{{translation('ENTER_YOUR_EMAIL_HERE')}}</label>
    <div class="input-group input-group-pill">
        <input type="email" class="form-control border-2 height-40 email" name="customer_email" id="subscribeSrEmail" placeholder="{{translation('ENTER_YOUR_EMAIL_HERE')}}" aria-label="Email address" aria-describedby="subscribeButton" required>
        <div class="text-center mb-3">
            <button type="submit" class="btn btn-primary-dark-w px-5 w-50 " name="subscribe">{{translation('SIGN_UP')}}</button>
        </div>
        <input type="reset" hidden id="configreset" value="Reset">
    </div>
    <span class="text-danger mail_error" style="font-size:16px;"></span>
</form>
