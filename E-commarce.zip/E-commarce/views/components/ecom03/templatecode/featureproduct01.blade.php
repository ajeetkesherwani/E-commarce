@php
use App\Models\Ecom\Services\EcomService;
use App\Models\WishList;
$wishlistAry = WishList::getProductsAry();
@endphp

@if(!empty($featureGroupList))
@foreach($featureGroupList as $groupKey=>$featureGroup)
@if(!empty($featureGroup->featured_product) && sizeof($featureGroup->featured_product) > 0 )
<div class="position-relative">

        @if($viewType == 'grid')
         <!-------------------- Grid View Start------------------------>
        <div class="border-bottom border-color-1 mb-2">
            <h3 class="section-title section-title__full d-inline-block mb-0 pb-2 font-size-22">{{translation($featureGroup->group_name)}}</h3>
        </div>
        <ul class="row list-unstyled products-group no-gutters">
            @foreach ($featureGroup->featured_product as $featured_product )
                @if(!empty($featured_product->product))
                    @php
                    $avgrating=AvgRating($featured_product->product->product_id);
                    @endphp
                    <li class="col-6 col-md-3 col-xl-2gdot4-only col-wd-2 product-item">
                        <div class="product-item__outer h-100">
                            <div class="product-item__inner px-xl-4 p-3">
                                <div class="product-item__body pb-xl-2">
                                    <div class="mb-2"><a href="{{ EcomService::url($featured_product->product->product_id , 'product')}}" class="font-size-12 text-gray-5">Model : {{ $featured_product->product->product_model ?? '' }}</a></div>
                                    <h5 class="mb-1 product-item__title"><a href="{{ EcomService::url($featured_product->product->product_id , 'product')}}" class="text-blue font-weight-bold">{{ Str::limit($featured_product->product->product_slug ?? '',50)}}</a></h5>
                                    <div class="mb-2">
                                        <a href="{{ EcomService::url($featured_product->product->product_id , 'product')}}" class="d-block text-center" onclick="showfunction('{{ $featured_product->product->product_slug }}')"><img class="img-fluid" src="{{getFullImageUrl($featured_product->product->product_image)}}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="{{$featured_product->product->products_name ?? ''}}"></a>
                                    </div>

                                    @if($featured_product->product->products_prices!=null)
                                            <div class="row d-flex">
                                                @foreach($featured_product->product->products_prices as $holeprice)
                                                    @if($holeprice->discount_percent !='0')
                                                        <div class="text-gray-100">
                                                            <del>
                                                                <small class="text-danger">
                                                                    {{currencyFormat($holeprice->max_sale_price) }}
                                                                </small>
                                                            </del>
                                                        </div>&nbsp;
                                                    @endif
                                                    <div class="text-gray-100">
                                                        {{ currencyFormat($holeprice->sale_price ?? '0.00') }} 
                                                    </div>
                                                    @if($holeprice->discount_percent != '0')
                                                        <div class="text-gray-100">
                                                            <small class="text-success ms-1">
                                                                {{ currencyFormat( $holeprice->discount_percent )}}% {{translation('PRODUCT_DISCOUNT')}}
                                                            </small>
                                                        </div>
                                                    @endif
                                                    @break
                                                @endforeach
                                            </div>
                                        @else
                                            @if($featured_product->product->discount_type != 'no')
                                                <div class="text-gray-100">
                                                    <del>
                                                        <small>
                                                            {{currencyFormat($featured_product->product->max_sale_price) }}
                                                        </small>
                                                    </del>
                                                </div>
                                        @endif
                                        <div class="text-gray-100 ">
                                            {{ currencyFormat($featured_product->product->sale_price ?? '0.00') }} 
                                        </div>
                                        @if($featured_product->product->discount_type != 'no')
                                            @if($featured_product->product->discount_type == 'flat')
                                                <div class="text-gray-100">
                                                    <small class="discount-price ms-1">
                                                        {{ currencyFormat( $featured_product->product->discount_percent )}} {{translation('PRODUCT_DISCOUNT')}}
                                                    </small>
                                                </div>
                                            @else
                                                <div class="text-gray-100">
                                                    <small class="discount-price ms-1">
                                                        {{ currencyFormat( $featured_product->product->discount_amount )}}% {{translation('PRODUCT_DISCOUNT')}}
                                                    </small>
                                                </div>
                                            @endif
                                        @endif
                                    @endif 

                                </div>

                                <div class="product-item__footer">
                                    <div class="border-top pt-2 flex-center-between flex-wrap">
                                        <a href="#" class="text-gray-6 font-size-13">
                                            @if(!empty($avgrating))
                                                @for($i=0;$i<5;$i++) 
                                                    @if($i<$avgrating) 
                                                        <small class="fas fa-star text-warning"></small>
                                                    @else
                                                        <small class="fas fa-star text-secondary"></small>
                                                    @endif
                                                @endfor
                                            @endif
                                        </a>
                                        @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))
                                            <a href="javascript:void(0);" onclick="addToWishListFromDetail({{ $featured_product->product->product_id }})"
                                                class="text-gray-6 font-size-13">
                                                @if(in_array($featured_product->product->product_id, $wishlistAry))
                                                    <i class="ec ec-favorites mr-1 font-size-15"></i>
                                                @else
                                                    <i class="ec ec-favorites mr-1 font-size-15"></i>
                                                @endif
                                                    Add to Wishlist
                                            </a>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                @endif
            @endforeach
        </ul>
        <!-------------------- Grid View End------------------------>
        @endif

        @if($viewType == 'list')
           <!----------- List View Start------------------------>
            <div class="border-bottom border-color-1 mb-2">
                <h3 class="section-title section-title__full d-inline-block mb-0 pb-2 font-size-22">{{translation($featureGroup->group_name)}}</h3>
            </div>
            <ul class="row list-unstyled products-group no-gutters mb-0 overflow-visible">
                @foreach ($featureGroup->featured_product as $featured_product )
                    @if(!empty($featured_product->product))
                        @php
                        $avgrating=AvgRating($featured_product->product->product_id);
                        @endphp
                        <li class="col-wd-3 col-md-4 product-item product-item__card pb-2 mb-2 pb-md-0 mb-md-0 border-bottom border-md-bottom-0">
                            <div class="product-item__outer h-100">
                                <div class="product-item__inner p-md-3 row no-gutters">
                                    <div class="col col-lg-auto product-media-left">
                                        <a href="{{ EcomService::url($featured_product->product->product_id , 'product')}}" class="max-width-150 d-block" tabindex="0"><img class="img-fluid" src="{{getFullImageUrl($featured_product->product->product_image)}}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="{{$featured_product->product->products_name ?? ''}}"></a>
                                    </div>
                                    <div class="col product-item__body pl-2 pl-lg-3 mr-xl-2 mr-wd-1">
                                        <div class="mb-4">
                                            <div class="mb-2"><a href="{{ EcomService::url($featured_product->product->product_id , 'product')}}" class="font-size-12 text-gray-5" tabindex="0">Model : {{ $featured_product->product->product_model ?? '' }}</a></div>
                                            <h5 class="product-item__title"><a href="{{ EcomService::url($featured_product->product->product_id , 'product')}}" class="text-blue font-weight-bold" tabindex="0">{{ $featured_product->product->products_name ?? '' }}</a></h5>
                                        </div>
                                        <div class="flex-center-between mb-3">
                                            <div class="prodcut-price">
                                                @if($featured_product->product->products_prices!=null)
                                                <div class="row d-flex">
                                                    @foreach($featured_product->product->products_prices as $holeprice)
                                                        @if($holeprice->discount_percent !='0')
                                                            <div class="text-gray-100">
                                                                <del>
                                                                    <small class="text-danger">
                                                                        {{currencyFormat($holeprice->max_sale_price) }}
                                                                    </small>
                                                                </del>
                                                            </div>&nbsp;
                                                        @endif
                                                        <div class="text-gray-100">
                                                            {{ currencyFormat($holeprice->sale_price ?? '0.00') }} 
                                                        </div>
                                                        @if($holeprice->discount_percent != '0')
                                                            <div class="text-gray-100">
                                                                <small class="text-success ms-1">
                                                                    {{ currencyFormat( $holeprice->discount_percent )}}% {{translation('PRODUCT_DISCOUNT')}}
                                                                </small>
                                                            </div>
                                                        @endif
                                                        @break
                                                    @endforeach
                                                </div>
                                            @else
                                                @if($featured_product->product->discount_type != 'no')
                                                    <div class="text-gray-100">
                                                        <del>
                                                            <small>
                                                                {{currencyFormat($featured_product->product->max_sale_price) }}
                                                            </small>
                                                        </del>
                                                    </div>
                                            @endif
                                            <div class="text-gray-100 ">
                                                {{ currencyFormat($featured_product->product->sale_price ?? '0.00') }} 
                                            </div>
                                            @if($featured_product->product->discount_type != 'no')
                                                @if($featured_product->product->discount_type == 'flat')
                                                    <div class="text-gray-100">
                                                        <small class="discount-price ms-1">
                                                            {{ currencyFormat( $featured_product->product->discount_percent )}} {{translation('PRODUCT_DISCOUNT')}}
                                                        </small>
                                                    </div>
                                                @else
                                                    <div class="text-gray-100">
                                                        <small class="discount-price ms-1">
                                                            {{ currencyFormat( $featured_product->product->discount_amount )}}% {{translation('PRODUCT_DISCOUNT')}}
                                                        </small>
                                                    </div>
                                                @endif
                                            @endif
                                        @endif
                                            </div>
                                        </div>
                                        <div class="product-item__footer">
                                            <div class="border-top pt-2 flex-center-between flex-wrap">
                                                <a href="#" class="text-gray-6 font-size-13" tabindex="0">
                                                    @if(!empty($avgrating))
                                                        @for($i=0;$i<5;$i++) 
                                                            @if($i<$avgrating) 
                                                                <small class="fas fa-star text-warning"></small>
                                                            @else
                                                                <small class="fas fa-star text-secondary"></small>
                                                            @endif
                                                        @endfor
                                                    @endif
                                                </a>
                                                @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))
                                                    <a href="javascript:void(0);" onclick="addToWishListFromDetail({{ $featured_product->product->product_id }})" class="text-gray-6 font-size-13" tabindex="0">
                                                    @if(in_array($featured_product->product->product_id, $wishlistAry))
                                                        <i class="ec ec-favorites mr-1 font-size-15"></i>
                                                    @else
                                                        <i class="ec ec-favorites mr-1 font-size-15"></i>
                                                    @endif
                                                        Add to Wishlist
                                                    </a>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    @endif
                @endforeach
            </ul>
            <!----------- List View End------------------------>
        @endif

        @if($viewType == 'slider')
          <!----------- Slider View Start ------------------------>
        <div class="border-bottom border-color-1 mb-2">
            <h3 class="section-title section-title__full d-inline-block mb-0 pb-2 font-size-22">{{translation($featureGroup->group_name)}}</h3>
        </div>
            <div class="js-slick-carousel u-slick position-static overflow-hidden u-slick-overflow-visble pb-7 pt-2 px-1"
            data-pagi-classes="text-center right-0 bottom-1 left-0 u-slick__pagination u-slick__pagination--long mb-0 z-index-n1 mt-3 mt-md-0"
            data-slides-show="7"
            data-slides-scroll="1"
            data-arrows-classes="position-absolute top-0 font-size-17 u-slick__arrow-normal top-10"
            data-arrow-left-classes="fa fa-angle-left right-1"
            data-arrow-right-classes="fa fa-angle-right right-0"
                data-responsive='[{
                    "breakpoint": 1400,
                    "settings": {
                        "slidesToShow": 6
                    }
                    }, {
                        "breakpoint": 1200,
                        "settings": {
                        "slidesToShow": 3
                        }
                    }, {
                    "breakpoint": 992,
                    "settings": {
                        "slidesToShow": 3
                    }
                    }, {
                    "breakpoint": 768,
                    "settings": {
                        "slidesToShow": 2
                    }
                    }, {
                    "breakpoint": 554,
                    "settings": {
                        "slidesToShow": 2
                    }
                    }]'>
                @foreach ($featureGroup->featured_product as $featured_product )
                    @if(!empty($featured_product->product))
                        @php
                        $avgrating=AvgRating($featured_product->product->product_id);
                        @endphp
                        <div class="js-slide products-group">
                            <div class="product-item">
                                <div class="product-item__outer h-100 w-100">
                                    <div class="product-item__inner px-wd-4 p-2 p-md-3">
                                        <div class="product-item__body pb-xl-2">
                                            <div class="mb-2"><a href="{{url('product/'.$featured_product->product->product_slug)}}" class="font-size-12 text-gray-5"></a></div>
                                            <h5 class="mb-1 text-lh-1dot2 font-size-14 mb-0"><a href="{{ EcomService::url($featured_product->product->product_id , 'product')}}" class="font-weight-bold">{{ Str::limit($featured_product->product->products_name ?? '',30)}}</a></h5>
                                            <div class="mb-2">
                                                <a href="{{ EcomService::url($featured_product->product->product_id , 'product')}}" class="d-block text-center" onclick="showfunction('{{ $featured_product->product->product_slug }}')"><img class="img-fluid" src="{{getFullImageUrl($featured_product->product->product_image)}}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"  alt="{{$featured_product->product->products_name ?? ''}}"></a>
                                            </div>
                                            <div class="flex-center-between mb-1">
                                                <div class="prodcut-price">
                                                    <a class="inner-link" href="{{ EcomService::url($featured_product->product->product_id , 'product')}}">
                                                        <span class="font-size-12 text-gray-5" style="height:32px;">
                                                            Model : {{ $featured_product->product->product_model ?? '' }}
                                                        </span>
                                                    </a>
                                                    @if($featured_product->product->products_prices!=null)
                                                    <div class="row d-flex">
                                                        @foreach($featured_product->product->products_prices as $holeprice)
                                                            @if($holeprice->discount_percent !='0')
                                                                <div class="text-gray-100">
                                                                    <del>
                                                                        <small class="text-danger">
                                                                            {{currencyFormat($holeprice->max_sale_price) }}
                                                                        </small>
                                                                    </del>
                                                                </div>&nbsp;
                                                            @endif
                                                            <div class="text-gray-100">
                                                                {{ currencyFormat($holeprice->sale_price ?? '0.00') }} 
                                                            </div>
                                                            @if($holeprice->discount_percent != '0')
                                                                <div class="text-gray-100">
                                                                    <small class="text-success ms-1">
                                                                        {{ currencyFormat( $holeprice->discount_percent )}}% {{translation('PRODUCT_DISCOUNT')}}
                                                                    </small>
                                                                </div>
                                                             @endif
                                                            @break
                                                        @endforeach
                                                    </div>
                                                @else
                                                    @if($featured_product->product->discount_type != 'no')
                                                            <div class="text-gray-100">
                                                                <del>
                                                                    <small>
                                                                        {{currencyFormat($featured_product->product->max_sale_price) }}
                                                                    </small>
                                                                </del>
                                                            </div>
                                                    @endif
                                                    <div class="text-gray-100 ">
                                                        {{ currencyFormat($featured_product->product->sale_price ?? '0.00') }} 
                                                    </div>
                                                    @if($featured_product->product->discount_type != 'no')
                                                        @if($featured_product->product->discount_type == 'flat')
                                                            <div class="text-gray-100">
                                                                <small class="discount-price ms-1">
                                                                    {{ currencyFormat( $featured_product->product->discount_percent )}} {{translation('PRODUCT_DISCOUNT')}}
                                                                </small>
                                                            </div>
                                                        @else
                                                            <div class="text-gray-100">
                                                                <small class="discount-price ms-1">
                                                                    {{ currencyFormat( $featured_product->product->discount_amount )}}% {{translation('PRODUCT_DISCOUNT')}}
                                                                </small>
                                                            </div>
                                                        @endif
                                                    @endif
                                                @endif
                                                </div>
                                            </div>
                                        </div>
                                        <div class="product-item__footer">
                                            <div class="border-top pt-2 flex-center-between flex-wrap">
                                                <a href="#" class="text-gray-6 font-size-13">
                                                    <div class=" mr-2">
                                                        @if(!empty($avgrating))
                                                            @for($i=0;$i<5;$i++) 
                                                                @if($i<$avgrating) 
                                                                    <small class="fas fa-star text-warning"></small>
                                                                @else
                                                                    <small class="fas fa-star text-secondary"></small>
                                                                @endif
                                                            @endfor
                                                        @endif
                                                    </div>
                                                </a>

                                                @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))
                                                <a href="javascript:void(0);" onclick="addToWishListFromDetail({{ $featured_product->product->product_id }})"
                                                    class="text-gray-6 font-size-13">
                                                    @if(in_array($featured_product->product->product_id, $wishlistAry))
                                                    <i class="ec ec-favorites mr-1 font-size-15"></i>
                                                    @else
                                                    <i class="ec ec-favorites mr-1 font-size-15"></i>
                                                    @endif
                                                    Add to Wishlist
                                                </a>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endif
                @endforeach
            </div>
            <!----------- Slider View End ------------------------>
        @endif
</div>
@endif
@endforeach
@endif


<!--------- Tab View Start ------------>
@if($viewType == 'tab')

<!-- Tab Prodcut Start -->
<div class="col">
    <div class="">
        <!-- Nav Classic -->
        <div class="position-relative bg-white text-center z-index-2">
            <ul class="nav nav-classic nav-tab justify-content-center" id="pills-tab"
                role="tablist">
                @foreach ($featureGroupList as $groupKey => $featureGroup)
                    @if (!empty($featureGroup->featured_product) && sizeof($featureGroup->featured_product) > 0)
                        <li class="nav-item">
                            <a class="nav-link {{ $groupKey == 0 ? 'active' : '' }}"
                                id="pills-two-example1-tab" data-toggle="pill"
                                href="#{{ str_replace(' ', '', $featureGroup->group_name) }}"
                                role="tab" aria-controls="pills-two-example1"
                                aria-selected="{{ $groupKey == 0 ? 'true' : '' }}">
                                <div
                                    class="d-md-flex justify-content-md-center align-items-md-center">
                                    {{ $featureGroup->group_name }}
                                </div>
                            </a>
                        </li>
                    @endif
                @endforeach
            </ul>
        </div>
        <!-- End Nav Classic -->

        <!-- Tab Content -->
        <div class="tab-content" id="pills-tabContent">
            @foreach ($featureGroupList as $groupKey => $featureGroup)
                <div class="tab-pane fade pt-2 {{ $groupKey == 0 ? 'show active' : '' }}"
                    role="tabpanel" id="{{ str_replace(' ', '', $featureGroup->group_name) }}"
                    aria-labelledby="pills-one-example1-tab">
                    <ul class="row list-unstyled products-group no-gutters">
                        @foreach ($featureGroup->featured_product as $featured_product)
                            @if (!empty($featured_product->product))
                                <li class="col-6 col-wd-3 col-md-4 product-item d-flex">
                                    <div class="product-item__outer w-100">
                                        <div class="product-item__inner px-xl-4 p-3">
                                            <div class="product-item__body pb-xl-2">
                                                <div class="mb-2">
                                                    <a href="{{url('product/'.$featured_product->product->product_slug)}}" class="font-size-12 text-gray-5">
                                                    </a>
                                                </div>
                                                <h5 class="text-lh-1dot2 font-size-14 mb-0" style="height:32px;">
                                                    <a href="{{ EcomService::url($featured_product->product->product_id , 'product')}}"
                                                        class="font-weight-bold">
                                                        {{ Str::limit($featured_product->product->products_name ?? '',50)}}
                                                    </a>
                                                </h5>
                                                <div class="mb-2">
                                                    <a href="{{ EcomService::url($featured_product->product->product_id , 'product')}}" class="d-block text-center" onclick="showfunction('{{ $featured_product->product->product_slug }}')">
                                                        <img class="img-fluid"
                                                            src="{{getFullImageUrl($featured_product->product->product_image)}}"
                                                            onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                                                            alt="{{$featured_product->product->products_name ?? ''}}">
                                                    </a>
                                                </div>
                                                <div class="flex-center-between mb-1">
                                                    <div class="prodcut-price">
                                                        <a class="inner-link" href="{{ EcomService::url($featured_product->product->product_id , 'product')}}">
                                                            <span class="text-gray-20 mb-2 font-size-12">
                                                                {{translation('PRODUCT_MODEL')}} : {{ $featured_product->product->product_model ?? '' }}
                                                            </span>
                                                        </a>
                                                        @if($featured_product->product->products_prices!=null)
                                                            <div class="row d-flex">
                                                                @foreach($featured_product->product->products_prices as $holeprice)
                                                                    @if($holeprice->discount_percent !='0')
                                                                        <div class="text-gray-100">
                                                                            <del>
                                                                                <small class="text-danger">
                                                                                    {{currencyFormat($holeprice->max_sale_price) }}
                                                                                </small>
                                                                            </del>
                                                                        </div>&nbsp;
                                                                    @endif
                                                                    <div class="text-gray-100">
                                                                        {{ currencyFormat($holeprice->sale_price ?? '0.00') }} 
                                                                    </div>
                                                                    @if($holeprice->discount_percent != '0')
                                                                        <div class="text-gray-100">
                                                                            <small class="text-success ms-1">
                                                                                {{ currencyFormat( $holeprice->discount_percent )}}% {{translation('PRODUCT_DISCOUNT')}}
                                                                            </small>
                                                                        </div>
                                                                    @endif
                                                                    @break
                                                                @endforeach
                                                            </div>
                                                        @else
                                                            @if($featured_product->product->discount_type != 'no')
                                                                <div class="text-gray-100">
                                                                    <del>
                                                                        <small>
                                                                            {{currencyFormat($featured_product->product->max_sale_price) }}
                                                                        </small>
                                                                    </del>
                                                                </div>
                                                            @endif
                                                            <div class="text-gray-100 ">
                                                                {{ currencyFormat($featured_product->product->sale_price ?? '0.00') }} 
                                                            </div>
                                                            @if($featured_product->product->discount_type != 'no')
                                                                @if($featured_product->product->discount_type == 'flat')
                                                                    <div class="text-gray-100">
                                                                        <small class="discount-price ms-1">
                                                                            {{ currencyFormat( $featured_product->product->discount_percent )}} {{translation('PRODUCT_DISCOUNT')}}
                                                                        </small>
                                                                    </div>
                                                                @else
                                                                    <div class="text-gray-100">
                                                                        <small class="discount-price ms-1">
                                                                            {{ currencyFormat( $featured_product->product->discount_amount )}}% {{translation('PRODUCT_DISCOUNT')}}
                                                                        </small>
                                                                    </div>
                                                                @endif
                                                            @endif
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="product-item__footer">
                                                    <div class="border-top pt-2 flex-center-between flex-wrap">
                                                        <a href="#" class="text-gray-6 font-size-13">
                                                            <div class=" mr-2">
                                                                @if(!empty($avgrating))
                                                                    @for($i=0;$i<5;$i++) 
                                                                        @if($i<$avgrating) 
                                                                            <small class="fas fa-star text-warning"></small>
                                                                        @else
                                                                            <small class="fas fa-star text-secondary"></small>
                                                                        @endif
                                                                    @endfor
                                                                @endif
                                                            </div>
                                                        </a>
                                                        @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))
                                                        <a href="javascript:void(0);" onclick="addToWishListFromDetail({{ $featured_product->product->product_id }})"
                                                            class="text-gray-6 font-size-13">
                                                            @if(in_array($featured_product->product->product_id, $wishlistAry))
                                                            <i class="ec ec-favorites mr-1 font-size-15"></i>
                                                            @else
                                                            <i class="ec ec-favorites mr-1 font-size-15"></i>
                                                            @endif
                                                            {{translation('ADD_TO_WISHLIST')}}
                                                        </a>
                                                        @endif
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            @endif
                        @endforeach
                    </ul>
                </div>
            @endforeach
        </div>
        <!-- End Tab Content -->
    </div>
</div>
@endif
<!-- Tab Prodcut End -->