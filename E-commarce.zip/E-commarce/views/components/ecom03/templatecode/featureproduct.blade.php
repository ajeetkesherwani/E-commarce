<!-- Recently viewed -->
@if(!empty($featureGroupList))
@foreach($featureGroupList as $groupKey=>$featureGroup)
@if(!empty($featureGroup->featured_product) && sizeof($featureGroup->featured_product) > 0 )
<div class="position-relative">
    <div class="border-bottom border-color-1 mb-2">
        <h3 class="section-title section-title__full d-inline-block mb-0 pb-2 font-size-22">{{translation($featureGroup->group_name)}}</h3>
    </div>
    <div class="js-slick-carousel u-slick position-static overflow-hidden u-slick-overflow-visble pb-7 pt-2 px-1"
        data-pagi-classes="text-center right-0 bottom-1 left-0 u-slick__pagination u-slick__pagination--long mb-0 z-index-n1 mt-3 mt-md-0"
        data-slides-show="7"
        data-slides-scroll="1"
        data-arrows-classes="position-absolute top-0 font-size-17 u-slick__arrow-normal top-10"
        data-arrow-left-classes="fa fa-angle-left right-1"
        data-arrow-right-classes="fa fa-angle-right right-0"
        data-responsive='[{
            "breakpoint": 1400,
            "settings": {
            "slidesToShow": 6
            }
        }, {
            "breakpoint": 1200,
            "settings": {
                "slidesToShow": 3
            }
        }, {
            "breakpoint": 992,
            "settings": {
            "slidesToShow": 3
            }
        }, {
            "breakpoint": 768,
            "settings": {
            "slidesToShow": 2
            }
        }, {
            "breakpoint": 554,
            "settings": {
            "slidesToShow": 2
            }
        }]'>
        <div class="js-slide products-group">
            @foreach ($featureGroup->featured_product as $featured_product )
                @if(!empty($featured_product->product))
                    @php
                    $avgrating=AvgRating($featured_product->product->product_id);
                    @endphp
                    <div class="product-item">
                        <div class="product-item__outer h-100 w-100">
                            <div class="product-item__inner px-wd-4 p-2 p-md-3">
                                <div class="product-item__body pb-xl-2">
                                    <div class="mb-2"><a href="{{url('product/'.$featured_product->$product->product_slug)}}" class="font-size-12 text-gray-5"></a></div>
                                    <h5 class="mb-1 product-item__title"><a href="{{ EcomService::url($featured_product->$product->product_id , 'product')}}" class="text-blue font-weight-bold">{{ Str::limit($featured_product->product->product_slug ?? '',50)}}</a></h5>
                                    <div class="mb-2">
                                        <a href="{{ EcomService::url($featured_product->product->product_id , 'product')}}" class="d-block text-center" onclick="showfunction('{{ $featured_product->product->product_slug }}')"><img class="img-fluid" src="{{getFullImageUrl($featured_product->$product->product_image)}}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"  alt="{{$featured_product->$product->products_name ?? ''}}"></a>
                                    </div>
                                    <div class="flex-center-between mb-1">
                                        <div class="prodcut-price">
                                            <a class="inner-link" href="{{ EcomService::url($featured_product->product->product_id , 'product')}}">
                                                <span class="text-gray-20 mb-2 font-size-12">
                                                    Model : {{ $featured_product->$product->product_model ?? '' }}
                                                </span>
                                            </a>
                                            @if($featured_product->product->product_discount_type != 'no')
                                                @if($featured_product->product->product_discount_type == 'flat')
                                                    <div class="text-gray-100 discount_amount">
                                                        <del>
                                                            {{currencyFormat($featured_product->product->product_sale_price+$featured_product->product->product_discount_amount) }}
                                                        </del>
                                                    </div>
                                                @else
                                                @php
                                                    $discounAmount=($featured_product->product->product_sale_price)*$featured_product->product->product_discount_amount/100;
                                                    $totalPrice=$featured_product->product->product_sale_price+$discounAmount;
                                                @endphp
                                                    <div class="text-gray-100 discount_amount">
                                                        <del>{{ currencyFormat($totalPrice)}}</del>
                                                    </div>
                                                @endif
                                            @endif
                                            <div class="text-gray-100 old-price">
                                                {{ currencyFormat($featured_product->product->product_sale_price ?? '0.00') }}
                                            </div>
                                            @if($featured_product->product->product_discount_type != 'no')
                                                <div class="text-gray-100">
                                                    @if($featured_product->product->product_discount_type == 'flat')
                                                        <span class="discount-price ms-1">
                                                            {{ currencyFormat($featured_product->product->product_discount_amount) }} off
                                                        </span>
                                                    @else
                                                        <span class="discount-price ms-1">
                                                            {{ currencyFormat( $featured_product->product->product_discount_amount )}}% off
                                                        </span>
                                                    @endif
                                                </div>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                                <div class="product-item__footer">
                                    <div class="border-top pt-2 flex-center-between flex-wrap">
                                        <a href="#" class="text-gray-6 font-size-13">
                                            <div class=" mr-2">
                                                @if(!empty($avgrating))
                                                    @for($i=0;$i<5;$i++) 
                                                        @if($i<$avgrating) 
                                                            <small class="fas fa-star text-warning"></small>
                                                        @else
                                                            <small class="fas fa-star text-secondary"></small>
                                                        @endif
                                                    @endfor
                                                @endif
                                            </div>
                                        </a>

                                        @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))
                                        <a href="javascript:void(0);" onclick="addToWishListFromDetail({{ $featured_product->product->product_id }})"
                                            class="text-gray-6 font-size-13">
                                            @if(in_array($featured_product->product->product_id, $wishlistAry))
                                            <i class="ec ec-favorites mr-1 font-size-15"></i>
                                            @else
                                            <i class="ec ec-favorites mr-1 font-size-15"></i>
                                            @endif
                                            Add to Wishlist
                                        </a>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif
            @endforeach
        </div>
    </div>
</div>
@endif
@endforeach
@endif
<!-- End Recently viewed -->