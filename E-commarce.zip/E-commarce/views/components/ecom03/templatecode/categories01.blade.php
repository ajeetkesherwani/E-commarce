@if (!empty($popular_category) && sizeof($popular_category) > 0 )
    @foreach($popular_category as $key=>$value)
        <div class="col-md-6 mb-4 mb-xl-0 col-xl-3">
            <a href="{{ App\Models\Ecom\Services\EcomService::url($value->categories_id , 'category')}}" class="d-black text-gray-90">
                <div class="min-height-132 py-1 d-flex bg-gray-1 align-items-center">
                    <div class="col-6 col-xl-5 col-wd-6 pr-0">
                        <img class="img-fluid" src="{{getFullImageUrl($value->categories_image)}}"
                        alt="{{$value->category_name ?? ''}}" 
                        onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" />
                    </div>
                    <div class="col-6 col-xl-7 col-wd-6">
                        <div class="mb-2 pb-1 font-size-18 font-weight-light text-ls-n1 text-lh-23">
                            {{$value->category_name ?? 'Test cat'}}
                        </div>
                        <div class="link text-gray-90 font-weight-bold font-size-15" href="{{url('category/'.$value->categories_slug)}}">
                            Shop now
                            <span class="link__icon ml-1">
                                <span class="link__icon-inner"><i class="ec ec-arrow-right-categproes"></i></span>
                            </span>
                        </div>
                    </div>
                </div>
            </a>
        </div>
    @endforeach
@endif