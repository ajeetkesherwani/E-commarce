<div class="row">
    @foreach($web_features as $key=>$feature_data)
    <div class="col-md-6 mb-4 mb-xl-0 col-xl-3">
        <a href="#" class="d-black text-gray-90">
            <div class="min-height-132 py-1 d-flex bg-gray-1 align-items-center">
                <div class="col-6 col-xl-5 col-wd-6 pr-0">
                    <img class="img-fluid" src="{{getFullImageUrl($feature_data->feature_icon)}}"
                     alt="{{getSetting('site_title')}} - {{$feature_data->feature_title}}"  
                      >
                </div>
                <div class="col-6 col-xl-7 col-wd-6">
                    <div class="mb-2 pb-1 font-size-18 font-weight-light text-ls-n1 text-lh-23">
                        {{$feature_data->feature_title}}
                    </div>
                    <div class="link text-gray-90 font-weight-bold font-size-15" >
                        {{$feature_data->feature_subtitle}}
                    </div>
                </div>
            </div>
        </a>
    </div>
    @endforeach
</div>
