<style>

.testimonial-reel {
    margin:0 1rem
}
.testimonial-reel .box {
  position: relative;
  margin-bottom: 30px;
}

.testimonial-reel .box .test-component {
  padding: 1rem 2.5rem;
  /* box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15); */
  min-height: 200px;
  box-shadow: 0 0 3px rgba(60,72,88,.1)!important;
    border-radius: 6px;
}
.testimonial-reel .box .test-title {
  text-align: center;
  margin-top: 3.3rem;
  margin-bottom: 15px;
}
.testimonial-reel .box .test-content {
  text-align: center;
}
.testimonial-reel .slick-slide {
  opacity: 0.3;
  transition: opacity 0.3s;
  padding-left: 1rem;
  padding-right: 1rem;
}
.testimonial-reel .slick-slide.slick-cloned {
  opacity: 0.3;
  transition: opacity 0.3s;
}
.testimonial-reel .slick-slide.slick-current.slick-active {
  opacity: 1;
  transition: opacity 0.3s;
}
</style>

<!-- @if ($testimonial_data->isNotEmpty())
    <div class="testi-slider owl-carousel owl-dot-style">
        @foreach ($testimonial_data as $key => $data)
            <div class="testi-slider-wrapper">
                <div class="testi-slider-inner">
                    <div class="testi-content">
                        <div class="testi-content-text">
                            {{ $data->testimonial_text }}
                        </div>
                        <div class="author-text">
                            <h4>
                                {{!empty($data->user_data) ? $data->user_data->first_name : '' }}
                                {{!empty($data->user_data) ? $data->user_data->last_name : '' }}
                                <span>
                                    {{!empty($data->user_data) ? $data->user_data->email : '' }}
                                </span>
                            </h4>
                        </div>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
@endif -->
<div class="position-relative">
    <div class="border-bottom border-color-1 mb-2">
        <h3 class="section-title section-title__full d-inline-block mb-0 pb-2 font-size-22">Testimonial</h3>
    </div>
    <div class="js-slick-carousel u-slick position-static overflow-hidden u-slick-overflow-visble pb-7 pt-2 px-1"
        data-pagi-classes="text-center right-0 bottom-1 left-0 u-slick__pagination u-slick__pagination--long mb-0 z-index-n1 mt-3 mt-md-0"
        data-slides-show="7"
        data-slides-scroll="1"
        data-arrows-classes="position-absolute top-0 font-size-17 u-slick__arrow-normal top-10"
        data-arrow-left-classes="fa fa-angle-left right-1"
        data-arrow-right-classes="fa fa-angle-right right-0"
        data-responsive='[{
            "breakpoint": 1400,
            "settings": {
            "slidesToShow": 3
            }
        }, {
            "breakpoint": 1200,
            "settings": {
                "slidesToShow": 2
            }
        }, {
            "breakpoint": 992,
            "settings": {
            "slidesToShow": 2
            }
        }, {
            "breakpoint": 768,
            "settings": {
            "slidesToShow": 1
            }
        }, {
            "breakpoint": 554,
            "settings": {
            "slidesToShow": 1
            }
        }]'>
        <div class="js-slide products-group">
            <div class="testimonial-reel ">
                <div class="box">
                    <div class="test-component">
                        <!-- Title -->
                        <div class="test-title">

                            <h4>
                                Efecha Omoware
                            </h4>

                        </div>
                        <!-- / Title -->

                        <div class="test-content">
                            <p>
                            I bought a Power Bank from here and its awesome, great performance. It's well worth the money for high quality products;...
                            </p>
                            </div>

                    </div>

                </div>
            </div>
        </div>
        
        
        <div class="js-slide products-group">
            <div class="testimonial-reel ">
                <div class="box">
                    <div class="test-component">
                        <!-- Title -->
                        <article class="test-title">

                            <h4>
                                Efecha Omoware
                            </h4>

                        </article>
                        <!-- / Title -->

                        <article class="test-content">
                            <p>
                                I now enjoy financial freedom like I’ve never know before doing what I love.
                            </p>
                        </article>

                    </div>

                </div>
            </div> 
        </div>
        
        <div class="js-slide products-group">
            <div class="testimonial-reel ">

                <div class="box">
                    <div class="test-component">
                        <!-- Title -->
                        <article class="test-title">

                            <h4>
                                Efecha Omoware
                            </h4>

                        </article>
                        <!-- / Title -->

                        <article class="test-content">
                            <p>
                                I now enjoy financial freedom like I’ve never know before doing what I love.
                            </p>
                        </article>
                    </div>
                </div>

            </div>
        </div>
        <div class="js-slide products-group">
            <div class="testimonial-reel ">

                <div class="box">
                    <div class="test-component">
                        <!-- Title -->
                        <article class="test-title">

                            <h4>
                                Efecha Omoware
                            </h4>

                        </article>
                        <!-- / Title -->

                        <article class="test-content">
                            <p>
                                I now enjoy financial freedom like I’ve never know before doing what I love.
                            </p>
                        </article>

                    </div>

                </div>

            </div>
        </div>
        <div class="js-slide products-group">
            <div class="testimonial-reel ">

                <div class="box">
                    <div class="test-component">
                        <!-- Title -->
                        <article class="test-title">

                            <h4>
                                Efecha Omoware
                            </h4>

                        </article>
                        <!-- / Title -->

                        <article class="test-content">
                            <p>
                                I now enjoy financial freedom like I’ve never know before doing what I love.
                            </p>
                        </article>

                    </div>

                </div>

            </div>
        </div>
    </div>
</div>