<!-- ======================== Banner Layout Start  =========================== -->
@if(!empty($banner_data))
    <div class="row">
        <a href="{{$banner_data->banners_url}}">
            <img src="{{getFullImageUrl($banner_data->banners_image)}}"
            onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
            alt="{{getSetting('site_title')}}-{{$banner_data->banners_title}}" class="img-fluid"/>
        </a>
    </div>
@endif
<!-- ======================== Banner Layout End =========================== -->

