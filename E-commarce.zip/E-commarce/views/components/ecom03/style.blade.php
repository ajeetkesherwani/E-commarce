        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="{{ getImageUrlWithKey('website_favicon') }}" />
        <!-- Google Fonts -->
        <link
            href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i&display=swap"
            rel="stylesheet">

        <!-- CSS Implementing Plugins -->
        <link rel="stylesheet" href="{{ LoadAssets('assets/vendor/font-awesome/css/fontawesome-all.min.css') }}">
        <link rel="stylesheet" href="{{ LoadAssets('assets/css/font-electro.css') }}">

        <link rel="stylesheet" href="{{ LoadAssets('assets/vendor/animate.css/animate.min.css') }}">
        <link rel="stylesheet" href="{{ LoadAssets('assets/vendor/hs-megamenu/src/hs.megamenu.css') }}">
        <link rel="stylesheet"
            href="{{ LoadAssets('assets/vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.css') }}">
        <link rel="stylesheet" href="{{ LoadAssets('assets/vendor/fancybox/jquery.fancybox.css') }}">
        <link rel="stylesheet" href="{{ LoadAssets('assets/vendor/slick-carousel/slick/slick.css') }}">
        <link rel="stylesheet"
            href="{{ LoadAssets('assets/vendor/bootstrap-select/dist/css/bootstrap-select.min.css') }}">

        <!-- CSS Electro Template -->
        <link rel="stylesheet" href="{{ LoadAssets('assets/css/theme.css') }}">
        <!-- // toastigy  -->
        <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
