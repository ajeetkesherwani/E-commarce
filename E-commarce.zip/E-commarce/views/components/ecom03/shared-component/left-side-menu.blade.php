@php
$urlSegment = Request::segment(2);
$imgurl = url($user_data->profile_photo ?? 'https://cdn.pixabay.com/photo/2020/07/01/12/58/icon-5359553_960_720.png');
@endphp
<div class="left-dashboard mb-5">
    <form method="post" enctype="multipart/form-data" id="changeProfileImage">
        <label for="fileToUpload">
            <div class="profile-picc" style="background-image: url('{{ $imgurl }}')">
                <span class="glyphicon glyphicon-camera"></span>
                <span>{{ translation('CHANGE_IMAGE') }}</span>
            </div>
        </label>
        <input type="File" name="fileToUpload" id="fileToUpload" />
        <h5 class="card-title text-center text-uppercase pt-2">
            {{ Auth::user()->first_name }} {{ Auth::user()->last_name }}
        </h5>
    </form>


    <div class="list-group mb-5" id="#nav">
        <a href="{{ url('account/dashboard') }}"
            class="list-group-item list-group-item-action {{ $urlSegment == 'dashboard' ? 'active' : '' }}">
            <i class="fa-sharp fa-solid fa-house" style="padding-right:6px"></i>
            {{ translation('DASHBOARD') }}
        </a>
        <a href="{{ url('account/profile') }}"
            class="list-group-item list-group-item-action {{ $urlSegment == 'profile' ? 'active' : '' }}">
            <i class="fa-solid fa-user" style="padding-right:6px"></i>
            {{ translation('MY_PROFILE') }}
        </a>
        <a href="{{ url('account/orders') }}"
            class="list-group-item list-group-item-action {{ $urlSegment == 'orders' ? 'active' : '' }} ">
            <i class="fa-solid fa-cart-shopping" style="padding-right:6px"></i>
            {{ translation('ORDERS') }}
        </a>
        <a href=" {{ url('account/addreses') }}"
            class="list-group-item list-group-item-action {{ $urlSegment == 'addreses' ? 'active' : '' }} ">
            <i class="fa-solid fa-address-book" style="padding-right:6px"></i>
            {{translation('ADDRESSES') }}
        </a>
        <a href="{{route('logout')}}"
            class="list-group-item list-group-item-action {{-- {{ $urlSegment == 'dashboard' ? 'active' : '' }} --}} " onclick="event.preventDefault(); document.getElementById('myLogOutForm').submit();">
            <i class="fa-solid fa-logout" style="padding-right:6px"></i>
            {{ translation('LOG_OUT') }}
            <form method="POST" id="myLogOutForm" action="{{ route('logout') }}">
                                                    @csrf
                                                </form>
        </a>
    </div>
</div>



@push('scripts')
    <script>
        $(document).ready(function() {
            $("#fileToUpload").change(function() {
                $.ajaxSetup({
                    headers: {
                        "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr(
                            "content"
                        ),
                    },
                });
                var profileimage = document.getElementById("changeProfileImage");
                var formData = new FormData(profileimage);
                $.ajax({
                    type: "POST",
                    url: "{{ url('account/change-image') }}",
                    data: formData,
                    cache: false,
                    contentType: false,
                    processData: false,
                    success: function(response) {
                        if (response.status == 400) {} else {
                            Notify("Profile Image Updated Successfully", true);
                            location.reload();
                        }
                    },
                    error: function(data) {
                        console.log(data);
                    },
                });
            });
        });
    </script>
@endpush
