@if(!empty($brand_data))
<div class="mb-8">
    <div class="py-2 border-top border-bottom">
        <div class="js-slick-carousel u-slick my-1"
            data-slides-show="5"
            data-slides-scroll="1"
            data-arrows-classes="d-none d-lg-inline-block u-slick__arrow-normal u-slick__arrow-centered--y"
            data-arrow-left-classes="fa fa-angle-left u-slick__arrow-classic-inner--left z-index-9"
            data-arrow-right-classes="fa fa-angle-right u-slick__arrow-classic-inner--right"
            data-responsive='[{
                "breakpoint": 992,
                "settings": {
                    "slidesToShow": 2
                }
            }, {
                "breakpoint": 768,
                "settings": {
                    "slidesToShow": 3
                }
            }, {
                "breakpoint": 554,
                "settings": {
                    "slidesToShow": 2
                }
            }]'>
            @foreach($brand_data as $key=>$data)
            <div class="js-slide">
                   @if(empty($data->brand_slug))
                    {{brandIDtoSlug($data->brand_id)}}
                    @endif
                <a href="{{url('brand/'.$data->brand_slug ?? "")}}" class="link-hover__brand">
                    <img class="img-fluid m-auto max-height-50" src="{{getFullImageUrl($data->brand_icon)}}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="{{$data->brand_name}}">
                </a>
            </div>
            @endforeach
        </div>
    </div>
</div>
@endif