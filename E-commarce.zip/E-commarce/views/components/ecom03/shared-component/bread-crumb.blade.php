  <div class="bg-gray-13 bg-md-transparent">
    <div class="container">
        <!-- breadcrumb -->
        <div >
            <nav aria-label="breadcrumb">
              @if (!empty($sublist))
                <ol class="breadcrumb flex-nowrap flex-xl-wrap overflow-auto overflow-xl-visble">
                  @foreach ($sublist as $key=>$list)
                    <li class="breadcrumb-item flex-shrink-0 flex-xl-shrink-1">
                      @if( $key <  sizeof($sublist) )
                      <a href="{{$list['link'] }}">{{ $list['name'] }}</a></li>
                      @endif
                  @endforeach
                  </ol>
                @endif
            </nav>
        </div>
        <!-- End breadcrumb -->
    </div>
</div>