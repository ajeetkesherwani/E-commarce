@if (!empty($featureGroupList) && sizeof($featureGroupList) > 0 )
    @foreach($featureGroupList->take(1) as $groupKey=>$featureGroup)
        <div class="mb-8">
            <div class="border-bottom border-color-1 mb-5">
                <h3 class="section-title section-title__sm mb-0 pb-2 font-size-18">{{translation($featureGroup->group_name)}}</h3>
            </div>
            @foreach ($featureGroup->featured_product->take(5) as $feature_product )
            @if(!empty($feature_product))
            <ul class="list-unstyled">
                <li class="mb-4">
                    <div class="row">
                        <div class="col-auto product-item__list">
                            <a href="" class="d-block width-75">
                                <img class="img-fluid" src="{{getFullImageUrl($feature_product->product->product_image)}}" onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                                alt="{{$feature_product->product->products_name ?? ''}}">
                            </a>
                        </div>
                        <div class="col">
                            <h3 class="text-lh-1dot2 font-size-14 mb-0"><a href="" class="text-black font-weight-bold">{{$feature_product->product->products_name ?? ''}}</a></h3>
                            <div class="font-weight-bold">
                                @if($feature_product->product->discount_type != 'no')
                                    @if($feature_product->product->discount_type == 'flat')
                                        {{-- <del class="font-size-11 text-gray-9 d-block">$2299.00</del> --}}
                                        <ins class="font-size-15 text-red text-decoration-none d-block">
                                            {{ currencyFormat($product->sale_price+$product->discount_amount) }}
                                        </ins>
                                    @else
                                        @php
                                            $discounAmount=($feature_product->product->sale_price)*$feature_product->product->discount_amount/100;
                                            $totalPrice=$feature_product->product->sale_price+$discounAmount;
                                        @endphp
                                            <div class="text-gray-100">
                                                {{ currencyFormat($totalPrice)}}
                                            </div>
                                    @endif
                                @else
                                    {{ currencyFormat($feature_product->product->sale_price)}}
                                @endif
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
            @endif
            @endforeach
        </div>
    @endforeach
@endif