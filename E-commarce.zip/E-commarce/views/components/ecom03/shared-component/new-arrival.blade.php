@if (!empty($product))
<section class="recent-add-area mb-70px">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <!-- Section Title -->
                <div class="section-title underline-shape">
                    <h2>{{translation('NEW_ARRIVALS')}}</h2>
                    <p>{{translation('NEW_ARRIVALS_SLOGAN')}}</p>
                </div>
                <!-- Section Title -->
            </div>
        </div>
        <!-- Recent Product slider Start -->
        <div class="best-sell-slider owl-carousel owl-nav-style-3">
            <!-- Product Single Item -->
            @foreach ($product as $product )
                <x-ecom03.shared-component.product viewtype="grid" :data="$product" />
            @endforeach
        </div>
        <!-- Recent Area Slider End -->
    </div>
</section>
@endif