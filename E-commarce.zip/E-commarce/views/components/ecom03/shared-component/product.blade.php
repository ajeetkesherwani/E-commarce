@php
$avgrating=AvgRating($product->product_id);
use App\Models\Ecom\Services\EcomService;
use App\Models\WishList;
$wishlistAry = WishList::getProductsAry();
$currentURL = URL::current();
if(strpos($currentURL,'search') == true){
    $size = 3;
}
elseif(strpos($currentURL,'product') == true){
    $size = 3;
}
elseif(strpos($currentURL,'brand') == true){
    $size = 3;
}
else{
    $size = 4;
}
@endphp
@if($viewtype == 'grid')
<li class="col-6 col-wd-3 col-md-{{$size}} product-item d-flex">
    <div class="product-item__outer w-100">
        <div class="product-item__inner px-xl-4 p-3">
            <div class="product-item__body pb-xl-2">
                <div class="mb-2">
                    <a href="{{url('product/'.$product->product_slug)}}" class="font-size-12 text-gray-5">
                    </a>
                </div>
                <h5 class="text-lh-1dot2 font-size-14 mb-0" style="height:32px;">
                    <a href="{{ EcomService::url($product->product_id , 'product')}}"
                        class="font-weight-bold">
                        {{ Str::limit($product->products_name ?? '',50)}}
                    </a>
                </h5>
                <div class="mb-2">
                    <a href="{{ EcomService::url($product->product_id , 'product')}}" class="d-block text-center" onclick="showfunction('{{ $product->product_slug }}')">
                        <img class="img-fluid"
                            src="{{getFullImageUrl($product->product_image)}}"
                            onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                            alt="{{$product->products_name ?? ''}}">
                    </a>
                </div>
                <div class="flex-center-between mb-1">
                    <div class="prodcut-price">
                        <a class="inner-link" href="{{ EcomService::url($product->product_id , 'product')}}">
                            <span class="text-gray-20 mb-2 font-size-12">
                                {{translation('PRODUCT_MODEL')}} : {{ $product->product_model ?? '' }}
                            </span>
                        </a>

                        @if($product->products_prices!=null)
                            <div class="row d-flex">
                                @foreach($product->products_prices as $holeprice)
                                    @if($holeprice->discount_percent !='0')
                                        <div class="text-gray-100">
                                            <del>
                                                <small class="text-danger">
                                                    {{currencyFormat($holeprice->max_sale_price) }}
                                                </small>
                                            </del>
                                        </div>&nbsp;
                                    @endif
                                    <div class="text-gray-100">
                                        {{ currencyFormat($holeprice->sale_price ?? '0.00') }} 
                                    </div>
                                    @if($holeprice->discount_percent != '0')
                                        <div class="text-gray-100">
                                            <small class="text-success ms-1">
                                                {{ currencyFormat( $holeprice->discount_percent )}}% {{translation('PRODUCT_DISCOUNT')}}
                                            </small>
                                        </div>
                                    @endif
                                    @break
                                @endforeach
                            </div>
                        @else
                            @if($product->discount_type != 'no')
                                <div class="text-gray-100">
                                    <del>
                                        <small>
                                            {{currencyFormat($product->max_sale_price) }}
                                        </small>
                                    </del>
                                </div>
                            @endif
                            <div class="text-gray-100 ">
                                {{ currencyFormat($product->sale_price ?? '0.00') }} 
                            </div>
                            @if($product->discount_type != 'no')
                                @if($product->discount_type == 'flat')
                                    <div class="text-gray-100">
                                        <small class="discount-price ms-1">
                                            {{ currencyFormat( $product->discount_percent )}} {{translation('PRODUCT_DISCOUNT')}}
                                        </small>
                                    </div>
                                @else
                                    <div class="text-gray-100">
                                        <small class="discount-price ms-1">
                                            {{ currencyFormat( $products->discount_amount )}}% {{translation('PRODUCT_DISCOUNT')}}
                                        </small>
                                    </div>
                                @endif
                            @endif
                        @endif
                    </div>
                </div>
                <div class="product-item__footer">
                    <div class="border-top pt-2 flex-center-between flex-wrap">
                        <a href="#" class="text-gray-6 font-size-13">
                            <div class=" mr-2">
                                @if(!empty($avgrating))
                                    @for($i=0;$i<5;$i++) 
                                        @if($i<$avgrating) 
                                            <small class="fas fa-star text-warning"></small>
                                        @else
                                            <small class="fas fa-star text-secondary"></small>
                                        @endif
                                    @endfor
                                @endif
                            </div>
                        </a>

                        @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))
                        <a href="javascript:void(0);" onclick="addToWishListFromDetail({{ $product->product_id }})"
                            class="text-gray-6 font-size-13">
                            @if(in_array($product->product_id, $wishlistAry))
                            <i class="ec ec-favorites mr-1 font-size-15"></i>
                            @else
                            <i class="ec ec-favorites mr-1 font-size-15"></i>
                            @endif
                            {{translation('ADD_TO_WISHLIST')}}
                        </a>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</li>
@endif

@if($viewtype == 'list')
<li class="product-item remove-divider product-listview__wrapper">
    <div class="product-item__outer w-100">
        <div class="product-item__inner remove-prodcut-hover row">
            <div class="product-item__header col-6 col-md-4">
                <div class="mb-2">
                    <a href="{{url('product/'.$product->product_slug)}}" class="d-block text-center">
                        <img class="img-fluid" src="{{getFullImageUrl($product->product_image)}}"
                            onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'" alt="{{$product->products_name ?? ''}}">
                    </a>
                </div>
            </div>
            <div class="product-item__body col-6 col-md-5">
                <div class="pr-lg-10">
                    <div class="mb-2">
                        <a href="{{url('product/'.$product->product_slug)}}" class="font-size-12 text-gray-5">
                        </a>
                    </div>
                    <h5 class="mb-2 product-item__title">
                        <a href="{{url('product/'.$product->product_slug)}}" class="text-blue font-weight-bold">
                            {{($product->products_name ?? '')}}
                        </a>
                    </h5>
                    @if(!empty($avgrating))
                    <div class="mb-3 d-none d-md-block">
                        <a class="d-inline-flex align-items-center small font-size-14" href="#">
                        <div class="mr-2">
                            @if(!empty($avgrating))
                                @for($i=0;$i<5;$i++) 
                                    @if($i<$avgrating) 
                                        <small class="fas fa-star text-warning"></small>
                                    @else
                                        <small class="fas fa-star text-secondary"></small>
                                    @endif
                                @endfor
                            @endif
                        </div>
                        </a>
                    </div>
                    @endif
                    <ul class="font-size-13 p-0 text-gray-110 mb-4 d-none d-md-block">
                        @foreach($product->products_to_features as $featKey=>$featVal)
                        <li class="line-clamp-1 mb-1 list-bullet">
                            {{$featVal->feature_title ?? ''}}: {{$featVal->feature_value ?? ''}}
                        </li>
                        @endforeach
                    </ul>
                </div>
            </div>
            <div class="product-item__footer col-md-3 d-md-block">
                <div class="mb-3">
                    @if($product->products_prices!=null)
                        <div class="row d-flex">
                            @foreach($product->products_prices as $holeprice)
                                @if($holeprice->discount_percent !='0')
                                    <div class="text-gray-100 ">
                                        <del>
                                            <small>
                                                {{currencyFormat($holeprice->max_sale_price) }}
                                            </small>
                                        </del>
                                    </div>&nbsp;
                                @endif
                                <div class="text-gray-100 ">
                                    {{ currencyFormat($holeprice->sale_price ?? '0.00') }} 
                                </div>
                                @if($holeprice->discount_percent != '0')
                                    <div class="text-gray-100">
                                        <span class=" ms-1">
                                            <small class="text-gray">
                                                {{ currencyFormat( $holeprice->discount_percent )}}% {{translation('PRODUCT_DISCOUNT')}}
                                            </small>
                                        </span>
                                    </div>
                                @endif
                                @break
                            @endforeach
                        </div>
                    @else
                        @if($product->discount_type != 'no')
                            <div class="text-gray-100 ">
                                <del>
                                    {{currencyFormat($product->max_sale_price) }}
                                </del>
                            </div>
                        @endif
                        <div class="text-gray-100">
                            {{ currencyFormat($product->sale_price ?? '0.00') }} 
                        </div>
                        @if($product->discount_type != 'no')
                            @if($product->discount_type == 'flat')
                                <div class="text-gray-100">
                                    <span class="ms-1">
                                        {{ currencyFormat( $product->discount_percent )}} {{translation('PRODUCT_DISCOUNT')}}
                                    </span>
                                </div>
                            @else
                                <div class="text-gray-100">
                                    <span class=" ms-1">
                                        {{ currencyFormat( $products->discount_amount )}}% {{translation('PRODUCT_DISCOUNT')}}
                                    </span>
                                </div>
                            @endif
                        @endif
                    @endif
                </div>
                <div class="flex-horizontal-center justify-content-between justify-content-wd-center flex-wrap">
                    @if (webFunctionStatus(config('constkey.is_wishlist_enabled')))
                    <a href="javascript:void(0);" onclick="addToWishListFromDetail({{ $product->product_id }})"
                        class="text-gray-6 font-size-13 mx-wd-3">
                        @if(in_array($product->product_id, $wishlistAry))
                        <i class="ec ec-favorites mr-1 font-size-15"></i>
                        @else
                        <i class="ec ec-favorites mr-1 font-size-15"></i>
                        @endif
                        {{translation('ADD_TO_WISHLIST')}}
                    </a>
                    @endif
                </div>
            </div>
        </div>
    </div>
</li>
@endif