<!-- Blog Grid Start Here-->
<div class="col-lg-4 mb-5">
  <article class="card border-0">
      <a href="{{ url('blog/'.$data->slug) }}" class="d-block"><img class="img-fluid" src="{{getFullImageUrl($data->img)}}"  onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
          alt="{{getSetting('site_title')}} Not-Found"></a>
      <div class="card-body pt-5 pb-0 px-0">
          <h4 class="mb-3"><a href="{{ url('blog/'.$data->slug) }}">{{ $data->post_title ?? ''}}</a></h4>
          <div class="mb-3 pb-3 border-bottom">
              <div class="list-group list-group-horizontal flex-wrap list-group-borderless align-items-center mx-n0dot5">
                  <a href="javascript:void(0)" class="mx-0dot5 text-gray-5"> {{translation('ADMIN')}}</a>
                  <span class="mx-2 font-size-n5 mt-1 text-gray-5"><i class="fas fa-circle"></i></span>
                  <a href="javascript:void(0)" class="mx-0dot5 text-gray-5">
                 @php
                   echo(date('F d, Y', strtotime($data->created_at ?? '')));
                 @endphp</a>
              </div>
          </div>
          <p style="height: 45px;">{{ $data->post_excerpt ?? ''}}</p>
          <div class="flex-horizontal-center">
              <a href="{{ url('blog/'.$data->slug) }}" class="btn btn-soft-secondary-w mb-md-0 font-weight-normal px-5 px-md-4 px-lg-5">{{translation('READ_MORE')}}</a>
          </div>
      </div>
  </article>
</div>

<!-- Blog Grid End Here-->

