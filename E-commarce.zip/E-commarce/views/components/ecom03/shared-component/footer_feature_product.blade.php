@php
use App\Models\Ecom\Services\EcomService;  
$count=count($featureGroupList);
if($count>0)
{
    $size=12/$count;
}
else {
    $size=12;
}
@endphp

@if (!empty($featureGroupList) && sizeof($featureGroupList) > 0 )
<div class="container d-none d-lg-block mb-3">
    <div class="row">
    @foreach($featureGroupList as $groupKey=>$featureGroup)
    @if(!empty($featureGroup->featured_product) && sizeof($featureGroup->featured_product) > 0 )
        <div class="col-wd-4 col-lg-{{$size}}">
            <div class="widget-column">
                <div class="border-bottom border-color-1 mb-5">
                    <h3 class="section-title section-title__sm mb-0 pb-2 font-size-16">
                       {{translation($featureGroup->group_name)}}
                    </h3>
                </div>
                <ul class="list-unstyled products-group">
                    @foreach ($featureGroup->featured_product->take(5) as $feature_product )
                    @if(!empty($feature_product->product))
                    <li class="product-item product-item__list row no-gutters mb-6 remove-divider">
                        <div class="col-auto">
                            <a href="{{ EcomService::url($feature_product->product->product_id , 'product')}}" class="d-block width-75 text-center"><img class="img-fluid" 
                                src="{{getFullImageUrl($feature_product->product->product_image)}}"
                                onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                                alt="{{$feature_product->product->products_name ?? ''}}"></a>
                        </div>
                        <div class="col pl-4 d-flex flex-column">
                            <h5 class="product-item__title mb-0"><a href="{{ EcomService::url($feature_product->product->product_id , 'product')}}" class="text-dark font-weight-bold">{{$feature_product->product->products_name ?? ''}}</a></h5>
                            <div class="prodcut-price mt-1">
                                <div class="font-size-14 font-weight-bold">
                                   @if($feature_product->product->discount_type != 'no')
                                    @if($feature_product->product->discount_type == 'flat')
                                        <div class="text-gray-100">{{ currencyFormat($product->sale_price+$product->discount_amount) }}
                                        </div>
                                        @else
                                        @php
                                            $discounAmount=($feature_product->product->sale_price)*$feature_product->product->discount_amount/100;
                                            $totalPrice=$feature_product->product->sale_price+$discounAmount;
                                        @endphp
                                            <div class="text-gray-100">
                                                {{ currencyFormat($totalPrice)}}
                                            </div>
                                    @endif
                                   @else
                                   {{ currencyFormat($feature_product->product->sale_price)}}
                                   @endif
                                </div>
                            </div>
                        </div>
                    </li>
                    @endif
                   @endforeach
                </ul>
            </div>
        </div>
    @endif
    @endforeach    
    </div>
</div>
@endif