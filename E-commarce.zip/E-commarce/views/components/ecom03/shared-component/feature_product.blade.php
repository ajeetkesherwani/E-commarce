@php
$avgrating=AvgRating($feature_product->product->product_id); 
use App\Models\Ecom\Services\EcomService;  
use App\Models\WishList;
$wishlistAry = WishList::getProductsAry();
@endphp

@if($viewtype == 'grid')
<div class="product-inner-item">
    <article class="list-product mb-30px">
        <div class="img-block text-center">
    
            <a href="{{ EcomService::url($feature_product->product->product_id , 'product')}}" class="thumbnail" >
                <img
                    class="first-img"
                    src="{{getFullImageUrl($feature_product->product->product_image)}}"
                    onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                    alt="{{$feature_product->product->products_name ?? ''}}"
                />
               <!--  <img
                    class="second-img"
                    src="{{getFullImageUrl($feature_product->product->product_image)}}"
                    alt=""
                /> -->
            </a>
            <div class="add-to-link">
                <ul>
                    @if (webFunctionStatus(config('constkey.is_cart_enabled')))
                        <li>
                            <a href="{{ url('product/'.$feature_product->product->product_slug) }}" title="View Details"
                                ><i class="ion-eye"></i
                            ></a>
                        </li>
                    @endif
                    @if (webFunctionStatus(config('constkey.is_wishlist_enabled'))) 
                     
                        <li>
                            
                            <a href="javascript:void(0);" onclick="addToWishListFromDetail({{ $feature_product->product->product_id }})" title="wishlist"
                                >
                                @if(in_array($feature_product->product->product_id, $wishlistAry))
                                <i class="ion-android-favorite-outline whishlist-active"></i>
                                @else
                                <i class="ion-android-favorite-outline"></i>
                                @endif
                            </a>
                        </li>
                    @endif
                    
                    <li>
                        <a  class="quick_view"
                            onclick="showfunction('{{ $feature_product->product->product_slug }}')" title="Quick View">
                            <i class="ion-ios-search-strong"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        
        <ul class="product-flag">
            <li class="new">
                {{ $feature_product->product->product_condition == 1 ? 'New' : 'Refurbished' }}
            </li>
        </ul>
        <div class="product-decs text-center">
            <a
                class="inner-link"
                href="{{ EcomService::url($feature_product->product->product_id , 'product')}}"
                ><span>{{ $feature_product->product->product_model ?? '' }}</span></a
            >
            <h2>
                <a
                    href="{{ EcomService::url($feature_product->product->product_id , 'product')}}"
                    class="product-link"
                    title="{{ $feature_product->product->products_name ?? '' }}"
                    >{{ sortStringName($feature_product->product->products_name ?? '') }}</a
                >
            </h2>
            <div class="rating-product">
                @if(!empty($avgrating))
                @for($i=0;$i<5;$i++)
                @if($i<$avgrating)
                <i class="ion-android-star"></i>
                @else
                <i class="ion-android-star-outline"></i>
                @endif
               @endfor
               @endif
            </div>
            <div class="pricing-meta">
                <ul>
                    @if($feature_product->product->discount_type != 'no')
                        @if($feature_product->product->discount_type == 'flat')
                        <li class="old-price">
                            {{ currencyFormat($feature_product->product->sale_price+$feature_product->product->discount_amount) }}
                        </li>
                        @else
                        @php
                        $discounAmount=($feature_product->product->sale_price)*$feature_product->product->discount_amount/100;
                        $totalPrice=$feature_product->product->sale_price+$discounAmount;
                        @endphp
                        <li class="old-price">
                            {{ currencyFormat($totalPrice)}}
                        </li>
                        @endif
                    @endif 
                    <li class="current-price">
                        {{ currencyFormat($feature_product->product->sale_price)}}
                    </li>
                    @if($feature_product->product->discount_type != 'no')
                    <li class="discount-price">
                        @if($feature_product->product->discount_type == 'flat')
                        {{ currencyFormat($feature_product->product->discount_amount) }} Off
                        @else
                        {{ currencyFormat( $feature_product->product->discount_amount )
                        }}%  Off
                        @endif
                    </li>
                    @endif
                </ul>
            </div>
        </div>
    </article>
</div>
@endif

@if($viewtype == 'list')

<div class="shop-list-wrap mb-30px scroll-zoom ">
    <div class="row list-product m-0px">
        <div class="col-md-12">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <div class="left-img">
                        <div class="img-block text-center">
                            <a
                                href="{{ EcomService::url($feature_product->product->product_id , 'product')}}"
                                class="thumbnail"
                            >
                                <img
                                    class="first-img"
                                    src="{{getFullImageUrl($feature_product->product->product_image)}}"
                                    onerror="this.onerror=null; this.src='{{asset(config('constkey.no_image'))}}'"
                                    alt="{{$feature_product->product->products_name ?? ''}}"
                                />
                                <!-- <img
                                    class="second-img"
                                    src="{{getFullImageUrl($feature_product->product->product_image)}}"
                                    alt=""
                                /> -->
                            </a>
                            <div class="quick-view">
                                <a
                                    class="quick_view"
                                    onclick="showfunction('{{ $feature_product->product->product_slug }}')"
                                    title="Quick View">
                                    <i class="ion-ios-search-strong"></i>
                                </a>
                            </div>
                        </div>
                        <ul class="product-flag">
                            <li class="new">
                                {{ $feature_product->product->product_condition == 1 ? 'New' : 'Refurbished' }}
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                    <div class="product-desc-wrap">
                        <div class="product-decs">
                            
                            <h2>
                                <a
                                    href="{{ EcomService::url($feature_product->product->product_id , 'product')}}"
                                    class="product-link"
                                >
                                    {{ $feature_product->product->products_name ?? '' }}
                                </a>
                            </h2>
                            <a
                                class="inner-link"
                                href="{{ EcomService::url($feature_product->product->product_id , 'product')}}"
                                ><span
                                    >{{ $feature_product->product->product_model ?? '' }}</span
                                ></a
                            >
                            <div class="rating-product">
                                @if(!empty($avgrating))
                                @for($i=0;$i<5;$i++)
                                @if($i<$avgrating)
                                <i class="ion-android-star"></i>
                                @else
                                <i class="ion-android-star-outline"></i>
                                @endif
                               @endfor
                               @endif
                                
                            </div>
                            <div class="pricing-meta">
                                <ul>
                                    <li class="old-price not-cut">
                                        {{ currencyFormat($feature_product->product->sale_price) }}
                                    </li>
                                </ul>
                            </div>
                           <div class="product-intro-info">
                            <p>{!! Str::limit( strip_tags($feature_product->product->products_description) ?? '',150) !!}</p>
                            
                           </div>
                            <div class="product-intro-info"> 
                            @foreach($feature_product->product->products_to_features as $featKey=>$featVal)
                             <p><span>{{$featVal->feature_title ?? ''}}: </span>{{$featVal->feature_value ?? ''}}</p>
                            @endforeach
                               
                           </div>
                           <!-- <div class="product-intro-info">
                                <p>
                                   {{ $feature_product->product->products_description ?? '' }} 
                                </p>
                                 <p>Comfortable cotton-blend fabrication.</p>
                                <p>
                                    Classic varsity jacket features brand
                                    details throughout.
                                </p>
                                <p>Flat knit collar.</p> 
                            </div> -->
                            <!-- <div class="in-stock">
                                Availability: <span> {{ $feature_product->product->stock_qty }}</span>
                            </div> -->
                        </div>
                        <div class="add-to-link">
                            <ul>
                               @auth
                                <li>
                                    <a href="javascript:void(0);" onclick="addToWishListFromDetail({{ $feature_product->product->product_id }})" title="Wishlist"
                                        >
                                        @if(in_array($feature_product->product->product_id, $wishlistAry))
                                        <i class="ion-android-favorite-outline whishlist-active"></i>
                                        @else
                                        <i class="ion-android-favorite-outline"></i>
                                        @endif
                                    </a>
                                </li>
                                @endauth
                                <li>
                                    <a href="{{ EcomService::url($feature_product->product->product_id , 'product')}}" title="View Details"
                                        ><i class="ion-eye"></i
                                    ></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endif 


