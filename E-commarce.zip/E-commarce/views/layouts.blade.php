<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">
        
        @yield('meta_info')
        <link rel="canonical" href="{{ url()->current() }}">
        <link rel="dns-prefetch" href="https://e-nnovation.net/"  />
        <x-styles />

        @stack('styles')
        
        {!! getSetting('web_additional_js') !!}
        {!! getSetting('web_additional_css') !!}
        
    </head>
    
    <body class="home-5 home-furniture">
    
        <div id="main">
            <x-header />
            {{ $slot }}
            <x-footer />        
        </div>

        <x-scripts />
        
        @stack('scripts')
    </body>
</html>
